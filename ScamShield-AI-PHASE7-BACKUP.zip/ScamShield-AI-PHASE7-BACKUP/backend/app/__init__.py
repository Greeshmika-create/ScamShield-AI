"""ScamShield AI - Enterprise Cybersecurity Backend Application Package."""

__version__ = "1.0.0"

