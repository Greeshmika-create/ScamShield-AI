"""Phase 4.1 URL Normalization and Canonicalization Engine for ScamShield AI.

Security & Architectural Mandates:
- Strictly passive: ZERO outbound HTTP/HTTPS requests, ZERO DNS queries, ZERO socket connections.
- Purely deterministic and local component parsing and canonicalization.
- Preserves raw submitted evidence in intended forensic fields without replacement.
- Credentials and userinfo are stripped from canonical URLs and masked in logging/serialization.
- Conforms strictly to RFC 3986, RFC 1035, RFC 5891 (IDNA2008), and WHATWG URL guidelines.
"""

import ipaddress
import re
from typing import Optional, Tuple
from urllib.parse import urlsplit, urlunsplit

import idna

from app.schemas.common import mask_url_credentials
from app.schemas.url_normalization import (
    NormalizedURLComponents,
    URLNormalizationResult,
)

# RFC 1035/1123 DNS Label pattern: 1-63 chars, alphanumeric with internal hyphens
HOSTNAME_LABEL_REGEX = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$")


class URLNormalizationError(ValueError):
    """Exception raised when URL normalization encounters invalid or unsafe syntax."""

    def __init__(self, message: str, error_code: str = "MALFORMED_URL_STRUCTURE"):
        clean_message = mask_url_credentials(str(message))
        super().__init__(clean_message)
        self.message = clean_message
        self.error_code = error_code


class URLNormalizer:
    """Deterministic, passive URL normalizer and canonicalizer."""

    MAX_URL_LENGTH: int = 2048
    MIN_URL_LENGTH: int = 4
    MAX_HOSTNAME_LENGTH: int = 253
    MAX_LABEL_LENGTH: int = 63
    ALLOWED_SCHEMES: set[str] = {"http", "https"}
    DEFAULT_PORTS: dict[str, int] = {"http": 80, "https": 443}

    @classmethod
    def validate_percent_encoding(cls, text: str) -> None:
        """Verify that all percent signs are followed by two valid hexadecimal characters.

        Conforms to RFC 3986 Section 2.1 without decoding characters that alter syntax.
        """
        idx = 0
        str_len = len(text)
        while True:
            pct_idx = text.find("%", idx)
            if pct_idx == -1:
                break
            if pct_idx + 2 >= str_len:
                raise URLNormalizationError(
                    "Invalid percent-encoding: incomplete escape sequence at end of string.",
                    error_code="INVALID_PERCENT_ENCODING",
                )
            hex_part = text[pct_idx + 1 : pct_idx + 3]
            if not all(c in "0123456789abcdefABCDEF" for c in hex_part):
                raise URLNormalizationError(
                    f"Invalid percent-encoding: sequence '%{hex_part}' is not valid hexadecimal.",
                    error_code="INVALID_PERCENT_ENCODING",
                )
            idx = pct_idx + 3

    @classmethod
    def normalize_hostname(
        cls, raw_host: str, netloc: str
    ) -> Tuple[str, str, bool, Optional[int], bool, bool]:
        """Normalize hostname, convert IDN to Punycode ASCII, and classify IP literals.

        Returns:
            (normalized_unicode_host, ascii_punycode_host, is_ip_literal, ip_version, is_idn, has_trailing_dot)
        """
        # 1. Check for IPv6 literal (must be enclosed in brackets in authority)
        if "[" in netloc or "]" in netloc:
            # Netloc must have properly balanced brackets
            if "[" not in netloc or "]" not in netloc:
                raise URLNormalizationError(
                    "Malformed IPv6 address literal: unbalanced brackets in authority.",
                    error_code="MALFORMED_IPV6",
                )
            # Extract bracket content
            bracket_match = re.search(r"\[([^\]]+)\]", netloc)
            if not bracket_match:
                raise URLNormalizationError(
                    "Malformed IPv6 address literal: invalid bracket syntax.",
                    error_code="MALFORMED_IPV6",
                )
            ipv6_candidate = bracket_match.group(1)
            try:
                ip_obj = ipaddress.IPv6Address(ipv6_candidate)
                normalized_ip = str(ip_obj)
                return normalized_ip, normalized_ip, True, 6, False, False
            except ValueError as e:
                raise URLNormalizationError(
                    f"Malformed IPv6 address literal '{ipv6_candidate}': {e}",
                    error_code="MALFORMED_IPV6",
                ) from e

        # 2. Check for IPv4 literal
        try:
            ip_obj = ipaddress.IPv4Address(raw_host)
            normalized_ip = str(ip_obj)
            return normalized_ip, normalized_ip, True, 4, False, False
        except ValueError:
            pass

        # 3. Domain Name Normalization (Standard ASCII or Internationalized IDN)
        has_trailing_dot = raw_host.endswith(".")
        cleaned_host = raw_host.rstrip(".")
        if not cleaned_host:
            raise URLNormalizationError(
                "URL hostname cannot be empty.",
                error_code="INVALID_HOSTNAME",
            )

        if len(cleaned_host) > cls.MAX_HOSTNAME_LENGTH:
            raise URLNormalizationError(
                f"Hostname exceeds maximum RFC 1035 length of {cls.MAX_HOSTNAME_LENGTH} characters.",
                error_code="INVALID_HOSTNAME",
            )

        # Internationalized domain handling via IDNA 2008 / UTS#46
        try:
            ascii_host = idna.encode(cleaned_host, uts46=True).decode("ascii").lower()
            unicode_host = idna.decode(ascii_host).lower()
        except idna.IDNAError as e:
            clean_e = mask_url_credentials(str(e))
            raise URLNormalizationError(
                f"Invalid internationalized domain name '{cleaned_host}': {clean_e}",
                error_code="IDNA_ENCODING_ERROR",
            ) from e
        except Exception as e:
            clean_e = mask_url_credentials(str(e))
            raise URLNormalizationError(
                f"Failed to normalize hostname '{cleaned_host}': {clean_e}",
                error_code="INVALID_HOSTNAME",
            ) from e

        # Validate DNS labels according to RFC 1035 rules
        labels = ascii_host.split(".")
        for label in labels:
            if not label:
                raise URLNormalizationError(
                    f"Malformed hostname '{cleaned_host}': contains empty label.",
                    error_code="INVALID_HOSTNAME",
                )
            if len(label) > cls.MAX_LABEL_LENGTH:
                raise URLNormalizationError(
                    f"Hostname label '{label}' exceeds maximum {cls.MAX_LABEL_LENGTH} characters.",
                    error_code="INVALID_HOSTNAME",
                )
            if not HOSTNAME_LABEL_REGEX.match(label):
                raise URLNormalizationError(
                    f"Hostname label '{label}' contains invalid characters or formatting.",
                    error_code="INVALID_HOSTNAME",
                )

        is_idn = (unicode_host != ascii_host) or ascii_host.startswith("xn--") or any(
            label.startswith("xn--") for label in labels
        )

        return unicode_host, ascii_host, False, None, is_idn, has_trailing_dot

    @classmethod
    def normalize(cls, raw_url: str, raise_on_error: bool = False) -> URLNormalizationResult:
        """Parse, validate, and normalize a URL into its authoritative canonical representation.

        Args:
            raw_url: Untrusted raw input string.
            raise_on_error: If True, raises URLNormalizationError on failure instead of returning invalid result.

        Returns:
            URLNormalizationResult containing the canonical URL and extracted components.
        """
        try:
            return cls._execute_normalization(raw_url)
        except URLNormalizationError as e:
            if raise_on_error:
                raise
            clean_msg = mask_url_credentials(e.message)
            return URLNormalizationResult(
                original_url=raw_url,
                canonical_url=None,
                is_valid=False,
                error_message=clean_msg,
                error_code=e.error_code,
                components=None,
            )
        except Exception as e:
            clean_msg = mask_url_credentials(str(e))
            if raise_on_error:
                raise URLNormalizationError(
                    f"Unexpected parsing failure: {clean_msg}", error_code="PARSER_ERROR"
                ) from e
            return URLNormalizationResult(
                original_url=raw_url,
                canonical_url=None,
                is_valid=False,
                error_message=f"Unexpected parsing failure: {clean_msg}",
                error_code="PARSER_ERROR",
                components=None,
            )

    @classmethod
    def _execute_normalization(cls, raw_url: str) -> URLNormalizationResult:
        """Internal deterministic normalization logic."""
        if not isinstance(raw_url, str):
            raise URLNormalizationError("URL input must be a string.", error_code="INVALID_INPUT_TYPE")

        trimmed = raw_url.strip()
        if not trimmed:
            raise URLNormalizationError("URL cannot be empty or whitespace-only.", error_code="EMPTY_INPUT")

        if len(trimmed) > cls.MAX_URL_LENGTH:
            raise URLNormalizationError(
                f"URL exceeds maximum permitted length of {cls.MAX_URL_LENGTH} characters.",
                error_code="EXCEEDS_MAX_LENGTH",
            )

        if len(trimmed) < cls.MIN_URL_LENGTH:
            raise URLNormalizationError("URL is too short to be a valid address.", error_code="INVALID_INPUT_FORMAT")

        # Reject ASCII control characters and unprintable chars
        if any(ord(c) < 32 or ord(c) == 127 for c in trimmed):
            raise URLNormalizationError("URL contains invalid control characters.", error_code="CONTROL_CHARACTERS")

        # Reject internal whitespace
        if any(c.isspace() for c in trimmed):
            raise URLNormalizationError("URL cannot contain internal whitespace.", error_code="INTERNAL_WHITESPACE")

        try:
            parsed = urlsplit(trimmed)
        except Exception as e:
            clean_e = mask_url_credentials(str(e))
            raise URLNormalizationError(f"Malformed URL structure: {clean_e}", error_code="MALFORMED_URL_STRUCTURE") from e

        # 1. Scheme Normalization
        raw_scheme = parsed.scheme
        if not raw_scheme:
            raise URLNormalizationError(
                "URL must specify an HTTP or HTTPS scheme (e.g. 'https://example.com').",
                error_code="MISSING_SCHEME",
            )

        scheme = raw_scheme.lower()
        if scheme not in cls.ALLOWED_SCHEMES:
            raise URLNormalizationError(
                f"Unsupported scheme '{scheme}'. Only HTTP and HTTPS protocols are accepted.",
                error_code="UNSUPPORTED_SCHEME",
            )

        # 2. Hostname / Authority Extraction
        if not parsed.netloc:
            raise URLNormalizationError("URL must contain a valid network authority.", error_code="MISSING_HOSTNAME")

        # Extract raw_hostname preserving original casing and trailing dot evidence
        authority = parsed.netloc
        if "@" in authority:
            authority = authority.rsplit("@", 1)[1]
        if "[" in authority and "]" in authority:
            raw_hostname = authority.split("]")[0] + "]"
        else:
            raw_hostname = authority.split(":")[0]

        if not raw_hostname or not parsed.hostname:
            raise URLNormalizationError("URL must contain a valid hostname or IP address.", error_code="MISSING_HOSTNAME")

        # 3. Userinfo / Embedded Credentials Detection
        has_credentials = bool(parsed.username or parsed.password)
        username = parsed.username if parsed.username else None

        # 4. Hostname Normalization & IDNA Handling
        unicode_host, ascii_host, is_ip_literal, ip_version, is_idn, has_trailing_dot = cls.normalize_hostname(
            raw_hostname, parsed.netloc
        )

        # 5. Port Validation and Default Normalization
        try:
            raw_port = parsed.port
        except ValueError as e:
            clean_e = mask_url_credentials(str(e))
            raise URLNormalizationError(
                f"URL specifies an invalid port number: {clean_e}",
                error_code="INVALID_PORT",
            ) from e

        canonical_port: Optional[int] = None
        if raw_port is not None:
            if raw_port < 1 or raw_port > 65535:
                raise URLNormalizationError(
                    "Port number must be an integer between 1 and 65535.",
                    error_code="INVALID_PORT",
                )
            default_port_for_scheme = cls.DEFAULT_PORTS.get(scheme)
            if raw_port != default_port_for_scheme:
                canonical_port = raw_port

        # 6. Validate Percent-Encoding Integrity
        cls.validate_percent_encoding(parsed.path)
        if parsed.query:
            cls.validate_percent_encoding(parsed.query)
        if parsed.fragment:
            cls.validate_percent_encoding(parsed.fragment)

        # 7. Path Normalization (Empty paths normalize to '/')
        normalized_path = parsed.path if parsed.path else "/"

        # 8. Reconstruct Canonical Network Location
        # RFC 3986 3.2.1: Deprecates cleartext userinfo and ensures credentials are
        # stripped from authoritative canonical URLs to prevent credential exposure.
        netloc_parts = []
        if is_ip_literal and ip_version == 6:
            netloc_parts.append(f"[{ascii_host}]")
        else:
            netloc_parts.append(ascii_host)

        if canonical_port is not None:
            netloc_parts.append(f":{canonical_port}")

        canonical_netloc = "".join(netloc_parts)

        # 9. Reconstruct Authoritative Canonical URL
        canonical_url = urlunsplit((
            scheme,
            canonical_netloc,
            normalized_path,
            parsed.query,
            parsed.fragment,
        ))

        components = NormalizedURLComponents(
            scheme=scheme,
            hostname=unicode_host,
            ascii_hostname=ascii_host,
            unicode_hostname=unicode_host,
            raw_hostname=raw_hostname,
            has_trailing_dot=has_trailing_dot,
            is_idn=is_idn,
            port=canonical_port,
            raw_port=raw_port,
            path=normalized_path,
            query=parsed.query if parsed.query else None,
            fragment=parsed.fragment if parsed.fragment else None,
            is_ip_literal=is_ip_literal,
            ip_version=ip_version,
            has_credentials=has_credentials,
            username=username,
            netloc=canonical_netloc,
        )

        return URLNormalizationResult(
            original_url=raw_url,
            canonical_url=canonical_url,
            is_valid=True,
            error_message=None,
            error_code=None,
            components=components,
        )


def normalize_url(raw_url: str, raise_on_error: bool = False) -> URLNormalizationResult:
    """Convenience function for normalizing and canonicalizing a URL string."""
    return URLNormalizer.normalize(raw_url, raise_on_error=raise_on_error)
