"""Phase 6 ML Model Artifact Manager and Integrity Validator for ScamShield AI.

Security & Architectural Mandates:
- Strictly passive: loads only trusted application-controlled artifacts from disk.
- Never accepts model artifacts or checksums from untrusted users or external networks.
- Enforces SHA-256 cryptographic checksum validation before loading.
- Documents that checksum verification guards against corruption or tampering when the
  expected checksum is controlled by the application code, but cannot prevent replacement
  if the entire host filesystem is compromised.
- Enforces 32-feature schema compatibility check against URL_FEATURE_NAMES.
- Rejects corrupted, mismatched, or missing artifacts with safe status codes (never raises 500s).
- Uses safe structured JSON representation (no insecure pickle deserialization).
"""

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Union

from app.services.scanners.url_extractor import URL_FEATURE_NAMES


@dataclass(frozen=True)
class ArtifactLoadResult:
    """Outcome of a model artifact loading and integrity verification attempt."""

    is_loaded: bool
    status: str  # "LOADED", "MODEL_NOT_FOUND", "CHECKSUM_MISMATCH", "SCHEMA_MISMATCH", "PARSE_ERROR"
    model_id: Optional[str] = None
    model_version: Optional[str] = None
    model_type: Optional[str] = None
    model_data: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary representation."""
        return {
            "is_loaded": self.is_loaded,
            "status": self.status,
            "model_id": self.model_id,
            "model_version": self.model_version,
            "model_type": self.model_type,
            "error_message": self.error_message,
        }


class MLArtifactLoader:
    """Safe loader for application-controlled ML model artifacts."""

    EXPECTED_FEATURE_COUNT: int = 32
    EXPECTED_FEATURES: Set[str] = set(URL_FEATURE_NAMES)

    @classmethod
    def get_default_artifacts_dir(cls) -> Path:
        """Resolve the default trusted application artifact directory."""
        # Relative to project root
        project_root = Path(__file__).resolve().parent.parent.parent.parent.parent
        return project_root / "ml" / "models" / "artifacts"

    @classmethod
    def load_artifact(
        cls,
        artifacts_dir: Optional[Union[str, Path]] = None,
        metadata_filename: str = "metadata.json",
    ) -> ArtifactLoadResult:
        """Load and cryptographically verify model artifact against signed metadata.

        Args:
            artifacts_dir: Directory containing model artifact and metadata manifest.
            metadata_filename: Filename of the metadata manifest.

        Returns:
            ArtifactLoadResult indicating whether model was safely verified and loaded.
        """
        dir_path = Path(artifacts_dir) if artifacts_dir else cls.get_default_artifacts_dir()

        # 1. Verify directory exists
        if not dir_path.is_dir():
            return ArtifactLoadResult(
                is_loaded=False,
                status="MODEL_NOT_FOUND",
                error_message=f"Model artifacts directory not found: {dir_path}",
            )

        # 2. Verify metadata manifest exists
        metadata_path = dir_path / metadata_filename
        if not metadata_path.is_file():
            return ArtifactLoadResult(
                is_loaded=False,
                status="MODEL_NOT_FOUND",
                error_message=f"Model metadata manifest not found: {metadata_path}",
            )

        # 3. Parse metadata manifest safely
        try:
            with open(metadata_path, "r", encoding="utf-8") as f:
                metadata = json.load(f)
        except Exception as e:
            return ArtifactLoadResult(
                is_loaded=False,
                status="PARSE_ERROR",
                error_message=f"Failed to parse metadata manifest: {e}",
            )

        artifact_filename = metadata.get("artifact_filename")
        expected_sha256 = metadata.get("sha256_checksum", "").strip().lower()
        model_id = metadata.get("model_id", "unknown_model")
        model_version = metadata.get("model_version", "1.0.0")
        model_type = metadata.get("model_type", "HEURISTIC_BASELINE")

        if not artifact_filename or not expected_sha256:
            return ArtifactLoadResult(
                is_loaded=False,
                status="SCHEMA_MISMATCH",
                model_id=model_id,
                error_message="Metadata manifest missing required artifact_filename or sha256_checksum fields.",
            )

        artifact_path = dir_path / artifact_filename
        if not artifact_path.is_file():
            return ArtifactLoadResult(
                is_loaded=False,
                status="MODEL_NOT_FOUND",
                model_id=model_id,
                error_message=f"Referenced model artifact file not found: {artifact_path}",
            )

        # 4. Compute and verify SHA-256 integrity checksum
        try:
            with open(artifact_path, "rb") as f:
                raw_bytes = f.read()
            computed_sha256 = hashlib.sha256(raw_bytes).hexdigest().lower()
        except Exception as e:
            return ArtifactLoadResult(
                is_loaded=False,
                status="PARSE_ERROR",
                model_id=model_id,
                error_message=f"Failed to read model artifact file for checksum verification: {e}",
            )

        if computed_sha256 != expected_sha256:
            return ArtifactLoadResult(
                is_loaded=False,
                status="CHECKSUM_MISMATCH",
                model_id=model_id,
                error_message=(
                    f"Cryptographic checksum mismatch for artifact '{artifact_filename}'. "
                    f"Expected: {expected_sha256}, Computed: {computed_sha256}. "
                    "Artifact may be corrupted or modified."
                ),
            )

        # 5. Parse model artifact JSON safely
        try:
            model_data = json.loads(raw_bytes.decode("utf-8"))
        except Exception as e:
            return ArtifactLoadResult(
                is_loaded=False,
                status="PARSE_ERROR",
                model_id=model_id,
                error_message=f"Failed to parse model artifact JSON: {e}",
            )

        # 6. Verify 32-feature schema compatibility
        artifact_features = model_data.get("features", [])
        if len(artifact_features) != cls.EXPECTED_FEATURE_COUNT:
            return ArtifactLoadResult(
                is_loaded=False,
                status="SCHEMA_MISMATCH",
                model_id=model_id,
                error_message=(
                    f"Feature count mismatch: model contains {len(artifact_features)} features, "
                    f"expected {cls.EXPECTED_FEATURE_COUNT}."
                ),
            )

        missing_features = cls.EXPECTED_FEATURES - set(artifact_features)
        if missing_features:
            return ArtifactLoadResult(
                is_loaded=False,
                status="SCHEMA_MISMATCH",
                model_id=model_id,
                error_message=f"Model artifact missing required features: {sorted(list(missing_features))[:5]}...",
            )

        weights = model_data.get("weights", {})
        if not isinstance(weights, dict) or not weights:
            return ArtifactLoadResult(
                is_loaded=False,
                status="SCHEMA_MISMATCH",
                model_id=model_id,
                error_message="Model artifact missing valid weights dictionary.",
            )

        return ArtifactLoadResult(
            is_loaded=True,
            status="LOADED",
            model_id=model_id,
            model_version=model_version,
            model_type=model_type,
            model_data=model_data,
            metadata=metadata,
            error_message=None,
        )

