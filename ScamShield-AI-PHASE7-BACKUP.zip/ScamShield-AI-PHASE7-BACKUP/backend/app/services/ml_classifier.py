"""Phase 6 Machine Learning URL Classifier Inference Service for ScamShield AI.

Security & Architectural Mandates:
- Strictly passive: evaluates static 32-feature lexical and structural representations.
- ZERO outbound HTTP/HTTPS requests, ZERO DNS queries, ZERO socket connections.
- Consumes URLFeatures from Phase 4.2 URLFeatureExtractor.
- Validates model artifact integrity (SHA-256) via MLArtifactLoader.
- Honest provenance disclosure: marks heuristic reference baseline models appropriately.
- Safe fallback: if model is missing, corrupt, or unexecuted, returns strictly null probability
  and UNAVAILABLE status without ever inventing a false clean (benign) verdict.
- Compliant with app.schemas.ml_analysis (URLMLAnalysis, MLFeatureImpact).
- Does not declare final safety: ML inference is strictly one corroborating evidence source.
"""

import math
from functools import lru_cache
from typing import Any, Dict, List, Optional, Union

from app.schemas.ml_analysis import MLFeatureImpact, URLMLAnalysis
from app.schemas.url_normalization import NormalizedURLComponents, URLNormalizationResult
from app.services.ml.artifact_manager import ArtifactLoadResult, MLArtifactLoader
from app.services.scanners.url_extractor import (
    URL_FEATURE_NAMES,
    URLFeatureExtractor,
    URLFeatures,
)


class URLClassifierService:
    """Asynchronous/synchronous inference service for lexical URL classification."""

    def __init__(self, artifact_loader_result: Optional[ArtifactLoadResult] = None):
        # Allow injecting pre-loaded/mocked artifact result for unit tests
        self._artifact_result = artifact_loader_result or MLArtifactLoader.load_artifact()

    @property
    def is_available(self) -> bool:
        """True if a valid, verified model artifact is successfully loaded in memory."""
        return self._artifact_result.is_loaded

    @property
    def model_id(self) -> Optional[str]:
        return self._artifact_result.model_id

    @property
    def model_version(self) -> Optional[str]:
        return self._artifact_result.model_version

    @property
    def model_type(self) -> Optional[str]:
        return self._artifact_result.model_type

    def predict_from_features(self, features: URLFeatures) -> URLMLAnalysis:
        """Execute deterministic inference over extracted 32 URL features.

        Args:
            features: Validated URLFeatures instance.

        Returns:
            URLMLAnalysis conforming to API schema.
        """
        # 1. Fallback Path: Model Artifact Missing / Corrupted / Unverified
        if not self.is_available:
            return URLMLAnalysis(
                model_id=self.model_id,
                prediction=None,
                threat_probability=None,  # Strictly null per schema contract
                top_contributing_features=None,
                evaluation_metadata={
                    "status": "UNAVAILABLE",
                    "reason": self._artifact_result.error_message or "Model artifact is not loaded.",
                    "model_status": self._artifact_result.status,
                },
            )

        try:
            model_data = self._artifact_result.model_data or {}
            weights: Dict[str, float] = model_data.get("weights", {})
            intercept: float = float(model_data.get("intercept", 0.0))
            thresholds: Dict[str, float] = model_data.get("decision_thresholds", {})
            malicious_threshold: float = float(thresholds.get("malicious_threshold", 0.85))
            suspicious_threshold: float = float(thresholds.get("suspicious_threshold", 0.45))

            feature_dict = features.to_dict()

            # 2. Linear projection: z = w0 + sum(wi * xi)
            z = intercept
            contributions: List[tuple[str, float, float]] = []

            for feat_name, weight in weights.items():
                val = float(feature_dict.get(feat_name, 0.0))
                term = weight * val
                z += term
                if abs(term) > 0.001:
                    contributions.append((feat_name, val, term))

            # 3. Sigmoid activation: P(Threat) = 1 / (1 + exp(-z))
            # Bound z to avoid numerical overflow in extreme cases
            bounded_z = max(-20.0, min(20.0, z))
            threat_prob = 1.0 / (1.0 + math.exp(-bounded_z))
            threat_prob = round(threat_prob, 4)

            # 4. Categorical Label Assignment
            # Supports BENIGN, SUSPICIOUS, PHISHING, and MALICIOUS consistently
            if threat_prob >= malicious_threshold:
                if features.has_ip_address > 0:
                    prediction = "MALICIOUS"
                elif (
                    features.has_banking_keyword > 0
                    or features.has_kyc_keyword > 0
                    or features.has_login_keyword > 0
                    or features.has_upi_keyword > 0
                ):
                    prediction = "PHISHING"
                else:
                    prediction = "MALICIOUS"
            elif threat_prob >= suspicious_threshold:
                prediction = "SUSPICIOUS"
            else:
                prediction = "BENIGN"

            # 5. Extract explainable top contributing risk features
            # Sort positive contributors by weighted impact
            positive_contributors = sorted(
                [c for c in contributions if c[2] > 0],
                key=lambda item: item[2],
                reverse=True,
            )

            top_impacts: List[MLFeatureImpact] = []
            for feat, val, _ in positive_contributors[:5]:
                top_impacts.append(
                    MLFeatureImpact(
                        feature=feat,
                        value=float(val),
                        impact="POSITIVE_RISK",
                    )
                )

            # Fallback to general impact generator if few positive contributors
            if not top_impacts:
                top_impacts = URLFeatureExtractor.to_ml_feature_impacts(features, top_n=3)

            return URLMLAnalysis(
                model_id=self.model_id,
                prediction=prediction,
                threat_probability=threat_prob,
                top_contributing_features=top_impacts,
                evaluation_metadata={
                    "status": "INFERRED",
                    "model_type": self.model_type,
                    "model_version": self.model_version,
                    "provenance": model_data.get("model_type", "HEURISTIC_BASELINE"),
                    "training_status": model_data.get("training_status", "BLOCKED_PENDING_VERIFIED_DATASET"),
                    "raw_activation_z": round(z, 4),
                    "active_features_count": len(contributions),
                },
            )

        except Exception as e:
            # Traps any inference error safely without exposing internal stack traces
            return URLMLAnalysis(
                model_id=self.model_id,
                prediction=None,
                threat_probability=None,
                top_contributing_features=None,
                evaluation_metadata={
                    "status": "ERROR",
                    "error_type": type(e).__name__,
                    "error_message": "Inference computation encountered an unexpected error.",
                },
            )

    def predict_target(
        self, target: Union[str, NormalizedURLComponents, URLNormalizationResult, URLFeatures]
    ) -> URLMLAnalysis:
        """Extract features and perform inference across any standard target representation."""
        if isinstance(target, URLFeatures):
            return self.predict_from_features(target)

        try:
            features = URLFeatureExtractor.extract(target)
            return self.predict_from_features(features)
        except Exception as e:
            return URLMLAnalysis(
                model_id=self.model_id,
                prediction=None,
                threat_probability=None,
                top_contributing_features=None,
                evaluation_metadata={
                    "status": "EXTRACTION_FAILURE",
                    "error_message": f"Feature extraction failed: {e}",
                },
            )


@lru_cache(maxsize=1)
def get_url_classifier() -> URLClassifierService:
    """Reuse one verified artifact load across URL scans."""
    return URLClassifierService()


def clear_url_classifier_cache() -> None:
    """Clear the cached classifier for tests or artifact reload events."""
    get_url_classifier.cache_clear()

