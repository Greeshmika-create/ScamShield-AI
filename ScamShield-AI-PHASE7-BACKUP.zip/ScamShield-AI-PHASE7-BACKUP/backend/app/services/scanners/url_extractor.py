"""Phase 4.2 URL Lexical and Structural Feature Extractor for ScamShield AI.

Security & Architectural Mandates:
- Strictly passive: ZERO outbound HTTP/HTTPS requests, ZERO DNS queries, ZERO socket connections.
- Purely deterministic and in-memory feature computation (<2ms execution budget).
- Computes the exact 32 features specified in docs/ARCHITECTURE.md Section 4.2.
- Consumes NormalizedURLComponents from Phase 4.1 URLNormalizer.
- Compatible with app.schemas.ml_analysis (URLMLAnalysis, MLFeatureImpact).
"""

from dataclasses import asdict, dataclass
import math
from typing import Any, Dict, List, Optional, Tuple, Union
from urllib.parse import parse_qsl

from app.schemas.ml_analysis import MLFeatureImpact
from app.schemas.url_normalization import NormalizedURLComponents, URLNormalizationResult
from app.services.url_normalizer import normalize_url


# The 32 standard feature names in deterministic canonical order
URL_FEATURE_NAMES: Tuple[str, ...] = (
    # 1-4: Length metrics (4)
    "url_length",
    "hostname_length",
    "path_length",
    "query_length",
    # 5-13: Character frequencies (9)
    "count_dot",
    "count_hyphen",
    "count_underscore",
    "count_slash",
    "count_question",
    "count_equal",
    "count_at",
    "count_ampersand",
    "count_percent",
    # 14-15: Domain hierarchy (2)
    "subdomain_count",
    "domain_depth",
    # 16: Statistical entropy (1)
    "domain_entropy",
    # 17-23: Suspicious token flags (7)
    "has_login_keyword",
    "has_verify_keyword",
    "has_account_keyword",
    "has_banking_keyword",
    "has_kyc_keyword",
    "has_upi_keyword",
    "has_support_keyword",
    # 24-26: Structural flags (3)
    "has_ip_address",
    "is_punycode",
    "has_non_standard_port",
    # 27-32: Lexical composition & ratios (6)
    "digit_count",
    "digit_ratio",
    "letter_count",
    "path_depth",
    "query_param_count",
    "suspicious_token_count",
)

assert len(URL_FEATURE_NAMES) == 32, "Feature specification must contain exactly 32 features."


@dataclass(frozen=True)
class URLFeatures:
    """Deterministic 32-feature extraction representation for lexical/structural URL analysis."""

    # 1-4: Length metrics
    url_length: int
    hostname_length: int
    path_length: int
    query_length: int

    # 5-13: Character frequencies
    count_dot: int
    count_hyphen: int
    count_underscore: int
    count_slash: int
    count_question: int
    count_equal: int
    count_at: int
    count_ampersand: int
    count_percent: int

    # 14-15: Domain hierarchy
    subdomain_count: int
    domain_depth: int

    # 16: Statistical entropy
    domain_entropy: float

    # 17-23: Suspicious token flags (1.0 or 0.0)
    has_login_keyword: float
    has_verify_keyword: float
    has_account_keyword: float
    has_banking_keyword: float
    has_kyc_keyword: float
    has_upi_keyword: float
    has_support_keyword: float

    # 24-26: Structural flags (1.0 or 0.0)
    has_ip_address: float
    is_punycode: float
    has_non_standard_port: float

    # 27-32: Lexical composition & ratios
    digit_count: int
    digit_ratio: float
    letter_count: int
    path_depth: int
    query_param_count: int
    suspicious_token_count: int

    def to_dict(self) -> Dict[str, Union[int, float]]:
        """Return feature dictionary with exactly 32 features."""
        d = asdict(self)
        assert len(d) == 32, f"Expected 32 features, got {len(d)}"
        return d

    def to_vector(self) -> List[float]:
        """Return canonical ordered float vector matching URL_FEATURE_NAMES."""
        d = self.to_dict()
        return [float(d[name]) for name in URL_FEATURE_NAMES]


class URLFeatureExtractor:
    """Passive, deterministic feature extractor for URL lexical and structural analysis."""

    # Keyword patterns matching Architecture Section 4.2
    SUSPICIOUS_KEYWORD_PATTERNS: Dict[str, Tuple[str, ...]] = {
        "has_login_keyword": ("login", "signin", "sign-in", "log-in", "auth", "authenticate"),
        "has_verify_keyword": ("verify", "verification", "confirm", "validation", "secure"),
        "has_account_keyword": ("account", "profile", "wallet", "userinfo", "credential"),
        "has_banking_keyword": ("bank", "banking", "netbanking", "sbi", "hdfc", "icici", "axis", "kotak"),
        "has_kyc_keyword": ("kyc", "aadhaar", "pan-card", "pancard", "update-kyc", "kycupdate"),
        "has_upi_keyword": ("upi", "vpa", "paytm", "phonepe", "gpay", "bhim", "refund"),
        "has_support_keyword": ("support", "helpdesk", "customer-care", "customercare", "service-desk"),
    }

    @staticmethod
    def calculate_shannon_entropy(text: str) -> float:
        """Calculate Shannon entropy H(X) = -sum(P(x) * log2(P(x))) of a string.

        High entropy indicates random/algorithmically generated domain names (DGA).
        """
        if not text:
            return 0.0

        length = len(text)
        freq: Dict[str, int] = {}
        for char in text:
            freq[char] = freq.get(char, 0) + 1

        entropy = 0.0
        for count in freq.values():
            prob = count / length
            entropy -= prob * math.log2(prob)

        return round(entropy, 4)

    @classmethod
    def extract_from_components(
        cls, components: NormalizedURLComponents, canonical_url: Optional[str] = None
    ) -> URLFeatures:
        """Extract all 32 lexical and structural features from NormalizedURLComponents."""
        # Canonical URL string
        if canonical_url:
            url_str = canonical_url
        else:
            url_str = f"{components.scheme}://{components.netloc}{components.path}"
            if components.query:
                url_str = f"{url_str}?{components.query}"
            if components.fragment:
                url_str = f"{url_str}#{components.fragment}"

        hostname = components.ascii_hostname.lower().rstrip(".")
        path = components.path or "/"
        query = components.query or ""

        # 1-4: Length metrics
        url_len = len(url_str)
        host_len = len(hostname)
        path_len = len(path)
        query_len = len(query)

        # 5-13: Character frequencies (counted across full canonical URL string)
        c_dot = url_str.count(".")
        c_hyphen = url_str.count("-")
        c_underscore = url_str.count("_")
        c_slash = url_str.count("/")
        c_question = url_str.count("?")
        c_equal = url_str.count("=")
        c_at = url_str.count("@")
        c_ampersand = url_str.count("&")
        c_percent = url_str.count("%")

        # 14-15: Domain hierarchy
        if components.is_ip_literal:
            subdomain_count = 0
            domain_depth = 1
        else:
            labels = [lbl for lbl in hostname.split(".") if lbl]
            domain_depth = len(labels)
            # Standard subdomains: labels beyond effective second-level or 2 labels
            subdomain_count = max(0, domain_depth - 2)

        # 16: Shannon entropy of domain string
        domain_entropy = cls.calculate_shannon_entropy(hostname)

        # 17-23: Suspicious token flags
        # Search lowercased hostname, path, and query
        searchable_text = f"{hostname} {path} {query}".lower()

        token_flags: Dict[str, float] = {}
        total_suspicious_matches = 0

        for feature_key, keywords in cls.SUSPICIOUS_KEYWORD_PATTERNS.items():
            matched = False
            for kw in keywords:
                if kw in searchable_text:
                    matched = True
                    total_suspicious_matches += 1
            token_flags[feature_key] = 1.0 if matched else 0.0

        # 24-26: Structural flags
        has_ip = 1.0 if components.is_ip_literal else 0.0
        is_puny = 1.0 if components.is_idn or "xn--" in hostname else 0.0
        has_non_std_port = 1.0 if components.port is not None else 0.0

        # 27-32: Lexical composition & ratios
        digit_count = sum(1 for c in url_str if c.isdigit())
        digit_ratio = round(digit_count / max(1, url_len), 4)
        letter_count = sum(1 for c in url_str if c.isalpha())

        path_segments = [s for s in path.strip("/").split("/") if s]
        path_depth = len(path_segments)

        query_param_count = len(parse_qsl(query, keep_blank_values=True)) if query else 0

        return URLFeatures(
            url_length=url_len,
            hostname_length=host_len,
            path_length=path_len,
            query_length=query_len,
            count_dot=c_dot,
            count_hyphen=c_hyphen,
            count_underscore=c_underscore,
            count_slash=c_slash,
            count_question=c_question,
            count_equal=c_equal,
            count_at=c_at,
            count_ampersand=c_ampersand,
            count_percent=c_percent,
            subdomain_count=subdomain_count,
            domain_depth=domain_depth,
            domain_entropy=domain_entropy,
            has_login_keyword=token_flags["has_login_keyword"],
            has_verify_keyword=token_flags["has_verify_keyword"],
            has_account_keyword=token_flags["has_account_keyword"],
            has_banking_keyword=token_flags["has_banking_keyword"],
            has_kyc_keyword=token_flags["has_kyc_keyword"],
            has_upi_keyword=token_flags["has_upi_keyword"],
            has_support_keyword=token_flags["has_support_keyword"],
            has_ip_address=has_ip,
            is_punycode=is_puny,
            has_non_standard_port=has_non_std_port,
            digit_count=digit_count,
            digit_ratio=digit_ratio,
            letter_count=letter_count,
            path_depth=path_depth,
            query_param_count=query_param_count,
            suspicious_token_count=total_suspicious_matches,
        )

    @classmethod
    def extract(
        cls, target: Union[str, NormalizedURLComponents, URLNormalizationResult]
    ) -> URLFeatures:
        """Extract 32 features from URL string, NormalizedURLComponents, or URLNormalizationResult."""
        if isinstance(target, NormalizedURLComponents):
            return cls.extract_from_components(target)

        if isinstance(target, URLNormalizationResult):
            if not target.is_valid or target.components is None:
                raise ValueError(f"Cannot extract features from invalid URL: {target.error_message}")
            return cls.extract_from_components(target.components, target.canonical_url)

        if isinstance(target, str):
            norm = normalize_url(target, raise_on_error=True)
            if not norm.is_valid or norm.components is None:
                raise ValueError(f"Normalization failed: {norm.error_message}")
            return cls.extract_from_components(norm.components, norm.canonical_url)

        raise TypeError(f"Unsupported target type for feature extraction: {type(target).__name__}")

    @classmethod
    def to_ml_feature_impacts(
        cls, features: URLFeatures, top_n: int = 5
    ) -> List[MLFeatureImpact]:
        """Convert highest-risk extracted features into explainable MLFeatureImpact objects.

        Prioritizes structural flags and suspicious keyword detections.
        """
        impacts: List[MLFeatureImpact] = []

        # High priority indicators
        if features.has_ip_address > 0:
            impacts.append(
                MLFeatureImpact(feature="has_ip_address", value=1.0, impact="POSITIVE_RISK")
            )
        if features.is_punycode > 0:
            impacts.append(
                MLFeatureImpact(feature="is_punycode", value=1.0, impact="POSITIVE_RISK")
            )
        if features.has_non_standard_port > 0:
            impacts.append(
                MLFeatureImpact(feature="has_non_standard_port", value=1.0, impact="POSITIVE_RISK")
            )
        if features.suspicious_token_count > 0:
            impacts.append(
                MLFeatureImpact(
                    feature="suspicious_token_count",
                    value=float(features.suspicious_token_count),
                    impact="POSITIVE_RISK",
                )
            )
        if features.domain_entropy >= 3.6:
            impacts.append(
                MLFeatureImpact(
                    feature="high_domain_entropy",
                    value=features.domain_entropy,
                    impact="POSITIVE_RISK",
                )
            )
        if features.subdomain_count >= 3:
            impacts.append(
                MLFeatureImpact(
                    feature="deep_subdomain_hierarchy",
                    value=float(features.subdomain_count),
                    impact="POSITIVE_RISK",
                )
            )
        if features.count_at > 0:
            impacts.append(
                MLFeatureImpact(
                    feature="contains_at_symbol",
                    value=float(features.count_at),
                    impact="POSITIVE_RISK",
                )
            )
        if features.digit_ratio >= 0.25:
            impacts.append(
                MLFeatureImpact(
                    feature="high_digit_ratio",
                    value=features.digit_ratio,
                    impact="POSITIVE_RISK",
                )
            )

        # If benign or few flags, provide baseline neutral telemetry
        if not impacts:
            impacts.append(
                MLFeatureImpact(
                    feature="domain_entropy",
                    value=features.domain_entropy,
                    impact="NEUTRAL",
                )
            )
            impacts.append(
                MLFeatureImpact(
                    feature="url_length",
                    value=float(features.url_length),
                    impact="NEUTRAL",
                )
            )

        return impacts[:top_n]
