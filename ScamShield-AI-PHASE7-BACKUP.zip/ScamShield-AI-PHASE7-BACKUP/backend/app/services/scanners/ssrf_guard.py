"""Phase 4.2 Static SSRF Guard and Target Validator for ScamShield AI.

Security & Architectural Mandates:
- Strictly passive: ZERO outbound HTTP/HTTPS requests, ZERO DNS queries, ZERO socket connections.
- Purely deterministic static validation of normalized URL hosts and IP literals.
- Blocks RFC 1918 private IPv4, IPv6 loopback / ULA, link-local, cloud metadata (169.254.169.254),
  CGNAT (100.64.0.0/10), broadcast, multicast, and loopback hostnames.
- Handles IPv4-mapped IPv6 (::ffff:x.x.x.x) and 6to4 encapsulation statically.
- Conforms to docs/THREAT_MODEL.md Section 3.1 and docs/ARCHITECTURE.md Section 2.
"""

from dataclasses import dataclass
import ipaddress
import re
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from urllib.parse import urlsplit

from app.core.errors import SSRFRejectedException
from app.schemas.url_normalization import NormalizedURLComponents, URLNormalizationResult


@dataclass(frozen=True)
class SSRFCheckResult:
    """Outcome of a static SSRF and target boundary evaluation."""

    is_safe: bool
    target: str
    host: str
    ip_address: Optional[str] = None
    is_ip: bool = False
    blocked_reason: Optional[str] = None
    matched_rule: Optional[str] = None
    matched_cidr: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary representation."""
        return {
            "is_safe": self.is_safe,
            "target": self.target,
            "host": self.host,
            "ip_address": self.ip_address,
            "is_ip": self.is_ip,
            "blocked_reason": self.blocked_reason,
            "matched_rule": self.matched_rule,
            "matched_cidr": self.matched_cidr,
        }


class SSRFGuard:
    """Static, passive target validator and SSRF firewall.

    Evaluates URL targets without resolving DNS or establishing socket connections.
    """

    # Static prohibited hostnames (case-insensitive)
    BLOCKED_HOSTNAMES: Set[str] = {
        "localhost",
        "localhost.localdomain",
        "ip6-localhost",
        "ip6-loopback",
    }

    # Prohibited domain suffixes for non-public / internal hostnames
    BLOCKED_SUFFIXES: Tuple[str, ...] = (
        ".localhost",
        ".local",
        ".internal",
        ".lan",
        ".home",
        ".corp",
        ".test",
        ".example",
        ".invalid",
    )

    # Allowed URL schemes
    ALLOWED_SCHEMES: Set[str] = {"http", "https"}

    # Prohibited IPv4 CIDR blocks (RFC standards)
    PROHIBITED_IPV4_NETWORKS: List[Tuple[ipaddress.IPv4Network, str, str]] = [
        (ipaddress.IPv4Network("0.0.0.0/8"), "THIS_HOST_NETWORK", "RFC 791 Current network / 'This host'"),
        (ipaddress.IPv4Network("10.0.0.0/8"), "PRIVATE_RFC1918_10", "RFC 1918 Private class A network"),
        (ipaddress.IPv4Network("100.64.0.0/10"), "CARRIER_GRADE_NAT", "RFC 6598 Shared Address Space / CGNAT"),
        (ipaddress.IPv4Network("127.0.0.0/8"), "LOOPBACK_IPV4", "RFC 1122 Loopback network"),
        (ipaddress.IPv4Network("169.254.0.0/16"), "LINK_LOCAL_METADATA", "RFC 3927 Link-local / Cloud metadata endpoint"),
        (ipaddress.IPv4Network("172.16.0.0/12"), "PRIVATE_RFC1918_172", "RFC 1918 Private class B network"),
        (ipaddress.IPv4Network("192.0.0.0/24"), "IETF_PROTOCOL_ASSIGNMENTS", "RFC 6890 IETF Protocol Assignments"),
        (ipaddress.IPv4Network("192.0.2.0/24"), "TEST_NET_1", "RFC 5737 Documentation TEST-NET-1"),
        (ipaddress.IPv4Network("192.168.0.0/16"), "PRIVATE_RFC1918_192", "RFC 1918 Private class C network"),
        (ipaddress.IPv4Network("198.18.0.0/15"), "BENCHMARK_NETWORK", "RFC 2544 Benchmarking network"),
        (ipaddress.IPv4Network("198.51.100.0/24"), "TEST_NET_2", "RFC 5737 Documentation TEST-NET-2"),
        (ipaddress.IPv4Network("203.0.113.0/24"), "TEST_NET_3", "RFC 5737 Documentation TEST-NET-3"),
        (ipaddress.IPv4Network("224.0.0.0/4"), "MULTICAST_IPV4", "RFC 5771 Multicast network"),
        (ipaddress.IPv4Network("255.255.255.255/32"), "BROADCAST_IPV4", "RFC 919 Limited broadcast address"),
        (ipaddress.IPv4Network("240.0.0.0/4"), "RESERVED_FUTURE_USE", "RFC 1112 Reserved for future use"),
    ]

    # Prohibited IPv6 CIDR blocks (RFC standards)
    PROHIBITED_IPV6_NETWORKS: List[Tuple[ipaddress.IPv6Network, str, str]] = [
        (ipaddress.IPv6Network("::/128"), "UNSPECIFIED_IPV6", "RFC 4291 Unspecified address"),
        (ipaddress.IPv6Network("::1/128"), "LOOPBACK_IPV6", "RFC 4291 Loopback address"),
        (ipaddress.IPv6Network("100::/64"), "DISCARD_PREFIX_IPV6", "RFC 6666 Discard-only prefix"),
        (ipaddress.IPv6Network("2001:db8::/32"), "DOCUMENTATION_IPV6", "RFC 3849 Documentation prefix"),
        (ipaddress.IPv6Network("fc00::/7"), "UNIQUE_LOCAL_IPV6", "RFC 4193 Unique Local Address (ULA)"),
        (ipaddress.IPv6Network("fe80::/10"), "LINK_LOCAL_IPV6", "RFC 4291 Link-local unicast"),
        (ipaddress.IPv6Network("ff00::/8"), "MULTICAST_IPV6", "RFC 4291 Multicast prefix"),
    ]

    @classmethod
    def extract_host_and_scheme(
        cls, target: Union[str, NormalizedURLComponents, URLNormalizationResult]
    ) -> Tuple[str, str, str]:
        """Extract clean scheme, host, and original target representation.

        Returns:
            (scheme, host, original_str)
        """
        if isinstance(target, NormalizedURLComponents):
            return target.scheme, target.ascii_hostname, target.netloc

        if isinstance(target, URLNormalizationResult):
            if not target.is_valid or target.components is None:
                raise SSRFRejectedException(
                    message=f"Target URL is invalid or malformed: {target.error_message or 'Normalization failed'}",
                    details={"error_code": target.error_code or "INVALID_URL"},
                )
            return target.components.scheme, target.components.ascii_hostname, target.original_url

        if isinstance(target, str):
            raw = target.strip()
            if not raw:
                raise SSRFRejectedException(message="Target cannot be empty or whitespace.")

            # If it looks like a URL with scheme
            if "://" in raw:
                try:
                    parsed = urlsplit(raw)
                    scheme = parsed.scheme.lower()
                    authority = parsed.netloc
                    # Strip userinfo
                    if "@" in authority:
                        authority = authority.rsplit("@", 1)[1]
                    # Strip port
                    if authority.startswith("[") and "]" in authority:
                        host = authority.split("]")[0][1:]
                    elif ":" in authority:
                        host = authority.split(":")[0]
                    else:
                        host = authority
                    return scheme, host.lower().strip(), raw
                except Exception as e:
                    raise SSRFRejectedException(
                        message=f"Malformed URL structure: {e}",
                        details={"error": str(e)},
                    ) from e
            else:
                # Raw hostname or IP candidate
                host = raw
                if host.startswith("[") and host.endswith("]"):
                    host = host[1:-1]
                return "http", host.lower().strip(), raw

        raise SSRFRejectedException(message=f"Unsupported target type: {type(target).__name__}")

    @classmethod
    def parse_ip_literal(cls, host: str) -> Optional[Union[ipaddress.IPv4Address, ipaddress.IPv6Address]]:
        """Statically parse a hostname into an IP address object if it is an IP literal.

        Never performs DNS lookups.
        """
        cleaned = host.strip().rstrip(".")
        if cleaned.startswith("[") and cleaned.endswith("]"):
            cleaned = cleaned[1:-1]

        # 1. Standard dotted-decimal IPv4 or bracketed/colon IPv6
        try:
            return ipaddress.ip_address(cleaned)
        except ValueError:
            pass

        # 2. Decimal integer IP literal (e.g. 2130706433 for 127.0.0.1)
        if cleaned.isdigit():
            try:
                num = int(cleaned)
                if 0 <= num <= 0xFFFFFFFF:
                    return ipaddress.IPv4Address(num)
            except (ValueError, OverflowError):
                pass

        # 3. Hexadecimal integer IP literal (e.g. 0x7f000001)
        if cleaned.lower().startswith("0x"):
            try:
                num = int(cleaned, 16)
                if 0 <= num <= 0xFFFFFFFF:
                    return ipaddress.IPv4Address(num)
            except (ValueError, OverflowError):
                pass

        # 4. Octal integer IP literal (e.g. 0177.0.0.1 or single octal 017700000001)
        if re.match(r"^0[0-7]+$", cleaned):
            try:
                num = int(cleaned, 8)
                if 0 <= num <= 0xFFFFFFFF:
                    return ipaddress.IPv4Address(num)
            except (ValueError, OverflowError):
                pass

        return None

    @classmethod
    def check_ipv4(cls, ip_obj: ipaddress.IPv4Address) -> Optional[Tuple[str, str, str]]:
        """Evaluate an IPv4 address against prohibited network CIDRs.

        Returns:
            (rule_name, description, cidr_str) if prohibited, None if safe.
        """
        for network, rule_name, description in cls.PROHIBITED_IPV4_NETWORKS:
            if ip_obj in network:
                return rule_name, description, str(network)
        return None

    @classmethod
    def check_ipv6(cls, ip_obj: ipaddress.IPv6Address) -> Optional[Tuple[str, str, str]]:
        """Evaluate an IPv6 address against prohibited network CIDRs.

        Unwraps IPv4-mapped IPv6 and extracts 6to4 embedded addresses.
        Returns:
            (rule_name, description, cidr_str) if prohibited, None if safe.
        """
        # 1. Check direct IPv6 network boundaries
        for network, rule_name, description in cls.PROHIBITED_IPV6_NETWORKS:
            if ip_obj in network:
                return rule_name, description, str(network)

        # 2. Check IPv4-mapped IPv6 (::ffff:x.x.x.x)
        if ip_obj.ipv4_mapped is not None:
            inner_ipv4 = ip_obj.ipv4_mapped
            ipv4_hit = cls.check_ipv4(inner_ipv4)
            if ipv4_hit:
                rule, desc, cidr = ipv4_hit
                return f"IPV4_MAPPED_{rule}", f"IPv4-mapped IPv6 wrapping {desc}", f"::ffff:{cidr}"

        # 3. Check 6to4 encapsulation (2002::/16 contains embedded IPv4 in bytes 2..6)
        if ip_obj in ipaddress.IPv6Network("2002::/16"):
            try:
                embedded_ipv4 = ipaddress.IPv4Address(ip_obj.packed[2:6])
                ipv4_hit = cls.check_ipv4(embedded_ipv4)
                if ipv4_hit:
                    rule, desc, cidr = ipv4_hit
                    return f"6TO4_EMBEDDED_{rule}", f"6to4 address embedding {desc}", f"2002:{cidr}"
            except Exception:
                pass

        return None

    @classmethod
    def check_target(
        cls, target: Union[str, NormalizedURLComponents, URLNormalizationResult]
    ) -> SSRFCheckResult:
        """Perform static, passive evaluation of a target for SSRF and private-routing violations.

        Returns:
            SSRFCheckResult indicating whether the target is safe.
        """
        try:
            scheme, host, original_str = cls.extract_host_and_scheme(target)
        except SSRFRejectedException as exc:
            return SSRFCheckResult(
                is_safe=False,
                target=str(target),
                host="",
                blocked_reason=exc.message,
                matched_rule="TARGET_EXTRACTION_FAILURE",
            )

        # 1. Scheme Validation
        if scheme not in cls.ALLOWED_SCHEMES:
            return SSRFCheckResult(
                is_safe=False,
                target=original_str,
                host=host,
                blocked_reason=f"Prohibited URL scheme '{scheme}'. Only HTTP and HTTPS are permitted.",
                matched_rule="PROHIBITED_SCHEME",
            )

        # 2. Hostname String Validation (Loopback & Internal Name Checks)
        cleaned_host = host.lower().rstrip(".")
        if cleaned_host in cls.BLOCKED_HOSTNAMES:
            return SSRFCheckResult(
                is_safe=False,
                target=original_str,
                host=host,
                blocked_reason=f"Prohibited loopback hostname '{cleaned_host}'.",
                matched_rule="LOOPBACK_HOSTNAME",
            )

        for suffix in cls.BLOCKED_SUFFIXES:
            if cleaned_host.endswith(suffix):
                return SSRFCheckResult(
                    is_safe=False,
                    target=original_str,
                    host=host,
                    blocked_reason=f"Prohibited non-public domain suffix '{suffix}'.",
                    matched_rule="INTERNAL_DOMAIN_SUFFIX",
                )

        # 3. IP Literal Parsing & CIDR Enforcement
        ip_obj = cls.parse_ip_literal(cleaned_host)
        if ip_obj is not None:
            if isinstance(ip_obj, ipaddress.IPv4Address):
                hit = cls.check_ipv4(ip_obj)
                if hit:
                    rule_name, description, cidr = hit
                    return SSRFCheckResult(
                        is_safe=False,
                        target=original_str,
                        host=host,
                        ip_address=str(ip_obj),
                        is_ip=True,
                        blocked_reason=f"Target resolves statically to prohibited IP address '{ip_obj}' ({description}).",
                        matched_rule=rule_name,
                        matched_cidr=cidr,
                    )
            elif isinstance(ip_obj, ipaddress.IPv6Address):
                hit = cls.check_ipv6(ip_obj)
                if hit:
                    rule_name, description, cidr = hit
                    return SSRFCheckResult(
                        is_safe=False,
                        target=original_str,
                        host=host,
                        ip_address=str(ip_obj),
                        is_ip=True,
                        blocked_reason=f"Target resolves statically to prohibited IPv6 address '{ip_obj}' ({description}).",
                        matched_rule=rule_name,
                        matched_cidr=cidr,
                    )

            # Public/routable IP literal
            return SSRFCheckResult(
                is_safe=True,
                target=original_str,
                host=host,
                ip_address=str(ip_obj),
                is_ip=True,
            )

        # Target is a standard domain name passing static checks
        return SSRFCheckResult(
            is_safe=True,
            target=original_str,
            host=host,
            is_ip=False,
        )

    @classmethod
    def validate_target(
        cls,
        target: Union[str, NormalizedURLComponents, URLNormalizationResult],
        raise_on_error: bool = True,
    ) -> SSRFCheckResult:
        """Validate target and optionally raise SSRFRejectedException on prohibited targets.

        Args:
            target: Input URL string, NormalizedURLComponents, or URLNormalizationResult.
            raise_on_error: If True, raises SSRFRejectedException on security violation.

        Returns:
            SSRFCheckResult.

        Raises:
            SSRFRejectedException: If raise_on_error is True and target violates SSRF policy.
        """
        result = cls.check_target(target)
        if not result.is_safe and raise_on_error:
            raise SSRFRejectedException(
                message=result.blocked_reason or "Target address is restricted or non-routable.",
                details={
                    "host": result.host,
                    "matched_rule": result.matched_rule,
                    "matched_cidr": result.matched_cidr,
                    "ip_address": result.ip_address,
                },
            )
        return result
