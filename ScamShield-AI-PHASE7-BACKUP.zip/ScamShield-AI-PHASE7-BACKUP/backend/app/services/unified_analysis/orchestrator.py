"""Coordinate existing passive URL, threat-intel, ML, and message services."""

import asyncio
import logging
from datetime import datetime, timezone
from typing import Optional

from app.schemas.analyze import AnalyzeRequest, AnalyzeResponse
from app.schemas.enums import ProviderStatus, TargetType
from app.schemas.ml_analysis import URLMLAnalysis
from app.schemas.threat_intelligence import ProviderReport
from app.services.message_nlp.analyzer import MessageAnalyzer
from app.services.ml_classifier import URLClassifierService, get_url_classifier
from app.services.scanners.ssrf_guard import SSRFGuard
from app.services.scanners.url_extractor import URLFeatureExtractor
from app.services.threat_intel.aggregator import ThreatIntelAggregator
from app.services.unified_analysis.evidence_combiner import EvidenceCombiner
from app.services.unified_analysis.risk_engine import RiskEngine
from app.services.url_normalizer import URLNormalizationError, URLNormalizer

logger = logging.getLogger(__name__)


class UnifiedAnalysisOrchestrator:
    """Passively run the applicable existing analysis components for one request."""

    def __init__(
        self,
        classifier: Optional[URLClassifierService] = None,
        threat_intel: Optional[ThreatIntelAggregator] = None,
        intel_timeout_seconds: float = 8.0,
    ):
        self.classifier = classifier or get_url_classifier()
        self.threat_intel = threat_intel or ThreatIntelAggregator()
        self.intel_timeout_seconds = intel_timeout_seconds

    async def analyze(self, request: AnalyzeRequest) -> AnalyzeResponse:
        if request.target_type == TargetType.MESSAGE:
            try:
                message_result = MessageAnalyzer.analyze(request.message_text or "")
            except Exception as exc:
                logger.warning("Unified message analyzer failed: %s", type(exc).__name__)
                bundle = EvidenceCombiner.combine()
                bundle.evidence_status["message_nlp"] = "ERROR"
            else:
                bundle = EvidenceCombiner.combine(message_analysis=message_result)
            return RiskEngine.score(bundle, TargetType.MESSAGE)

        return await self._analyze_url(request.url or "")

    async def _analyze_url(self, submitted_url: str) -> AnalyzeResponse:
        try:
            normalized = URLNormalizer.normalize(submitted_url, raise_on_error=True)
        except URLNormalizationError:
            bundle = EvidenceCombiner.combine()
            bundle.evidence_status["url_normalization"] = "ERROR"
            return RiskEngine.score(bundle, TargetType.URL)

        if not normalized.is_valid or normalized.components is None or normalized.canonical_url is None:
            bundle = EvidenceCombiner.combine()
            bundle.evidence_status["url_normalization"] = "ERROR"
            return RiskEngine.score(bundle, TargetType.URL)

        ssrf_result = SSRFGuard.check_target(normalized)
        try:
            features = URLFeatureExtractor.extract(normalized)
            lexical_status = "AVAILABLE"
        except Exception as exc:
            logger.warning("Unified URL feature extraction failed: %s", type(exc).__name__)
            features = None
            lexical_status = "ERROR"

        try:
            ml_analysis = self.classifier.predict_from_features(features) if features is not None else None
            ml_status = (ml_analysis.evaluation_metadata or {}).get("status", "AVAILABLE") if ml_analysis else "UNAVAILABLE"
        except Exception as exc:
            logger.warning("Unified URL classifier failed: %s", type(exc).__name__)
            ml_analysis = URLMLAnalysis(evaluation_metadata={"status": "ERROR"})
            ml_status = "ERROR"

        reports = []
        if ssrf_result.is_safe:
            try:
                reports = await asyncio.wait_for(
                    self.threat_intel.inspect_url(normalized.canonical_url),
                    timeout=self.intel_timeout_seconds,
                )
            except (asyncio.TimeoutError, TimeoutError):
                reports = [ProviderReport(
                    provider_name="Threat intelligence aggregation",
                    status=ProviderStatus.TIMEOUT,
                    error_category="AGGREGATOR_TIMEOUT",
                )]
            except Exception as exc:
                logger.warning("Unified threat intelligence failed: %s", type(exc).__name__)
                reports = [ProviderReport(
                    provider_name="Threat intelligence aggregation",
                    status=ProviderStatus.ERROR,
                    error_category=f"AGGREGATOR_ERROR_{type(exc).__name__.upper()}",
                )]

        bundle = EvidenceCombiner.combine(
            url_features=features,
            ssrf_result=ssrf_result,
            ml_analysis=ml_analysis,
            provider_reports=reports,
        )
        bundle.evidence_status["url_features"] = lexical_status
        if ml_analysis is None:
            bundle.evidence_status["url_ml"] = ml_status
        if not ssrf_result.is_safe:
            bundle.evidence_status["threat_intel"] = "SKIPPED_SSRF_REJECTED"
        elif not reports:
            bundle.evidence_status["threat_intel"] = "UNAVAILABLE"

        return RiskEngine.score(bundle, TargetType.URL)


async def analyze(request: AnalyzeRequest) -> AnalyzeResponse:
    """Convenience entry point using default application components."""
    return await UnifiedAnalysisOrchestrator().analyze(request)