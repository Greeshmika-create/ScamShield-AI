"""Deterministic provisional risk scoring over available evidence."""

from app.schemas.analyze import AnalyzeResponse, RiskBand
from app.schemas.enums import ConfidenceLevel, TargetType, Verdict
from app.services.unified_analysis.evidence_combiner import EvidenceBundle


class RiskEngine:
    """Assign a heuristic score and evidence-qualified verdict, never a probability."""

    SEVERITY_POINTS = {"INFO": 0, "LOW": 12, "MEDIUM": 25, "HIGH": 40, "CRITICAL": 60}
    FAILURE_STATUSES = {"TIMEOUT", "ERROR", "UNCONFIGURED", "UNAVAILABLE", "EXTRACTION_FAILURE"}

    @classmethod
    def score(cls, bundle: EvidenceBundle, target_type: TargetType) -> AnalyzeResponse:
        candidate_scores = [
            cls.SEVERITY_POINTS.get(finding.severity.value, 0)
            for finding in bundle.findings
        ]
        if bundle.ssrf_blocked:
            candidate_scores.append(100)
        if any(f.category.value == "INTEL" and f.is_confirmed for f in bundle.findings):
            candidate_scores.append(95)
        if bundle.message_score is not None and bundle.message_score > 0:
            candidate_scores.append(min(100, bundle.message_score))
        if bundle.ml_probability is not None and any(
            finding.category.value == "ML" for finding in bundle.findings
        ):
            candidate_scores.append(round(bundle.ml_probability * 70))

        provider_statuses = [
            status for key, status in bundle.evidence_status.items() if key.startswith("intel:")
        ]
        complete_url_evidence = (
            bundle.lexical_feature_count == 32
            and bundle.evidence_status.get("url_ml") == "INFERRED"
            and bool(provider_statuses)
            and all(status in {"AVAILABLE_CLEAN", "AVAILABLE_FLAGGED"} for status in provider_statuses)
        )
        complete_evidence = (
            bundle.has_complete_local_analysis
            if target_type == TargetType.MESSAGE
            else complete_url_evidence
        )

        if candidate_scores:
            score = min(100, max(candidate_scores))
        elif complete_evidence:
            score = 0
        else:
            score = None

        if score is None:
            risk_band = None
            verdict = Verdict.UNVERIFIED
        elif score >= 75:
            risk_band = RiskBand.CRITICAL
            verdict = Verdict.MALICIOUS
        elif score >= 50:
            risk_band = RiskBand.HIGH
            verdict = Verdict.SUSPICIOUS
        elif score >= 25:
            risk_band = RiskBand.MODERATE
            verdict = Verdict.SUSPICIOUS
        else:
            risk_band = RiskBand.LOW
            verdict = Verdict.NO_KNOWN_THREAT

        failures = any(status in cls.FAILURE_STATUSES for status in bundle.evidence_status.values())
        if not complete_evidence and score is not None and score < 25:
            score = None
            risk_band = None
            verdict = Verdict.UNVERIFIED
        if score is None or failures:
            confidence = ConfidenceLevel.PROVISIONAL
        elif len(bundle.evidence_status) > 1:
            confidence = ConfidenceLevel.HIGH
        else:
            confidence = ConfidenceLevel.MEDIUM

        if bundle.findings:
            summary = "Risk assessment is based on: " + "; ".join(
                finding.title for finding in bundle.findings[:4]
            ) + "."
        elif score == 0:
            summary = "No known risk indicators were detected by the available analysis. This is not a guarantee of safety."
        else:
            summary = "Evidence was incomplete; a clean assessment cannot be made."

        return AnalyzeResponse(
            target_type=target_type,
            risk_score=score,
            risk_band=risk_band,
            verdict=verdict,
            confidence_level=confidence,
            findings=bundle.findings,
            provider_reports=bundle.provider_reports,
            evidence_status=bundle.evidence_status,
            reasoning_summary=summary,
        )