"""Convert existing Phase 4-7 outputs into shared, explainable evidence."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from app.schemas.enums import EvidenceCategory, FindingSeverity, ProviderStatus
from app.schemas.evidence import ThreatFinding
from app.schemas.message_analysis import MessageAnalysisResult
from app.schemas.ml_analysis import URLMLAnalysis
from app.schemas.threat_intelligence import ProviderReport
from app.services.scanners.ssrf_guard import SSRFCheckResult
from app.services.scanners.url_extractor import URLFeatures


@dataclass
class EvidenceBundle:
    findings: List[ThreatFinding] = field(default_factory=list)
    provider_reports: List[ProviderReport] = field(default_factory=list)
    evidence_status: Dict[str, str] = field(default_factory=dict)
    lexical_feature_count: int = 0
    ml_probability: Optional[float] = None
    message_score: Optional[int] = None
    has_complete_local_analysis: bool = False
    ssrf_blocked: bool = False


class EvidenceCombiner:
    """Normalize verified signals without inventing evidence for missing providers."""

    @staticmethod
    def combine(
        *,
        url_features: Optional[URLFeatures] = None,
        ssrf_result: Optional[SSRFCheckResult] = None,
        ml_analysis: Optional[URLMLAnalysis] = None,
        provider_reports: Optional[Sequence[ProviderReport]] = None,
        message_analysis: Optional[MessageAnalysisResult] = None,
    ) -> EvidenceBundle:
        bundle = EvidenceBundle()

        if ssrf_result is not None:
            bundle.evidence_status["ssrf"] = "BLOCKED" if not ssrf_result.is_safe else "AVAILABLE"
            if not ssrf_result.is_safe:
                bundle.ssrf_blocked = True
                bundle.findings.append(ThreatFinding(
                    category=EvidenceCategory.HEURISTIC,
                    rule_name=ssrf_result.matched_rule or "SSRF_REJECTED",
                    severity=FindingSeverity.CRITICAL,
                    title="URL target rejected by static SSRF guard",
                    description=ssrf_result.blocked_reason or "Static target validation rejected this URL.",
                    source="Static SSRF Guard",
                    confidence="HIGH",
                    is_confirmed=True,
                ))

        if url_features is not None:
            static_flags = (
                ("has_ip_address", bool(url_features.has_ip_address), FindingSeverity.HIGH, "IP address used as URL hostname"),
                ("is_punycode", bool(url_features.is_punycode), FindingSeverity.MEDIUM, "Internationalized or punycode hostname"),
                ("has_non_standard_port", bool(url_features.has_non_standard_port), FindingSeverity.MEDIUM, "Non-standard URL port"),
            )
            for rule_name, matched, severity, title in static_flags:
                if matched:
                    bundle.findings.append(ThreatFinding(
                        category=EvidenceCategory.HEURISTIC,
                        rule_name=rule_name.upper(),
                        severity=severity,
                        title=title,
                        description=f"The static URL feature extractor identified {title.lower()}.",
                        source="Static URL Feature Extractor",
                        confidence="MEDIUM",
                        raw_evidence={rule_name: True},
                    ))
            if url_features.suspicious_token_count:
                bundle.findings.append(ThreatFinding(
                    category=EvidenceCategory.HEURISTIC,
                    rule_name="SUSPICIOUS_URL_TOKENS",
                    severity=FindingSeverity.LOW if url_features.suspicious_token_count == 1 else FindingSeverity.MEDIUM,
                    title="Suspicious URL keyword patterns",
                    description="Static lexical analysis found suspicious keyword patterns in the URL.",
                    source="Static URL Feature Extractor",
                    confidence="LOW",
                    raw_evidence={"suspicious_token_count": url_features.suspicious_token_count},
                ))
            bundle.lexical_feature_count = len(url_features.to_dict())
            bundle.evidence_status["url_features"] = "AVAILABLE"

        if ml_analysis is not None:
            metadata = ml_analysis.evaluation_metadata or {}
            status = str(metadata.get("status", "AVAILABLE" if ml_analysis.threat_probability is not None else "UNAVAILABLE"))
            bundle.evidence_status["url_ml"] = status
            bundle.ml_probability = ml_analysis.threat_probability
            prediction = (ml_analysis.prediction or "").upper()
            if ml_analysis.threat_probability is not None and prediction not in {"", "BENIGN", "CLEAN"}:
                bundle.findings.append(ThreatFinding(
                    category=EvidenceCategory.ML,
                    rule_name="URL_ML_" + prediction,
                    severity=FindingSeverity.HIGH if ml_analysis.threat_probability >= 0.85 else FindingSeverity.MEDIUM,
                    title="URL classifier flagged a risk pattern",
                    description="The URL lexical classifier produced a non-benign prediction; this is heuristic evidence, not a probability of fraud.",
                    source=ml_analysis.model_id or "URL lexical classifier",
                    confidence="MEDIUM",
                    raw_evidence={"prediction": prediction, "threat_probability": ml_analysis.threat_probability},
                ))

        bundle.provider_reports = list(provider_reports or [])
        if provider_reports is not None:
            for report in bundle.provider_reports:
                bundle.evidence_status[f"intel:{report.provider_name}"] = report.status.value
                if report.status == ProviderStatus.AVAILABLE_FLAGGED:
                    bundle.findings.append(ThreatFinding(
                        category=EvidenceCategory.INTEL,
                        rule_name="INTEL_" + "_".join(report.provider_name.upper().split()),
                        severity=FindingSeverity.CRITICAL,
                        title="Threat intelligence provider reported a match",
                        description=report.threat_details or "A configured threat intelligence provider reported a match.",
                        source=report.provider_name,
                        confidence="HIGH",
                        is_confirmed=True,
                        raw_evidence=report.raw_evidence,
                    ))

        if message_analysis is not None:
            bundle.evidence_status["message_nlp"] = message_analysis.status
            bundle.has_complete_local_analysis = message_analysis.status in {"ANALYZED", "NO_KNOWN_INDICATORS"}
            bundle.message_score = message_analysis.threat_score_estimate
            for indicator in message_analysis.indicators:
                bundle.findings.append(ThreatFinding(
                    category=EvidenceCategory.LINGUISTIC,
                    rule_name=indicator.rule_name,
                    severity=indicator.severity,
                    title=indicator.title,
                    description=indicator.description,
                    source="Multilingual Message NLP",
                    confidence="MEDIUM",
                    raw_evidence={"matched_phrases": indicator.matched_phrases},
                ))

        return bundle