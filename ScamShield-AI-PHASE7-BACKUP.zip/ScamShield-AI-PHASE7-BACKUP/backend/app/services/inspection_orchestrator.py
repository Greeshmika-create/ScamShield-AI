"""Coordinate URL and message scan services into established API responses."""

import asyncio
import logging
import time
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from uuid import uuid4

from app.core.config import Settings, get_settings
from app.schemas.common import UserGuidance
from app.schemas.enums import ProviderStatus, TargetType
from app.schemas.message_scan import MessageScanRequest, MessageScanResponse
from app.schemas.ml_analysis import MessageMLAnalysis
from app.schemas.threat_intelligence import ProviderReport
from app.schemas.url_scan import URLScanRequest, URLScanResponse
from app.services.message_nlp.analyzer import MessageAnalyzer
from app.services.ml_classifier import URLClassifierService, get_url_classifier
from app.services.scanners.ssrf_guard import SSRFGuard
from app.services.scanners.url_extractor import URLFeatureExtractor
from app.services.threat_intel.aggregator import ThreatIntelAggregator
from app.services.unified_analysis.evidence_combiner import EvidenceCombiner
from app.services.unified_analysis.risk_engine import RiskEngine
from app.services.url_normalizer import URLNormalizationError, URLNormalizer

logger = logging.getLogger(__name__)

SENSITIVE_QUERY_KEYS = {
    "access_token", "api_key", "apikey", "auth", "authorization", "code",
    "key", "otp", "password", "refresh_token", "secret", "session", "token",
}

ENGLISH_GUIDANCE = (
    "Do not share passwords, one-time codes, payment PINs, or financial details. "
    "Verify requests through an official channel."
)
TELUGU_GUIDANCE = "పాస్‌వర్డ్‌లు, OTPలు లేదా చెల్లింపు PINలను పంచుకోవద్దు. అధికారిక మార్గం ద్వారా అభ్యర్థనను ధృవీకరించండి."


def _safe_url_for_response(value: str) -> str:
    """Remove URL userinfo and redact sensitive query values for response display."""
    try:
        parts = urlsplit(value)
        authority = parts.netloc.rsplit("@", 1)[-1]
        query = urlencode([
            (key, "[REDACTED]" if key.lower().replace("-", "_") in SENSITIVE_QUERY_KEYS else item)
            for key, item in parse_qsl(parts.query, keep_blank_values=True)
        ])
        return urlunsplit((parts.scheme, authority, parts.path, query, ""))
    except Exception:
        return "[URL REDACTED]"


class InspectionOrchestrator:
    """Run the existing passive scanners and apply Phase 8 evidence scoring."""

    def __init__(
        self,
        classifier: Optional[URLClassifierService] = None,
        threat_intel: Optional[ThreatIntelAggregator] = None,
        settings: Optional[Settings] = None,
    ) -> None:
        self.settings = settings or get_settings()
        self.classifier = classifier or get_url_classifier()
        self.threat_intel = threat_intel or ThreatIntelAggregator(settings=self.settings)

    async def scan_url(self, request: URLScanRequest) -> URLScanResponse:
        started = time.perf_counter()
        normalized = URLNormalizer.normalize(request.url, raise_on_error=True)
        if not normalized.is_valid or normalized.components is None or normalized.canonical_url is None:
            raise URLNormalizationError("URL normalization failed.")

        ssrf_result = SSRFGuard.validate_target(normalized)
        features = URLFeatureExtractor.extract(normalized)
        ml_analysis = self.classifier.predict_from_features(features)
        safe_url = _safe_url_for_response(normalized.canonical_url)

        try:
            reports = await asyncio.wait_for(
            self.threat_intel.inspect_url(safe_url),
                timeout=self.settings.TOTAL_SCAN_TIMEOUT_SECONDS,
            )
        except (asyncio.TimeoutError, TimeoutError):
            reports = [ProviderReport(
                provider_name="Threat intelligence aggregation",
                status=ProviderStatus.TIMEOUT,
                error_category="AGGREGATOR_TIMEOUT",
            )]
        except Exception as exc:
            logger.warning("URL threat intelligence failed: %s", type(exc).__name__)
            reports = [ProviderReport(
                provider_name="Threat intelligence aggregation",
                status=ProviderStatus.ERROR,
                error_category=f"AGGREGATOR_ERROR_{type(exc).__name__.upper()}",
            )]

        evidence = EvidenceCombiner.combine(
            url_features=features,
            ssrf_result=ssrf_result,
            ml_analysis=ml_analysis,
            provider_reports=reports,
        )
        risk = RiskEngine.score(evidence, TargetType.URL)
        return URLScanResponse(
            scan_id=str(uuid4()),
            scanned_at=datetime.now(timezone.utc).isoformat(),
            target_url=safe_url,
            canonical_url=safe_url,
            target_domain=normalized.components.ascii_hostname,
            verdict=risk.verdict,
            risk_score=risk.risk_score,
            confidence_level=risk.confidence_level,
            threat_intelligence=risk.provider_reports,
            findings=risk.findings,
            ml_analysis=ml_analysis,
            execution_time_ms=max(0, int((time.perf_counter() - started) * 1000)),
        )

    async def scan_message(self, request: MessageScanRequest) -> MessageScanResponse:
        started = time.perf_counter()
        message_analysis = MessageAnalyzer.analyze(request.message_text)
        evidence = EvidenceCombiner.combine(message_analysis=message_analysis)
        risk = RiskEngine.score(evidence, TargetType.MESSAGE)
        extracted_urls = [
            _safe_url_for_response(url)
            for url in message_analysis.features.extracted_urls
        ]

        return MessageScanResponse(
            scan_id=str(uuid4()),
            scanned_at=datetime.now(timezone.utc).isoformat(),
            message_preview=message_analysis.message_preview,
            detected_language=message_analysis.script_assessment.detected_language.value,
            extracted_urls=extracted_urls,
            verdict=risk.verdict,
            risk_score=risk.risk_score,
            confidence_level=risk.confidence_level,
            findings=risk.findings,
            ml_analysis=MessageMLAnalysis(
                evaluation_metadata={
                    "status": "NOT_CONFIGURED",
                    "reason": "No message ML model is configured; multilingual heuristic findings are reported separately.",
                }
            ),
            user_guidance=UserGuidance(english=ENGLISH_GUIDANCE, telugu=TELUGU_GUIDANCE),
            execution_time_ms=max(0, int((time.perf_counter() - started) * 1000)),
        )


async def scan_url(request: URLScanRequest) -> URLScanResponse:
    return await InspectionOrchestrator().scan_url(request)


async def scan_message(request: MessageScanRequest) -> MessageScanResponse:
    return await InspectionOrchestrator().scan_message(request)