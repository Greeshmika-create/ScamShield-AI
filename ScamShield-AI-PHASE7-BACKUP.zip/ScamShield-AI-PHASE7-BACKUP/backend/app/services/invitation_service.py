"""Admin invitation service interface and foundations for ScamShield AI.

Defines the service contract and security constraints for inviting administrators.
Actual email delivery, token generation, and database persistence belong to Phase 10.
"""

from abc import ABC, abstractmethod
from datetime import datetime, timezone, timedelta
import logging
import uuid

from app.core.audit import record_security_audit
from app.core.errors import ForbiddenException, InvalidInputException
from app.core.permissions import validate_role_assignment
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import AuditEventType, InvitationStatus, UserRole
from app.schemas.invitation import AdminInvitationCreate, AdminInvitationResponse

logger = logging.getLogger("scamshield.invitation")


class AdminInvitationServiceInterface(ABC):
    """Abstract interface defining administrative invitation operations."""

    @abstractmethod
    def create_invitation(
        self,
        actor: AuthenticatedPrincipal,
        invitation_data: AdminInvitationCreate,
    ) -> AdminInvitationResponse:
        """Create a validated administrative invitation.

        Rules:
        - Only OWNER can invite administrators.
        - Only ADMIN role can be assigned.
        - Emits security audit record for every invitation attempt.
        """
        pass


class AdminInvitationService(AdminInvitationServiceInterface):
    """Core administrative invitation service foundation.

    In Phase 3.4:
    - Enforces authorization constraints (OWNER only).
    - Validates target email and eligible roles.
    - Emits structured security audit events.
    - Database persistence and SMTP delivery belong to Phase 10.
    """

    def create_invitation(
        self,
        actor: AuthenticatedPrincipal,
        invitation_data: AdminInvitationCreate,
    ) -> AdminInvitationResponse:
        # 1. Authorize actor (only OWNER can invite administrators)
        validate_role_assignment(actor=actor, target_new_role=invitation_data.role)

        # 2. Prevent self-invitation
        if actor.email and actor.email.lower() == invitation_data.invitee_email.lower():
            raise InvalidInputException("Cannot issue an administrator invitation to oneself.")

        # 3. Construct validated invitation response model
        invitation_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(days=7)

        response = AdminInvitationResponse(
            invitation_id=invitation_id,
            inviter_user_id=actor.user_id,
            invitee_email=invitation_data.invitee_email,
            role=invitation_data.role,
            status=InvitationStatus.PENDING,
            expires_at=expires_at,
            created_at=now,
        )

        # 4. Record security audit event
        record_security_audit(
            event_type=AuditEventType.ADMIN_INVITED,
            action="admin_invitation_created",
            actor_user_id=actor.user_id,
            actor_role=actor.role,
            details={
                "invitation_id": invitation_id,
                "invitee_email": invitation_data.invitee_email,
                "assigned_role": invitation_data.role.value,
                "expires_at": expires_at.isoformat(),
            },
        )

        logger.info(
            "Admin invitation created for %s by OWNER %s (invitation_id=%s)",
            invitation_data.invitee_email,
            actor.user_id,
            invitation_id,
        )

        return response


def get_admin_invitation_service() -> AdminInvitationService:
    """Dependency provider returning the AdminInvitationService instance."""
    return AdminInvitationService()

