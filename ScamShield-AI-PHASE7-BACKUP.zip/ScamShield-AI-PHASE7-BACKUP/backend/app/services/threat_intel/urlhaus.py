"""Phase 5 URLhaus (abuse.ch) Threat Intelligence Adapter.

Security & Architectural Mandates:
- Strictly passive: submits canonical URL to URLhaus API (https://urlhaus-api.abuse.ch/v1/url/).
- Detects active malware distribution endpoints and malicious payload hosting.
- Traps network exceptions, timeouts, and non-200 HTTP responses.
- API keys are never exposed in logs or exception messages.
"""

from typing import Any, Dict, Optional, Tuple
import httpx

from app.schemas.enums import ProviderStatus
from app.services.threat_intel.base import BaseThreatIntelProvider


class URLhausClient(BaseThreatIntelProvider):
    """Asynchronous client for abuse.ch URLhaus threat intelligence API."""

    ENDPOINT_URL = "https://urlhaus-api.abuse.ch/v1/url/"
    PROVIDER_NAME = "URLhaus"

    def __init__(self, api_key: Optional[str] = None):
        super().__init__(provider_name=self.PROVIDER_NAME, api_key=api_key)

    async def query_feed(
        self, canonical_url: str, client: httpx.AsyncClient
    ) -> Tuple[ProviderStatus, Optional[str], Optional[Dict[str, Any]], Optional[str]]:
        """Query URLhaus API for active malware hosting indicators."""
        headers = {"Accept": "application/json"}
        if self.api_key:
            headers["Auth-Key"] = self.api_key

        response = await client.post(
            self.ENDPOINT_URL,
            data={"url": canonical_url},
            headers=headers,
        )
        response.raise_for_status()

        data = response.json()
        if not isinstance(data, dict):
            return ProviderStatus.ERROR, None, None, "INVALID_PROVIDER_RESPONSE_JSON"
        raw_status = data.get("query_status")
        if not isinstance(raw_status, str):
            return ProviderStatus.ERROR, None, None, "INVALID_PROVIDER_QUERY_STATUS"
        query_status = raw_status.lower()

        if query_status == "ok":
            url_status = data.get("url_status", "active")
            threat = data.get("threat", "malware_download")
            tags = data.get("tags") or []
            if not isinstance(url_status, str) or not isinstance(threat, str):
                return ProviderStatus.ERROR, None, None, "INVALID_PROVIDER_STRING_FIELD"
            if not isinstance(tags, list) or not all(isinstance(tag, str) for tag in tags):
                return ProviderStatus.ERROR, None, None, "INVALID_PROVIDER_TAGS"
            threat_summary = f"Flagged by URLhaus as active threat: {threat} (status: {url_status})"
            raw_evidence = {
                "query_status": "ok",
                "url_status": url_status,
                "threat": threat,
                "tags": tags,
                "urlhaus_reference": data.get("urlhaus_reference"),
                "date_added": data.get("date_added"),
            }
            return ProviderStatus.AVAILABLE_FLAGGED, threat_summary, raw_evidence, None

        if query_status == "no_results":
            return ProviderStatus.AVAILABLE_CLEAN, None, {"query_status": "no_results"}, None

        # Unknown statuses are provider anomalies, not confirmed clean results.
        return ProviderStatus.ERROR, None, {"query_status": query_status}, "UNKNOWN_QUERY_STATUS"

