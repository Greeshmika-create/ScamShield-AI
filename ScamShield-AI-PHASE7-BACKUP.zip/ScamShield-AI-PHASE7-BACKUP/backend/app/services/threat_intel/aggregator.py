"""Phase 5 Threat Intelligence Aggregator Orchestrator for ScamShield AI.

Security & Architectural Mandates:
- Strictly passive: inspects canonical URLs using external reputation blocklists.
- Concurrent execution: queries GSB, URLhaus, and PhishTank in parallel via asyncio.gather.
- Isolated timeouts: each provider capped at 2.5s budget via asyncio.wait_for.
- Fail-open resilience: upstream timeouts, outages, and rate limits return clean status
  (TIMEOUT / ERROR) rather than crashing or terminating the scan pipeline.
- Quota protection: deduplicates queries using in-memory 2-hour TTL cache (cache.py).
- Zero-mock policy: never fabricates threat indicators or fakes clean statuses on error.
"""

import asyncio
from datetime import datetime, timezone
from typing import List, Optional
import httpx

from app.core.config import Settings, get_settings
from app.schemas.enums import ProviderStatus
from app.schemas.threat_intelligence import ProviderReport
from app.services.threat_intel.base import BaseThreatIntelProvider
from app.services.threat_intel.cache import ThreatIntelCache, get_threat_intel_cache
from app.services.threat_intel.gsb import GoogleSafeBrowsingClient
from app.services.threat_intel.phishtank import PhishTankClient
from app.services.threat_intel.urlhaus import URLhausClient


class ThreatIntelAggregator:
    """Asynchronous orchestrator for external threat intelligence aggregation."""

    def __init__(
        self,
        settings: Optional[Settings] = None,
        cache: Optional[ThreatIntelCache] = None,
    ):
        self.settings = settings or get_settings()
        self.cache = cache or get_threat_intel_cache(
            default_ttl_hours=self.settings.INTEL_CACHE_TTL_HOURS
        )
        self.timeout_seconds = self.settings.INTEL_TIMEOUT_SECONDS

        # Initialize provider adapters
        self.providers: List[BaseThreatIntelProvider] = [
            GoogleSafeBrowsingClient(api_key=self.settings.GOOGLE_SAFE_BROWSING_API_KEY),
            URLhausClient(api_key=self.settings.URLHAUS_API_KEY),
            PhishTankClient(api_key=self.settings.PHISHTANK_API_KEY),
        ]

    async def _query_single_provider(
        self,
        provider: BaseThreatIntelProvider,
        canonical_url: str,
        client: httpx.AsyncClient,
    ) -> ProviderReport:
        """Query an individual provider with cache lookup, isolated timeout, and error trapping."""
        # 1. Fast Path: Check TTL Cache
        cached_report = self.cache.get(canonical_url, provider.provider_name)
        if cached_report is not None:
            return cached_report

        # 2. Check if provider is configured
        if not provider.is_configured:
            return provider.create_unconfigured_report()

        # 3. Query upstream feed with isolated 2.5s timeout budget
        try:
            report = await asyncio.wait_for(
                provider.check_url(canonical_url, client=client),
                timeout=self.timeout_seconds,
            )

            # Cache definitive results for repeat lookups
            if report.status in {ProviderStatus.AVAILABLE_CLEAN, ProviderStatus.AVAILABLE_FLAGGED}:
                self.cache.set(canonical_url, provider.provider_name, report)

            return report

        except (asyncio.TimeoutError, TimeoutError):
            timeout_ms = int(self.timeout_seconds * 1000)
            return provider.create_timeout_report(timeout_ms)

        except Exception as e:
            # Trap any unexpected task error without breaking other concurrent providers
            return ProviderReport(
                provider_name=provider.provider_name,
                status=ProviderStatus.ERROR,
                response_time_ms=0,
                threat_details=None,
                check_timestamp=datetime.now(timezone.utc).isoformat(),
                error_category=f"INTERNAL_TASK_ERROR_{type(e).__name__.upper()}",
                raw_evidence=None,
            )

    async def inspect_url(
        self,
        canonical_url: str,
        client: Optional[httpx.AsyncClient] = None,
    ) -> List[ProviderReport]:
        """Concurrently query all configured threat intelligence feeds for a canonical URL.

        Args:
            canonical_url: Canonicalized target URL (userinfo stripped).
            client: Optional shared httpx.AsyncClient instance.

        Returns:
            List of ProviderReport objects conforming to schema.
        """
        if client is not None:
            tasks = [
                self._query_single_provider(provider, canonical_url, client)
                for provider in self.providers
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)
        else:
            async with httpx.AsyncClient(timeout=self.timeout_seconds + 1.0) as local_client:
                tasks = [
                    self._query_single_provider(provider, canonical_url, local_client)
                    for provider in self.providers
                ]
                results = await asyncio.gather(*tasks, return_exceptions=True)

        reports: List[ProviderReport] = []
        for i, res in enumerate(results):
            provider = self.providers[i]
            if isinstance(res, ProviderReport):
                reports.append(res)
            elif isinstance(res, Exception):
                reports.append(
                    ProviderReport(
                        provider_name=provider.provider_name,
                        status=ProviderStatus.ERROR,
                        response_time_ms=0,
                        threat_details=None,
                        check_timestamp=datetime.now(timezone.utc).isoformat(),
                        error_category=f"UNHANDLED_{type(res).__name__.upper()}",
                        raw_evidence=None,
                    )
                )

        return reports

    @staticmethod
    def is_flagged(reports: List[ProviderReport]) -> bool:
        """Return True if at least one threat feed confirmed target as active threat."""
        return any(r.status == ProviderStatus.AVAILABLE_FLAGGED for r in reports)

    @staticmethod
    def get_flagged_providers(reports: List[ProviderReport]) -> List[str]:
        """Return names of all providers that flagged the URL as malicious."""
        return [r.provider_name for r in reports if r.status == ProviderStatus.AVAILABLE_FLAGGED]

    @staticmethod
    def get_threat_summaries(reports: List[ProviderReport]) -> List[str]:
        """Extract all human-readable threat descriptions from flagged reports."""
        return [
            r.threat_details
            for r in reports
            if r.status == ProviderStatus.AVAILABLE_FLAGGED and r.threat_details
        ]

