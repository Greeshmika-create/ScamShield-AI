"""External threat intelligence adapters (Google Safe Browsing, URLhaus, PhishTank)."""

