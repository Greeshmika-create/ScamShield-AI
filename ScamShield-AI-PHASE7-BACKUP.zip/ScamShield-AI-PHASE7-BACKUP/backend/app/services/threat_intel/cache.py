"""Phase 5 In-Memory Threat Intelligence TTL Cache for ScamShield AI.

Security & Architectural Mandates:
- Strictly local and in-memory (<1ms lookups).
- Keyed deterministically by SHA-256(canonical_url) + '_' + provider_name.
- Enforces configurable TTL expiration (default: 2 hours conforming to docs/ARCHITECTURE.md Section 6).
- Eliminates external API quota exhaustion and avoids redundant network queries.
- Clean abstract structure ready for Supabase PostgreSQL persistence in Phase 10.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import threading
from typing import Dict, Optional

from app.schemas.threat_intelligence import ProviderReport


@dataclass(frozen=True)
class CachedIntelEntry:
    """Internal cache entry wrapping a provider report with expiration metadata."""

    cache_key: str
    provider_name: str
    report: ProviderReport
    cached_at: datetime
    expires_at: datetime

    def is_expired(self, now: Optional[datetime] = None) -> bool:
        """Check if cached entry has exceeded its TTL window."""
        current_time = now or datetime.now(timezone.utc)
        return current_time >= self.expires_at


class ThreatIntelCache:
    """Thread-safe in-memory TTL cache for threat intelligence provider lookups."""

    DEFAULT_TTL_HOURS: int = 2

    def __init__(self, default_ttl_hours: int = DEFAULT_TTL_HOURS):
        self.default_ttl_seconds = int(default_ttl_hours * 3600)
        self._cache: Dict[str, CachedIntelEntry] = {}
        self._lock = threading.Lock()

    @staticmethod
    def generate_cache_key(canonical_url: str, provider_name: str) -> str:
        """Deterministically calculate cache key: SHA-256(canonical_url) + '_' + provider_name."""
        url_hash = hashlib.sha256(canonical_url.strip().encode("utf-8")).hexdigest()
        provider_slug = provider_name.strip().lower().replace(" ", "_")
        return f"{url_hash}_{provider_slug}"

    def get(self, canonical_url: str, provider_name: str) -> Optional[ProviderReport]:
        """Retrieve cached provider report if present and not expired.

        Returns:
            ProviderReport if valid cached entry exists; otherwise None.
        """
        key = self.generate_cache_key(canonical_url, provider_name)
        now = datetime.now(timezone.utc)

        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None

            if entry.is_expired(now):
                # Eagerly evict expired item
                del self._cache[key]
                return None

            return entry.report

    def set(
        self,
        canonical_url: str,
        provider_name: str,
        report: ProviderReport,
        ttl_seconds: Optional[int] = None,
    ) -> None:
        """Store provider lookup result with TTL expiration.

        Only caches definitive outcomes (AVAILABLE_CLEAN or AVAILABLE_FLAGGED).
        Transient errors or timeouts are NEVER cached to ensure subsequent retries.
        """
        # Only cache definitive results
        if report.status not in {"AVAILABLE_CLEAN", "AVAILABLE_FLAGGED"}:
            return

        key = self.generate_cache_key(canonical_url, provider_name)
        now = datetime.now(timezone.utc)
        duration = ttl_seconds if ttl_seconds is not None else self.default_ttl_seconds
        expires_at = now + timedelta(seconds=duration)

        entry = CachedIntelEntry(
            cache_key=key,
            provider_name=provider_name,
            report=report,
            cached_at=now,
            expires_at=expires_at,
        )

        with self._lock:
            self._cache[key] = entry

    def cleanup_expired(self) -> int:
        """Evict all expired entries and return the count of removed items."""
        now = datetime.now(timezone.utc)
        evicted = 0

        with self._lock:
            keys_to_remove = [
                k for k, entry in self._cache.items() if entry.is_expired(now)
            ]
            for k in keys_to_remove:
                del self._cache[k]
                evicted += 1

        return evicted

    def clear(self) -> None:
        """Purge all entries from the cache."""
        with self._lock:
            self._cache.clear()

    def size(self) -> int:
        """Return total active entries in cache."""
        with self._lock:
            return len(self._cache)


# Global singleton instance for application runtime
_global_threat_intel_cache: Optional[ThreatIntelCache] = None


def get_threat_intel_cache(default_ttl_hours: int = 2) -> ThreatIntelCache:
    """Retrieve or initialize the global threat intelligence cache singleton."""
    global _global_threat_intel_cache
    if _global_threat_intel_cache is None:
        _global_threat_intel_cache = ThreatIntelCache(default_ttl_hours=default_ttl_hours)
    return _global_threat_intel_cache

