"""Phase 5 PhishTank Threat Intelligence Adapter.

Security & Architectural Mandates:
- Strictly passive: queries PhishTank checkurl API (https://checkurl.phishtank.com/checkurl/).
- Identifies community-verified active phishing targets.
- Handles rate-limiting and timeouts gracefully without failing scans.
- API keys and secrets are protected from logging and exceptions.
"""

from typing import Any, Dict, Optional, Tuple
import httpx

from app.schemas.enums import ProviderStatus
from app.services.threat_intel.base import BaseThreatIntelProvider


class PhishTankClient(BaseThreatIntelProvider):
    """Asynchronous client for PhishTank phishing verification API."""

    ENDPOINT_URL = "https://checkurl.phishtank.com/checkurl/"
    PROVIDER_NAME = "PhishTank"

    def __init__(self, api_key: Optional[str] = None):
        super().__init__(provider_name=self.PROVIDER_NAME, api_key=api_key)

    async def query_feed(
        self, canonical_url: str, client: httpx.AsyncClient
    ) -> Tuple[ProviderStatus, Optional[str], Optional[Dict[str, Any]], Optional[str]]:
        """Query PhishTank API for confirmed phishing reports."""
        form_data = {
            "url": canonical_url,
            "format": "json",
        }
        if self.api_key:
            form_data["app_key"] = self.api_key

        headers = {
            "User-Agent": "phishtank/scamshield-ai",
            "Accept": "application/json",
        }

        response = await client.post(
            self.ENDPOINT_URL,
            data=form_data,
            headers=headers,
        )
        response.raise_for_status()

        data = response.json()
        if not isinstance(data, dict):
            return ProviderStatus.ERROR, None, None, "INVALID_PROVIDER_RESPONSE_JSON"
        results = data.get("results")

        if isinstance(results, dict):
            in_database = results.get("in_database", False)
            is_valid_phish = results.get("valid", False)
            if not isinstance(in_database, bool) or not isinstance(is_valid_phish, bool):
                return ProviderStatus.ERROR, None, None, "INVALID_PROVIDER_BOOLEAN_FIELD"

            if in_database and is_valid_phish:
                phish_id = results.get("phish_id")
                threat_summary = f"Flagged by PhishTank as verified phishing target (Phish ID: {phish_id})"
                raw_evidence = {
                    "in_database": True,
                    "verified_phish": True,
                    "phish_id": phish_id,
                    "phish_detail_page": results.get("phish_detail_page"),
                    "verification_time": results.get("verification_time"),
                }
                return ProviderStatus.AVAILABLE_FLAGGED, threat_summary, raw_evidence, None

            return ProviderStatus.AVAILABLE_CLEAN, None, {"in_database": in_database}, None

        return ProviderStatus.ERROR, None, {}, "INVALID_PROVIDER_RESULTS"

