"""Phase 5 Google Safe Browsing (GSB v4) Threat Intelligence Adapter.

Security & Architectural Mandates:
- Strictly passive: sends canonical URL string to Google Safe Browsing v4 threatMatches:find.
- Never reveals API keys in logs, reports, or errors.
- Unconfigured states return UNCONFIGURED with zero outbound connections.
- Corroborates MALWARE, SOCIAL_ENGINEERING, UNWANTED_SOFTWARE, and POTENTIALLY_HARMFUL_APPLICATION.
"""

from typing import Any, Dict, Optional, Tuple
import httpx

from app.schemas.enums import ProviderStatus
from app.services.threat_intel.base import BaseThreatIntelProvider


class GoogleSafeBrowsingClient(BaseThreatIntelProvider):
    """Asynchronous client for Google Safe Browsing v4 Threat Matches API."""

    ENDPOINT_URL = "https://safebrowsing.googleapis.com/v4/threatMatches:find"
    PROVIDER_NAME = "Google Safe Browsing"

    def __init__(self, api_key: Optional[str] = None):
        super().__init__(provider_name=self.PROVIDER_NAME, api_key=api_key)

    async def query_feed(
        self, canonical_url: str, client: httpx.AsyncClient
    ) -> Tuple[ProviderStatus, Optional[str], Optional[Dict[str, Any]], Optional[str]]:
        """Query Google Safe Browsing v4 API for threat matches."""
        request_payload = {
            "client": {
                "clientId": "scamshield-ai",
                "clientVersion": "1.0.0",
            },
            "threatInfo": {
                "threatTypes": [
                    "MALWARE",
                    "SOCIAL_ENGINEERING",
                    "UNWANTED_SOFTWARE",
                    "POTENTIALLY_HARMFUL_APPLICATION",
                ],
                "platformTypes": ["ANY_PLATFORM"],
                "threatEntryTypes": ["URL"],
                "threatEntries": [{"url": canonical_url}],
            },
        }

        # API key is passed strictly as query parameter in the upstream request URL
        response = await client.post(
            self.ENDPOINT_URL,
            params={"key": self.api_key},
            json=request_payload,
            headers={"Content-Type": "application/json"},
        )
        response.raise_for_status()

        data = response.json()
        if not isinstance(data, dict):
            return ProviderStatus.ERROR, None, None, "INVALID_PROVIDER_RESPONSE_JSON"
        matches = data.get("matches", [])
        if matches is None:
            matches = []
        if not isinstance(matches, list):
            return ProviderStatus.ERROR, None, None, "INVALID_PROVIDER_MATCHES_TYPE"

        if matches:
            threat_types = set()
            platforms = set()
            for match in matches:
                if not isinstance(match, dict):
                    return ProviderStatus.ERROR, None, None, "INVALID_PROVIDER_MATCH_ITEM"
                threat_type = match.get("threatType")
                platform = match.get("platformType")
                if threat_type is not None and not isinstance(threat_type, str):
                    return ProviderStatus.ERROR, None, None, "INVALID_PROVIDER_THREAT_TYPE"
                if platform is not None and not isinstance(platform, str):
                    return ProviderStatus.ERROR, None, None, "INVALID_PROVIDER_PLATFORM_TYPE"
                threat_types.add(threat_type or "UNKNOWN")
                platforms.add(platform or "ANY_PLATFORM")

            ordered_threat_types = sorted(threat_types)
            ordered_platforms = sorted(platforms)
            threat_summary = f"Flagged by Google Safe Browsing ({', '.join(ordered_threat_types)})"
            raw_evidence = {
                "match_count": len(matches),
                "threat_types": ordered_threat_types,
                "platforms": ordered_platforms,
            }
            return ProviderStatus.AVAILABLE_FLAGGED, threat_summary, raw_evidence, None

        return ProviderStatus.AVAILABLE_CLEAN, None, None, None

