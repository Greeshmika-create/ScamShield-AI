"""Phase 5 Base Threat Intelligence Provider Specification for ScamShield AI.

Security & Architectural Mandates:
- Abstract provider contract for external threat feeds.
- Measures response time in milliseconds with monotonic timing.
- Enforces strict isolation: provider failures, timeouts, and network exceptions
  are trapped and mapped to standardized ProviderStatus enums without crashing.
- Prevents credential exposure: API keys are never included in reports, exceptions, or logs.
- Fails closed/unconfigured gracefully: unconfigured providers do not attempt network connections.
"""

from abc import ABC, abstractmethod
from datetime import datetime, timezone
import time
from typing import Any, Dict, Optional, Tuple
import httpx

from app.schemas.enums import ProviderStatus
from app.schemas.threat_intelligence import ProviderReport


class BaseThreatIntelProvider(ABC):
    """Abstract base class for all asynchronous external threat intelligence adapters."""

    def __init__(self, provider_name: str, api_key: Optional[str] = None):
        self.provider_name = provider_name
        self.api_key = api_key.strip() if api_key and api_key.strip() else None

    @property
    def is_configured(self) -> bool:
        """Verify whether a valid operational API key is present (not a dummy placeholder)."""
        if not self.api_key:
            return False
        lower = self.api_key.lower()
        placeholders = {"your_", "placeholder", "none", "null", "test_key", "change_me"}
        return not any(p in lower for p in placeholders)

    def create_unconfigured_report(self) -> ProviderReport:
        """Generate standardized report when provider lacks valid credentials."""
        return ProviderReport(
            provider_name=self.provider_name,
            status=ProviderStatus.UNCONFIGURED,
            response_time_ms=0,
            threat_details=None,
            check_timestamp=datetime.now(timezone.utc).isoformat(),
            error_category=None,
            raw_evidence=None,
        )

    def create_timeout_report(self, elapsed_ms: int) -> ProviderReport:
        """Generate standardized report when provider exceeds timeout budget."""
        return ProviderReport(
            provider_name=self.provider_name,
            status=ProviderStatus.TIMEOUT,
            response_time_ms=elapsed_ms,
            threat_details=None,
            check_timestamp=datetime.now(timezone.utc).isoformat(),
            error_category="UPSTREAM_TIMEOUT",
            raw_evidence=None,
        )

    def create_error_report(self, elapsed_ms: int, error_category: str) -> ProviderReport:
        """Generate standardized report when provider encounters network or HTTP error."""
        return ProviderReport(
            provider_name=self.provider_name,
            status=ProviderStatus.ERROR,
            response_time_ms=elapsed_ms,
            threat_details=None,
            check_timestamp=datetime.now(timezone.utc).isoformat(),
            error_category=error_category,
            raw_evidence=None,
        )

    @abstractmethod
    async def query_feed(
        self, canonical_url: str, client: httpx.AsyncClient
    ) -> Tuple[ProviderStatus, Optional[str], Optional[Dict[str, Any]], Optional[str]]:
        """Execute upstream feed query.

        Returns:
            (status, threat_details, raw_evidence, error_category)
        """
        pass

    async def check_url(
        self, canonical_url: str, client: Optional[httpx.AsyncClient] = None
    ) -> ProviderReport:
        """Query threat intelligence provider for a target URL with timing and error isolation.

        Args:
            canonical_url: Normalized canonical URL to inspect.
            client: Optional shared httpx.AsyncClient instance.

        Returns:
            ProviderReport conforming to API contract.
        """
        if not self.is_configured:
            return self.create_unconfigured_report()

        start_time = time.monotonic()
        timestamp = datetime.now(timezone.utc).isoformat()

        try:
            if client is not None:
                status, threat_details, raw_evidence, error_category = await self.query_feed(
                    canonical_url, client
                )
            else:
                async with httpx.AsyncClient(timeout=3.0) as local_client:
                    status, threat_details, raw_evidence, error_category = await self.query_feed(
                        canonical_url, local_client
                    )

            elapsed_ms = int((time.monotonic() - start_time) * 1000)

            return ProviderReport(
                provider_name=self.provider_name,
                status=status,
                response_time_ms=elapsed_ms,
                threat_details=threat_details,
                check_timestamp=timestamp,
                error_category=error_category,
                raw_evidence=raw_evidence,
            )

        except (httpx.TimeoutException, TimeoutError):
            elapsed_ms = int((time.monotonic() - start_time) * 1000)
            return self.create_timeout_report(elapsed_ms)

        except httpx.HTTPStatusError as e:
            elapsed_ms = int((time.monotonic() - start_time) * 1000)
            return self.create_error_report(elapsed_ms, f"UPSTREAM_HTTP_{e.response.status_code}")

        except (httpx.RequestError, Exception) as e:
            elapsed_ms = int((time.monotonic() - start_time) * 1000)
            err_type = type(e).__name__.upper()
            return self.create_error_report(elapsed_ms, f"NETWORK_ERROR_{err_type}")

