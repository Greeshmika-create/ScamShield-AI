"""Phase 7 Multilingual Scam Indicator Engine for ScamShield AI.

Security & Architectural Mandates:
- Strictly passive: deterministic rule-based pattern matching in volatile RAM.
- Explainable cybersecurity findings: each indicator maps to a structured ScamIndicator.
- Multilingual threat coverage:
  - English
  - Telugu script & transliterated Telugish
  - Hindi & Marathi (Devanagari)
  - Tamil, Kannada, Malayalam, Bengali
- Strict False-Positive Defenses:
  - Neutral mentions of "OTP", "bank", or "delivery" alone DO NOT trigger threats.
  - Legitimate transaction receipts containing safety notices ("do not share", "never share")
    suppress credential-theft false positives.
  - Demands corroborating action verbs and coercion pressure.
"""

import re
from typing import List, Tuple

from app.schemas.enums import FindingSeverity
from app.schemas.message_analysis import ScamIndicator


# Safety disclaimer patterns in legitimate transactional messages
SAFETY_DISCLAIMER_PATTERNS = [
    re.compile(r"\b(?:do\s+not|never|don't)\s+share\b", re.IGNORECASE),
    re.compile(r"\bnot\s+share\s+with\s+anyone\b", re.IGNORECASE),
    re.compile(r"\bbank\s+never\s+asks?\b", re.IGNORECASE),
    re.compile(r"\bdo\s+not\s+disclose\b", re.IGNORECASE),
    re.compile(r"\bevariki\s+cheppakandi\b", re.IGNORECASE),  # Telugu
    re.compile(r"\bkisi\s+ko\s+na\s+bataye\b", re.IGNORECASE),  # Hindi
    re.compile(r"\byarukkum\s+pagiradheergal\b", re.IGNORECASE),  # Tamil
    re.compile(r"\bshare\s+cheyoddu\b", re.IGNORECASE),  # Telugish
]


class ScamIndicatorEngine:
    """Multilingual threat pattern and social engineering coercion detector."""

    # Categorized rule specifications
    # Format: (rule_name, category, severity, title, description, [regex_patterns])
    RULES: List[Tuple[str, str, FindingSeverity, str, str, List[re.Pattern]]] = [
        # 1. Banking & KYC Account Suspension Threats
        (
            "BANKING_KYC_SUSPENSION",
            "BANKING_KYC_SUSPENSION",
            FindingSeverity.CRITICAL,
            "Urgent Account Suspension & Deceptive KYC Update",
            "Message threatens immediate account deactivation or demands urgent KYC/PAN renewal.",
            [
                # English
                re.compile(r"\b(?:yono|sbi|hdfc|icici|axis|pnb|bob)\s+(?:account|services?)\s+(?:blocked|suspended|deactivated|closed)\b", re.IGNORECASE),
                re.compile(r"\b(?:kyc|pan\s*card|aadhaar)\s+(?:suspended|expired|pending|update\s+immediately)\b", re.IGNORECASE),
                re.compile(r"\bupdate\s+your\s+(?:kyc|pan|bank\s+account)\s+to\s+avoid\s+(?:block|deactivat)", re.IGNORECASE),
                # Telugu & Telugish
                re.compile(r"(?:ఖాతా|ఎకౌంట్|అకౌంట్)\s*(?:బ్లాక్|రద్దు|సస్పెండ్)", re.IGNORECASE),
                re.compile(r"\b(?:account|khata)\s*(?:block\s*aindi|suspend\s*aindi|update\s*cheyandi)\b", re.IGNORECASE),
                re.compile(r"\bkyc\s*(?:update\s*cheyandi|cheyyandi|lekapothe)\b", re.IGNORECASE),
                # Hindi (Devanagari)
                re.compile(r"(?:खाता|अकाउंट)\s*(?:ब्लॉक|बंद|निलंबित)\s*(?:हो\s*गया|कर\s*दिया)", re.IGNORECASE),
                re.compile(r"केवाईसी\s*(?:अपडेट|सत्यापन)\s*(?:करें|नहीं\s*किया)", re.IGNORECASE),
                # Tamil & Kannada
                re.compile(r"(?:கணக்கு|வங்கி)\s*(?:முடக்கப்பட்டது|புதுப்பிக்கவும்)", re.IGNORECASE),
                re.compile(r"(?:ಖಾತೆ|ಬ್ಯಾಂಕ್)\s*(?:ಸ್ಥಗಿತಗೊಂಡಿದೆ|ಅಮಾನತು)", re.IGNORECASE),
            ],
        ),

        # 2. Urgency & Coercive Deadline Threats (Power Cut, Legal Action)
        (
            "URGENCY_COERCION",
            "URGENCY_COERCION",
            FindingSeverity.HIGH,
            "Urgent Utility Disconnection & Coercive Deadline",
            "Message exploits panic and tight deadlines (such as imminent electricity power disconnection).",
            [
                # English
                re.compile(r"\b(?:electricity|power|bill)\s+(?:cut|disconnected?|interrupted?)\s+(?:tonight|today|by|at\s+\d{1,2}\s*(?:pm|am))\b", re.IGNORECASE),
                re.compile(r"\b(?:immediate|urgent)\s+action\s+required\s+within\s+\d+\s*(?:hours?|mins?)\b", re.IGNORECASE),
                re.compile(r"\b(?:apepdcl|tsspdcl|bescom|tneb|mseb|dhbvn|uppcl)\b", re.IGNORECASE),
                # Telugu & Telugish
                re.compile(r"(?:విద్యుత్|కరెంట్)\s*(?:సరఫరా\s*నిలిపివేయబడుతుంది|కట్\s*అవుతుంది)", re.IGNORECASE),
                re.compile(r"\b(?:current\s*bill|power\s*cut)\s*(?:avtundi|avuthundi|lekapothe)\b", re.IGNORECASE),
                re.compile(r"\b(?:9\s*pm|ratiri)\s*ki\s*(?:power|current)\s*cut\b", re.IGNORECASE),
                # Hindi (Devanagari)
                re.compile(r"(?:बिजली|विद्युत)\s*(?:काट\s*दी\s*जाएगी|काटेंगे|कट\s*होगा)", re.IGNORECASE),
                re.compile(r"\bआज\s*रात\s*\d{1,2}\s*बजे\s*बिजली\b", re.IGNORECASE),
            ],
        ),

        # 3. Credential & OTP Theft Coercion
        (
            "CREDENTIAL_OTP_THEFT",
            "CREDENTIAL_OTP_THEFT",
            FindingSeverity.CRITICAL,
            "Credential, PIN, or OTP Extraction Coercion",
            "Message attempts to elicit one-time passwords, PINs, or confidential security credentials.",
            [
                # English
                re.compile(r"\b(?:share|send|provide|give|verify)\s+(?:your\s+)?(?:otp|one[- ]time\s+password|pin|password|mpin)\b", re.IGNORECASE),
                re.compile(r"\b(?:otp|pin)\s+(?:required|needed)\s+to\s+(?:cancel|stop|refund|prevent)\b", re.IGNORECASE),
                re.compile(r"\bforward\s+(?:this\s+)?(?:sms|otp|message)\s+to\b", re.IGNORECASE),
                # Telugu & Telugish
                re.compile(r"\botp\s*(?:cheppandi|ivvandi|share\s*cheyandi|pampandi)\b", re.IGNORECASE),
                re.compile(r"(?:ఓటీపీ|పిన్)\s*(?:చెప్పండి|పంపండి|ఇవ్వండి)", re.IGNORECASE),
                # Hindi (Devanagari)
                re.compile(r"(?:ओटीपी|पिन|पासवर्ड)\s*(?:बताएं|भेजें|साझा\s*करें)", re.IGNORECASE),
            ],
        ),

        # 4. Payment & Counterfeit UPI Collect Fraud
        (
            "PAYMENT_UPI_FRAUD",
            "PAYMENT_UPI_FRAUD",
            FindingSeverity.CRITICAL,
            "Deceptive UPI Payment & PIN Entry Coercion",
            "Message uses fake cashback, refunds, or lottery claims to trick user into entering a UPI PIN.",
            [
                # English
                re.compile(r"\benter\s+(?:upi\s+)?pin\s+to\s+(?:receive|accept|credit|get)\s+(?:money|cash|payment|₹|rs)\b", re.IGNORECASE),
                re.compile(r"\b(?:cashback|refund|prize)\s+(?:of\s+)?(?:₹|rs\.?)\s*\d+.*(?:claim|receive|collect)\b", re.IGNORECASE),
                re.compile(r"\bapprove\s+(?:collect\s+)?request\s+(?:on|in)\s+(?:phonepe|gpay|paytm|bhim)\b", re.IGNORECASE),
                # Telugu & Telugish
                re.compile(r"\bpin\s*(?:enter\s*cheyandi|kottandi)\s*(?:dabbulu|money|vasthundi)\b", re.IGNORECASE),
                re.compile(r"(?:డబ్బులు\s*రావడానికి|పొందడానికి)\s*(?:పిన్\s*నొక్కండి|ఎంటర్\s*చేయండి)", re.IGNORECASE),
                # Hindi (Devanagari)
                re.compile(r"(?:पैसे\s*पाने|रिफंड\s*के)\s*लिए\s*यूपीआई\s*पिन\s*दर्ज\s*करें", re.IGNORECASE),
            ],
        ),

        # 5. Fake Rewards, Lottery & Government Loan Scams
        (
            "LOTTERY_PRIZE_SCAM",
            "LOTTERY_PRIZE_SCAM",
            FindingSeverity.HIGH,
            "Fake Lottery, Lucky Draw, or Unsolicited Loan Approval",
            "Message claims recipient has won an unverified lottery (e.g. KBC) or pre-approved government loan.",
            [
                # English
                re.compile(r"\b(?:won|winner|selected)\s+(?:a\s+)?(?:lottery|lucky\s+draw|cash\s+prize)\s+(?:of\s+)?(?:₹|rs\.?|\$)\s*\d+", re.IGNORECASE),
                re.compile(r"\b(?:kbc|kaun\s+banega\s+crorepati)\s+(?:lottery|head\s+office|sim\s+card)\b", re.IGNORECASE),
                re.compile(r"\b(?:pm\s*yojana|mudra\s*loan|subsidy)\s+(?:approved|granted|sanctioned)\s+(?:of\s+)?(?:₹|rs\.?)\s*\d+", re.IGNORECASE),
                # Telugu & Telugish
                re.compile(r"(?:లక్కీ\s*డ్రా|లాటరీ|బహుమతి)\s*(?:గెలుచుకున్నారు|వచ్చింది)", re.IGNORECASE),
                re.compile(r"\b(?:lottery|prize|loan)\s*(?:geluchukunnaru|vachindi|approved\s*aindi)\b", re.IGNORECASE),
                # Hindi (Devanagari)
                re.compile(r"(?:लॉटरी|इनाम|लोन)\s*(?:जीता\s*है|मंजूर\s*हुआ|स्वीकृत)", re.IGNORECASE),
            ],
        ),

        # 6. Delivery & Unpaid Parcel Impersonation
        (
            "DELIVERY_FEE_SCAM",
            "DELIVERY_FEE_SCAM",
            FindingSeverity.MEDIUM,
            "Fake Courier & Delivery Fee Phishing",
            "Message impersonates postal or courier services claiming package on hold pending small fee.",
            [
                re.compile(r"\b(?:india\s*post|courier|package|parcel|shipment)\s+(?:on\s+hold|cannot\s+be\s+delivered|incomplete\s+address)\b", re.IGNORECASE),
                re.compile(r"\bpay\s+(?:small\s+fee|redelivery\s+charge|₹\s*\d+|rs\.?\s*\d+)\s+to\s+(?:update\s+address|reschedule)\b", re.IGNORECASE),
                re.compile(r"\b(?:update\s+your\s+address\s+within\s+\d+\s*hours|parcel\s+will\s+be\s+returned)\b", re.IGNORECASE),
            ],
        ),

        # 7. Work-From-Home & Fake Job Offers
        (
            "SUSPICIOUS_JOB_OFFER",
            "SUSPICIOUS_JOB_OFFER",
            FindingSeverity.MEDIUM,
            "Deceptive Part-Time Work-From-Home Scam",
            "Message advertises unrealistic daily earnings for trivial tasks (e.g. liking YouTube videos).",
            [
                re.compile(r"\b(?:part[- ]time\s+job|work\s+from\s+home)\b.*(?:earn\s+(?:₹|rs\.?)\s*\d+.*(?:daily|per\s+day))\b", re.IGNORECASE),
                re.compile(r"\b(?:like\s+youtube\s+videos|subscribe|rating\s+products)\s+(?:and\s+)?earn\b", re.IGNORECASE),
                re.compile(r"\bcontact\s+(?:hr|manager)\s+on\s+telegram\s+@?\w+\b", re.IGNORECASE),
            ],
        ),

        # 8. Malicious APK & Remote Support Tool Coercion
        (
            "SUSPICIOUS_APK_INSTALL",
            "SUSPICIOUS_APK_INSTALL",
            FindingSeverity.CRITICAL,
            "Coercive Mobile APK or Remote Access Tool Download",
            "Message instructs recipient to download an Android APK file or remote access application.",
            [
                re.compile(r"\bdownload\s+(?:and\s+install\s+)?(?:the\s+)?(?:app|apk|application)\s+(?:from|via|at)\b", re.IGNORECASE),
                re.compile(r"\bhttps?://[^\s]+\.apk\b", re.IGNORECASE),
                re.compile(r"\b(?:install|download)\s+(?:anydesk|quicksupport|teamviewer|rustdesk)\b", re.IGNORECASE),
            ],
        ),
    ]

    @classmethod
    def has_safety_disclaimer(cls, text: str) -> bool:
        """Check if message contains an explicit legitimate safety advisory (e.g. 'do not share')."""
        return any(pattern.search(text) for pattern in SAFETY_DISCLAIMER_PATTERNS)

    @classmethod
    def evaluate_message(cls, normalized_text: str) -> List[ScamIndicator]:
        """Analyze normalized message string against categorized multilingual threat rules.

        Args:
            normalized_text: Unicode-normalized, zero-width-stripped message text.

        Returns:
            List of detected ScamIndicator models.
        """
        has_safety = cls.has_safety_disclaimer(normalized_text)
        indicators: List[ScamIndicator] = []

        for rule_name, category, severity, title, description, patterns in cls.RULES:
            matched_phrases: List[str] = []

            for pattern in patterns:
                for match in pattern.finditer(normalized_text):
                    phrase = match.group(0).strip()
                    if phrase and phrase not in matched_phrases:
                        matched_phrases.append(phrase)

            if matched_phrases:
                # Anti-False-Positive Filter:
                # If message contains legitimate safety notices ("bank never asks, do not share OTP")
                # and matches credential theft rule, verify whether it's advising against sharing
                if rule_name == "CREDENTIAL_OTP_THEFT" and has_safety:
                    # Check if matching phrase is part of the warning itself
                    # (e.g. "Do not share OTP" -> skip credential theft flag)
                    continue

                indicators.append(
                    ScamIndicator(
                        category=category,
                        rule_name=rule_name,
                        severity=severity,
                        title=title,
                        description=description,
                        matched_phrases=matched_phrases[:5],
                    )
                )

        return indicators

