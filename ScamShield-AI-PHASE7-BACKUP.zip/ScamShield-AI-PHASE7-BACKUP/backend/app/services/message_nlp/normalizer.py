"""Phase 7 Unicode & Text Normalizer for ScamShield AI.

Security & Architectural Mandates:
- Strictly passive: in-memory string processing only.
- Normalizes Unicode safely via NFKC representation.
- Strips and flags adversarial zero-width spaces (\u200B, \u200C, \u200D, \uFEFF) and bidi overrides.
- Preserves distinct Indian script vowel signs, viramas, and consonant clusters.
- Never translates non-English text to English.
- Protects user privacy: server-side PII masking for 6-digit OTPs, 10-digit mobile numbers, and UPI VPAs.
- Full unredacted messages exist ONLY in volatile RAM during request execution.
"""

from dataclasses import dataclass
import re
import unicodedata
from typing import Tuple

from app.schemas.common import mask_sensitive_pii


# Adversarial zero-width and invisible formatting characters
ZERO_WIDTH_CHARS = {
    "\u200B",  # Zero-width space
    "\u200C",  # Zero-width non-joiner
    "\u200D",  # Zero-width joiner
    "\uFEFF",  # Zero-width no-break space / Byte Order Mark
    "\u200E",  # Left-to-right mark
    "\u200F",  # Right-to-left mark
    "\u202A",  # Left-to-right embedding
    "\u202B",  # Right-to-left embedding
    "\u202C",  # Pop directional formatting
    "\u202D",  # Left-to-right override
    "\u202E",  # Right-to-left override
    "\u2066",  # Left-to-right isolate
    "\u2067",  # Right-to-left isolate
    "\u2068",  # First strong isolate
    "\u2069",  # Pop directional isolate
}

ZERO_WIDTH_REGEX = re.compile(
    r"[\u200B\u200C\u200D\uFEFF\u200E\u200F\u202A-\u202E\u2066-\u2069]"
)

UPI_HANDLE_REGEX = re.compile(
    r"(?<![\w.+-])[\w.+-]+@(?:oksbi|okhdfcbank|okicici|okaxis|okbizaxis|"
    r"ybl|ibl|axl|paytm|upi|apl|phonepe|gpay|bhim|sbi|hdfcbank|icici|"
    r"axisbank|yesbank|kotak|indus|airtel|jio|freecharge|amazonpay)\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class NormalizationResult:
    """Outcome of Unicode normalization and invisible character stripping."""

    normalized_text: str
    original_text: str
    zero_width_count: int
    obfuscation_detected: bool
    safe_preview: str


class MessageNormalizer:
    """Deterministic, passive text and Unicode normalizer."""

    @classmethod
    def strip_zero_width_characters(cls, text: str) -> Tuple[str, int]:
        """Detect and remove invisible zero-width characters and directional overrides.

        Returns:
            (cleaned_text, count_of_removed_characters)
        """
        matches = ZERO_WIDTH_REGEX.findall(text)
        count = len(matches)
        cleaned = ZERO_WIDTH_REGEX.sub("", text)
        return cleaned, count

    @classmethod
    def normalize_whitespace(cls, text: str) -> str:
        """Collapse redundant tabs and multiple spaces while preserving structural linebreaks."""
        lines = text.splitlines()
        normalized_lines = []
        for line in lines:
            # Collapse multiple spaces and tabs within the line
            collapsed = re.sub(r"[ \t]+", " ", line).strip()
            if collapsed:
                normalized_lines.append(collapsed)

        return "\n".join(normalized_lines)

    @classmethod
    def create_safe_preview(cls, text: str, max_length: int = 120) -> str:
        """Generate privacy-safe preview string with PII masked and length capped to 120 chars."""
        # 1. Mask OTPs, mobile numbers, and UPI addresses
        masked = mask_sensitive_pii(text)
        masked = masked.replace("[OTP-REDACTED]", "[OTP REDACTED]")
        masked = masked.replace("[PHONE-REDACTED]", "[PHONE REDACTED]")
        masked = UPI_HANDLE_REGEX.sub("[UPI REDACTED]", masked)

        # 2. Collapse internal whitespace to single line
        single_line = " ".join(masked.split())

        # 3. Truncate with ellipsis if exceeds max_length
        if len(single_line) > max_length:
            return single_line[: max_length - 3] + "..."

        return single_line

    @classmethod
    def normalize(cls, raw_text: str) -> NormalizationResult:
        """Execute complete text normalization pipeline on raw submitted message string.

        Args:
            raw_text: Raw untrusted user message input.

        Returns:
            NormalizationResult containing cleaned text, obfuscation markers, and safe preview.
        """
        if not isinstance(raw_text, str):
            raw_text = str(raw_text)

        # 1. Unicode NFKC normalization
        nfkc_text = unicodedata.normalize("NFKC", raw_text)

        # 2. Strip and count zero-width obfuscation characters
        cleaned_text, zero_width_count = cls.strip_zero_width_characters(nfkc_text)

        # 3. Normalize whitespace
        clean_normalized = cls.normalize_whitespace(cleaned_text)

        # 4. Generate safe PII-masked preview
        preview = cls.create_safe_preview(clean_normalized, max_length=120)

        return NormalizationResult(
            normalized_text=clean_normalized,
            original_text=raw_text,
            zero_width_count=zero_width_count,
            obfuscation_detected=zero_width_count > 0,
            safe_preview=preview,
        )

