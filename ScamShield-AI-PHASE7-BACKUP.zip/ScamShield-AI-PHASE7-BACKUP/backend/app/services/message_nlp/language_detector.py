"""Phase 7 Language & Script Detection for ScamShield AI.

Security & Architectural Mandates:
- Strictly passive: offline Unicode code-point inspection and lexical phonetic heuristics.
- ZERO external translation APIs (preserves user message privacy).
- Accurately detects Indian Unicode scripts:
  - Telugu: \\u0C00–\\u0C7F
  - Devanagari (Hindi, Marathi): \\u0900–\\u097F
  - Tamil: \\u0B80–\\u0BFF
  - Kannada: \\u0C80–\\u0CFF
  - Malayalam: \\u0D00–\\u0D7F
  - Bengali: \\u0980–\\u09FF
  - Latin (English, Telugish): \\u0041–\\u005A, \\u0061–\\u007A
- Distinguishes script detection from full grammatical language identification.
- Identifies transliterated Latin-script "Telugish" via phonetic lexical markers.
"""

import re
from typing import Dict, List, Set, Tuple

from app.schemas.enums import DetectedLanguage
from app.schemas.message_analysis import ScriptAssessment


# Unicode Script Code-Point Ranges
SCRIPT_RANGES: Dict[str, Tuple[int, int]] = {
    "TELUGU": (0x0C00, 0x0C7F),
    "DEVANAGARI": (0x0900, 0x097F),
    "TAMIL": (0x0B80, 0x0BFF),
    "KANNADA": (0x0C80, 0x0CFF),
    "MALAYALAM": (0x0D00, 0x0D7F),
    "BENGALI": (0x0980, 0x09FF),
    "LATIN": (0x0041, 0x007A),  # Includes standard ASCII letters
}

# Common transliterated Telugish phonetic markers and function words
TELUGISH_PHONETIC_MARKERS: Set[str] = {
    "mee",
    "meeru",
    "aindi",
    "ayindi",
    "avtundi",
    "avuthundi",
    "cheyandi",
    "cheyyandi",
    "chesukondi",
    "lekapothe",
    "ventane",
    "ravatledu",
    "kaavali",
    "katha",
    "khata",
    "dabbulu",
    "sommu",
    "chudandi",
    "ivvandi",
    "vasthundi",
    "eeroju",
    "ippude",
    "gurinchi",
    "mariyu",
    "leka",
    "kosam",
    "unnadi",
    "choodandi",
}


class LanguageDetector:
    """Offline Unicode script and regional language identifier."""

    @classmethod
    def get_script_for_char(cls, char: str) -> str:
        """Classify a single character's Unicode script."""
        cp = ord(char)

        # Check Latin alphabet
        if (0x0041 <= cp <= 0x005A) or (0x0061 <= cp <= 0x007A):
            return "LATIN"

        # Check Indian scripts
        for script_name, (start, end) in SCRIPT_RANGES.items():
            if script_name != "LATIN" and start <= cp <= end:
                return script_name

        return "OTHER"

    @classmethod
    def calculate_script_distribution(cls, text: str) -> Dict[str, float]:
        """Compute normalized distribution of scripts across linguistic characters."""
        counts: Dict[str, int] = {}
        total_letters = 0

        for char in text:
            # Skip whitespace, digits, and generic punctuation for script evaluation
            if char.isspace() or char.isdigit() or not char.isalnum():
                continue

            script = cls.get_script_for_char(char)
            if script != "OTHER":
                counts[script] = counts.get(script, 0) + 1
                total_letters += 1

        if total_letters == 0:
            return {"UNKNOWN": 1.0}

        return {script: round(c / total_letters, 4) for script, c in counts.items()}

    @classmethod
    def detect_telugish_markers(cls, text: str) -> Tuple[bool, List[str]]:
        """Identify conversational transliterated Telugish markers in Latin text."""
        # Tokenize words using lowercase alphanumeric regex
        words = re.findall(r"\b[a-z]{2,15}\b", text.lower())
        matched = [w for w in words if w in TELUGISH_PHONETIC_MARKERS]
        return len(matched) >= 1, sorted(list(set(matched)))

    @classmethod
    def assess_message(cls, text: str) -> ScriptAssessment:
        """Perform complete offline script and language assessment.

        Args:
            text: Normalized message text.

        Returns:
            ScriptAssessment model.
        """
        dist = cls.calculate_script_distribution(text)

        if "UNKNOWN" in dist:
            return ScriptAssessment(
                primary_script="UNKNOWN",
                detected_language=DetectedLanguage.UNKNOWN,
                is_mixed_script=False,
                script_distribution={"UNKNOWN": 1.0},
                confidence="LOW",
                limitations_notice="Insufficient linguistic characters to determine script.",
            )

        # Sort scripts by descending frequency
        sorted_scripts = sorted(dist.items(), key=lambda item: item[1], reverse=True)
        primary_script, primary_ratio = sorted_scripts[0]

        # A complete word in another script can be meaningful even below 15% of a long message.
        is_mixed = len(sorted_scripts) > 1 and sorted_scripts[1][1] >= 0.05

        # Check for transliterated Telugish in Latin text
        has_telugish, markers = cls.detect_telugish_markers(text)

        # Determine language categorization
        if primary_script == "TELUGU":
            if is_mixed:
                detected_lang = DetectedLanguage.MIXED
            else:
                detected_lang = DetectedLanguage.TELUGU_SCRIPT
            confidence = "HIGH"

        elif primary_script == "LATIN":
            if is_mixed:
                detected_lang = DetectedLanguage.MIXED
                confidence = "MEDIUM"
            elif has_telugish:
                detected_lang = DetectedLanguage.TELUGISH
                confidence = "HIGH"
            else:
                detected_lang = DetectedLanguage.ENGLISH
                confidence = "HIGH"

        elif primary_script in {"DEVANAGARI", "TAMIL", "KANNADA", "MALAYALAM", "BENGALI"}:
            if is_mixed:
                detected_lang = DetectedLanguage.MIXED
            else:
                # Script is verified; specific language maps to UNKNOWN or MIXED without full morphological parser
                detected_lang = DetectedLanguage.UNKNOWN
            confidence = "HIGH"

        else:
            detected_lang = DetectedLanguage.UNKNOWN
            confidence = "LOW"

        limitations = (
            f"Primary script '{primary_script}' detected via Unicode inspection. "
            "Full semantic language identification for shared scripts (e.g., Devanagari for Hindi/Marathi) "
            "requires secondary dictionary/lexical modeling."
        )

        return ScriptAssessment(
            primary_script=primary_script,
            detected_language=detected_lang,
            is_mixed_script=is_mixed,
            script_distribution=dist,
            confidence=confidence,
            limitations_notice=limitations,
        )

