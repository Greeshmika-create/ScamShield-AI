"""Phase 7 Quantitative Message Feature and Sub-Word N-Gram Extractor for ScamShield AI.

Security & Architectural Mandates:
- Strictly passive: pure lexical feature extraction in volatile memory.
- ZERO outbound network queries: does NOT fetch extracted URLs or contact phone numbers.
- Extracts sub-word character n-grams (n=2 to 5) with word boundary markers.
- Extracts structural metrics: URLs, phone numbers, currency references, urgency markers.
"""

import re
from typing import List, Set, Tuple

from app.schemas.message_analysis import MessageFeatures


# Regex for extracting candidate URLs (HTTP/HTTPS, www, and common TLD paths)
URL_EXTRACTION_REGEX = re.compile(
    r"(?:https?://[^\s<>\"']+|www\.[a-zA-Z0-9-]+\.[^\s<>\"']+|[a-zA-Z0-9-]+\.(?:com|in|org|net|xyz|top|online|vip|app|site|live|co\.in)/[^\s<>\"']*)",
    re.IGNORECASE,
)

# Regex for extracting Indian mobile phone numbers (10 digits starting with 6-9, with optional +91 or 0 prefix)
INDIAN_PHONE_REGEX = re.compile(
    r"(?:\+91[\s-]?)?[6-9]\d{9}\b"
)

# Currency symbols and keywords
CURRENCY_REGEX = re.compile(
    r"(?:₹|rs\.?|inr|\$|\beuros?)\s*\d+",
    re.IGNORECASE,
)

# Urgency keywords across English and regional transliterations
URGENCY_REGEX = re.compile(
    r"\b(?:immediately|urgent|urgently|today|tonight|within\s+\d+\s*(?:hours?|mins?)|expire|expiring|deadline|last\s+chance|ventane|ippude|eeroju|turant|aaj\s*hi)\b",
    re.IGNORECASE,
)

# Credential request keywords
CREDENTIAL_REGEX = re.compile(
    r"\b(?:otp|one[- ]time\s+password|pin|mpin|cvv|password|passcode)\b",
    re.IGNORECASE,
)

# APK or remote management tool keywords
APK_REGEX = re.compile(
    r"(?:\.apk\b|anydesk|quicksupport|teamviewer|rustdesk|\bdownload\s+app\b)",
    re.IGNORECASE,
)


class MessageFeatureExtractor:
    """Extracts quantitative lexical, structural, and n-gram features from normalized text."""

    @classmethod
    def extract_urls(cls, text: str) -> List[str]:
        """Extract candidate URL strings passively without network connection."""
        raw_urls = URL_EXTRACTION_REGEX.findall(text)
        cleaned_urls = []
        for url in raw_urls:
            # Strip trailing punctuation (periods, commas, parens)
            u = url.rstrip(".,;:!?)>\"'")
            if u and u not in cleaned_urls:
                cleaned_urls.append(u)
        return cleaned_urls

    @classmethod
    def extract_phone_numbers(cls, text: str) -> List[str]:
        """Extract candidate Indian telephone numbers."""
        matches = INDIAN_PHONE_REGEX.findall(text)
        cleaned_phones = []
        for phone in matches:
            p = re.sub(r"[\s-]", "", phone)
            if p and p not in cleaned_phones:
                cleaned_phones.append(p)
        return cleaned_phones

    @classmethod
    def generate_subword_char_ngrams(
        cls, text: str, min_n: int = 2, max_n: int = 5, max_ngrams: int = 30
    ) -> List[str]:
        """Generate sub-word character n-grams with word boundary markers (<word>).

        Resilient against regional phonetic transliteration variations (e.g. cheyandi vs cheyyandi).
        """
        words = re.findall(r"\b\w+\b", text.lower())
        ngrams_set: Set[str] = set()

        for word in words:
            padded = f"<{word}>"
            word_len = len(padded)
            for n in range(min_n, max_n + 1):
                if word_len >= n:
                    for i in range(word_len - n + 1):
                        ngrams_set.add(padded[i : i + n])
                        if len(ngrams_set) >= max_ngrams:
                            return sorted(list(ngrams_set))

        return sorted(list(ngrams_set))

    @classmethod
    def extract_features(cls, text: str, zero_width_count: int = 0) -> MessageFeatures:
        """Extract quantitative features from normalized text.

        Args:
            text: Normalized message text.
            zero_width_count: Count of stripped zero-width characters.

        Returns:
            MessageFeatures schema instance.
        """
        urls = cls.extract_urls(text)
        phones = cls.extract_phone_numbers(text)
        currency_matches = CURRENCY_REGEX.findall(text)
        urgency_matches = URGENCY_REGEX.findall(text)
        credential_matches = CREDENTIAL_REGEX.findall(text)
        has_apk = bool(APK_REGEX.search(text))

        words = text.split()

        return MessageFeatures(
            message_length=len(text),
            word_count=len(words),
            url_count=len(urls),
            extracted_urls=urls,
            phone_count=len(phones),
            extracted_phones=phones,
            currency_count=len(currency_matches),
            urgency_count=len(urgency_matches),
            credential_request_count=len(credential_matches),
            zero_width_obfuscation_count=zero_width_count,
            has_apk_reference=has_apk,
        )

