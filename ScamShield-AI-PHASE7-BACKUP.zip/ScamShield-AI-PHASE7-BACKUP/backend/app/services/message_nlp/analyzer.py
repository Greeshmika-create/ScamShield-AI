"""Phase 7 Multilingual Message Analyzer Coordinator for ScamShield AI.

Security & Architectural Mandates:
- Strictly passive: deterministic in-memory orchestration of normalizer,
  language detector, feature extractor, and indicator engine.
- Volatile RAM only: raw message body is never logged or persisted.
- Privacy-safe previews with PII masked (OTPs, mobile numbers, UPI VPAs).
- Deterministic heuristic threat score calculation (0 to 100).
- Robust error handling: captures unexpected exceptions and returns safe fallback
  status="ERROR" without crashing or exposing stack traces.
- ZERO external network requests: no DNS queries, no HTTP requests, no phone validation calls.
"""

import logging
from typing import List

from app.schemas.enums import DetectedLanguage, FindingSeverity
from app.schemas.message_analysis import (
    MessageAnalysisResult,
    MessageFeatures,
    ScamIndicator,
    ScriptAssessment,
)
from app.services.message_nlp.feature_extractor import MessageFeatureExtractor
from app.services.message_nlp.indicator_engine import ScamIndicatorEngine
from app.services.message_nlp.language_detector import LanguageDetector
from app.services.message_nlp.normalizer import MessageNormalizer, NormalizationResult

logger = logging.getLogger(__name__)

# Heuristic score weights per finding severity
SEVERITY_WEIGHTS = {
    FindingSeverity.CRITICAL: 40,
    FindingSeverity.HIGH: 25,
    FindingSeverity.MEDIUM: 15,
    FindingSeverity.LOW: 5,
    FindingSeverity.INFO: 0,
}


class MessageAnalyzer:
    """Coordinates multilingual text normalization, script assessment, feature extraction, and indicator matching."""

    @classmethod
    def calculate_threat_score(
        cls,
        indicators: List[ScamIndicator],
        features: MessageFeatures,
    ) -> int:
        """Calculate deterministic heuristic threat score between 0 and 100.

        Formula:
        - Base sum of weights per detected indicator severity.
        - Add 10 points if zero-width obfuscation detected.
        - Capped strictly at 100.
        """
        if not indicators and features.zero_width_obfuscation_count == 0 and not features.has_apk_reference:
            return 0

        score = 0
        for indicator in indicators:
            weight = SEVERITY_WEIGHTS.get(indicator.severity, 10)
            score += weight

        if features.zero_width_obfuscation_count > 0:
            score += 10

        # Bound score strictly to [0, 100]
        return min(max(score, 0), 100)

    @classmethod
    def generate_summary(
        cls,
        indicators: List[ScamIndicator],
        assessment: ScriptAssessment,
        threat_score: int,
    ) -> str:
        """Formulate a concise, human-readable summary of analysis findings."""
        if not indicators:
            return "No known scam indicators detected in message text. Exercise standard vigilance."

        category_titles = [ind.title for ind in indicators]
        lang_note = f"in {assessment.detected_language.value}" if assessment.detected_language != DetectedLanguage.UNKNOWN else ""

        if len(category_titles) == 1:
            return f"Suspicious indicator detected {lang_note}: {category_titles[0]} (Threat score: {threat_score}/100)."
        else:
            joined = "; ".join(category_titles[:3])
            return f"{len(indicators)} suspicious indicators detected {lang_note}: {joined} (Threat score: {threat_score}/100)."

    @classmethod
    def analyze(cls, raw_text: str) -> MessageAnalysisResult:
        """Perform end-to-end passive analysis on untrusted message string.

        Args:
            raw_text: Raw message content from user.

        Returns:
            MessageAnalysisResult with structured findings, features, and threat assessment.
        """
        # Protect against non-string input
        if not isinstance(raw_text, str):
            raw_text = str(raw_text) if raw_text is not None else ""

        # Handle empty or whitespace-only input safely
        if not raw_text.strip():
            return MessageAnalysisResult(
                status="NO_KNOWN_INDICATORS",
                message_preview="",
                script_assessment=ScriptAssessment(
                    primary_script="UNKNOWN",
                    detected_language=DetectedLanguage.UNKNOWN,
                    is_mixed_script=False,
                    script_distribution={"UNKNOWN": 1.0},
                    confidence="LOW",
                    limitations_notice="Empty message provided.",
                ),
                features=MessageFeatures(
                    message_length=0,
                    word_count=0,
                    url_count=0,
                    extracted_urls=[],
                    phone_count=0,
                    extracted_phones=[],
                    currency_count=0,
                    urgency_count=0,
                    credential_request_count=0,
                    zero_width_obfuscation_count=0,
                    has_apk_reference=False,
                ),
                indicators=[],
                threat_score_estimate=0,
                summary="Empty message text provided for analysis.",
            )

        try:
            # 1. Normalize Unicode and strip zero-width obfuscation
            norm: NormalizationResult = MessageNormalizer.normalize(raw_text)

            # 2. Assess script composition and language markers
            assessment: ScriptAssessment = LanguageDetector.assess_message(norm.normalized_text)

            # 3. Extract quantitative features and candidate URLs/phones
            features: MessageFeatures = MessageFeatureExtractor.extract_features(
                norm.normalized_text,
                zero_width_count=norm.zero_width_count,
            )

            # 4. Evaluate multilingual scam indicators and coercion patterns
            indicators: List[ScamIndicator] = ScamIndicatorEngine.evaluate_message(norm.normalized_text)

            # 5. Calculate heuristic threat score estimate
            threat_score = cls.calculate_threat_score(indicators, features)

            # 6. Determine status and summary
            status = "ANALYZED" if (indicators or threat_score > 0) else "NO_KNOWN_INDICATORS"
            summary = cls.generate_summary(indicators, assessment, threat_score)

            return MessageAnalysisResult(
                status=status,
                message_preview=norm.safe_preview,
                script_assessment=assessment,
                features=features,
                indicators=indicators,
                threat_score_estimate=threat_score,
                summary=summary,
            )

        except Exception as err:
            logger.error(f"Message analysis error occurred: {type(err).__name__}")
            safe_preview = MessageNormalizer.create_safe_preview(raw_text[:120])
            return MessageAnalysisResult(
                status="ERROR",
                message_preview=safe_preview,
                script_assessment=ScriptAssessment(
                    primary_script="UNKNOWN",
                    detected_language=DetectedLanguage.UNKNOWN,
                    is_mixed_script=False,
                    script_distribution={"UNKNOWN": 1.0},
                    confidence="LOW",
                    limitations_notice="Analysis encountered an internal processing error.",
                ),
                features=MessageFeatures(
                    message_length=len(raw_text),
                    word_count=len(raw_text.split()),
                    url_count=0,
                    extracted_urls=[],
                    phone_count=0,
                    extracted_phones=[],
                    currency_count=0,
                    urgency_count=0,
                    credential_request_count=0,
                    zero_width_obfuscation_count=0,
                    has_apk_reference=False,
                ),
                indicators=[],
                threat_score_estimate=0,
                summary="Analysis could not be completed due to an internal processing error.",
            )

