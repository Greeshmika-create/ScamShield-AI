"""Secure request lifecycle middleware for ScamShield AI.

Provides:
1. Request ID tracing with client-supplied format validation.
2. Monotonic request processing time measurement (X-Process-Time).
3. Safe structured access logging with URL query parameter and header redaction.
4. Security response headers (X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Cache-Control).
5. Request body size limits (1MB) and Content-Type validation for JSON endpoints.
"""

import logging
import re
import time
from urllib.parse import parse_qsl, urlencode
import uuid
from typing import Callable, Optional, Set, Union
from fastapi import Request, Response, status
from fastapi.datastructures import URL
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import ClientDisconnect

from app.core.errors import PayloadTooLargeException, _build_error_payload
from app.core.logging import get_request_id, reset_request_id, set_request_id

access_logger = logging.getLogger("scamshield.access")
error_logger = logging.getLogger("scamshield.errors")

# Status 413 (RFC 9110 HTTP_413_CONTENT_TOO_LARGE)
HTTP_413_STATUS = getattr(status, "HTTP_413_CONTENT_TOO_LARGE", 413)

# Maximum permitted payload size: 1MB (1,048,576 bytes)
MAX_REQUEST_BODY_SIZE = 1_048_576

# Regex for client-supplied correlation IDs: must be safe alphanumeric/hyphen/underscore (8 to 64 chars)
REQUEST_ID_REGEX = re.compile(r"^[a-zA-Z0-9_\-]{8,64}$")

# Sensitive query parameter keys that must be redacted from logs
SENSITIVE_QUERY_KEYS: Set[str] = {
    "token",
    "secret",
    "password",
    "passwd",
    "key",
    "api_key",
    "apikey",
    "auth",
    "authorization",
    "otp",
    "code",
    "account",
    "card",
    "phone",
    "session",
    "cookie",
    "access_token",
    "refresh_token",
}


def validate_client_correlation_id(incoming_header: Optional[str]) -> Optional[str]:
    """Validate incoming client correlation identifier against strict alphanumeric format.

    Returns the sanitized string if valid (8 to 64 chars matching ^[a-zA-Z0-9_-]{8,64}$),
    or None if invalid or missing.
    Untrusted client correlation IDs are never used as authoritative server request IDs.
    """
    if incoming_header:
        candidate = incoming_header.strip()
        if REQUEST_ID_REGEX.match(candidate):
            return candidate
    return None


def validate_or_generate_request_id(incoming_header: Optional[str] = None) -> str:
    """Always generate a server-authoritative UUIDv4 request ID.

    Preserved for backward-compatible call signatures, but never trusts client-supplied values.
    """
    return str(uuid.uuid4())


def sanitize_url_path(url: Union[URL, str]) -> str:
    """Sanitize URL path and query parameters to avoid logging secrets, tokens, or PII."""
    parsed_url = URL(url) if isinstance(url, str) else url
    path = parsed_url.path
    if not parsed_url.query:
        return path

    pairs = parse_qsl(parsed_url.query, keep_blank_values=True)
    sanitized_pairs = []
    for k, v in pairs:
        k_normalized = k.lower().replace("-", "_")
        if k_normalized in SENSITIVE_QUERY_KEYS or any(
            sub in k_normalized for sub in ("token", "secret", "password", "auth", "otp")
        ):
            sanitized_pairs.append((k, "[REDACTED]"))
        else:
            sanitized_pairs.append((k, v))

    return f"{path}?{urlencode(sanitized_pairs)}"


class RequestTracingMiddleware(BaseHTTPMiddleware):
    """
    Middleware managing request correlation and performance timing.

    1. Always generates an authoritative server-controlled UUIDv4 for every request.
    2. Validates any client-supplied correlation header (X-Request-ID, X-Correlation-ID,
       X-Client-Correlation-ID) strictly and keeps it isolated as untrusted client correlation ID.
    3. Measures monotonic duration using time.perf_counter().
    4. Exposes server request ID in logging contextvar.
    5. Emits structured access log with sanitized paths and zero body leakage.
    6. Injects X-Request-ID (authoritative) and X-Process-Time on all responses.
    7. Injects X-Client-Correlation-ID if a valid client correlation ID was provided.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        start_time = time.perf_counter()

        # Always generate a server-controlled authoritative request ID (UUIDv4)
        server_req_id = str(uuid.uuid4())

        # Extract and validate client correlation ID strictly (untrusted, isolated)
        raw_client_id = (
            request.headers.get("X-Client-Correlation-ID")
            or request.headers.get("X-Correlation-ID")
            or request.headers.get("X-Request-ID")
        )
        client_corr_id = validate_client_correlation_id(raw_client_id)

        # Attach to request state and contextvar
        request.state.request_id = server_req_id
        request.state.client_correlation_id = client_corr_id
        token = set_request_id(server_req_id)

        try:
            try:
                response = await call_next(request)
            except Exception as exc:
                # Handle unhandled errors that escape route handlers and log with correlation id
                error_logger.exception(
                    "[%s] Unhandled exception during request processing on %s %s: %s",
                    server_req_id,
                    request.method,
                    request.url.path,
                    str(exc),
                )
                error_headers = {"X-Request-ID": server_req_id}
                if client_corr_id:
                    error_headers["X-Client-Correlation-ID"] = client_corr_id

                response = JSONResponse(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    content=_build_error_payload(
                        error_code="INTERNAL_ERROR",
                        message="An unexpected internal server error occurred.",
                        request_id=server_req_id,
                    ),
                    headers=error_headers,
                )

            duration = time.perf_counter() - start_time

            # Attach headers
            response.headers["X-Request-ID"] = server_req_id
            if client_corr_id:
                response.headers["X-Client-Correlation-ID"] = client_corr_id
            response.headers["X-Process-Time"] = f"{duration:.6f}s"

            # Log completion safely while request_id is still active in context
            sanitized_path = sanitize_url_path(request.url)
            if client_corr_id:
                access_logger.info(
                    "[%s] HTTP %s %s completed with status %d in %.2fms (client_corr_id=%s)",
                    server_req_id,
                    request.method,
                    sanitized_path,
                    response.status_code,
                    duration * 1000,
                    client_corr_id,
                )
            else:
                access_logger.info(
                    "[%s] HTTP %s %s completed with status %d in %.2fms",
                    server_req_id,
                    request.method,
                    sanitized_path,
                    response.status_code,
                    duration * 1000,
                )

            return response
        finally:
            reset_request_id(token)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """
    Injects enterprise security headers on every HTTP response.

    - X-Content-Type-Options: nosniff
    - X-Frame-Options: DENY
    - Referrer-Policy: strict-origin-when-cross-origin
    - Cache-Control: no-store, no-cache for API data endpoints
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        response = await call_next(request)

        # Core API security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"

        # Sensitive API data endpoints must never be cached by intermediaries
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"

        return response


class RequestProtectionMiddleware(BaseHTTPMiddleware):
    """
    Enforces payload size boundaries and Content-Type validation for JSON API endpoints.

    - Rejects request bodies exceeding 1MB (HTTP 413) via Content-Length or streaming byte count.
    - Prevents unbounded buffering by interrupting streaming requests as soon as 1MB is exceeded.
    - Enforces Content-Type 'application/json' on POST/PUT/PATCH requests with bodies (HTTP 415).
    - Preserves valid JSON payloads under 1MB.
    - Safely handles client disconnects or malformed streams.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        # Only inspect mutation requests targeting /api/ routes
        if request.url.path.startswith("/api/") and request.method in ("POST", "PUT", "PATCH"):
            content_length_header = request.headers.get("content-length")
            transfer_encoding = request.headers.get("transfer-encoding", "").strip().lower()

            # 1. Fast Content-Length header size check before consuming stream
            if content_length_header:
                try:
                    content_length = int(content_length_header)
                    if content_length > MAX_REQUEST_BODY_SIZE:
                        req_id = getattr(request.state, "request_id", None) or get_request_id()
                        headers = {"X-Request-ID": req_id} if req_id else {}
                        return JSONResponse(
                            status_code=HTTP_413_STATUS,
                            content=_build_error_payload(
                                error_code="INVALID_INPUT_FORMAT",
                                message="Request payload exceeds maximum allowed size of 1MB.",
                                request_id=req_id,
                            ),
                            headers=headers,
                        )
                except ValueError:
                    req_id = getattr(request.state, "request_id", None) or get_request_id()
                    headers = {"X-Request-ID": req_id} if req_id else {}
                    return JSONResponse(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        content=_build_error_payload(
                            error_code="INVALID_INPUT_FORMAT",
                            message="Invalid Content-Length header provided.",
                            request_id=req_id,
                        ),
                        headers=headers,
                    )

            # 2. Content-Type validation
            # Check if body is indicated (Content-Length > 0, chunked transfer encoding, or Content-Type header present)
            content_type = request.headers.get("content-type", "").strip().lower()
            has_body_indication = (
                (content_length_header is not None and content_length_header != "0")
                or transfer_encoding == "chunked"
                or bool(content_type)
            )
            if has_body_indication:
                if not content_type or not content_type.startswith("application/json"):
                    req_id = getattr(request.state, "request_id", None) or get_request_id()
                    headers = {"X-Request-ID": req_id} if req_id else {}
                    return JSONResponse(
                        status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                        content=_build_error_payload(
                            error_code="INVALID_INPUT_FORMAT",
                            message="Unsupported Media Type: Content-Type must be 'application/json' for JSON API endpoints.",
                            request_id=req_id,
                        ),
                        headers=headers,
                    )

            # 3. Streamed byte counting (for chunked requests or requests without Content-Length)
            # Wraps ASGI receive to enforce the 1MB cap dynamically on actual received bytes.
            # Avoids unbounded buffering by stopping as soon as received_bytes > MAX_REQUEST_BODY_SIZE.
            original_receive = request._receive
            received_bytes = 0

            async def bounded_receive() -> dict:
                nonlocal received_bytes
                message = await original_receive()
                if message.get("type") == "http.request":
                    chunk = message.get("body", b"")
                    received_bytes += len(chunk)
                    if received_bytes > MAX_REQUEST_BODY_SIZE:
                        request.state.payload_too_large = True
                        raise PayloadTooLargeException("Request payload exceeds maximum allowed size of 1MB.")
                return message

            request._receive = bounded_receive

        try:
            response = await call_next(request)
        except (PayloadTooLargeException, ClientDisconnect, BaseExceptionGroup) as exc:
            target_exc = exc
            if isinstance(exc, BaseExceptionGroup):
                matched_payload, _ = exc.split(PayloadTooLargeException)
                if matched_payload:
                    target_exc = PayloadTooLargeException("Request payload exceeds maximum allowed size of 1MB.")
                else:
                    matched_disconnect, _ = exc.split(ClientDisconnect)
                    if matched_disconnect:
                        target_exc = ClientDisconnect()
                    else:
                        raise

            req_id = getattr(request.state, "request_id", None) or get_request_id()
            headers = {"X-Request-ID": req_id} if req_id else {}

            if isinstance(target_exc, PayloadTooLargeException):
                return JSONResponse(
                    status_code=HTTP_413_STATUS,
                    content=_build_error_payload(
                        error_code="INVALID_INPUT_FORMAT",
                        message=target_exc.message if hasattr(target_exc, "message") else "Request payload exceeds maximum allowed size of 1MB.",
                        request_id=req_id,
                    ),
                    headers=headers,
                )
            if isinstance(target_exc, ClientDisconnect):
                return JSONResponse(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    content=_build_error_payload(
                        error_code="INVALID_INPUT_FORMAT",
                        message="Client disconnected before request stream completed.",
                        request_id=req_id,
                    ),
                    headers=headers,
                )
            raise

        if getattr(request.state, "payload_too_large", False):
            req_id = getattr(request.state, "request_id", None) or get_request_id()
            headers = {"X-Request-ID": req_id} if req_id else {}
            return JSONResponse(
                status_code=HTTP_413_STATUS,
                content=_build_error_payload(
                    error_code="INVALID_INPUT_FORMAT",
                    message="Request payload exceeds maximum allowed size of 1MB.",
                    request_id=req_id,
                ),
                headers=headers,
            )

        return response
