"""Centralized secure logging configuration for ScamShield AI."""

from contextvars import ContextVar, Token
import logging
import re
import sys
from typing import Any, Dict, List, Optional, Tuple, Union

# ContextVar storing the current request ID across asyncio tasks
request_id_ctx_var: ContextVar[Optional[str]] = ContextVar("request_id", default=None)


def get_request_id() -> Optional[str]:
    """Retrieve current request ID from asyncio context."""
    return request_id_ctx_var.get()


def set_request_id(req_id: Optional[str]) -> Token[Optional[str]]:
    """Set current request ID in asyncio context."""
    return request_id_ctx_var.set(req_id)


def reset_request_id(token: Token[Optional[str]]) -> None:
    """Reset request ID context to previous state."""
    request_id_ctx_var.reset(token)


class RequestIdFilter(logging.Filter):
    """Injects current request_id from contextvar into log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = get_request_id() or "-"
        return True


class SensitiveDataFilter(logging.Filter):
    """Redacts potential secrets, keys, passwords, OTPs, and tokens from log output."""

    SENSITIVE_KEY_PATTERN = re.compile(
        r"(?i)\b(api[-_]?key|secret|password|passwd|token|auth|authorization|otp|cookie|session[-_]?id|access[-_]?token|refresh[-_]?token|service[-_]?role[-_]?key)\b\s*[:=]\s*([^\s,;&\'\"]+)"
    )
    BEARER_PATTERN = re.compile(r"(?i)\bBearer\s+[a-zA-Z0-9_\-\.]+")
    OTP_PATTERN = re.compile(r"\b\d{6}\b")
    PHONE_PATTERN = re.compile(r"(?:\+91[\-\s]?)?[6-9]\d{9}\b")
    ACCOUNT_PATTERN = re.compile(r"\b\d{4}[ -]?\d{4}[ -]?\d{4}(?:[ -]?\d{4})?\b")

    def _sanitize_string(self, text: str) -> str:
        """Apply redaction regex passes to a text string."""
        sanitized = self.SENSITIVE_KEY_PATTERN.sub(r"\1=[REDACTED]", text)
        sanitized = self.BEARER_PATTERN.sub("Bearer [REDACTED]", sanitized)
        sanitized = self.OTP_PATTERN.sub("[OTP-REDACTED]", sanitized)
        sanitized = self.PHONE_PATTERN.sub("[PHONE-REDACTED]", sanitized)
        sanitized = self.ACCOUNT_PATTERN.sub("[ACCOUNT-REDACTED]", sanitized)
        return sanitized

    def _sanitize_obj(self, obj: Any) -> Any:
        if isinstance(obj, str):
            return self._sanitize_string(obj)
        elif isinstance(obj, dict):
            return {k: self._sanitize_obj(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._sanitize_obj(v) for v in obj]
        elif isinstance(obj, tuple):
            return tuple(self._sanitize_obj(v) for v in obj)
        return obj

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = self._sanitize_string(record.msg)
        if record.args:
            record.args = self._sanitize_obj(record.args)
        return True


def setup_logging(log_level: Optional[str] = "INFO") -> None:
    """Configure centralized application logger."""
    level = getattr(logging, (log_level or "INFO").upper(), logging.INFO)

    log_format = (
        "%(asctime)s | %(levelname)-8s | [%(request_id)s] %(name)s:%(funcName)s:%(lineno)d - %(message)s"
    )
    date_format = "%Y-%m-%d %H:%M:%S"

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    # Remove existing handlers to avoid duplicates, preserving test harness LogCapture handlers
    for handler in list(root_logger.handlers):
        if not type(handler).__name__.startswith("LogCapture"):
            root_logger.removeHandler(handler)

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    formatter = logging.Formatter(fmt=log_format, datefmt=date_format)
    console_handler.setFormatter(formatter)
    console_handler.addFilter(RequestIdFilter())
    console_handler.addFilter(SensitiveDataFilter())

    root_logger.addHandler(console_handler)

    # Set external libraries to warning by default to reduce noise
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.error").setLevel(logging.INFO)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
