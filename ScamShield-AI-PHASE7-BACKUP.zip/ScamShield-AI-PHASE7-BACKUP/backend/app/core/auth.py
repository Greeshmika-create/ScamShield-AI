"""Pluggable authentication verification abstraction for ScamShield AI.

Separates token verification from route handlers and business logic.
Provides foundations for Phase 10 Supabase Auth JWT verification while failing
closed when unconfigured in Phase 3.4.
"""

from abc import ABC, abstractmethod
import logging
from typing import Any, Dict, Optional
from fastapi import Depends
import jwt
from jwt.exceptions import ExpiredSignatureError, InvalidTokenError

from app.core.config import Settings, get_settings
from app.core.errors import ServiceUnavailableException, UnauthorizedException
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import AccountStatus, AuthProvider, UserRole

logger = logging.getLogger("scamshield.auth")


class TokenVerifier(ABC):
    """Abstract base class for pluggable authentication token verification.

    Must validate:
    - Token signature with authoritative key/secret.
    - Token expiration (exp).
    - Expected audience (aud).
    - Expected issuer (iss) when configured.
    """

    @abstractmethod
    async def verify_token(self, token: str) -> AuthenticatedPrincipal:
        """Verify an incoming bearer token and extract an authenticated principal.

        Raises:
            UnauthorizedException: If token is expired, tampered, malformed, or has invalid claims.
            ServiceUnavailableException: If identity provider is unconfigured or unreachable.
        """
        pass


class UnconfiguredTokenVerifier(TokenVerifier):
    """Default production verifier when no external authentication provider is configured.

    Fails closed: Rejects token validation with HTTP 503 Service Unavailable.
    Never accepts arbitrary tokens, bypasses, or mock sessions in production.
    """

    async def verify_token(self, token: str) -> AuthenticatedPrincipal:
        logger.warning("Authentication attempted but no authentication provider is configured.")
        raise ServiceUnavailableException(
            message="Authentication provider is currently unconfigured or unavailable."
        )


class SupabaseTokenVerifier(TokenVerifier):
    """Supabase JWT token verification foundation.

    Signing-Key Strategy & Phase 10 Asymmetric/JWKS Architecture:
    ------------------------------------------------------------
    1. Symmetric Signing (HS256 - Current Phase 3.4 Baseline):
       - Uses HMAC-SHA256 with SUPABASE_JWT_SECRET shared between Supabase and ScamShield AI.
       - Token header algorithm is strictly verified against an explicit allowlist.
    2. Asymmetric Signing (RS256 / ES256 - Phase 10 Evolution):
       - When configured for JWKS in Phase 10, SupabaseTokenVerifier can resolve public keys from
         `{SUPABASE_URL}/auth/v1/.well-known/jwks.json`.
       - Algorithm Confusion Prevention: HMAC secret verification and Public Key verification are never
         permitted to overlap or fall back. If an RS256 token is received when only HS256 is allowed,
         it is rejected immediately.
       - No Insecure Fallbacks: "none" algorithm and unverified signature decoding are strictly prohibited.
    """

    def __init__(self, settings: Settings):
        self.settings = settings
        self.secret = settings.SUPABASE_JWT_SECRET
        self.audience = settings.SUPABASE_JWT_AUDIENCE
        self.issuer = settings.expected_jwt_issuer
        self.allowed_algorithms = list(settings.ALLOWED_JWT_ALGORITHMS or ["HS256"])

    async def verify_token(self, token: str) -> AuthenticatedPrincipal:
        if not self.secret or not self.secret.strip():
            logger.error("Supabase JWT secret is not configured in settings.")
            raise ServiceUnavailableException(
                message="Authentication provider is currently unconfigured or unavailable."
            )

        # 1. Header and algorithm inspection (prevents algorithm confusion and "none" attacks)
        try:
            unverified_header = jwt.get_unverified_header(token)
        except Exception as exc:
            logger.info("Authentication failed: Malformed JWT header (%s)", str(exc))
            raise UnauthorizedException(message="Invalid or tampered authentication credentials.")

        token_alg = unverified_header.get("alg")
        if not token_alg or token_alg.upper() == "NONE" or token_alg not in self.allowed_algorithms:
            logger.warning("Rejected token with disallowed or missing algorithm: %s", token_alg)
            raise UnauthorizedException(
                message=f"Unsupported or disallowed JWT signing algorithm: '{token_alg}'."
            )

        # 2. Strict claim requirements (signature, expiration, audience, issuer)
        require_claims = ["exp", "sub"]
        if self.audience:
            require_claims.append("aud")
        if self.issuer:
            require_claims.append("iss")

        options = {
            "require": require_claims,
            "verify_signature": True,
            "verify_exp": True,
            "verify_aud": bool(self.audience),
            "verify_iss": bool(self.issuer),
        }

        try:
            payload: Dict[str, Any] = jwt.decode(
                token,
                key=self.secret,
                algorithms=self.allowed_algorithms,
                audience=self.audience if self.audience else None,
                issuer=self.issuer if self.issuer else None,
                options=options,
            )
        except ExpiredSignatureError:
            logger.info("Authentication failed: Bearer token has expired.")
            raise UnauthorizedException(message="Authentication token has expired. Please log in again.")
        except InvalidTokenError as exc:
            logger.info("Authentication failed: Invalid token claims or signature (%s)", str(exc))
            raise UnauthorizedException(message="Invalid or tampered authentication credentials.")

        # 3. Subject validation
        user_id = str(payload.get("sub", "")).strip()
        if not user_id:
            raise UnauthorizedException(message="Token does not contain a valid subject claim.")

        email = payload.get("email")

        # 4. Role resolution: Strictly extract ONLY from trusted app_metadata.role
        # In Supabase Auth:
        # - app_metadata is server-controlled by service role/administrators.
        # - user_metadata is client-writable by end users and MUST NEVER be used for authorization!
        app_metadata = payload.get("app_metadata")
        raw_role = None
        if isinstance(app_metadata, dict):
            raw_role = app_metadata.get("role")

        # Missing or unknown roles fail safely to least-privilege (UserRole.USER)
        if raw_role:
            try:
                role = UserRole(str(raw_role).upper().strip())
            except (ValueError, AttributeError):
                logger.warning(
                    "Unknown role '%s' encountered in app_metadata for user '%s'. Defaulting safely to USER.",
                    raw_role,
                    user_id,
                )
                role = UserRole.USER
        else:
            role = UserRole.USER

        # 5. Account status resolution from app_metadata
        raw_status = None
        if isinstance(app_metadata, dict):
            raw_status = app_metadata.get("account_status")

        if raw_status:
            try:
                account_status = AccountStatus(str(raw_status).upper().strip())
            except (ValueError, AttributeError):
                account_status = AccountStatus.ACTIVE
        else:
            account_status = AccountStatus.ACTIVE

        # 6. Sanitize custom claims (exclude sensitive/internal tokens and credentials)
        safe_claims = {
            k: v
            for k, v in payload.items()
            if k not in {"password", "secret", "token", "exp", "iat"}
        }

        user_metadata = payload.get("user_metadata", {})
        full_name = user_metadata.get("full_name") if isinstance(user_metadata, dict) else None

        return AuthenticatedPrincipal(
            user_id=user_id,
            email=email,
            role=role,
            provider=AuthProvider.SUPABASE,
            is_authenticated=True,
            account_status=account_status,
            full_name=full_name,
            custom_claims=safe_claims,
        )


class DemoTokenVerifier(SupabaseTokenVerifier):
    """Verify short-lived demo JWTs while preserving the standard principal and RBAC path."""

    async def verify_token(self, token: str) -> AuthenticatedPrincipal:
        principal = await super().verify_token(token)
        return principal.model_copy(update={"provider": AuthProvider.DEMO})


def get_token_verifier(settings: Settings = Depends(get_settings)) -> TokenVerifier:
    """Dependency provider returning the active TokenVerifier implementation.

    Fails closed with UnconfiguredTokenVerifier if SUPABASE_JWT_SECRET is missing.
    Can be overridden in tests via app.dependency_overrides[get_token_verifier].
    """
    if settings.SUPABASE_JWT_SECRET and settings.SUPABASE_JWT_SECRET.strip():
        return SupabaseTokenVerifier(settings=settings)
    if settings.DEMO_AUTH_ENABLED and settings.ENVIRONMENT in {"development", "test"}:
        if not settings.DEMO_AUTH_SECRET or not settings.DEMO_AUTH_SECRET.strip():
            return UnconfiguredTokenVerifier()
        demo_settings = settings.model_copy(update={
            "SUPABASE_JWT_SECRET": settings.DEMO_AUTH_SECRET,
            "SUPABASE_URL": None,
            "SUPABASE_JWT_ISSUER": None,
        })
        return DemoTokenVerifier(demo_settings)
    return UnconfiguredTokenVerifier()
