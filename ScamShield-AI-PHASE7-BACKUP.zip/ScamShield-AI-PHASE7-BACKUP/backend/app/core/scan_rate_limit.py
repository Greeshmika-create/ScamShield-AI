"""Process-local sliding-window rate limiting for authenticated scan routes."""

from collections import defaultdict, deque
from threading import Lock
import time

from fastapi import Depends, Request

from app.core.config import Settings, get_settings
from app.core.errors import RateLimitExceededException


class ScanRateLimiter:
    """Keep a bounded recent-request window for each direct client address."""

    def __init__(self, window_seconds: float = 60.0) -> None:
        self.window_seconds = window_seconds
        self._requests: dict[str, deque[float]] = defaultdict(deque)
        self._lock = Lock()

    def allow(self, client_key: str, limit: int, now: float | None = None) -> bool:
        current = time.monotonic() if now is None else now
        cutoff = current - self.window_seconds
        with self._lock:
            requests = self._requests[client_key]
            while requests and requests[0] <= cutoff:
                requests.popleft()
            if len(requests) >= limit:
                return False
            requests.append(current)
            if len(self._requests) > 1024:
                stale_keys = [
                    key for key, values in self._requests.items()
                    if not values or values[-1] <= cutoff
                ]
                for key in stale_keys:
                    self._requests.pop(key, None)
            return True

    def reset(self) -> None:
        """Clear all windows; intended for isolated tests and process lifecycle hooks."""
        with self._lock:
            self._requests.clear()


scan_rate_limiter = ScanRateLimiter()


def require_scan_rate_limit(
    request: Request,
    settings: Settings = Depends(get_settings),
) -> None:
    client_key = request.client.host if request.client else "unknown"
    if not scan_rate_limiter.allow(client_key, settings.RATE_LIMIT_PER_MINUTE):
        raise RateLimitExceededException()