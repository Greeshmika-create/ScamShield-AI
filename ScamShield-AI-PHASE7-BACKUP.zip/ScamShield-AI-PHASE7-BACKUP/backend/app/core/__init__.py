"""Core application utilities, settings, logging, and error handling."""

from app.core.audit import emit_audit_event, record_security_audit
from app.core.auth import (
    SupabaseTokenVerifier,
    TokenVerifier,
    UnconfiguredTokenVerifier,
    get_token_verifier,
)
from app.core.config import Settings, get_settings
from app.core.dependencies import (
    get_current_principal,
    require_admin,
    require_authenticated_user,
    require_owner,
    require_permission,
)
from app.core.permissions import (
    ROLE_PERMISSIONS,
    can_modify_role,
    has_permission,
    validate_role_assignment,
)

__all__ = [
    "Settings",
    "get_settings",
    "TokenVerifier",
    "UnconfiguredTokenVerifier",
    "SupabaseTokenVerifier",
    "get_token_verifier",
    "ROLE_PERMISSIONS",
    "has_permission",
    "can_modify_role",
    "validate_role_assignment",
    "get_current_principal",
    "require_authenticated_user",
    "require_admin",
    "require_owner",
    "require_permission",
    "emit_audit_event",
    "record_security_audit",
]

