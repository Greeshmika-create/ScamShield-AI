"""Audit logging foundations for sensitive security operations in ScamShield AI."""

import logging
from typing import Any, Dict, Optional

from app.core.logging import get_request_id
from app.schemas.audit import AuditEvent
from app.schemas.enums import AuditEventType, UserRole

audit_logger = logging.getLogger("scamshield.audit")


def emit_audit_event(event: AuditEvent) -> None:
    """Emit an authoritative security audit event.

    Note:
    - Persistent database storage of audit records belongs to Phase 10 (Supabase integration).
    - In Phase 3.4, audit events are strictly emitted to the dedicated 'scamshield.audit'
      logging channel with zero sensitive credentials, tokens, or OTPs.
    """
    req_id = event.request_id or get_request_id() or "-"
    audit_logger.info(
        "[%s] AUDIT_EVENT [%s] action='%s' actor='%s' role='%s' target='%s' details=%s",
        req_id,
        event.event_type.value,
        event.action,
        event.actor_user_id or "ANONYMOUS",
        event.actor_role.value if event.actor_role else "NONE",
        event.target_user_id or "NONE",
        event.details,
    )


def record_security_audit(
    event_type: AuditEventType,
    action: str,
    actor_user_id: Optional[str] = None,
    actor_role: Optional[UserRole] = None,
    target_user_id: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
) -> AuditEvent:
    """Helper to construct and safely emit a security audit event."""
    req_id = get_request_id()
    event = AuditEvent(
        event_type=event_type,
        action=action,
        actor_user_id=actor_user_id,
        actor_role=actor_role,
        target_user_id=target_user_id,
        details=details or {},
        ip_address=ip_address,
        user_agent=user_agent,
        request_id=req_id,
    )
    emit_audit_event(event)
    return event

