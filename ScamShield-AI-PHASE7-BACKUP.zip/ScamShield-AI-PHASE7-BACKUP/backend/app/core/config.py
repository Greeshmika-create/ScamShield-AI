"""Application configuration and environment settings."""

import json
import secrets
from functools import lru_cache
from typing import Any, List, Optional
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Centralized application settings with strict validation."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=True,
    )

    # Core Application
    PROJECT_NAME: str = "ScamShield AI"
    VERSION: str = "1.0.0"
    API_V1_PREFIX: str = "/api/v1"
    ENVIRONMENT: str = Field(default="development")
    PORT: int = Field(default=8000, ge=1024, le=65535)
    HOST: str = Field(default="0.0.0.0")
    LOG_LEVEL: str = Field(default="INFO")

    # Security & CORS
    CORS_ORIGINS: List[str] = Field(
        default_factory=lambda: ["http://localhost:5173", "http://127.0.0.1:5173"]
    )

    # Database & Supabase (Phase 3.1: Configurable, but not actively connected)
    SUPABASE_URL: Optional[str] = None
    SUPABASE_SERVICE_ROLE_KEY: Optional[str] = None
    SUPABASE_ANON_KEY: Optional[str] = None
    SUPABASE_DB_URL: Optional[str] = None
    DB_POOL_MIN_SIZE: int = Field(default=1, ge=0, le=20)
    DB_POOL_MAX_SIZE: int = Field(default=10, ge=1, le=100)
    DB_CONNECT_TIMEOUT_SECONDS: float = Field(default=5.0, gt=0.0, le=60.0)

    # Authentication & JWT (Phase 3.4: Configuration foundations for Phase 10 Supabase Auth)
    SUPABASE_JWT_SECRET: Optional[str] = None
    SUPABASE_JWT_AUDIENCE: str = Field(default="authenticated")
    SUPABASE_JWT_ISSUER: Optional[str] = None
    ALLOWED_JWT_ALGORITHMS: List[str] = Field(default_factory=lambda: ["HS256"])
    DEMO_AUTH_ENABLED: bool = Field(default=False)
    DEMO_AUTH_SECRET: Optional[str] = Field(default_factory=lambda: secrets.token_urlsafe(48))
    DEMO_ACCESS_TOKEN_TTL_SECONDS: int = Field(default=3600, ge=60, le=86400)

    @property
    def expected_jwt_issuer(self) -> Optional[str]:
        """Expected JWT issuer. Uses SUPABASE_JWT_ISSUER if set, otherwise derives from SUPABASE_URL."""
        if self.SUPABASE_JWT_ISSUER and self.SUPABASE_JWT_ISSUER.strip():
            return self.SUPABASE_JWT_ISSUER.strip()
        if self.SUPABASE_URL and self.SUPABASE_URL.strip():
            return f"{self.SUPABASE_URL.strip().rstrip('/')}/auth/v1"
        return None

    # Threat Intelligence API Keys (Phase 3.1: Configurable, but not queried)
    GOOGLE_SAFE_BROWSING_API_KEY: Optional[str] = None
    URLHAUS_API_KEY: Optional[str] = None
    PHISHTANK_API_KEY: Optional[str] = None

    # Scanner Timeouts & Limits
    INTEL_TIMEOUT_SECONDS: float = Field(default=2.5, gt=0.0, le=10.0)
    TOTAL_SCAN_TIMEOUT_SECONDS: float = Field(default=6.0, gt=0.0, le=30.0)
    INTEL_CACHE_TTL_HOURS: int = Field(default=2, ge=1, le=168)
    RATE_LIMIT_PER_MINUTE: int = Field(default=30, ge=1, le=1000)

    @field_validator("ENVIRONMENT")
    @classmethod
    def validate_environment(cls, v: str) -> str:
        allowed = {"development", "staging", "production", "test"}
        val = v.lower().strip()
        if val not in allowed:
            raise ValueError(f"ENVIRONMENT must be one of {sorted(allowed)}, got '{v}'")
        return val

    @field_validator("LOG_LEVEL")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        val = v.upper().strip()
        if val not in allowed:
            raise ValueError(f"LOG_LEVEL must be one of {sorted(allowed)}, got '{v}'")
        return val

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def parse_cors_origins(cls, v: Any) -> List[str]:
        origins: List[str] = []
        if isinstance(v, str):
            v_trimmed = v.strip()
            if v_trimmed.startswith("[") and v_trimmed.endswith("]"):
                try:
                    parsed = json.loads(v_trimmed)
                    if isinstance(parsed, list):
                        origins = [str(item).strip() for item in parsed if str(item).strip()]
                except json.JSONDecodeError:
                    pass
            if not origins:
                # Split comma separated
                origins = [part.strip() for part in v_trimmed.split(",") if part.strip()]
        elif isinstance(v, (list, tuple)):
            origins = [str(item).strip() for item in v if str(item).strip()]
        else:
            origins = ["http://localhost:5173", "http://127.0.0.1:5173"]

        if "*" in origins:
            raise ValueError("Wildcard origin '*' cannot be used with credentialed requests for CORS security.")

        return origins

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == "production"

    @property
    def is_testing(self) -> bool:
        return self.ENVIRONMENT == "test"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Retrieve cached application settings instance."""
    return Settings()

