"""Standardized exception classes and global error handlers."""

import logging
from datetime import datetime, timezone
import re
from typing import Any, Dict, Optional
from fastapi import Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.logging import get_request_id
from app.schemas.common import mask_sensitive_pii

logger = logging.getLogger("scamshield.errors")

# Status codes (RFC 9110 compliant)
HTTP_422_STATUS = getattr(status, "HTTP_422_UNPROCESSABLE_CONTENT", 422)
HTTP_413_STATUS = getattr(status, "HTTP_413_CONTENT_TOO_LARGE", 413)


class ScamShieldException(Exception):
    """Base application exception for ScamShield AI."""

    def __init__(
        self,
        status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR,
        error_code: str = "INTERNAL_ERROR",
        message: str = "An unexpected error occurred during processing.",
        details: Optional[Dict[str, Any]] = None,
    ):
        self.status_code = status_code
        self.error_code = error_code
        self.message = message
        self.details = details or {}
        super().__init__(message)


class SSRFRejectedException(ScamShieldException):
    """Raised when submitted target resolves to a private, loopback, or metadata address."""

    def __init__(self, message: str = "Target address is restricted or non-routable.", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=status.HTTP_400_BAD_REQUEST,
            error_code="INVALID_INPUT_FORMAT",
            message=message,
            details=details,
        )


class InvalidInputException(ScamShieldException):
    """Raised when payload or parameters violate input format specifications."""

    def __init__(self, message: str = "Invalid input format provided.", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=HTTP_422_STATUS,
            error_code="INVALID_INPUT_FORMAT",
            message=message,
            details=details,
        )


class ResourceNotFoundException(ScamShieldException):
    """Raised when an inspected resource or scan record cannot be located."""

    def __init__(self, message: str = "The requested resource was not found.", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="NOT_FOUND",
            message=message,
            details=details,
        )


NotFoundException = ResourceNotFoundException


class RateLimitExceededException(ScamShieldException):
    """Raised when client exceeds allowed inspection frequency limit."""

    def __init__(self, message: str = "Scan rate limit exceeded (maximum 30 scans/min).", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            error_code="RATE_LIMITED",
            message=message,
            details=details,
        )


RateLimitedException = RateLimitExceededException


class ScanTimeoutException(ScamShieldException):
    """Raised when inspection workflow exceeds execution deadline."""

    def __init__(self, message: str = "Scan processing deadline exceeded.", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            error_code="REQUEST_TIMEOUT",
            message=message,
            details=details,
        )


RequestTimeoutException = ScanTimeoutException


class ServiceUnavailableException(ScamShieldException):
    """Raised when upstream services or backend components are unavailable."""

    def __init__(self, message: str = "Backend service temporarily unavailable.", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            error_code="BACKEND_UNAVAILABLE",
            message=message,
            details=details,
        )


class UnauthorizedException(ScamShieldException):
    """Raised when authentication credentials are missing or invalid."""

    def __init__(self, message: str = "Authentication required.", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=status.HTTP_401_UNAUTHORIZED,
            error_code="UNAUTHORIZED",
            message=message,
            details=details,
        )


class ForbiddenException(ScamShieldException):
    """Raised when user lacks permissions for the requested operation."""

    def __init__(self, message: str = "Access forbidden.", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=status.HTTP_403_FORBIDDEN,
            error_code="FORBIDDEN",
            message=message,
            details=details,
        )


class PayloadTooLargeException(ScamShieldException):
    """Raised when incoming request payload exceeds permitted size limit."""

    def __init__(self, message: str = "Request payload exceeds maximum allowed size.", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=HTTP_413_STATUS,
            error_code="INVALID_INPUT_FORMAT",
            message=message,
            details=details,
        )


class UnsupportedMediaTypeException(ScamShieldException):
    """Raised when incoming Content-Type header is unsupported for the endpoint."""

    def __init__(self, message: str = "Unsupported Content-Type. JSON is required.", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            error_code="INVALID_INPUT_FORMAT",
            message=message,
            details=details,
        )


class InternalInspectionException(ScamShieldException):
    """Raised when internal engine pipeline encounters unrecoverable failure."""

    def __init__(self, message: str = "Internal error occurred during processing.", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="INTERNAL_ERROR",
            message=message,
            details=details,
        )


InternalErrorException = InternalInspectionException


def _build_error_payload(
    error_code: str,
    message: str,
    details: Optional[Dict[str, Any]] = None,
    request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Format unified JSON error envelope conforming to API specification."""
    req_id = request_id or get_request_id()
    payload: Dict[str, Any] = {
        "error_code": error_code,
        "message": message,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    if req_id:
        payload["request_id"] = req_id
    if details is not None and len(details) > 0:
        payload["details"] = details
    return payload


async def scamshield_exception_handler(request: Request, exc: ScamShieldException) -> JSONResponse:
    """Handle custom application exceptions."""
    req_id = get_request_id()
    logger.warning(
        "[%s] Application exception [%s] on %s %s: %s",
        req_id or "-",
        exc.error_code,
        request.method,
        request.url.path,
        exc.message,
    )
    headers = {"X-Request-ID": req_id} if req_id else {}
    return JSONResponse(
        status_code=exc.status_code,
        content=_build_error_payload(exc.error_code, exc.message, exc.details, request_id=req_id),
        headers=headers,
    )


async def starlette_http_exception_handler(request: Request, exc: StarletteHTTPException) -> JSONResponse:
    """Handle standard Starlette / FastAPI HTTP exceptions conforming to approved ErrorCode enum."""
    req_id = get_request_id()
    error_code = "INTERNAL_ERROR"
    if exc.status_code == status.HTTP_404_NOT_FOUND:
        error_code = "NOT_FOUND"
    elif exc.status_code == status.HTTP_401_UNAUTHORIZED:
        error_code = "UNAUTHORIZED"
    elif exc.status_code == status.HTTP_403_FORBIDDEN:
        error_code = "FORBIDDEN"
    elif exc.status_code == status.HTTP_429_TOO_MANY_REQUESTS:
        error_code = "RATE_LIMITED"
    elif exc.status_code in (status.HTTP_408_REQUEST_TIMEOUT, status.HTTP_504_GATEWAY_TIMEOUT):
        error_code = "REQUEST_TIMEOUT"
    elif exc.status_code == status.HTTP_503_SERVICE_UNAVAILABLE:
        error_code = "BACKEND_UNAVAILABLE"
    elif exc.status_code in (
        status.HTTP_400_BAD_REQUEST,
        status.HTTP_405_METHOD_NOT_ALLOWED,
        HTTP_413_STATUS,
        status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
        HTTP_422_STATUS,
    ):
        error_code = "INVALID_INPUT_FORMAT"
    elif exc.status_code >= 500:
        error_code = "INTERNAL_ERROR"

    message = str(exc.detail) if exc.detail else "An HTTP error occurred."
    headers = {"X-Request-ID": req_id} if req_id else {}
    return JSONResponse(
        status_code=exc.status_code,
        content=_build_error_payload(error_code, message, request_id=req_id),
        headers=headers,
    )


async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    """Handle Pydantic request schema validation errors, ensuring zero sensitive inputs are echoed back."""
    req_id = get_request_id()
    sanitized_errors = []
    for error in exc.errors():
        field_loc = " -> ".join([str(loc) for loc in error.get("loc", [])])
        raw_msg = error.get("msg", "Invalid value")
        # Mask any potential PII or secrets reflected in custom validator error messages
        clean_msg = mask_sensitive_pii(raw_msg)
        sanitized_errors.append({
            "field": field_loc,
            "message": clean_msg,
            "type": error.get("type", "value_error"),
        })

    logger.info(
        "Validation failed on %s %s: %d error(s)",
        request.method,
        request.url.path,
        len(sanitized_errors),
    )

    headers = {"X-Request-ID": req_id} if req_id else {}
    return JSONResponse(
        status_code=HTTP_422_STATUS,
        content=_build_error_payload(
            error_code="INVALID_INPUT_FORMAT",
            message="Input data validation failed. Review the submitted fields.",
            details={"validation_errors": sanitized_errors},
            request_id=req_id,
        ),
        headers=headers,
    )


async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Catch-all unhandled exception handler to avoid leaking stack traces, credentials, or internal paths."""
    req_id = get_request_id()
    logger.exception(
        "[%s] Unhandled server error encountered on %s %s: %s",
        req_id or "-",
        request.method,
        request.url.path,
        str(exc),
    )
    headers = {"X-Request-ID": req_id} if req_id else {}
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=_build_error_payload(
            error_code="INTERNAL_ERROR",
            message="An unexpected internal server error occurred. No sensitive diagnostics leaked.",
            request_id=req_id,
        ),
        headers=headers,
    )
