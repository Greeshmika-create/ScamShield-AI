"""Reusable FastAPI authentication and authorization dependency providers for ScamShield AI."""

from typing import Callable, Optional
from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.core.audit import record_security_audit
from app.core.auth import TokenVerifier, get_token_verifier
from app.core.errors import ForbiddenException, UnauthorizedException
from app.core.permissions import has_permission
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import AuditEventType, Permission, UserRole

# HTTP Bearer authentication scheme without automatic error raising
# (auto_error=False allows optional auth and clean custom 401 responses)
http_bearer = HTTPBearer(auto_error=False)


async def get_current_principal(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(http_bearer),
    verifier: TokenVerifier = Depends(get_token_verifier),
) -> Optional[AuthenticatedPrincipal]:
    """Extract and verify bearer credentials from the Authorization header if provided.

    Returns:
        AuthenticatedPrincipal if token is valid.
        None if Authorization header is missing.

    Raises:
        UnauthorizedException (HTTP 401): If token is malformed, invalid, or expired.
        ServiceUnavailableException (HTTP 503): If auth provider is unconfigured/offline.
    """
    if credentials is None:
        return None

    token = credentials.credentials
    if not token or not token.strip():
        raise UnauthorizedException(message="Invalid or empty authorization token provided.")

    return await verifier.verify_token(token.strip())


async def require_authenticated_user(
    principal: Optional[AuthenticatedPrincipal] = Depends(get_current_principal),
) -> AuthenticatedPrincipal:
    """Enforce that the request originates from a verified, active user.

    Raises:
        UnauthorizedException (HTTP 401): If missing authentication credentials.
        ForbiddenException (HTTP 403): If authenticated user is suspended or pending activation.
    """
    if principal is None:
        raise UnauthorizedException(message="Authentication credentials required.")

    if not principal.is_active:
        raise ForbiddenException(message="Access forbidden: User account is inactive or suspended.")

    return principal


async def require_admin(
    request: Request,
    principal: AuthenticatedPrincipal = Depends(require_authenticated_user),
) -> AuthenticatedPrincipal:
    """Enforce that the requesting principal holds administrative authority (ADMIN or OWNER).

    Raises:
        ForbiddenException (HTTP 403): If the authenticated principal is a regular USER.
    """
    if not has_permission(principal, Permission.ADMIN_OPERATIONS):
        record_security_audit(
            event_type=AuditEventType.PERMISSION_DENIED,
            action="admin_access_denied",
            actor_user_id=principal.user_id,
            actor_role=principal.role,
            details={
                "attempted_path": request.url.path,
                "attempted_method": request.method,
                "required_role": "ADMIN",
            },
        )
        raise ForbiddenException(
            message="Access forbidden: Administrator privileges required for this operation."
        )

    return principal


async def require_owner(
    request: Request,
    principal: AuthenticatedPrincipal = Depends(require_authenticated_user),
) -> AuthenticatedPrincipal:
    """Enforce that the requesting principal holds root OWNER authority.

    Rules:
    - Regular users are denied (HTTP 403).
    - Administrators (ADMIN) are denied (HTTP 403).
    - Only OWNER is granted access.

    Raises:
        ForbiddenException (HTTP 403): If the authenticated principal is not the OWNER.
    """
    if not has_permission(principal, Permission.OWNER_OPERATIONS):
        record_security_audit(
            event_type=AuditEventType.PERMISSION_DENIED,
            action="owner_access_denied",
            actor_user_id=principal.user_id,
            actor_role=principal.role,
            details={
                "attempted_path": request.url.path,
                "attempted_method": request.method,
                "required_role": "OWNER",
            },
        )
        raise ForbiddenException(
            message="Access forbidden: System OWNER privileges required for this operation."
        )

    return principal


def require_permission(permission: Permission) -> Callable:
    """Factory dependency to enforce a specific granular application permission."""

    async def permission_dependency(
        request: Request,
        principal: AuthenticatedPrincipal = Depends(require_authenticated_user),
    ) -> AuthenticatedPrincipal:
        if not has_permission(principal, permission):
            record_security_audit(
                event_type=AuditEventType.PERMISSION_DENIED,
                action=f"permission_denied_{permission.value}",
                actor_user_id=principal.user_id,
                actor_role=principal.role,
                details={
                    "attempted_path": request.url.path,
                    "attempted_method": request.method,
                    "required_permission": permission.value,
                },
            )
            raise ForbiddenException(
                message=f"Access forbidden: Lacking required permission '{permission.value}'."
            )
        return principal

    return permission_dependency

