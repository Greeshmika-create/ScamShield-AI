"""Centralized Role-Based Access Control (RBAC) permission policies for ScamShield AI.

Locked Roles:
- USER: Regular user. Can scan targets, view own history, view own analytics.
- ADMIN: Operations administrator. Access authorized administrative data and controls. Cannot access OWNER-only operations.
- OWNER: Root authority. Full system control, role assignments, administrator invitations, and owner-only operations.
"""

from typing import Dict, Set

from app.core.errors import ForbiddenException
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import AccountStatus, Permission, UserRole

# Authoritative permission mapping per role tier
ROLE_PERMISSIONS: Dict[UserRole, Set[Permission]] = {
    UserRole.USER: {
        Permission.SCAN_EXECUTE,
        Permission.HISTORY_READ_OWN,
        Permission.ANALYTICS_READ_OWN,
    },
    UserRole.ADMIN: {
        Permission.SCAN_EXECUTE,
        Permission.HISTORY_READ_OWN,
        Permission.ANALYTICS_READ_OWN,
        Permission.ADMIN_READ,
        Permission.ADMIN_OPERATIONS,
    },
    UserRole.OWNER: {
        Permission.SCAN_EXECUTE,
        Permission.HISTORY_READ_OWN,
        Permission.ANALYTICS_READ_OWN,
        Permission.ADMIN_READ,
        Permission.ADMIN_OPERATIONS,
        Permission.OWNER_OPERATIONS,
        Permission.ADMIN_INVITE,
        Permission.ROLE_ASSIGN,
        Permission.ADMIN_REVOKE,
    },
}


def has_permission(principal: AuthenticatedPrincipal, permission: Permission) -> bool:
    """Evaluate whether an authenticated principal holds a specific application permission.

    Rules:
    - Inactive or suspended accounts hold zero permissions.
    - Permissions are strictly determined by the centralized ROLE_PERMISSIONS matrix.
    """
    if not principal.is_authenticated or principal.account_status != AccountStatus.ACTIVE:
        return False

    allowed_permissions = ROLE_PERMISSIONS.get(principal.role, set())
    return permission in allowed_permissions


def can_modify_role(
    actor: AuthenticatedPrincipal,
    target_current_role: UserRole,
    target_new_role: UserRole,
) -> bool:
    """Verify whether the actor is authorized to modify another user's role.

    Rules:
    - Only OWNER can modify or assign roles.
    - ADMIN cannot modify roles or invite other ADMINs.
    - USER cannot modify roles.
    - No one can create another OWNER through routine assignment.
    """
    if not actor.is_authenticated or actor.account_status != AccountStatus.ACTIVE:
        return False

    if actor.role != UserRole.OWNER:
        return False

    # Prevent routine privilege escalation to OWNER
    if target_new_role == UserRole.OWNER:
        return False

    return True


def validate_role_assignment(
    actor: AuthenticatedPrincipal,
    target_new_role: UserRole,
) -> None:
    """Validate that the requesting actor has authority to assign the requested role.

    Raises ForbiddenException (HTTP 403) with standardized error code on violation.
    """
    if not actor.is_authenticated:
        raise ForbiddenException("Authentication required to perform role assignment.")

    if actor.role != UserRole.OWNER:
        raise ForbiddenException(
            "Access forbidden: Only the system OWNER has authority to assign or modify application roles."
        )

    if target_new_role == UserRole.OWNER:
        raise ForbiddenException(
            "Access forbidden: The OWNER role cannot be assigned via administrative invitation or assignment."
        )

