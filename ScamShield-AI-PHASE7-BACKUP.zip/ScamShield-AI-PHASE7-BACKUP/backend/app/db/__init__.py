"""Database connection and Supabase client abstractions."""

