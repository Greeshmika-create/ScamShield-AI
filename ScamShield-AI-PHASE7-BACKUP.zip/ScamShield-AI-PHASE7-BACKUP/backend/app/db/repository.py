"""Parameterized PostgreSQL repository for Phase 10 scan persistence."""

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from uuid import uuid4

from app.schemas.analytics import AnalyticsOverviewResponse, ThreatCategoryCount, VerdictDistribution
from app.schemas.enums import SortOrder, TargetType, Verdict
from app.schemas.history import HistoryItem, HistoryQueryParams, HistoryResponse

logger = logging.getLogger(__name__)


class ScanRepository:
    """Persist and retrieve user-owned scan records through an asyncpg pool."""

    def __init__(self, database_manager) -> None:
        self.database = database_manager

    @property
    def pool(self):
        return getattr(self.database, "pool", None)

    async def save_completed_scan(
        self,
        *,
        owner_user_id: str,
        target_type: TargetType,
        target_preview: str,
        canonical_target: Optional[str],
        verdict: Verdict,
        risk_score: Optional[int],
        risk_band: Optional[str],
        confidence_level: str,
        detected_language: Optional[str],
        execution_time_ms: int,
        findings: Optional[list] = None,
        provider_reports: Optional[list] = None,
        url_analysis: Optional[Dict[str, Any]] = None,
        message_analysis: Optional[Dict[str, Any]] = None,
        reasoning_summary: Optional[str] = None,
        evidence_status: Optional[Dict[str, str]] = None,
    ) -> str:
        if self.pool is None:
            return ""

        scan_id = str(uuid4())
        findings = findings or []
        provider_reports = provider_reports or []
        evidence_status = evidence_status or {}

        async with self.pool.acquire() as connection:
            async with connection.transaction():
                await connection.execute(
                    """
                    INSERT INTO public.user_profiles (auth_user_id)
                    VALUES ($1)
                    ON CONFLICT (auth_user_id) DO UPDATE SET updated_at = timezone('utc', now())
                    """,
                    owner_user_id,
                )
                await connection.execute(
                    """
                    INSERT INTO public.scans
                        (id, owner_user_id, target_type, target_preview, canonical_target,
                         verdict, risk_score, risk_band, confidence_level, detected_language,
                         execution_time_ms)
                    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
                    """,
                    scan_id,
                    owner_user_id,
                    target_type.value,
                    target_preview,
                    canonical_target,
                    verdict.value,
                    risk_score,
                    risk_band,
                    confidence_level,
                    detected_language,
                    execution_time_ms,
                )

                if target_type == TargetType.URL and url_analysis:
                    await connection.execute(
                        """
                        INSERT INTO public.url_analysis_records
                            (scan_id, canonical_url, target_domain, ml_status, ml_prediction,
                             ml_threat_probability, feature_count)
                        VALUES ($1,$2,$3,$4,$5,$6,$7)
                        """,
                        scan_id,
                        url_analysis.get("canonical_url"),
                        url_analysis.get("target_domain"),
                        url_analysis.get("ml_status"),
                        url_analysis.get("ml_prediction"),
                        url_analysis.get("ml_threat_probability"),
                        url_analysis.get("feature_count"),
                    )

                if target_type == TargetType.MESSAGE and message_analysis:
                    await connection.execute(
                        """
                        INSERT INTO public.message_analysis_records
                            (scan_id, detected_language, mixed_script, nl_status, nl_threat_score)
                        VALUES ($1,$2,$3,$4,$5)
                        """,
                        scan_id,
                        detected_language,
                        message_analysis.get("mixed_script", False),
                        message_analysis.get("status"),
                        message_analysis.get("threat_score"),
                    )

                await connection.execute(
                    """
                    INSERT INTO public.risk_assessments
                        (scan_id, risk_score, risk_band, verdict, confidence_level,
                         reasoning_summary, safety_disclaimer, evidence_status)
                    VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
                    """,
                    scan_id,
                    risk_score,
                    risk_band,
                    verdict.value,
                    confidence_level,
                    reasoning_summary,
                    "No known indicators do not guarantee safety.",
                    json.dumps(evidence_status),
                )

                for finding in findings:
                    await connection.execute(
                        """
                        INSERT INTO public.threat_findings
                            (scan_id, category, rule_name, severity, title, description,
                             source, is_confirmed, raw_evidence)
                        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
                        """,
                        scan_id,
                        finding.category.value,
                        finding.rule_name,
                        finding.severity.value,
                        finding.title,
                        finding.description,
                        finding.source,
                        finding.is_confirmed,
                        json.dumps(finding.raw_evidence or {}),
                    )

                for report in provider_reports:
                    check_timestamp = None
                    if report.check_timestamp:
                        try:
                            check_timestamp = datetime.fromisoformat(
                                report.check_timestamp.replace("Z", "+00:00")
                            )
                        except (TypeError, ValueError):
                            check_timestamp = None
                    await connection.execute(
                        """
                        INSERT INTO public.provider_reports
                            (scan_id, provider_name, status, response_time_ms,
                             threat_details, error_category, check_timestamp, raw_evidence)
                        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
                        """,
                        scan_id,
                        report.provider_name,
                        report.status.value,
                        report.response_time_ms,
                        report.threat_details,
                        report.error_category,
                        check_timestamp,
                        json.dumps(report.raw_evidence or {}),
                    )

        return scan_id

    async def record_audit_event(
        self,
        *,
        owner_user_id: str,
        event_type: str,
        action: str,
        details: Optional[Dict[str, Any]] = None,
        ip_address: Optional[str] = None,
        request_id: Optional[str] = None,
    ) -> str:
        if self.pool is None:
            return ""
        event_id = str(uuid4())
        async with self.pool.acquire() as connection:
            await connection.execute(
                """
                INSERT INTO public.audit_events
                    (id, owner_user_id, event_type, action, details, ip_address, request_id)
                VALUES ($1,$2,$3,$4,$5,$6,$7)
                """,
                event_id,
                owner_user_id,
                event_type,
                action,
                json.dumps(details or {}),
                ip_address,
                request_id,
            )
        return event_id

    async def list_history(self, owner_user_id: str, query: HistoryQueryParams) -> HistoryResponse:
        if self.pool is None:
            return HistoryResponse(total_count=0, limit=query.limit, offset=query.offset, items=[])

        where = ["owner_user_id = $1"]
        params: List[Any] = [owner_user_id]
        position = 2
        if query.target_type:
            where.append(f"target_type = ${position}")
            params.append(query.target_type.value)
            position += 1
        if query.verdict:
            where.append(f"verdict = ${position}")
            params.append(query.verdict.value)
            position += 1

        where_sql = " AND ".join(where)
        order = "ASC" if query.sort_order == SortOrder.OLDEST else "DESC"

        async with self.pool.acquire() as connection:
            count_row = await connection.fetchrow(
                f"SELECT COUNT(*) AS count FROM public.scans WHERE {where_sql}", *params
            )
            rows = await connection.fetch(
                f"""
                SELECT id, created_at, target_type, target_preview, verdict,
                       risk_score, execution_time_ms
                FROM public.scans
                WHERE {where_sql}
                ORDER BY created_at {order}
                LIMIT $%d OFFSET $%d
                """ % (position, position + 1),
                *params,
                query.limit,
                query.offset,
            )

        items = [
            HistoryItem(
                scan_id=str(row["id"]),
                scanned_at=row["created_at"].isoformat(),
                target_type=TargetType(row["target_type"]),
                target_preview=row["target_preview"],
                verdict=Verdict(row["verdict"]),
                risk_score=row["risk_score"],
                execution_time_ms=row["execution_time_ms"],
            )
            for row in rows
        ]
        return HistoryResponse(
            total_count=int(count_row["count"]),
            limit=query.limit,
            offset=query.offset,
            items=items,
        )

    async def get_scan_detail(self, owner_user_id: str, scan_id: str) -> Optional[Dict[str, Any]]:
        if self.pool is None:
            return None
        async with self.pool.acquire() as connection:
            scan = await connection.fetchrow(
                """
                SELECT * FROM public.scans
                WHERE id = $1 AND owner_user_id = $2
                """,
                scan_id,
                owner_user_id,
            )
            if scan is None:
                return None
            findings = await connection.fetch(
                "SELECT * FROM public.threat_findings WHERE scan_id = $1 ORDER BY severity DESC", scan_id
            )
            providers = await connection.fetch(
                "SELECT * FROM public.provider_reports WHERE scan_id = $1", scan_id
            )
            risk = await connection.fetchrow(
                "SELECT * FROM public.risk_assessments WHERE scan_id = $1", scan_id
            )
            url = await connection.fetchrow(
                "SELECT * FROM public.url_analysis_records WHERE scan_id = $1", scan_id
            )
            message = await connection.fetchrow(
                "SELECT * FROM public.message_analysis_records WHERE scan_id = $1", scan_id
            )

        return {
            "scan": dict(scan),
            "risk": dict(risk) if risk else None,
            "findings": [dict(row) for row in findings],
            "providers": [dict(row) for row in providers],
            "url_analysis": dict(url) if url else None,
            "message_analysis": dict(message) if message else None,
        }

    async def get_analytics(self, owner_user_id: str) -> AnalyticsOverviewResponse:
        if self.pool is None:
            return AnalyticsOverviewResponse(
                total_scans=0,
                verdict_distribution=VerdictDistribution(),
                average_scan_latency_ms=0,
                detected_language_distribution={},
                top_threat_categories=[],
            )

        async with self.pool.acquire() as connection:
            summary = await connection.fetchrow(
                """
                SELECT COUNT(*) AS total,
                       COALESCE(ROUND(AVG(execution_time_ms)), 0)::INTEGER AS avg_ms
                FROM public.scans WHERE owner_user_id = $1
                """,
                owner_user_id,
            )
            verdict_rows = await connection.fetch(
                "SELECT verdict, COUNT(*) AS count FROM public.scans WHERE owner_user_id = $1 GROUP BY verdict",
                owner_user_id,
            )
            language_rows = await connection.fetch(
                """
                SELECT detected_language, COUNT(*) AS count
                FROM public.scans
                WHERE owner_user_id = $1 AND target_type = 'MESSAGE' AND detected_language IS NOT NULL
                GROUP BY detected_language
                """,
                owner_user_id,
            )
            category_rows = await connection.fetch(
                """
                SELECT category, COUNT(*) AS count
                FROM public.threat_findings f
                JOIN public.scans s ON s.id = f.scan_id
                WHERE s.owner_user_id = $1
                GROUP BY category
                ORDER BY count DESC
                LIMIT 10
                """,
                owner_user_id,
            )

        verdicts = {"MALICIOUS": 0, "SUSPICIOUS": 0, "NO_KNOWN_THREAT": 0, "UNVERIFIED": 0}
        for row in verdict_rows:
            verdicts[row["verdict"]] = int(row["count"])
        languages = {row["detected_language"]: int(row["count"]) for row in language_rows}
        categories = [
            ThreatCategoryCount(category=row["category"], count=int(row["count"]))
            for row in category_rows
        ]

        return AnalyticsOverviewResponse(
            total_scans=int(summary["total"]),
            verdict_distribution=VerdictDistribution(**verdicts),
            average_scan_latency_ms=int(summary["avg_ms"]),
            detected_language_distribution=languages,
            top_threat_categories=categories,
        )
