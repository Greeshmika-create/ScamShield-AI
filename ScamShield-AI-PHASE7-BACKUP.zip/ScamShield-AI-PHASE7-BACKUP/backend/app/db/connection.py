"""Asynchronous Supabase PostgreSQL connection lifecycle."""

import logging
from typing import Optional

from app.core.config import Settings

logger = logging.getLogger(__name__)

try:
    import asyncpg
except ImportError:  # Dependency must be installed for real database connectivity.
    asyncpg = None


class DatabaseManager:
    """Own the async connection pool and expose non-sensitive health state."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.pool = None
        self.status = "UNCONFIGURED"

    @property
    def is_configured(self) -> bool:
        return bool(self.settings.SUPABASE_DB_URL and self.settings.SUPABASE_DB_URL.strip())

    async def start(self) -> None:
        if not self.is_configured:
            self.status = "UNCONFIGURED"
            return
        if asyncpg is None:
            self.status = "ERROR"
            logger.warning("PostgreSQL driver is unavailable")
            return

        try:
            self.pool = await asyncpg.create_pool(
                dsn=self.settings.SUPABASE_DB_URL,
                min_size=self.settings.DB_POOL_MIN_SIZE,
                max_size=self.settings.DB_POOL_MAX_SIZE,
                timeout=self.settings.DB_CONNECT_TIMEOUT_SECONDS,
                command_timeout=self.settings.DB_CONNECT_TIMEOUT_SECONDS,
                ssl="require",
            )
            async with self.pool.acquire() as connection:
                await connection.fetchval("SELECT 1")
            self.status = "CONNECTED"
        except Exception as exc:
            self.pool = None
            self.status = "DISCONNECTED"
            logger.warning("Database startup check failed: %s", type(exc).__name__)

    async def stop(self) -> None:
        if self.pool is not None:
            await self.pool.close()
            self.pool = None
        if self.status != "UNCONFIGURED":
            self.status = "DISCONNECTED"

    async def check_connection(self) -> str:
        if not self.is_configured:
            return "UNCONFIGURED"
        if self.pool is None:
            return "DISCONNECTED"
        try:
            async with self.pool.acquire() as connection:
                await connection.fetchval("SELECT 1")
            self.status = "CONNECTED"
            return "CONNECTED"
        except Exception as exc:
            self.status = "DISCONNECTED"
            logger.warning("Database health check failed: %s", type(exc).__name__)
            return "DISCONNECTED"

    def acquire(self):
        if self.pool is None:
            raise RuntimeError("Database pool is unavailable")
        return self.pool.acquire()
