"""ScamShield AI - Enterprise FastAPI Application Entry Point."""

from contextlib import asynccontextmanager
from typing import AsyncGenerator
import logging
from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.api.v1.router import api_v1_router
from app.core.config import Settings, get_settings
from app.core.errors import (
    ScamShieldException,
    scamshield_exception_handler,
    starlette_http_exception_handler,
    unhandled_exception_handler,
    validation_exception_handler,
)
from app.core.logging import setup_logging
from app.core.middleware import (
    RequestProtectionMiddleware,
    RequestTracingMiddleware,
    SecurityHeadersMiddleware,
)
from app.db.connection import DatabaseManager

logger = logging.getLogger("scamshield.main")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan manager for graceful startup and shutdown."""
    settings = getattr(app.state, "settings", None) or get_settings()
    setup_logging(settings.LOG_LEVEL)
    logger.info(
        "Starting ScamShield AI Backend v%s in [%s] environment",
        settings.VERSION,
        settings.ENVIRONMENT,
    )
    logger.info("CORS allowed origins: %s", settings.CORS_ORIGINS)

    app.state.database = DatabaseManager(settings)
    await app.state.database.start()

    yield

    await app.state.database.stop()
    logger.info("Shutting down ScamShield AI Backend gracefully.")


def create_application(settings: Settings | None = None) -> FastAPI:
    """Factory function to build and configure the FastAPI application instance."""
    app_settings = settings or get_settings()

    app = FastAPI(
        title=app_settings.PROJECT_NAME,
        version=app_settings.VERSION,
        description=(
            "Enterprise-grade multilingual phishing and digital scam detection platform backend."
        ),
        docs_url="/docs" if not app_settings.is_production else None,
        redoc_url="/redoc" if not app_settings.is_production else None,
        openapi_url="/openapi.json" if not app_settings.is_production else None,
        lifespan=lifespan,
    )
    app.state.settings = app_settings

    # 1. Custom Middleware Pipeline
    # Addition order: Innermost added first, Outermost added last.
    # Outermost (RequestTracingMiddleware) executes first on request and last on response.
    app.add_middleware(RequestProtectionMiddleware)
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RequestTracingMiddleware)

    # 2. CORS Configuration (Outermost layer to resolve browser preflight OPTIONS immediately)
    # Note: CORS is a browser cross-origin policy, NOT an authentication or authorization control.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=app_settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=[
            "Content-Type",
            "Authorization",
            "X-Request-ID",
            "X-Correlation-ID",
            "X-Client-Correlation-ID",
            "Accept",
            "Origin",
            "X-Requested-With",
        ],
        expose_headers=["X-Request-ID", "X-Client-Correlation-ID", "X-Process-Time"],
    )

    # 3. Register Standardized Exception Handlers
    app.add_exception_handler(ScamShieldException, scamshield_exception_handler)  # type: ignore
    app.add_exception_handler(StarletteHTTPException, starlette_http_exception_handler)  # type: ignore
    app.add_exception_handler(RequestValidationError, validation_exception_handler)  # type: ignore
    app.add_exception_handler(Exception, unhandled_exception_handler)

    # 4. Mount Versioned API Routes under /api/v1
    app.include_router(api_v1_router, prefix=app_settings.API_V1_PREFIX)

    if settings is not None:
        app.dependency_overrides[get_settings] = lambda: settings

    # 4. Root information endpoint
    @app.get("/", tags=["Root"], include_in_schema=False)
    async def root():
        return {
            "name": app_settings.PROJECT_NAME,
            "version": app_settings.VERSION,
            "status": "OPERATIONAL",
            "docs": "/docs" if not app_settings.is_production else None,
            "health": f"{app_settings.API_V1_PREFIX}/health",
        }

    return app


# Application singleton instance for ASGI servers (Uvicorn)
app = create_application()
