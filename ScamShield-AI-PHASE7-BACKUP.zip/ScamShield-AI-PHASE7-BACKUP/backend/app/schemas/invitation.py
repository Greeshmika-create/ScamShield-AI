"""Data contracts for administrator invitations conforming to ScamShield AI security foundations."""

from datetime import datetime, timezone, timedelta
import uuid
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.schemas.enums import InvitationStatus, UserRole


class AdminInvitationCreate(BaseModel):
    """Payload contract for requesting an administrator invitation."""

    model_config = ConfigDict(
        extra="forbid",
        str_strip_whitespace=True,
    )

    invitee_email: str = Field(
        ...,
        description="Verified corporate/admin email address of the invitee",
        examples=["security-ops@scamshield.ai"],
    )
    role: UserRole = Field(
        default=UserRole.ADMIN,
        description="Application role to assign upon invitation acceptance. Only ADMIN is eligible.",
    )

    @field_validator("invitee_email")
    @classmethod
    def validate_invitee_email(cls, v: str) -> str:
        clean = v.strip().lower()
        if "@" not in clean or "." not in clean.split("@")[-1]:
            raise ValueError("Invalid email format for administrator invitation.")
        return clean

    @field_validator("role")
    @classmethod
    def validate_assignable_role(cls, v: UserRole) -> UserRole:
        # Only ADMIN role can be invited. OWNER cannot be invited.
        if v != UserRole.ADMIN:
            raise ValueError("Only the 'ADMIN' role can be assigned via administrator invitations.")
        return v


class AdminInvitationResponse(BaseModel):
    """Response contract representing an issued administrator invitation."""

    model_config = ConfigDict(
        extra="forbid",
        str_strip_whitespace=True,
    )

    invitation_id: str = Field(
        default_factory=lambda: str(uuid.uuid4()),
        description="Unique identifier for the invitation record",
    )
    inviter_user_id: str = Field(
        ...,
        description="Subject ID of the OWNER who authorized the invitation",
    )
    invitee_email: str = Field(
        ...,
        description="Target email address invited to the administrator role",
    )
    role: UserRole = Field(
        default=UserRole.ADMIN,
        description="Role to be granted upon acceptance",
    )
    status: InvitationStatus = Field(
        default=InvitationStatus.PENDING,
        description="Lifecycle standing of the invitation",
    )
    expires_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc) + timedelta(days=7),
        description="Expiration deadline for accepting the invitation (default 7 days)",
    )
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="UTC timestamp of invitation creation",
    )

