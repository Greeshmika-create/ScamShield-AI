"""Schemas for Phase 4.1 URL normalization, canonicalization, and component extraction."""

from typing import Optional
from pydantic import BaseModel, Field, SerializationInfo, field_serializer
from app.schemas.common import mask_url_credentials


class NormalizedURLComponents(BaseModel):
    """Structured breakdown of individual components extracted from a normalized URL."""

    scheme: str = Field(
        ...,
        description="Normalized lowercased URL scheme (http or https)",
        examples=["https"],
    )
    hostname: str = Field(
        ...,
        description="Normalized Unicode/standard hostname (lowercased, trailing dot removed)",
        examples=["example.com"],
    )
    ascii_hostname: str = Field(
        ...,
        description="ASCII/Punycode IDNA representation of the hostname",
        examples=["example.com"],
    )
    unicode_hostname: str = Field(
        ...,
        description="Normalized Unicode representation of the hostname",
        examples=["example.com"],
    )
    raw_hostname: Optional[str] = Field(
        default=None,
        description="Raw unnormalized hostname as extracted from authority before case-folding or dot stripping",
        examples=["Example.Com."],
    )
    has_trailing_dot: bool = Field(
        default=False,
        description="True if the original hostname had a trailing dot (DNS root zone notation)",
    )
    is_idn: bool = Field(
        default=False,
        description="True if the hostname is an Internationalized Domain Name (IDN)",
    )
    port: Optional[int] = Field(
        default=None,
        description="Explicit non-default port number (None if default 80/443 or omitted)",
        examples=[8080],
    )
    raw_port: Optional[int] = Field(
        default=None,
        description="Raw port number as specified in the original input, if present",
        examples=[80],
    )
    path: str = Field(
        ...,
        description="Normalized path component (empty paths normalized to '/')",
        examples=["/login"],
    )
    query: Optional[str] = Field(
        default=None,
        description="Query string preserving parameter order (without leading '?')",
        examples=["token=xyz&ref=123"],
    )
    fragment: Optional[str] = Field(
        default=None,
        description="URL fragment identifier (without leading '#')",
        examples=["section-2"],
    )
    is_ip_literal: bool = Field(
        default=False,
        description="True if the hostname is an IPv4 or IPv6 address literal",
    )
    ip_version: Optional[int] = Field(
        default=None,
        description="IP version (4 or 6) if hostname is an IP literal, otherwise None",
        examples=[4],
    )
    has_credentials: bool = Field(
        default=False,
        description="True if userinfo or embedded credentials were detected in the URL authority",
    )
    username: Optional[str] = Field(
        default=None,
        description="Sanitized username component if userinfo is present",
    )
    netloc: str = Field(
        ...,
        description="Normalized network location authority string (excludes sensitive credentials)",
        examples=["example.com:8080"],
    )

    def __repr__(self) -> str:
        """Safe representation without credential exposure."""
        return (
            f"NormalizedURLComponents(scheme='{self.scheme}', hostname='{self.hostname}', "
            f"ascii_hostname='{self.ascii_hostname}', netloc='{self.netloc}', path='{self.path}')"
        )

    def __str__(self) -> str:
        return self.__repr__()


class URLNormalizationResult(BaseModel):
    """Complete structured outcome of passive URL normalization and canonicalization.

    Phase 4.1 Rule: This model represents syntax normalization only.
    It does not assign threat verdicts, compute risk scores, or assert that a URL is safe.
    """

    original_url: str = Field(
        ...,
        description="Raw unedited input string as submitted by the caller (forensic field)",
    )
    canonical_url: Optional[str] = Field(
        default=None,
        description="Authoritative normalized canonical URL representation (userinfo excluded)",
        examples=["https://example.com/login"],
    )
    is_valid: bool = Field(
        ...,
        description="True if the URL was parsed and normalized successfully according to RFC standards",
    )
    error_message: Optional[str] = Field(
        default=None,
        description="Human-readable explanation of why normalization failed, if invalid",
    )
    error_code: Optional[str] = Field(
        default=None,
        description="Machine-readable categorization code for validation failure",
        examples=["UNSUPPORTED_SCHEME", "INVALID_HOSTNAME"],
    )
    components: Optional[NormalizedURLComponents] = Field(
        default=None,
        description="Structured URL components extracted during normalization",
    )

    @property
    def safe_original_url(self) -> str:
        """Original URL with embedded passwords masked for safe logging and presentation."""
        return mask_url_credentials(self.original_url)

    @field_serializer("original_url", when_used="always")
    def serialize_original_url(self, v: str, info: SerializationInfo) -> str:
        """Mask credentials during serialization unless explicitly requested via context."""
        if info.context and info.context.get("include_sensitive"):
            return v
        return mask_url_credentials(v)

    def __repr__(self) -> str:
        """Mask credentials in string representations to prevent accidental leakage in logs."""
        return (
            f"URLNormalizationResult(is_valid={self.is_valid}, "
            f"canonical_url='{self.canonical_url}', error_code={self.error_code})"
        )

    def __str__(self) -> str:
        """String conversion returns safe representation matching repr."""
        return self.__repr__()
