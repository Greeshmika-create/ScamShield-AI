"""Audit event schema definitions for tracking privileged and security-relevant actions."""

from datetime import datetime, timezone
import uuid
from typing import Any, Dict, Optional, Set
from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.schemas.common import sanitize_sensitive_data
from app.schemas.enums import AuditEventType, UserRole

FORBIDDEN_AUDIT_KEYS: Set[str] = {
    "password",
    "password_hash",
    "otp",
    "token",
    "access_token",
    "refresh_token",
    "secret",
    "raw_message",
    "message_content",
}


class AuditEvent(BaseModel):
    """
    Structured security audit record for sensitive operations.

    Rules:
    - Never stores raw credentials, OTPs, auth tokens, or raw message texts.
    - All detail payloads are sanitized through PII masking and credential stripping.
    - Provides non-repudiation metadata (actor, target, role, request ID, timestamp).
    """

    model_config = ConfigDict(
        extra="forbid",
        str_strip_whitespace=True,
    )

    event_id: str = Field(
        default_factory=lambda: str(uuid.uuid4()),
        description="Unique identifier for the audit event",
    )
    event_type: AuditEventType = Field(
        ...,
        description="Classification of the security-relevant event",
    )
    actor_user_id: Optional[str] = Field(
        default=None,
        description="Subject ID of the principal performing the action (None if system/unauthenticated)",
    )
    actor_role: Optional[UserRole] = Field(
        default=None,
        description="Role held by the actor at time of action",
    )
    target_user_id: Optional[str] = Field(
        default=None,
        description="Subject ID of the user targeted by the action (if applicable)",
    )
    action: str = Field(
        ...,
        description="Human-readable description of the attempted or completed action",
        examples=["create_admin_invitation", "role_elevation_attempt", "permission_denied"],
    )
    details: Dict[str, Any] = Field(
        default_factory=dict,
        description="Sanitized contextual diagnostic details, free of secrets or raw message contents",
    )
    ip_address: Optional[str] = Field(
        default=None,
        description="Client IP address where available",
    )
    user_agent: Optional[str] = Field(
        default=None,
        description="Client User-Agent header where available",
    )
    request_id: Optional[str] = Field(
        default=None,
        description="Correlation request ID matching active server trace",
    )
    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="Authoritative UTC timestamp of the audit event",
    )

    @model_validator(mode="before")
    @classmethod
    def sanitize_audit_payload(cls, data: Any) -> Any:
        if isinstance(data, dict):
            raw_details = data.get("details", {})
            if isinstance(raw_details, dict):
                clean_details = {}
                for k, v in raw_details.items():
                    k_lower = str(k).lower().strip()
                    # Strip any sensitive credential fields
                    if any(forbidden in k_lower for forbidden in FORBIDDEN_AUDIT_KEYS):
                        clean_details[k] = "[REDACTED_SECURITY_DATA]"
                    else:
                        clean_details[k] = sanitize_sensitive_data(v)
                data["details"] = clean_details
        return data

