"""ScamShield AI Pydantic schema layer for strongly typed API contracts."""

from app.schemas.analytics import (
    AnalyticsOverviewResponse,
    ThreatCategoryCount,
    VerdictDistribution,
)
from app.schemas.common import (
    OptionalDomainIntel,
    UserGuidance,
    create_safe_preview,
    mask_sensitive_pii,
    mask_url_credentials,
    sanitize_sensitive_data,
)
from app.schemas.audit import AuditEvent
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import (
    AccountStatus,
    AuditEventType,
    AuthProvider,
    ConfidenceLevel,
    DetectedLanguage,
    ErrorCode,
    EvidenceCategory,
    FindingSeverity,
    InvitationStatus,
    Permission,
    ProviderStatus,
    SortOrder,
    TargetType,
    UserRole,
    Verdict,
)
from app.schemas.invitation import (
    AdminInvitationCreate,
    AdminInvitationResponse,
)
from app.schemas.error import StandardErrorResponse
from app.schemas.evidence import ThreatFinding
from app.schemas.health import ComponentHealth, HealthResponse
from app.schemas.history import (
    HistoryItem,
    HistoryQueryParams,
    HistoryResponse,
)
from app.schemas.ml_analysis import (
    MessageMLAnalysis,
    MLFeatureImpact,
    URLMLAnalysis,
)
from app.schemas.risk import RiskScoreDetails
from app.schemas.threat_intelligence import ProviderReport
from app.schemas.url_scan import URLScanRequest, URLScanResponse
from app.schemas.url_normalization import (
    NormalizedURLComponents,
    URLNormalizationResult,
)
from app.schemas.message_scan import MessageScanRequest, MessageScanResponse

__all__ = [
    # Enums
    "Verdict",
    "ProviderStatus",
    "FindingSeverity",
    "EvidenceCategory",
    "ConfidenceLevel",
    "TargetType",
    "DetectedLanguage",
    "SortOrder",
    "ErrorCode",
    "UserRole",
    "AuthProvider",
    "AccountStatus",
    "InvitationStatus",
    "AuditEventType",
    "Permission",
    # Auth & Security
    "AuthenticatedPrincipal",
    "AdminInvitationCreate",
    "AdminInvitationResponse",
    "AuditEvent",
    # Common
    "UserGuidance",
    "OptionalDomainIntel",
    "mask_sensitive_pii",
    "mask_url_credentials",
    "sanitize_sensitive_data",
    "create_safe_preview",
    # Threat Intelligence
    "ProviderReport",
    # Evidence & ML
    "ThreatFinding",
    "MLFeatureImpact",
    "URLMLAnalysis",
    "MessageMLAnalysis",
    "RiskScoreDetails",
    # URL Scan & Normalization
    "URLScanRequest",
    "URLScanResponse",
    "NormalizedURLComponents",
    "URLNormalizationResult",
    # Message Scan
    "MessageScanRequest",
    "MessageScanResponse",
    # History & Analytics
    "HistoryItem",
    "HistoryQueryParams",
    "HistoryResponse",
    "VerdictDistribution",
    "ThreatCategoryCount",
    "AnalyticsOverviewResponse",
    # Errors & Health
    "StandardErrorResponse",
    "ComponentHealth",
    "HealthResponse",
]
