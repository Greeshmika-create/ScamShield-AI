"""Schemas for Machine Learning inferences, feature weights, and calibration metadata."""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class MLFeatureImpact(BaseModel):
    """Impact of an extracted lexical or structural feature on the URL classification score."""

    feature: str = Field(
        ...,
        description="Feature name or token attribute",
        examples=["has_ip_address", "suspicious_keyword_count", "entropy"],
    )
    value: float = Field(
        ...,
        description="Extracted numerical or binary feature value",
        examples=[1.0, 2.0],
    )
    impact: str = Field(
        default="POSITIVE_RISK",
        description="Directional impact of feature towards malicious verdict (POSITIVE_RISK, NEGATIVE_RISK, NEUTRAL)",
        examples=["POSITIVE_RISK"],
    )


class URLMLAnalysis(BaseModel):
    """Machine learning inference results for URL lexical analysis."""

    model_id: Optional[str] = Field(
        default=None,
        description="Identifier and version of the active classification model",
        examples=["url_lexical_rf_v1.0"],
    )
    prediction: Optional[str] = Field(
        default=None,
        description="Raw categorical prediction from model",
        examples=["MALICIOUS", "BENIGN"],
    )
    threat_probability: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Calibrated threat probability (strictly null when model is unexecuted or unavailable; never defaults to 0)",
        examples=[0.982],
    )
    top_contributing_features: Optional[List[MLFeatureImpact]] = Field(
        default=None,
        description="Ranked list of highest-impact extracted features",
    )
    evaluation_metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Model calibration, validation F1/ROC-AUC, and threshold metadata",
    )


class MessageMLAnalysis(BaseModel):
    """Machine learning inference results for multilingual scam message text."""

    model_id: Optional[str] = Field(
        default=None,
        description="Identifier and version of active NLP model",
        examples=["telugu_english_phish_svm_v1.0"],
    )
    prediction: Optional[str] = Field(
        default=None,
        description="Raw categorical intent prediction",
        examples=["SCAM", "BENIGN"],
    )
    threat_probability: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Calibrated threat probability (strictly null when unexecuted; never defaults to 0)",
        examples=[0.884],
    )
    top_contributing_ngrams: Optional[List[str]] = Field(
        default=None,
        description="Salient multilingual n-grams and tokens influencing classification",
        examples=[["block", "update che", "yono", "ventane"]],
    )
    evaluation_metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Model calibration and test set metric references",
    )

