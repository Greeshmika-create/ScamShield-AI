"""Shared common sub-models and serialization helpers."""

import re
from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, Field


class UserGuidance(BaseModel):
    """Bilingual actionable remediation advice for end-users."""

    english: str = Field(
        ...,
        description="Remediation instructions in English",
        examples=["Do not reply or share personal credentials. Banks never send account block alerts via unofficial channels."],
    )
    telugu: str = Field(
        ...,
        description="Remediation instructions in authentic Telugu script",
        examples=["ఎలాంటి వివరాలు పంచుకోవద్దు. మీ బ్యాంక్ ఎప్పుడూ ఇలాంటి అనధికారిక సందేశాల ద్వారా అకౌంట్ బ్లాక్ చేయదు."],
    )


class OptionalDomainIntel(BaseModel):
    """Optional passive domain intelligence (populated only when reliable passive sources exist)."""

    domain_age_days: Optional[int] = Field(
        default=None,
        description="Age of domain in days since creation date, if passively known",
    )
    registrar: Optional[str] = Field(
        default=None,
        description="Passively resolved registrar name, if known",
    )
    ssl_issuer: Optional[str] = Field(
        default=None,
        description="Passively reported SSL certificate authority, if known",
    )
    ssl_valid: Optional[bool] = Field(
        default=None,
        description="Whether certificate is passively known to be valid",
    )


def mask_url_credentials(text: str) -> str:
    """Mask embedded passwords in URLs within any text string.

    Transforms:
      https://user:password@host/path -> https://user:[MASKED]@host/path
      http://:password@host/path      -> http://:[MASKED]@host/path
      user:password@host/path         -> user:[MASKED]@host/path
    """
    if not isinstance(text, str):
        return str(text) if text is not None else ""

    # Match URLs with scheme: http(s)://[userinfo]@[host_and_rest]
    # Handles passwords containing '@' or special characters
    url_pattern = re.compile(
        r"(https?://)([^/\s?#'\"]+@[^/\s?#'\"]+)(/[^\s'\"\)\]]*|\?[^\s'\"\)\]]*|#[^\s'\"\)\]]*|(?=[,;:\s'\"\)\]]|$))",
        re.IGNORECASE,
    )

    def sub_url(m: re.Match) -> str:
        scheme = m.group(1)
        authority = m.group(2)
        rest = m.group(3)
        # Split on the LAST '@' in authority
        userinfo, host = authority.rsplit("@", 1)
        if ":" in userinfo:
            user, _ = userinfo.split(":", 1)
            return f"{scheme}{user}:[MASKED]@{host}{rest}"
        else:
            return f"{scheme}{userinfo}@{host}{rest}"

    result = url_pattern.sub(sub_url, text)

    # Authority without scheme, e.g. "analyst:secret@foo.com"
    bare_pattern = re.compile(
        r"(^|[\s\"'\(])([a-zA-Z0-9_\-\.%]+:[^@\s/'\"]+@([a-zA-Z0-9_\-\.\[\]:]+))",
    )

    def sub_bare(m: re.Match) -> str:
        pre = m.group(1)
        auth = m.group(2)
        userinfo, host = auth.rsplit("@", 1)
        if ":" in userinfo:
            user, _ = userinfo.split(":", 1)
            return f"{pre}{user}:[MASKED]@{host}"
        return f"{pre}{auth}"

    result = bare_pattern.sub(sub_bare, result)
    return result


def mask_sensitive_pii(text: str) -> str:
    """Mask potential 6-digit OTPs, 10-digit Indian mobile numbers, and bank account/card sequences."""
    # 6-digit standalone OTPs
    masked = re.sub(r"\b\d{6}\b", "[OTP-REDACTED]", text)
    # 10-digit Indian phone numbers with optional +91 or 91 country code
    masked = re.sub(r"(?:\+91[\-\s]?)?[6-9]\d{9}\b", "[PHONE-REDACTED]", masked)
    # 12 to 16-digit card/account numbers
    masked = re.sub(r"\b\d{4}[ -]?\d{4}[ -]?\d{4}(?:[ -]?\d{4})?\b", "[ACCOUNT-REDACTED]", masked)
    return masked


def sanitize_sensitive_data(data: Any) -> Any:
    """
    Recursively sanitize data structures to mask PII (OTPs, phone numbers, bank accounts)
    and embedded URL credentials before logging, storing, or returning evidence payloads.
    """
    if isinstance(data, str):
        return mask_url_credentials(mask_sensitive_pii(data))
    elif isinstance(data, dict):
        return {k: sanitize_sensitive_data(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [sanitize_sensitive_data(item) for item in data]
    elif isinstance(data, tuple):
        return tuple(sanitize_sensitive_data(item) for item in data)
    elif isinstance(data, set):
        return {sanitize_sensitive_data(item) for item in data}
    return data


def create_safe_preview(text: str, max_length: int = 120) -> str:
    """Create a privacy-safe, length-capped preview string with sensitive entities redacted."""
    sanitized = mask_url_credentials(mask_sensitive_pii(text.strip()))
    if len(sanitized) > max_length:
        return sanitized[: max_length - 3].rstrip() + "..."
    return sanitized
