"""Standardized error response schemas conforming to API Contract Specification."""

from datetime import datetime, timezone
from typing import Any, Dict, Optional
from pydantic import BaseModel, Field
from app.schemas.enums import ErrorCode


class StandardErrorResponse(BaseModel):
    """Standardized error payload returned across all failed API invocations."""

    error_code: str = Field(
        ...,
        description="Machine-readable standardized error identifier",
        examples=[
            ErrorCode.INVALID_INPUT_FORMAT.value,
            ErrorCode.UNAUTHORIZED.value,
            ErrorCode.FORBIDDEN.value,
            ErrorCode.NOT_FOUND.value,
            ErrorCode.RATE_LIMITED.value,
            ErrorCode.REQUEST_TIMEOUT.value,
            ErrorCode.BACKEND_UNAVAILABLE.value,
            ErrorCode.INTERNAL_ERROR.value,
        ],
    )
    message: str = Field(
        ...,
        description="Human-readable explanation of the failure condition (free of sensitive credentials or stack traces)",
        examples=["Validation failed for the submitted payload."],
    )
    details: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Structured contextual diagnostic details, free of sensitive data",
    )
    request_id: Optional[str] = Field(
        default=None,
        description="Unique correlation identifier for tracing the request across logs and diagnostics",
        examples=["c8b417e2-4521-4fa2-9eb2-f38b25a3d750"],
    )
    timestamp: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(),
        description="ISO-8601 UTC timestamp of error generation",
    )
