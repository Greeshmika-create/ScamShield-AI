"""Schemas for forensic findings and explainable threat indicators."""

from typing import Any, Dict, Optional
from pydantic import BaseModel, Field, field_validator
from app.schemas.common import mask_sensitive_pii, sanitize_sensitive_data
from app.schemas.enums import EvidenceCategory, FindingSeverity


class ThreatFinding(BaseModel):
    """Specific forensic anomaly, heuristic flag, or verified IoC finding."""

    category: EvidenceCategory = Field(
        ...,
        description="Originating category of the evidence",
        examples=[EvidenceCategory.INTEL, EvidenceCategory.HEURISTIC, EvidenceCategory.ML, EvidenceCategory.LINGUISTIC],
    )
    rule_name: str = Field(
        ...,
        description="Machine-readable rule identifier",
        examples=["RAW_IP_HOST", "URGENCY_FINANCIAL_COERCION", "URLHAUS_HIT"],
    )
    severity: FindingSeverity = Field(
        ...,
        description="Severity classification",
        examples=[FindingSeverity.HIGH, FindingSeverity.CRITICAL],
    )
    title: str = Field(
        ...,
        description="Concise human-readable finding title",
        examples=["IP Address Used in Hostname", "Urgency & Account Suspension Coercion"],
    )
    description: str = Field(
        ...,
        description="Detailed explanation of the risk indicator and its significance",
    )
    source: Optional[str] = Field(
        default=None,
        description="Specific origin or detector of the evidence",
        examples=["Static Lexical Parser", "URLhaus Threat Feed", "Multilingual NLP Classifier"],
    )
    confidence: Optional[str] = Field(
        default=None,
        description="Confidence qualifier for the finding (e.g. HIGH, MEDIUM, LOW)",
        examples=["HIGH"],
    )
    is_confirmed: bool = Field(
        default=False,
        description="True for confirmed indicators of compromise (e.g., threat feed hit); False for heuristic/probabilistic indicators",
    )
    raw_evidence: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Safe structured parameters and extracted substrings corroborating the finding",
        examples=[{"host": "192.168.1.10"}],
    )

    @field_validator("raw_evidence", mode="after")
    @classmethod
    def sanitize_raw_evidence(cls, v: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Ensure sensitive PII (OTPs, phone numbers, accounts) is masked in raw evidence before storage/serialization."""
        if v is None:
            return None
        return sanitize_sensitive_data(v)

    @field_validator("title", "description", mode="after")
    @classmethod
    def sanitize_text_fields(cls, v: str) -> str:
        """Ensure sensitive PII is masked in human-readable finding text."""
        return mask_sensitive_pii(v)

