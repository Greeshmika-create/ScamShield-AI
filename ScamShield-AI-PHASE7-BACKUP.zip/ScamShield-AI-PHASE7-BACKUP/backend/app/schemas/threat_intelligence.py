"""Schemas for external threat intelligence provider reports and operational telemetry."""

from typing import Any, Dict, Optional
from pydantic import BaseModel, Field
from app.schemas.enums import ProviderStatus


class ProviderReport(BaseModel):
    """Operational lookup result from an individual threat intelligence feed."""

    provider_name: str = Field(
        ...,
        description="Name of the external reputation service (e.g. Google Safe Browsing, URLhaus, PhishTank)",
        examples=["Google Safe Browsing", "URLhaus", "PhishTank"],
    )
    status: ProviderStatus = Field(
        ...,
        description="Operational status of the query",
        examples=[ProviderStatus.AVAILABLE_CLEAN, ProviderStatus.AVAILABLE_FLAGGED, ProviderStatus.TIMEOUT],
    )
    response_time_ms: int = Field(
        default=0,
        ge=0,
        description="Time elapsed in milliseconds for the upstream request",
        examples=[142],
    )
    threat_details: Optional[str] = Field(
        default=None,
        description="Detailed threat indicator or malware classification if flagged, otherwise null",
        examples=["Known active malware distribution endpoint"],
    )
    check_timestamp: Optional[str] = Field(
        default=None,
        description="ISO-8601 UTC timestamp of provider check execution",
    )
    error_category: Optional[str] = Field(
        default=None,
        description="Categorical failure reason if status is TIMEOUT or ERROR",
        examples=["UPSTREAM_HTTP_503", "CONNECTION_TIMEOUT"],
    )
    raw_evidence: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Safe metadata returned by the upstream provider",
    )

