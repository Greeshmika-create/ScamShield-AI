"""Request and response models for unified risk analysis."""

from enum import Enum
from typing import Dict, List, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.schemas.common import sanitize_sensitive_data
from app.schemas.enums import ConfidenceLevel, TargetType, Verdict
from app.schemas.evidence import ThreatFinding
from app.schemas.message_scan import MessageScanRequest
from app.schemas.threat_intelligence import ProviderReport
from app.schemas.url_scan import URLScanRequest


class RiskBand(str, Enum):
    """Provisional heuristic score band, not a calibrated fraud probability."""

    LOW = "LOW"
    MODERATE = "MODERATE"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class AnalyzeRequest(BaseModel):
    """Submit exactly one URL or message for passive analysis."""

    model_config = ConfigDict(extra="forbid")

    url: Optional[str] = Field(default=None, description="URL to analyze without fetching the target.")
    message_text: Optional[str] = Field(default=None, description="Message text to analyze in memory.")

    @field_validator("url", mode="before")
    @classmethod
    def validate_url(cls, value: object) -> Optional[str]:
        if value is None:
            return None
        if not isinstance(value, str):
            raise ValueError("URL must be a string.")
        try:
            return URLScanRequest(url=value).url
        except Exception:
            raise ValueError("URL must be a valid HTTP or HTTPS address.") from None

    @field_validator("message_text", mode="before")
    @classmethod
    def validate_message(cls, value: object) -> Optional[str]:
        if value is None:
            return None
        if not isinstance(value, str):
            raise ValueError("Message content must be a string.")
        try:
            return MessageScanRequest(message_text=value).message_text
        except Exception:
            raise ValueError("Message content must be 5 to 5000 characters.") from None

    @model_validator(mode="after")
    def require_single_target(self) -> "AnalyzeRequest":
        if (self.url is None) == (self.message_text is None):
            raise ValueError("Provide exactly one of 'url' or 'message_text'.")
        return self

    @property
    def target_type(self) -> TargetType:
        return TargetType.URL if self.url is not None else TargetType.MESSAGE

    def __repr__(self) -> str:
        """Avoid placing URL credentials or raw message contents in debug logs."""
        return f"AnalyzeRequest(target_type={self.target_type.value!r})"

    def __str__(self) -> str:
        return self.__repr__()


class AnalyzeResponse(BaseModel):
    """Unified, privacy-safe risk assessment."""

    analysis_id: UUID = Field(default_factory=uuid4)
    target_type: TargetType
    risk_score: Optional[int] = Field(default=None, ge=0, le=100)
    risk_band: Optional[RiskBand] = None
    verdict: Verdict
    confidence_level: ConfidenceLevel
    findings: List[ThreatFinding] = Field(default_factory=list)
    provider_reports: List[ProviderReport] = Field(default_factory=list)
    evidence_status: Dict[str, str] = Field(default_factory=dict)
    reasoning_summary: str
    safety_disclaimer: str = (
        "Risk bands are provisional heuristic assessments, not calibrated probabilities. "
        "An absence of known findings does not guarantee safety."
    )

    @field_validator("provider_reports", mode="before")
    @classmethod
    def sanitize_provider_reports(cls, value: object) -> object:
        def redact_credentials(item: object) -> object:
            if isinstance(item, BaseModel):
                return redact_credentials(item.model_dump())
            if isinstance(item, dict):
                sanitized = {}
                for key, nested in item.items():
                    key_text = str(key).lower()
                    if any(secret_name in key_text for secret_name in ("password", "passwd", "api_key", "token", "secret", "authorization")):
                        sanitized[key] = "[REDACTED]"
                    else:
                        sanitized[key] = redact_credentials(nested)
                return sanitized
            if isinstance(item, list):
                return [redact_credentials(nested) for nested in item]
            return sanitize_sensitive_data(item)

        return redact_credentials(value)

    @field_validator("reasoning_summary", "safety_disclaimer", mode="before")
    @classmethod
    def sanitize_response_text(cls, value: object) -> object:
        return sanitize_sensitive_data(value)