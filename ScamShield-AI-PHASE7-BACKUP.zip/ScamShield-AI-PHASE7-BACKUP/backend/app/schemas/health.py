"""Health and operational telemetry schemas."""

from typing import Dict, Literal
from pydantic import BaseModel, Field


class ComponentHealth(BaseModel):
    """Component-level operational health indicators."""

    api_gateway: Literal["HEALTHY", "DEGRADED", "UNHEALTHY"] = Field(
        default="HEALTHY",
        description="FastAPI gateway process status",
    )
    supabase_connection: Literal[
        "CONNECTED", "DISCONNECTED", "ERROR", "UNCONFIGURED", "NOT_CONFIGURED", "NOT_CONNECTED"
    ] = Field(
        default="NOT_CONFIGURED",
        description="Database connectivity status (strictly checked, never assumed)",
    )
    ml_models_loaded: bool = Field(
        default=False,
        description="Whether machine learning classification artifacts are resident in memory",
    )


class HealthResponse(BaseModel):
    """Operational health response conforming to API Contract Specification."""

    status: Literal["OPERATIONAL", "DEGRADED", "UNHEALTHY"] = Field(
        ...,
        description="Overall API service health assessment",
        examples=["OPERATIONAL", "DEGRADED"],
    )
    version: str = Field(..., description="API software version", examples=["1.0.0"])
    environment: str = Field(..., description="Active runtime environment", examples=["development"])
    components: ComponentHealth = Field(
        ...,
        description="Genuine subsystem health telemetry",
    )
    providers: Dict[str, str] = Field(
        ...,
        description="External threat intelligence provider operational states",
        examples=[
            {
                "google_safe_browsing": "UNCONFIGURED",
                "urlhaus": "UNCONFIGURED",
                "phishtank": "UNCONFIGURED",
            }
        ],
    )
    timestamp: str = Field(
        ...,
        description="ISO-8601 UTC timestamp of health evaluation",
    )

