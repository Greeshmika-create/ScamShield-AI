"""Schemas for paginated audit trail history and query filters."""

from typing import List, Optional
from pydantic import BaseModel, Field, field_validator
from app.schemas.enums import SortOrder, TargetType, Verdict


class HistoryItem(BaseModel):
    """Summarized historical investigation record."""

    scan_id: str = Field(
        ...,
        description="UUIDv4 identifier of the investigation record",
        examples=["c8b417e2-4521-4fa2-9eb2-f38b25a3d750"],
    )
    scanned_at: str = Field(
        ...,
        description="ISO-8601 UTC timestamp of original scan execution",
        examples=["2026-11-05T11:35:10.120Z"],
    )
    target_type: TargetType = Field(
        ...,
        description="Modality of the scanned entity (URL or MESSAGE)",
        examples=[TargetType.URL],
    )
    target_preview: str = Field(
        ...,
        description="Privacy-safe preview string (URL domain or truncated/redacted message preview)",
        examples=["http://192.168.1.10/verify-bank-account"],
    )
    verdict: Verdict = Field(
        ...,
        description="Authoritative final classification assigned",
        examples=[Verdict.MALICIOUS],
    )
    risk_score: Optional[int] = Field(
        default=None,
        ge=0,
        le=100,
        description="Calibrated threat score from 0 to 100 (null if unverified)",
        examples=[96],
    )
    execution_time_ms: int = Field(
        ...,
        ge=0,
        description="Inspection latency in milliseconds",
        examples=[412],
    )


class HistoryQueryParams(BaseModel):
    """Validation schema for scan history filter query parameters."""

    limit: int = Field(
        default=20,
        ge=1,
        le=100,
        description="Maximum number of historical records to return (1-100)",
    )
    offset: int = Field(
        default=0,
        ge=0,
        description="Number of records to skip for pagination",
    )
    target_type: Optional[TargetType] = Field(
        default=None,
        description="Filter records by modality (URL or MESSAGE)",
    )
    verdict: Optional[Verdict] = Field(
        default=None,
        description="Filter records by authoritative verdict",
    )
    sort_order: SortOrder = Field(
        default=SortOrder.NEWEST,
        description="Chronological sort direction (NEWEST or OLDEST)",
    )

    @field_validator("limit", mode="before")
    @classmethod
    def parse_limit(cls, v: object) -> int:
        if v is None:
            return 20
        try:
            val = int(str(v))
            if val < 1:
                return 1
            if val > 100:
                return 100
            return val
        except (ValueError, TypeError):
            return 20

    @field_validator("offset", mode="before")
    @classmethod
    def parse_offset(cls, v: object) -> int:
        if v is None:
            return 0
        try:
            val = int(str(v))
            return max(0, val)
        except (ValueError, TypeError):
            return 0


class HistoryResponse(BaseModel):
    """Paginated collection of authentic historical scan records."""

    total_count: int = Field(
        ...,
        ge=0,
        description="Total number of scan records matching the query filters in the database",
        examples=[42],
    )
    limit: int = Field(
        ...,
        ge=1,
        le=100,
        description="Page size limit applied",
        examples=[20],
    )
    offset: int = Field(
        ...,
        ge=0,
        description="Pagination offset applied",
        examples=[0],
    )
    items: List[HistoryItem] = Field(
        default_factory=list,
        description="List of retrieved scan records",
    )

