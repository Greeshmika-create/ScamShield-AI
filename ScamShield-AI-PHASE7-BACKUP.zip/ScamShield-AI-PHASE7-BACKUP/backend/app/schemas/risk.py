"""Schemas for Evidence-Based Risk Scoring and verdict calibration."""

from typing import Optional
from pydantic import BaseModel, Field
from app.schemas.enums import ConfidenceLevel, Verdict


class RiskScoreDetails(BaseModel):
    """Calibrated threat score output by the Evidence-Based Risk Scoring Engine (ERSE)."""

    score: Optional[int] = Field(
        default=None,
        ge=0,
        le=100,
        description="Unified risk score from 0 (lowest risk) to 100 (confirmed malicious). Null if verdict is UNVERIFIED.",
        examples=[96],
    )
    verdict: Verdict = Field(
        ...,
        description="Authoritative final threat classification",
        examples=[Verdict.MALICIOUS, Verdict.SUSPICIOUS, Verdict.NO_KNOWN_THREAT, Verdict.UNVERIFIED],
    )
    confidence_level: ConfidenceLevel = Field(
        ...,
        description="Confidence qualifier based on evidence corroboration",
        examples=[ConfidenceLevel.HIGH, ConfidenceLevel.MEDIUM, ConfidenceLevel.PROVISIONAL],
    )
    safety_disclaimer: str = Field(
        default="NO_KNOWN_THREAT indicates no current blocklist hits or high-confidence heuristic matches; it is never a guarantee against novel zero-day threats.",
        description="Mandatory cautionary notice clarifying verdict boundaries",
    )
    reasoning_summary: Optional[str] = Field(
        default=None,
        description="Deterministic explanation justifying the assigned verdict",
    )

