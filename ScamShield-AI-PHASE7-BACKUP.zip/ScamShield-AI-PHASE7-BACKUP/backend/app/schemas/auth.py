"""Strongly typed authenticated user principal models conforming to ScamShield AI security foundations."""

import copy
from datetime import datetime
from typing import Any, Dict, Optional, Set
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.schemas.enums import AccountStatus, AuthProvider, UserRole

# Sensitive credential keywords strictly prohibited from principal representations
FORBIDDEN_CREDENTIAL_FIELDS: Set[str] = {
    "password",
    "password_hash",
    "hashed_password",
    "otp",
    "token",
    "access_token",
    "refresh_token",
    "secret",
    "api_key",
}


class FrozenDict(dict):
    """Immutable dictionary that prohibits item mutation, insertion, or deletion after instantiation."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._frozen = True

    def __setitem__(self, key: Any, value: Any) -> None:
        if getattr(self, "_frozen", False):
            raise TypeError("AuthenticatedPrincipal custom_claims is immutable: item assignment not permitted.")
        super().__setitem__(key, value)

    def __delitem__(self, key: Any) -> None:
        raise TypeError("AuthenticatedPrincipal custom_claims is immutable: item deletion not permitted.")

    def pop(self, *args, **kwargs) -> Any:
        raise TypeError("AuthenticatedPrincipal custom_claims is immutable: pop not permitted.")

    def popitem(self) -> Any:
        raise TypeError("AuthenticatedPrincipal custom_claims is immutable: popitem not permitted.")

    def clear(self) -> None:
        raise TypeError("AuthenticatedPrincipal custom_claims is immutable: clear not permitted.")

    def update(self, *args, **kwargs) -> None:
        raise TypeError("AuthenticatedPrincipal custom_claims is immutable: update not permitted.")

    def setdefault(self, *args, **kwargs) -> Any:
        raise TypeError("AuthenticatedPrincipal custom_claims is immutable: setdefault not permitted.")


def recursively_freeze(val: Any) -> Any:
    """Recursively freeze nested dictionaries and collections into deeply immutable structures.

    - dicts -> FrozenDict
    - lists/tuples -> tuple
    - all other values -> defensive deepcopy
    """
    if isinstance(val, dict):
        return FrozenDict({k: recursively_freeze(v) for k, v in val.items()})
    elif isinstance(val, (list, tuple)):
        return tuple(recursively_freeze(v) for v in val)
    return copy.deepcopy(val)


class AuthenticatedPrincipal(BaseModel):
    """
    Strongly typed, immutable security principal representing an authenticated entity.

    Rules:
    - Never instantiated directly from untrusted request body inputs.
    - Never contains raw passwords, OTPs, or session tokens.
    - Strictly validated role and account standing.
    - Immutable once created (frozen=True).
    """

    model_config = ConfigDict(
        frozen=True,
        extra="forbid",
        str_strip_whitespace=True,
    )

    user_id: str = Field(
        ...,
        min_length=1,
        max_length=128,
        description="Authoritative unique subject identifier (UUID or provider identifier)",
        examples=["a1b2c3d4-e5f6-7890-abcd-ef1234567890"],
    )
    email: Optional[str] = Field(
        default=None,
        description="Verified email address of the principal",
        examples=["user@example.com"],
    )
    role: UserRole = Field(
        default=UserRole.USER,
        description="Authorized application role (USER, ADMIN, OWNER)",
    )
    provider: AuthProvider = Field(
        default=AuthProvider.SUPABASE,
        description="Identity provider that validated credentials",
    )
    is_authenticated: bool = Field(
        default=True,
        description="Whether the principal has undergone verified authentication",
    )
    account_status: AccountStatus = Field(
        default=AccountStatus.ACTIVE,
        description="Operational account standing (ACTIVE, SUSPENDED, PENDING)",
    )
    full_name: Optional[str] = Field(
        default=None,
        max_length=256,
        description="Display name of the user",
        examples=["Aditya Sharma"],
    )
    custom_claims: Dict[str, Any] = Field(
        default_factory=FrozenDict,
        description="Sanitized, deeply immutable claims extracted from verified identity provider",
    )
    created_at: Optional[datetime] = Field(
        default=None,
        description="Account creation timestamp",
    )

    @field_validator("custom_claims", mode="after")
    @classmethod
    def freeze_custom_claims(cls, v: Any) -> Dict[str, Any]:
        """Ensure custom_claims is deeply frozen into immutable structures."""
        return recursively_freeze(v)

    @field_validator("email")
    @classmethod
    def validate_email_format(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            v_clean = v.strip().lower()
            if "@" not in v_clean or "." not in v_clean.split("@")[-1]:
                raise ValueError("Invalid email address format.")
            return v_clean
        return v

    @model_validator(mode="before")
    @classmethod
    def reject_credentials_in_payload(cls, data: Any) -> Any:
        if isinstance(data, dict):
            # Prohibit credentials at top-level
            for key in data.keys():
                if key.lower() in FORBIDDEN_CREDENTIAL_FIELDS:
                    raise ValueError(f"Sensitive credential field '{key}' must never exist on AuthenticatedPrincipal.")
            # Prohibit credentials inside custom_claims
            claims = data.get("custom_claims")
            if isinstance(claims, dict):
                for claim_key in claims.keys():
                    if claim_key.lower() in FORBIDDEN_CREDENTIAL_FIELDS:
                        raise ValueError(f"Sensitive credential key '{claim_key}' prohibited in custom claims.")
        return data

    @property
    def is_active(self) -> bool:
        """Check if account is active and operational."""
        return self.is_authenticated and self.account_status == AccountStatus.ACTIVE

    @property
    def is_admin(self) -> bool:
        """Check if principal holds administrative authority (ADMIN or OWNER)."""
        return self.is_active and self.role in (UserRole.ADMIN, UserRole.OWNER)

    @property
    def is_owner(self) -> bool:
        """Check if principal holds root owner authority."""
        return self.is_active and self.role == UserRole.OWNER


class DemoLoginResponse(BaseModel):
    """Short-lived local-demo session issued by the backend."""

    access_token: str = Field(..., min_length=1)
    token_type: str = Field(default="bearer")
    expires_in: int = Field(..., ge=60)

