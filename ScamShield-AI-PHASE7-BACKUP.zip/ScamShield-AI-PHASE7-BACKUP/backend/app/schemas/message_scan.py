"""Schemas for multilingual message inspection requests and forensic responses."""

from typing import List, Optional
from pydantic import BaseModel, Field, field_validator
from app.schemas.common import UserGuidance, create_safe_preview
from app.schemas.enums import ConfidenceLevel, Verdict
from app.schemas.evidence import ThreatFinding
from app.schemas.ml_analysis import MessageMLAnalysis


class MessageScanRequest(BaseModel):
    """
    Message inspection request schema.

    Character Counting Convention:
    - Frontend (JavaScript): `str.length` counts UTF-16 code units.
    - Backend (Python 3): `len(str)` counts Unicode code points (characters).
    - Supplementary multilingual characters and emojis (e.g. 🚨, 💰, \U0001F600) count as
      1 character in Python. The 5000 character limit accommodates Telugu script,
      Telugish, and Unicode emojis without clipping surrogate pairs.
    """

    message_text: str = Field(
        ...,
        description="Raw suspicious message text (SMS, WhatsApp, email) in English, Telugu script, or Telugish",
        examples=["Mee SBI YONO account block aindi. Ventane update cheyandi: http://sbi-kyc-fix.xyz"],
    )
    sender_identifier: Optional[str] = Field(
        default=None,
        description="Optional sender phone number, short-code, or alphanumeric header (max 64 chars)",
        examples=["SBI-ALERT", "+919876543210"],
    )

    @field_validator("message_text", mode="before")
    @classmethod
    def validate_message_text(cls, v: str) -> str:
        if not isinstance(v, str):
            raise ValueError("Message content must be a string.")

        trimmed = v.strip()
        if not trimmed:
            raise ValueError("Message content cannot be empty or whitespace-only.")

        # Minimum length 5 characters (prevents empty/accidental submissions)
        if len(trimmed) < 5:
            raise ValueError("Message content must be at least 5 characters long for forensic evaluation.")

        # Maximum length 5000 Unicode characters (code points)
        if len(trimmed) > 5000:
            raise ValueError(f"Message exceeds maximum permitted length of 5000 characters (received {len(trimmed)}).")

        return trimmed

    @field_validator("sender_identifier", mode="before")
    @classmethod
    def validate_sender_identifier(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return None
        if not isinstance(v, str):
            raise ValueError("Sender identifier must be a string.")
        trimmed = v.strip()
        if not trimmed:
            return None
        if len(trimmed) > 64:
            raise ValueError("Sender identifier exceeds maximum length of 64 characters.")
        return trimmed

    def __repr__(self) -> str:
        """Prevent sensitive message body from leaking into debug prints or logs."""
        preview = create_safe_preview(self.message_text, max_length=30)
        sender = self.sender_identifier or "NONE"
        return f"MessageScanRequest(sender={sender!r}, preview={preview!r}, length={len(self.message_text)})"

    def __str__(self) -> str:
        return self.__repr__()


class MessageScanResponse(BaseModel):
    """Complete forensic inspection report for suspicious message text."""

    scan_id: str = Field(
        ...,
        description="Unique scan investigation identifier (UUIDv4)",
        examples=["7f139d4e-128a-4bc3-a801-98782a129d91"],
    )
    scanned_at: str = Field(
        ...,
        description="ISO-8601 UTC timestamp of scan execution",
        examples=["2026-11-05T11:36:00.540Z"],
    )
    message_preview: str = Field(
        ...,
        description="Privacy-safe preview with sensitive PII (OTPs, account numbers) masked and length capped to 120 chars",
        examples=["Mee SBI YONO account block aindi. Ventane update cheyandi..."],
    )
    detected_language: str = Field(
        ...,
        description="Linguistic script classification (ENGLISH, TELUGU_SCRIPT, TELUGISH, MIXED)",
        examples=["TELUGISH"],
    )
    extracted_urls: List[str] = Field(
        default_factory=list,
        description="List of URLs passively parsed from the message body",
        examples=[["http://sbi-kyc-fix.xyz"]],
    )
    verdict: Verdict = Field(
        ...,
        description="Authoritative final threat classification",
        examples=[Verdict.SUSPICIOUS],
    )
    risk_score: Optional[int] = Field(
        default=None,
        ge=0,
        le=100,
        description="Calibrated threat score from 0 to 100 (null if verdict is UNVERIFIED)",
        examples=[78],
    )
    confidence_level: ConfidenceLevel = Field(
        ...,
        description="Evidence corroboration rating (HIGH, MEDIUM, PROVISIONAL)",
        examples=[ConfidenceLevel.HIGH],
    )
    findings: List[ThreatFinding] = Field(
        default_factory=list,
        description="Explainable linguistic triggers, urgency coercion flags, and ML intent findings",
    )
    ml_analysis: MessageMLAnalysis = Field(
        default_factory=MessageMLAnalysis,
        description="Multilingual NLP intent classifier inferences and significant n-grams",
    )
    user_guidance: UserGuidance = Field(
        ...,
        description="Bilingual remediation recommendations in English and authentic Telugu script",
    )
    execution_time_ms: int = Field(
        ...,
        ge=0,
        description="Total message evaluation pipeline latency in milliseconds",
        examples=[38],
    )

