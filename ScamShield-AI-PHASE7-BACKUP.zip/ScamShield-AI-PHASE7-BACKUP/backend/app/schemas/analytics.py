"""Schemas for live telemetry, verdict distribution, and threat category analytics."""

from typing import Dict, List
from pydantic import BaseModel, Field


class VerdictDistribution(BaseModel):
    """Aggregate distribution counts across all authoritative verdicts."""

    MALICIOUS: int = Field(default=0, ge=0, description="Total confirmed malicious detections")
    SUSPICIOUS: int = Field(default=0, ge=0, description="Total anomalous/suspicious detections")
    NO_KNOWN_THREAT: int = Field(default=0, ge=0, description="Total scans with no active threat signals")
    UNVERIFIED: int = Field(default=0, ge=0, description="Total scans where external feeds were unavailable")


class ThreatCategoryCount(BaseModel):
    """Itemized frequency count for an identified threat vector category."""

    category: str = Field(
        ...,
        description="Name of the threat category (e.g., Financial Fraud / KYC, Malware URL)",
        examples=["Financial Fraud / KYC", "Malware URL", "Utility / Power Cut Coercion"],
    )
    count: int = Field(
        ...,
        ge=0,
        description="Number of incidents classified under this category",
        examples=[62],
    )


class AnalyticsOverviewResponse(BaseModel):
    """Live telemetry overview computed across all authentic database records."""

    total_scans: int = Field(
        ...,
        ge=0,
        description="Total number of investigations recorded",
        examples=[284],
    )
    verdict_distribution: VerdictDistribution = Field(
        default_factory=VerdictDistribution,
        description="Categorical breakdown across the 4 standard verdicts",
    )
    average_scan_latency_ms: int = Field(
        default=0,
        ge=0,
        description="Mean end-to-end processing latency across scans in milliseconds",
        examples=[320],
    )
    detected_language_distribution: Dict[str, int] = Field(
        default_factory=dict,
        description="Frequency distribution of detected message languages and scripts",
        examples=[{"ENGLISH": 180, "TELUGISH": 64, "TELUGU_SCRIPT": 40}],
    )
    top_threat_categories: List[ThreatCategoryCount] = Field(
        default_factory=list,
        description="Ranked list of top detected scam and phishing vectors",
    )

