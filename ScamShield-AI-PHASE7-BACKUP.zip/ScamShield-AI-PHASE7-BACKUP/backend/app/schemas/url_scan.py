"""Schemas for URL inspection requests, passive normalization, and forensic responses."""

import ipaddress
import re
from typing import List, Optional
from urllib.parse import urlsplit, urlunsplit
from pydantic import BaseModel, Field, field_validator
from app.schemas.common import OptionalDomainIntel
from app.schemas.enums import ConfidenceLevel, Verdict
from app.schemas.evidence import ThreatFinding
from app.schemas.ml_analysis import URLMLAnalysis
from app.schemas.threat_intelligence import ProviderReport

HOSTNAME_LABEL_REGEX = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$")


class URLScanRequest(BaseModel):
    """URL inspection request model with strict static validation and safe normalization."""

    url: str = Field(
        ...,
        description="Target URL to be passively analyzed (HTTP or HTTPS only, max 2048 chars)",
        examples=["http://192.168.1.10/verify-bank-account", "https://sbi.co.in.scam-gateway.xyz/login"],
    )

    @field_validator("url", mode="before")
    @classmethod
    def validate_and_normalize_url(cls, v: str) -> str:
        if not isinstance(v, str):
            raise ValueError("URL must be a string.")

        trimmed = v.strip()
        if not trimmed:
            raise ValueError("URL cannot be empty or whitespace-only.")

        if len(trimmed) > 2048:
            raise ValueError("URL exceeds maximum permitted length of 2048 characters.")

        if len(trimmed) < 4:
            raise ValueError("URL is too short to be a valid HTTP or HTTPS address.")

        # Reject control characters and unprintable chars
        if any(ord(c) < 32 or ord(c) == 127 for c in trimmed):
            raise ValueError("URL contains invalid control characters.")

        # Disallow internal whitespace
        if any(c.isspace() for c in trimmed):
            raise ValueError("URL cannot contain internal whitespace.")

        try:
            parsed = urlsplit(trimmed)
        except Exception as e:
            raise ValueError(f"Malformed URL structure: {e}") from e

        scheme = parsed.scheme.lower()
        if not scheme:
            raise ValueError("URL must specify an HTTP or HTTPS scheme (e.g. 'https://example.com').")

        if scheme not in {"http", "https"}:
            raise ValueError(f"Unsupported scheme '{scheme}'. Only HTTP and HTTPS protocols are accepted.")

        hostname = parsed.hostname
        if not hostname:
            raise ValueError("URL must contain a valid hostname or IP address.")

        if len(hostname) > 253:
            raise ValueError("Hostname exceeds maximum RFC 1035 length of 253 characters.")

        # Validate hostname syntax without DNS resolution
        is_ip = False
        try:
            ipaddress.ip_address(hostname)
            is_ip = True
        except ValueError:
            pass

        if not is_ip:
            # Validate standard domain labels
            labels = hostname.rstrip(".").split(".")
            for label in labels:
                if not label:
                    raise ValueError(f"Malformed hostname '{hostname}': contains empty label.")
                if len(label) > 63:
                    raise ValueError(f"Hostname label '{label}' exceeds maximum 63 characters.")
                if not HOSTNAME_LABEL_REGEX.match(label):
                    raise ValueError(f"Hostname label '{label}' contains invalid characters or formatting.")

        # Validate explicit port if provided
        if parsed.port is not None:
            if parsed.port < 1 or parsed.port > 65535:
                raise ValueError("URL specifies an invalid port number (must be between 1 and 65535).")

        # Reconstruct canonical URL with lowercased scheme and hostname
        netloc_parts = []
        if parsed.username or parsed.password:
            user_info = parsed.username or ""
            if parsed.password:
                user_info += f":{parsed.password}"
            netloc_parts.append(f"{user_info}@")
        netloc_parts.append(hostname.lower())
        if parsed.port:
            # Only include port if non-standard for scheme
            if not ((scheme == "http" and parsed.port == 80) or (scheme == "https" and parsed.port == 443)):
                netloc_parts.append(f":{parsed.port}")

        normalized_netloc = "".join(netloc_parts)
        normalized_path = parsed.path if parsed.path else "/"

        canonical = urlunsplit((
            scheme,
            normalized_netloc,
            normalized_path,
            parsed.query,
            parsed.fragment,
        ))

        return canonical


class URLScanResponse(BaseModel):
    """Complete forensic inspection report for a target URL."""

    scan_id: str = Field(
        ...,
        description="Unique scan investigation identifier (UUIDv4)",
        examples=["c8b417e2-4521-4fa2-9eb2-f38b25a3d750"],
    )
    scanned_at: str = Field(
        ...,
        description="ISO-8601 UTC timestamp of scan execution",
        examples=["2026-11-05T11:35:10.120Z"],
    )
    target_url: str = Field(
        ...,
        description="Original target URL submitted for inspection",
    )
    canonical_url: str = Field(
        ...,
        description="Normalized canonical URL representation",
    )
    target_domain: str = Field(
        ...,
        description="Passively extracted domain or IP hostname",
        examples=["192.168.1.10"],
    )
    verdict: Verdict = Field(
        ...,
        description="Authoritative final threat classification",
        examples=[Verdict.MALICIOUS],
    )
    risk_score: Optional[int] = Field(
        default=None,
        ge=0,
        le=100,
        description="Calibrated threat score from 0 to 100 (null if verdict is UNVERIFIED)",
        examples=[96],
    )
    confidence_level: ConfidenceLevel = Field(
        ...,
        description="Evidence corroboration rating (HIGH, MEDIUM, PROVISIONAL)",
        examples=[ConfidenceLevel.HIGH],
    )
    threat_intelligence: List[ProviderReport] = Field(
        default_factory=list,
        description="Results from external reputation feeds (Google Safe Browsing, URLhaus, PhishTank)",
    )
    findings: List[ThreatFinding] = Field(
        default_factory=list,
        description="Granular explainable indicators of compromise and heuristic anomalies",
    )
    domain_intelligence: Optional[OptionalDomainIntel] = Field(
        default=None,
        description="Optional passive domain metadata, if available",
    )
    ml_analysis: URLMLAnalysis = Field(
        default_factory=URLMLAnalysis,
        description="Lexical machine learning classifier inferences and feature weights",
    )
    execution_time_ms: int = Field(
        ...,
        ge=0,
        description="Total passive scan pipeline latency in milliseconds",
        examples=[412],
    )

