"""Phase 7 Schemas for Multilingual Message NLP and Scam Indicator Analysis."""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from app.schemas.enums import DetectedLanguage, FindingSeverity


class ScamIndicator(BaseModel):
    """Specific explainable scam indicator or coercion heuristic flag."""

    category: str = Field(
        ...,
        description="Category of detected coercion or fraud motif",
        examples=["BANKING_KYC_SUSPENSION", "CREDENTIAL_OTP_THEFT", "URGENCY_COERCION"],
    )
    rule_name: str = Field(
        ...,
        description="Machine-readable rule identifier",
        examples=["YONO_KYC_BLOCK_THREAT", "OTP_SHARING_REQUEST", "POWER_CUT_URGENCY"],
    )
    severity: FindingSeverity = Field(
        ...,
        description="Severity classification of the indicator",
        examples=[FindingSeverity.HIGH, FindingSeverity.CRITICAL],
    )
    title: str = Field(
        ...,
        description="Concise human-readable title of the indicator",
        examples=["Bank Account Block & Urgent KYC Coercion"],
    )
    description: str = Field(
        ...,
        description="Detailed explanation of the risk pattern and why it was flagged",
    )
    matched_phrases: List[str] = Field(
        default_factory=list,
        description="Specific extracted substrings or n-grams that triggered the rule",
        examples=[["yono account block", "update cheyandi"]],
    )


class ScriptAssessment(BaseModel):
    """Structured assessment of message script composition and language categorization."""

    primary_script: str = Field(
        ...,
        description="Predominant Unicode script (LATIN, TELUGU, DEVANAGARI, TAMIL, KANNADA, MALAYALAM, BENGALI)",
        examples=["TELUGU", "LATIN"],
    )
    detected_language: DetectedLanguage = Field(
        ...,
        description="Standard language enum categorization (ENGLISH, TELUGU_SCRIPT, TELUGISH, MIXED, UNKNOWN)",
        examples=[DetectedLanguage.TELUGISH, DetectedLanguage.TELUGU_SCRIPT],
    )
    is_mixed_script: bool = Field(
        default=False,
        description="True if message contains multiple distinct linguistic scripts (e.g. English + Telugu)",
    )
    script_distribution: Dict[str, float] = Field(
        default_factory=dict,
        description="Normalized percentage distribution of character code points across scripts",
        examples=[{"LATIN": 0.85, "TELUGU": 0.15}],
    )
    confidence: str = Field(
        default="HIGH",
        description="Confidence qualifier for script and language detection (HIGH, MEDIUM, LOW)",
        examples=["HIGH"],
    )
    limitations_notice: str = Field(
        default="Script detection identifies Unicode character ranges. It does not perform full grammatical language identification.",
        description="Honest boundary disclosure distinguishing script detection from semantic translation",
    )


class MessageFeatures(BaseModel):
    """Quantitative feature representation extracted from suspicious message content."""

    message_length: int = Field(..., ge=0, description="Total Unicode character count")
    word_count: int = Field(..., ge=0, description="Total whitespace-delimited word tokens")
    url_count: int = Field(default=0, ge=0, description="Number of extracted web URLs")
    extracted_urls: List[str] = Field(default_factory=list, description="Passively parsed URL candidates")
    phone_count: int = Field(default=0, ge=0, description="Number of extracted contact phone numbers")
    extracted_phones: List[str] = Field(default_factory=list, description="Passively parsed contact phone numbers")
    currency_count: int = Field(default=0, ge=0, description="Count of currency markers (₹, Rs, INR, $)")
    urgency_count: int = Field(default=0, ge=0, description="Count of temporal pressure terms (immediately, 24hr, 9 PM)")
    credential_request_count: int = Field(default=0, ge=0, description="Count of credential theft requests (OTP, PIN, password)")
    zero_width_obfuscation_count: int = Field(default=0, ge=0, description="Count of stripped invisible zero-width characters")
    has_apk_reference: bool = Field(default=False, description="True if message instructs downloading/installing an APK or remote tool")


class MessageAnalysisResult(BaseModel):
    """Authoritative outcome of multilingual message NLP and scam indicator inspection."""

    status: str = Field(
        ...,
        description="Execution outcome (ANALYZED, NO_KNOWN_INDICATORS, UNAVAILABLE, ERROR)",
        examples=["ANALYZED"],
    )
    message_preview: str = Field(
        ...,
        description="Privacy-safe preview with sensitive PII (OTPs, phone numbers, VPAs) masked and capped to 120 chars",
    )
    script_assessment: ScriptAssessment = Field(
        ...,
        description="Unicode script breakdown and language assessment",
    )
    features: MessageFeatures = Field(
        ...,
        description="Extracted quantitative lexical and structural message features",
    )
    indicators: List[ScamIndicator] = Field(
        default_factory=list,
        description="List of matched explainable threat indicators and coercion rules",
    )
    threat_score_estimate: int = Field(
        default=0,
        ge=0,
        le=100,
        description="Heuristic indicator threat score estimate (0 to 100)",
    )
    summary: str = Field(
        ...,
        description="Concise human-readable explanation of findings",
        examples=["Suspicious indicators detected: Urgent KYC suspension threats identified."],
    )
    cautious_disclaimer: str = Field(
        default="Absence of known scam indicators does not guarantee message legitimacy. Exercise routine security vigilance.",
        description="Mandatory cautionary disclaimer regarding zero-day safety boundaries",
    )

