"""Standard enumerations conforming to ScamShield AI API Contract Specification."""

from enum import Enum


class Verdict(str, Enum):
    """Authoritative threat classification assigned by the scoring engine."""

    MALICIOUS = "MALICIOUS"
    SUSPICIOUS = "SUSPICIOUS"
    NO_KNOWN_THREAT = "NO_KNOWN_THREAT"
    UNVERIFIED = "UNVERIFIED"


class ProviderStatus(str, Enum):
    """Operational outcome of an external threat intelligence lookup."""

    AVAILABLE_CLEAN = "AVAILABLE_CLEAN"
    AVAILABLE_FLAGGED = "AVAILABLE_FLAGGED"
    TIMEOUT = "TIMEOUT"
    ERROR = "ERROR"
    UNCONFIGURED = "UNCONFIGURED"


class FindingSeverity(str, Enum):
    """Severity classification for forensic evidence markers."""

    INFO = "INFO"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class EvidenceCategory(str, Enum):
    """Categorical source of forensic findings."""

    INTEL = "INTEL"
    HEURISTIC = "HEURISTIC"
    ML = "ML"
    LINGUISTIC = "LINGUISTIC"


class ConfidenceLevel(str, Enum):
    """Confidence rating of the forensic determination."""

    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    PROVISIONAL = "PROVISIONAL"


class TargetType(str, Enum):
    """Inspection target modality."""

    URL = "URL"
    MESSAGE = "MESSAGE"


class DetectedLanguage(str, Enum):
    """Linguistic classification of inspected message content."""

    ENGLISH = "ENGLISH"
    TELUGU_SCRIPT = "TELUGU_SCRIPT"
    TELUGISH = "TELUGISH"
    MIXED = "MIXED"
    UNKNOWN = "UNKNOWN"


class SortOrder(str, Enum):
    """Chronological sort order for queries."""

    NEWEST = "NEWEST"
    OLDEST = "OLDEST"


class ErrorCode(str, Enum):
    """Standardized machine-readable error codes."""

    INVALID_INPUT_FORMAT = "INVALID_INPUT_FORMAT"
    UNAUTHORIZED = "UNAUTHORIZED"
    FORBIDDEN = "FORBIDDEN"
    NOT_FOUND = "NOT_FOUND"
    RATE_LIMITED = "RATE_LIMITED"
    REQUEST_TIMEOUT = "REQUEST_TIMEOUT"
    BACKEND_UNAVAILABLE = "BACKEND_UNAVAILABLE"
    INTERNAL_ERROR = "INTERNAL_ERROR"


class UserRole(str, Enum):
    """Application user access tier."""

    USER = "USER"
    ADMIN = "ADMIN"
    OWNER = "OWNER"


class AuthProvider(str, Enum):
    """Identity provider issuing authenticated credentials."""

    SUPABASE = "SUPABASE"
    GOOGLE = "GOOGLE"
    DEMO = "DEMO"
    SYSTEM = "SYSTEM"


class AccountStatus(str, Enum):
    """Operational status of a user account."""

    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"
    PENDING = "PENDING"


class InvitationStatus(str, Enum):
    """Lifecycle state of an administrative role invitation."""

    PENDING = "PENDING"
    ACCEPTED = "ACCEPTED"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"


class AuditEventType(str, Enum):
    """Security audit event classifications for sensitive operations."""

    ADMIN_INVITED = "ADMIN_INVITED"
    ROLE_ASSIGNED = "ROLE_ASSIGNED"
    ROLE_CHANGED = "ROLE_CHANGED"
    ADMIN_REMOVED = "ADMIN_REMOVED"
    PERMISSION_DENIED = "PERMISSION_DENIED"
    AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED"
    SCAN_EXECUTED = "SCAN_EXECUTED"


class Permission(str, Enum):
    """Fine-grained application permission identifiers."""

    SCAN_EXECUTE = "scan:execute"
    HISTORY_READ_OWN = "history:read_own"
    ANALYTICS_READ_OWN = "analytics:read_own"
    ADMIN_READ = "admin:read"
    ADMIN_OPERATIONS = "admin:operations"
    OWNER_OPERATIONS = "owner:operations"
    ADMIN_INVITE = "admin:invite"
    ROLE_ASSIGN = "role:assign"
    ADMIN_REVOKE = "admin:revoke"

