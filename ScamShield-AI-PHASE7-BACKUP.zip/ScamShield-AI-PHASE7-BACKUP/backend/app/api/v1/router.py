"""API v1 master router aggregating versioned endpoint controllers."""

from fastapi import APIRouter
from app.api.v1.endpoints import analytics, analyze, auth, health, history, scan_message, scan_url

api_v1_router = APIRouter()

# Attach health and telemetry endpoints
api_v1_router.include_router(auth.router)
api_v1_router.include_router(health.router)
api_v1_router.include_router(analyze.router)
api_v1_router.include_router(scan_url.router)
api_v1_router.include_router(scan_message.router)
api_v1_router.include_router(history.router)
api_v1_router.include_router(analytics.router)

