"""Authenticated database-backed scan telemetry endpoint."""

from fastapi import APIRouter, Depends, Request

from app.core.dependencies import require_permission
from app.db.repository import ScanRepository
from app.schemas.analytics import AnalyticsOverviewResponse
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import Permission

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("/overview", response_model=AnalyticsOverviewResponse)
async def get_analytics_overview(
    request: Request,
    principal: AuthenticatedPrincipal = Depends(require_permission(Permission.ANALYTICS_READ_OWN)),
) -> AnalyticsOverviewResponse:
    database = getattr(request.app.state, "database", None)
    if database is None:
        return AnalyticsOverviewResponse()
    return await ScanRepository(database).get_analytics(principal.user_id)
