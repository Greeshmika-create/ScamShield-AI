"""Authenticated passive URL inspection endpoint."""

import logging

from fastapi import APIRouter, Depends, Request

from app.core.audit import record_security_audit
from app.core.dependencies import require_permission
from app.core.errors import InternalInspectionException, InvalidInputException, ScamShieldException
from app.core.scan_rate_limit import require_scan_rate_limit
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import AuditEventType, Permission, TargetType
from app.schemas.url_scan import URLScanRequest, URLScanResponse
from app.services.inspection_orchestrator import InspectionOrchestrator
from app.services.url_normalizer import URLNormalizationError
from app.db.repository import ScanRepository

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/scan", tags=["Inspection"])


@router.post("/url", response_model=URLScanResponse)
async def scan_url(
    payload: URLScanRequest,
    request: Request,
    principal: AuthenticatedPrincipal = Depends(require_permission(Permission.SCAN_EXECUTE)),
    _rate_limit: None = Depends(require_scan_rate_limit),
) -> URLScanResponse:
    """Passively inspect a URL without contacting the submitted target."""
    try:
        response = await InspectionOrchestrator().scan_url(payload)
    except URLNormalizationError:
        raise InvalidInputException("URL could not be normalized.") from None
    except ScamShieldException:
        raise
    except Exception as exc:
        logger.error("URL scan failed: %s", type(exc).__name__)
        raise InternalInspectionException() from None

    database = getattr(request.app.state, "database", None)
    if database is not None:
        try:
            ml_status = (response.ml_analysis.evaluation_metadata or {}).get("status")
            await ScanRepository(database).save_completed_scan(
                owner_user_id=principal.user_id,
                target_type=TargetType.URL,
                target_preview=response.canonical_url,
                canonical_target=response.canonical_url,
                verdict=response.verdict,
                risk_score=response.risk_score,
                risk_band=None,
                confidence_level=response.confidence_level.value,
                detected_language=None,
                execution_time_ms=response.execution_time_ms,
                findings=response.findings,
                provider_reports=response.threat_intelligence,
                url_analysis={
                    "canonical_url": response.canonical_url,
                    "target_domain": response.target_domain,
                    "ml_status": ml_status,
                    "ml_prediction": response.ml_analysis.prediction,
                    "ml_threat_probability": response.ml_analysis.threat_probability,
                    "feature_count": 32,
                },
            )
        except Exception as exc:
            logger.warning("URL scan persistence failed: %s", type(exc).__name__)

    audit_details = {
        "scan_id": response.scan_id,
        "target_type": "URL",
        "verdict": response.verdict.value,
        "execution_time_ms": response.execution_time_ms,
    }
    record_security_audit(
        event_type=AuditEventType.SCAN_EXECUTED,
        action="scan_url_completed",
        actor_user_id=principal.user_id,
        actor_role=principal.role,
        details=audit_details,
        ip_address=request.client.host if request.client else None,
    )
    if database is not None:
        try:
            await ScanRepository(database).record_audit_event(
                owner_user_id=principal.user_id,
                event_type=AuditEventType.SCAN_EXECUTED.value,
                action="scan_url_completed",
                details=audit_details,
                ip_address=request.client.host if request.client else None,
            )
        except Exception as exc:
            logger.warning("URL audit persistence failed: %s", type(exc).__name__)
    return response