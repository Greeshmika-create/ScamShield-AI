"""Authenticated scan-history endpoints backed by Supabase PostgreSQL."""

from fastapi import APIRouter, Depends, Request

from app.core.dependencies import require_permission
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import Permission
from app.schemas.history import HistoryQueryParams, HistoryResponse
from app.db.repository import ScanRepository

router = APIRouter(prefix="/history", tags=["Scan History"])


@router.get("", response_model=HistoryResponse)
async def get_history(
    request: Request,
    query: HistoryQueryParams = Depends(),
    principal: AuthenticatedPrincipal = Depends(require_permission(Permission.HISTORY_READ_OWN)),
) -> HistoryResponse:
    database = getattr(request.app.state, "database", None)
    if database is None:
        return HistoryResponse(total_count=0, limit=query.limit, offset=query.offset, items=[])
    return await ScanRepository(database).list_history(principal.user_id, query)


@router.get("/{scan_id}")
async def get_scan_detail(
    scan_id: str,
    request: Request,
    principal: AuthenticatedPrincipal = Depends(require_permission(Permission.HISTORY_READ_OWN)),
):
    database = getattr(request.app.state, "database", None)
    if database is None:
        return {"scan": None, "findings": [], "providers": [], "risk": None}
    detail = await ScanRepository(database).get_scan_detail(principal.user_id, scan_id)
    if detail is None:
        from app.core.errors import ResourceNotFoundException
        raise ResourceNotFoundException("Scan record was not found.")
    return detail
