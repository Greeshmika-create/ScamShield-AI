"""Environment-gated local demo authentication endpoint."""

from datetime import datetime, timedelta, timezone

import jwt
from fastapi import APIRouter, Depends

from app.core.config import Settings, get_settings
from app.core.errors import ForbiddenException
from app.schemas.auth import DemoLoginResponse

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/demo-login", response_model=DemoLoginResponse)
async def demo_login(settings: Settings = Depends(get_settings)) -> DemoLoginResponse:
    """Issue a short-lived fixed USER bearer token only for local/test environments."""
    if settings.ENVIRONMENT not in {"development", "test"}:
        raise ForbiddenException("Demo authentication is not available in this environment.")
    if not settings.DEMO_AUTH_ENABLED:
        raise ForbiddenException("Demo authentication is disabled.")
    if not settings.DEMO_AUTH_SECRET or not settings.DEMO_AUTH_SECRET.strip():
        raise ForbiddenException("Demo authentication is not configured.")

    now = datetime.now(timezone.utc)
    expires_in = settings.DEMO_ACCESS_TOKEN_TTL_SECONDS
    payload = {
        "sub": "demo-hackathon-user",
        "email": "demo.user@scamshield.local",
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=expires_in)).timestamp()),
        "aud": settings.SUPABASE_JWT_AUDIENCE,
        "app_metadata": {
            "role": "USER",
            "account_status": "ACTIVE",
        },
        "user_metadata": {
            "full_name": "Local Demo User",
        },
    }
    access_token = jwt.encode(
        payload,
        settings.DEMO_AUTH_SECRET,
        algorithm="HS256",
    )
    return DemoLoginResponse(
        access_token=access_token,
        expires_in=expires_in,
    )
