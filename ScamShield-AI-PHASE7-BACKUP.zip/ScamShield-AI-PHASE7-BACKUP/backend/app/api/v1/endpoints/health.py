"""Health evaluation and system operational telemetry endpoint."""

from datetime import datetime, timezone
from fastapi import APIRouter, Depends, Request, status
from app.core.config import Settings, get_settings
from app.schemas.health import ComponentHealth, HealthResponse
from app.services.ml_classifier import get_url_classifier

router = APIRouter(tags=["Health & Telemetry"])


def _is_valid_credential(value: str | None) -> bool:
    """Check if a credential string is present and not a dummy placeholder."""
    if not value or not value.strip():
        return False
    lower = value.strip().lower()
    placeholders = {"your_", "placeholder", "none", "null", "test_key", "change_me"}
    return not any(p in lower for p in placeholders)


@router.get(
    "/health",
    response_model=HealthResponse,
    status_code=status.HTTP_200_OK,
    summary="Operational Health & Telemetry",
    description="Exposes authentic backend operational status. Does not report dependencies as available unless verified.",
)
async def check_health(request: Request, settings: Settings = Depends(get_settings)) -> HealthResponse:
    """Evaluate operational status of API gateway and dependencies without assumptions."""

    # 1. Supabase Database Status (Strictly checked, never assumed)
    database = getattr(request.app.state, "database", None)
    db_status = "NOT_CONFIGURED"
    if database is not None:
        if database.is_configured:
            db_status = await database.check_connection()
        elif _is_valid_credential(settings.SUPABASE_URL) and _is_valid_credential(settings.SUPABASE_SERVICE_ROLE_KEY):
            db_status = "NOT_CONNECTED"
    elif _is_valid_credential(settings.SUPABASE_URL) and _is_valid_credential(settings.SUPABASE_SERVICE_ROLE_KEY):
        db_status = "NOT_CONNECTED"

    # 2. Machine Learning Artifact Status
    try:
        ml_loaded = get_url_classifier().is_available
    except Exception:
        ml_loaded = False

    # 3. External Threat Intelligence Provider Status
    providers = {
        "google_safe_browsing": (
            "CONFIGURED_NOT_VERIFIED" if _is_valid_credential(settings.GOOGLE_SAFE_BROWSING_API_KEY) else "UNCONFIGURED"
        ),
        "urlhaus": (
            "CONFIGURED_NOT_VERIFIED" if _is_valid_credential(settings.URLHAUS_API_KEY) else "UNCONFIGURED"
        ),
        "phishtank": (
            "CONFIGURED_NOT_VERIFIED" if _is_valid_credential(settings.PHISHTANK_API_KEY) else "UNCONFIGURED"
        ),
    }

    # API gateway is running and healthy
    components = ComponentHealth(
        api_gateway="HEALTHY",
        supabase_connection=db_status,
        ml_models_loaded=ml_loaded,
    )

    return HealthResponse(
        status="OPERATIONAL",
        version=settings.VERSION,
        environment=settings.ENVIRONMENT,
        components=components,
        providers=providers,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )

