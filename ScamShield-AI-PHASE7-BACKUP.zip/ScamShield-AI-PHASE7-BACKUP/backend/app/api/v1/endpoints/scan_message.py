"""Authenticated privacy-preserving message inspection endpoint."""

import logging

from fastapi import APIRouter, Depends, Request

from app.core.audit import record_security_audit
from app.core.dependencies import require_permission
from app.core.errors import InternalInspectionException, ScamShieldException
from app.core.scan_rate_limit import require_scan_rate_limit
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import AuditEventType, Permission, TargetType
from app.schemas.message_scan import MessageScanRequest, MessageScanResponse
from app.services.inspection_orchestrator import InspectionOrchestrator
from app.db.repository import ScanRepository

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/scan", tags=["Inspection"])


@router.post("/message", response_model=MessageScanResponse)
async def scan_message(
    payload: MessageScanRequest,
    request: Request,
    principal: AuthenticatedPrincipal = Depends(require_permission(Permission.SCAN_EXECUTE)),
    _rate_limit: None = Depends(require_scan_rate_limit),
) -> MessageScanResponse:
    """Inspect message text in memory and return only a masked preview."""
    try:
        response = await InspectionOrchestrator().scan_message(payload)
    except ScamShieldException:
        raise
    except Exception as exc:
        logger.error("Message scan failed: %s", type(exc).__name__)
        raise InternalInspectionException() from None

    database = getattr(request.app.state, "database", None)
    if database is not None:
        try:
            await ScanRepository(database).save_completed_scan(
                owner_user_id=principal.user_id,
                target_type=TargetType.MESSAGE,
                target_preview=response.message_preview,
                canonical_target=None,
                verdict=response.verdict,
                risk_score=response.risk_score,
                risk_band=None,
                confidence_level=response.confidence_level.value,
                detected_language=response.detected_language,
                execution_time_ms=response.execution_time_ms,
                findings=response.findings,
                provider_reports=[],
                message_analysis={
                    "status": (response.ml_analysis.evaluation_metadata or {}).get("status"),
                    "mixed_script": response.detected_language == "MIXED",
                    "threat_score": response.risk_score,
                },
            )
        except Exception as exc:
            logger.warning("Message scan persistence failed: %s", type(exc).__name__)

    audit_details = {
        "scan_id": response.scan_id,
        "target_type": "MESSAGE",
        "verdict": response.verdict.value,
        "execution_time_ms": response.execution_time_ms,
    }
    record_security_audit(
        event_type=AuditEventType.SCAN_EXECUTED,
        action="scan_message_completed",
        actor_user_id=principal.user_id,
        actor_role=principal.role,
        details=audit_details,
        ip_address=request.client.host if request.client else None,
    )
    if database is not None:
        try:
            await ScanRepository(database).record_audit_event(
                owner_user_id=principal.user_id,
                event_type=AuditEventType.SCAN_EXECUTED.value,
                action="scan_message_completed",
                details=audit_details,
                ip_address=request.client.host if request.client else None,
            )
        except Exception as exc:
            logger.warning("Message audit persistence failed: %s", type(exc).__name__)
    return response