"""Authenticated unified passive analysis endpoint."""

import logging

from fastapi import APIRouter, Depends

from app.core.dependencies import require_authenticated_user
from app.core.errors import InternalInspectionException
from app.schemas.analyze import AnalyzeRequest, AnalyzeResponse
from app.schemas.auth import AuthenticatedPrincipal
from app.services.unified_analysis.orchestrator import UnifiedAnalysisOrchestrator

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/analyze", tags=["Unified Analysis"])


@router.post("", response_model=AnalyzeResponse)
async def analyze(
    payload: AnalyzeRequest,
    _principal: AuthenticatedPrincipal = Depends(require_authenticated_user),
) -> AnalyzeResponse:
    """Analyze a URL or message without logging or returning submitted raw content."""
    try:
        return await UnifiedAnalysisOrchestrator().analyze(payload)
    except Exception as exc:
        logger.error("Unified analysis request failed: %s", type(exc).__name__)
        raise InternalInspectionException() from None