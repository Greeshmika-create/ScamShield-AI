"""Tests for Phase 3.4 Authentication Foundations, Identity Models, and Token Verification."""

from datetime import datetime, timezone, timedelta
from typing import Optional
import jwt
import pytest
from fastapi import APIRouter, Depends
from fastapi.testclient import TestClient
from pydantic import BaseModel, ValidationError

from app.core.auth import SupabaseTokenVerifier, UnconfiguredTokenVerifier, get_token_verifier
from app.core.config import Settings
from app.core.dependencies import get_current_principal, require_authenticated_user
from app.core.errors import ServiceUnavailableException, UnauthorizedException
from app.main import create_application
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import AccountStatus, AuthProvider, UserRole

TEST_SECRET = "super-secret-test-jwt-signing-key-minimum-32-chars-long"


# Test token generator helper (strictly for testing isolated token verification, never used in production)
def create_test_jwt(
    sub: str = "test-user-uuid-1234",
    email: str = "security.tester@scamshield.ai",
    role: Optional[str] = "USER",
    account_status: str = "ACTIVE",
    exp_delta: timedelta = timedelta(hours=1),
    secret: str = TEST_SECRET,
    aud: Optional[str] = "authenticated",
    issuer: Optional[str] = None,
    algorithm: str = "HS256",
    custom_app_metadata: Optional[dict] = None,
    custom_user_metadata: Optional[dict] = None,
) -> str:
    now = datetime.now(timezone.utc)
    app_meta = {"account_status": account_status}
    if role is not None:
        app_meta["role"] = role
    if custom_app_metadata:
        app_meta.update(custom_app_metadata)

    user_meta = {"full_name": "Test User"}
    if custom_user_metadata:
        user_meta.update(custom_user_metadata)

    payload = {
        "sub": sub,
        "email": email,
        "iat": int(now.timestamp()),
        "exp": int((now + exp_delta).timestamp()),
        "app_metadata": app_meta,
        "user_metadata": user_meta,
    }
    if aud is not None:
        payload["aud"] = aud
    if issuer is not None:
        payload["iss"] = issuer

    if algorithm.lower() == "none":
        import base64
        import json

        header = {"typ": "JWT", "alg": "none"}

        def b64_json(obj):
            return base64.urlsafe_b64encode(json.dumps(obj).encode()).rstrip(b"=").decode()

        return f"{b64_json(header)}.{b64_json(payload)}."

    return jwt.encode(payload, secret, algorithm=algorithm)


# ==============================================================================
# 1. Unconfigured Authentication Provider Tests (Fail-Closed)
# ==============================================================================

def test_unconfigured_auth_provider_fails_closed_with_503():
    """When auth provider is unconfigured, any attempt to authenticate fails closed with 503."""
    test_router = APIRouter()

    @test_router.get("/api/v1/protected-sample")
    def protected_route(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"user_id": principal.user_id}

    # App with default settings (SUPABASE_JWT_SECRET is None)
    app = create_application(settings=Settings(ENVIRONMENT="test", SUPABASE_JWT_SECRET=None))
    app.include_router(test_router)

    with TestClient(app) as client:
        response = client.get(
            "/api/v1/protected-sample",
            headers={"Authorization": "Bearer some.arbitrary.jwt.token"},
        )
        assert response.status_code == 503
        data = response.json()
        assert data["error_code"] == "BACKEND_UNAVAILABLE"
        assert "unconfigured or unavailable" in data["message"]


def test_missing_authentication_returns_401():
    """Accessing protected endpoint without Authorization header returns standardized 401."""
    test_router = APIRouter()

    @test_router.get("/api/v1/user-data")
    def user_data_route(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"user_id": principal.user_id}

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as client:
        response = client.get("/api/v1/user-data")
        assert response.status_code == 401
        data = response.json()
        assert data["error_code"] == "UNAUTHORIZED"
        assert "Authentication credentials required" in data["message"]
        assert "X-Request-ID" in response.headers


def test_empty_bearer_token_returns_401():
    """Authorization header with empty or whitespace token returns 401."""
    test_router = APIRouter()

    @test_router.get("/api/v1/user-profile")
    def profile_route(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"user_id": principal.user_id}

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as client:
        response = client.get("/api/v1/user-profile", headers={"Authorization": "Bearer   "})
        assert response.status_code == 401
        data = response.json()
        assert data["error_code"] == "UNAUTHORIZED"


# ==============================================================================
# 2. Token Verification & Signature Validation Tests
# ==============================================================================

def test_invalid_token_signature_returns_401():
    """Token signed with an unrecognized secret is rejected with 401."""
    test_router = APIRouter()

    @test_router.get("/api/v1/secure-test")
    def secure_route(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"sub": principal.user_id}

    settings = Settings(ENVIRONMENT="test", SUPABASE_JWT_SECRET=TEST_SECRET)
    app = create_application(settings=settings)
    app.include_router(test_router)

    with TestClient(app) as client:
        # Token signed with forged secret
        forged_token = create_test_jwt(secret="forged-unauthorized-secret-attacker-key")
        response = client.get(
            "/api/v1/secure-test",
            headers={"Authorization": f"Bearer {forged_token}"},
        )
        assert response.status_code == 401
        data = response.json()
        assert data["error_code"] == "UNAUTHORIZED"
        assert "Invalid or tampered" in data["message"]


def test_expired_token_returns_401():
    """Expired token is rejected with 401."""
    test_router = APIRouter()

    @test_router.get("/api/v1/secure-test")
    def secure_route(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"sub": principal.user_id}

    settings = Settings(ENVIRONMENT="test", SUPABASE_JWT_SECRET=TEST_SECRET)
    app = create_application(settings=settings)
    app.include_router(test_router)

    with TestClient(app) as client:
        # Token expired 10 minutes ago
        expired_token = create_test_jwt(exp_delta=timedelta(minutes=-10))
        response = client.get(
            "/api/v1/secure-test",
            headers={"Authorization": f"Bearer {expired_token}"},
        )
        assert response.status_code == 401
        data = response.json()
        assert data["error_code"] == "UNAUTHORIZED"
        assert "expired" in data["message"].lower()


def test_token_missing_sub_claim_returns_401():
    """Token missing the subject (sub) claim is rejected with 401."""
    test_router = APIRouter()

    @test_router.get("/api/v1/secure-test")
    def secure_route(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"sub": principal.user_id}

    settings = Settings(ENVIRONMENT="test", SUPABASE_JWT_SECRET=TEST_SECRET)
    app = create_application(settings=settings)
    app.include_router(test_router)

    # Token without 'sub'
    now = datetime.now(timezone.utc)
    token_without_sub = jwt.encode(
        {"email": "no-sub@example.com", "aud": "authenticated", "exp": int((now + timedelta(hours=1)).timestamp())},
        TEST_SECRET,
        algorithm="HS256",
    )

    with TestClient(app) as client:
        response = client.get(
            "/api/v1/secure-test",
            headers={"Authorization": f"Bearer {token_without_sub}"},
        )
        assert response.status_code == 401
        assert response.json()["error_code"] == "UNAUTHORIZED"


def test_valid_supabase_token_extracts_principal():
    """Valid token signed by configured secret extracts AuthenticatedPrincipal cleanly."""
    test_router = APIRouter()

    @test_router.get("/api/v1/me")
    def me_route(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {
            "user_id": principal.user_id,
            "email": principal.email,
            "role": principal.role.value,
            "is_active": principal.is_active,
        }

    settings = Settings(ENVIRONMENT="test", SUPABASE_JWT_SECRET=TEST_SECRET)
    app = create_application(settings=settings)
    app.include_router(test_router)

    valid_token = create_test_jwt(
        sub="usr-8899-aabb",
        email="verified.analyst@scamshield.ai",
        role="ADMIN",
    )

    with TestClient(app) as client:
        response = client.get(
            "/api/v1/me",
            headers={"Authorization": f"Bearer {valid_token}"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["user_id"] == "usr-8899-aabb"
        assert data["email"] == "verified.analyst@scamshield.ai"
        assert data["role"] == "ADMIN"
        assert data["is_active"] is True


# ==============================================================================
# 3. Principal Model Integrity & Security Protections
# ==============================================================================

def test_untrusted_identity_in_body_or_query_ignored():
    """Endpoint ignoring request body identity fields and strictly relying on verified principal."""
    test_router = APIRouter()

    class ScanSubmission(BaseModel):
        target: str
        # Attacker attempts to pass untrusted identity fields in payload
        user_id: str = "attacker-injected-id"
        role: str = "OWNER"

    @test_router.post("/api/v1/test-untrusted-body")
    def scan_route(
        submission: ScanSubmission,
        principal: AuthenticatedPrincipal = Depends(require_authenticated_user),
    ):
        return {
            "authoritative_user_id": principal.user_id,
            "authoritative_role": principal.role.value,
            "ignored_body_user_id": submission.user_id,
            "ignored_body_role": submission.role,
        }

    settings = Settings(ENVIRONMENT="test", SUPABASE_JWT_SECRET=TEST_SECRET)
    app = create_application(settings=settings)
    app.include_router(test_router)

    # Legitimate authenticated token for a normal USER
    user_token = create_test_jwt(sub="legit-user-001", role="USER")

    with TestClient(app) as client:
        response = client.post(
            "/api/v1/test-untrusted-body",
            json={
                "target": "https://suspicious-site.com",
                "user_id": "malicious-spoofed-subject",
                "role": "OWNER",
            },
            headers={"Authorization": f"Bearer {user_token}"},
        )
        assert response.status_code == 200
        data = response.json()
        # Authoritative principal retains genuine verified credentials
        assert data["authoritative_user_id"] == "legit-user-001"
        assert data["authoritative_role"] == "USER"


def test_forbidden_credentials_rejected_in_principal_construction():
    """Attempting to construct AuthenticatedPrincipal with passwords or secrets raises ValidationError."""
    # Top-level password attempt
    with pytest.raises(ValidationError) as exc1:
        AuthenticatedPrincipal(
            user_id="usr-123",
            password="plaintext_password_attempt",  # type: ignore[call-arg]
        )
    assert "must never exist" in str(exc1.value).lower() or "extra fields" in str(exc1.value).lower()

    # Inside custom_claims
    with pytest.raises(ValueError) as exc2:
        AuthenticatedPrincipal(
            user_id="usr-123",
            custom_claims={"otp": "123456", "token": "secret"},
        )
    assert "prohibited in custom claims" in str(exc2.value)


def test_principal_is_immutable():
    """AuthenticatedPrincipal instances are strictly immutable (frozen=True)."""
    principal = AuthenticatedPrincipal(
        user_id="usr-fixed-id",
        email="frozen@example.com",
        role=UserRole.USER,
    )
    with pytest.raises(ValidationError):
        principal.role = UserRole.OWNER  # type: ignore[misc]


def test_suspended_account_rejected_with_403():
    """A valid token for a suspended account is rejected with HTTP 403 Forbidden."""
    test_router = APIRouter()

    @test_router.get("/api/v1/account-status-check")
    def status_route(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"status": "ok"}

    settings = Settings(ENVIRONMENT="test", SUPABASE_JWT_SECRET=TEST_SECRET)
    app = create_application(settings=settings)
    app.include_router(test_router)

    suspended_token = create_test_jwt(sub="usr-banned", account_status="SUSPENDED")

    with TestClient(app) as client:
        response = client.get(
            "/api/v1/account-status-check",
            headers={"Authorization": f"Bearer {suspended_token}"},
        )
        assert response.status_code == 403
        data = response.json()
        assert data["error_code"] == "FORBIDDEN"
        assert "inactive or suspended" in data["message"].lower()


# ==============================================================================
# 4. Focused Security Review Tests (Phase 3.4 Verification)
# ==============================================================================

def test_token_with_incorrect_issuer_rejected_with_401():
    """Tokens with incorrect or missing issuer are rejected with 401 when issuer validation is configured."""
    test_router = APIRouter()

    @test_router.get("/api/v1/issuer-check")
    def issuer_route(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"user_id": principal.user_id}

    settings = Settings(
        ENVIRONMENT="test",
        SUPABASE_JWT_SECRET=TEST_SECRET,
        SUPABASE_JWT_ISSUER="https://auth.scamshield.ai",
    )
    app = create_application(settings=settings)
    app.include_router(test_router)

    with TestClient(app) as client:
        # 1. Wrong issuer
        token_wrong_iss = create_test_jwt(issuer="https://evil-unauthorized.issuer.com")
        res1 = client.get(
            "/api/v1/issuer-check",
            headers={"Authorization": f"Bearer {token_wrong_iss}"},
        )
        assert res1.status_code == 401
        assert res1.json()["error_code"] == "UNAUTHORIZED"

        # 2. Missing issuer
        token_missing_iss = create_test_jwt(issuer=None)
        res2 = client.get(
            "/api/v1/issuer-check",
            headers={"Authorization": f"Bearer {token_missing_iss}"},
        )
        assert res2.status_code == 401
        assert res2.json()["error_code"] == "UNAUTHORIZED"

        # 3. Matching issuer succeeds
        token_valid_iss = create_test_jwt(issuer="https://auth.scamshield.ai")
        res3 = client.get(
            "/api/v1/issuer-check",
            headers={"Authorization": f"Bearer {token_valid_iss}"},
        )
        assert res3.status_code == 200


def test_token_with_incorrect_audience_rejected_with_401():
    """Tokens with incorrect or missing audience are rejected with 401."""
    test_router = APIRouter()

    @test_router.get("/api/v1/aud-check")
    def aud_route(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"user_id": principal.user_id}

    settings = Settings(
        ENVIRONMENT="test",
        SUPABASE_JWT_SECRET=TEST_SECRET,
        SUPABASE_JWT_AUDIENCE="authenticated",
    )
    app = create_application(settings=settings)
    app.include_router(test_router)

    with TestClient(app) as client:
        # Wrong audience
        token_wrong_aud = create_test_jwt(aud="unrelated-service-audience")
        res1 = client.get(
            "/api/v1/aud-check",
            headers={"Authorization": f"Bearer {token_wrong_aud}"},
        )
        assert res1.status_code == 401
        assert res1.json()["error_code"] == "UNAUTHORIZED"

        # Missing audience
        token_no_aud = create_test_jwt(aud=None)
        res2 = client.get(
            "/api/v1/aud-check",
            headers={"Authorization": f"Bearer {token_no_aud}"},
        )
        assert res2.status_code == 401
        assert res2.json()["error_code"] == "UNAUTHORIZED"


def test_token_missing_role_defaults_safely_to_user():
    """When a verified token contains no role in app_metadata, it defaults safely to USER."""
    test_router = APIRouter()

    @test_router.get("/api/v1/role-default-check")
    def role_check(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"role": principal.role.value}

    settings = Settings(ENVIRONMENT="test", SUPABASE_JWT_SECRET=TEST_SECRET)
    app = create_application(settings=settings)
    app.include_router(test_router)

    # Token with no role claim
    token_no_role = create_test_jwt(role=None)

    with TestClient(app) as client:
        res = client.get(
            "/api/v1/role-default-check",
            headers={"Authorization": f"Bearer {token_no_role}"},
        )
        assert res.status_code == 200
        assert res.json()["role"] == "USER"


def test_token_unknown_role_defaults_safely_to_user():
    """When a token contains an unapproved or unknown role string, it defaults safely to least-privilege USER."""
    test_router = APIRouter()

    @test_router.get("/api/v1/unknown-role-check")
    def role_check(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"role": principal.role.value}

    settings = Settings(ENVIRONMENT="test", SUPABASE_JWT_SECRET=TEST_SECRET)
    app = create_application(settings=settings)
    app.include_router(test_router)

    token_unknown_role = create_test_jwt(role="UNAPPROVED_SUPERADMIN_ROLE")

    with TestClient(app) as client:
        res = client.get(
            "/api/v1/unknown-role-check",
            headers={"Authorization": f"Bearer {token_unknown_role}"},
        )
        assert res.status_code == 200
        assert res.json()["role"] == "USER"


def test_user_metadata_role_privilege_escalation_prevented():
    """user_metadata.role is client-writable in Supabase and must NEVER grant administrative privileges."""
    from app.core.dependencies import require_admin, require_owner

    test_router = APIRouter()

    @test_router.get("/api/v1/admin-only-action")
    def admin_action(principal: AuthenticatedPrincipal = Depends(require_admin)):
        return {"status": "admin_granted"}

    @test_router.get("/api/v1/owner-only-action")
    def owner_action(principal: AuthenticatedPrincipal = Depends(require_owner)):
        return {"status": "owner_granted"}

    @test_router.get("/api/v1/inspect-principal-role")
    def inspect_role(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"role": principal.role.value}

    settings = Settings(ENVIRONMENT="test", SUPABASE_JWT_SECRET=TEST_SECRET)
    app = create_application(settings=settings)
    app.include_router(test_router)

    # Attack Vector 1: Attacker sets user_metadata.role = "ADMIN" while app_metadata.role = "USER"
    exploit_token_1 = create_test_jwt(
        role="USER",
        custom_user_metadata={"role": "ADMIN"},
    )

    with TestClient(app) as client:
        # Admin access must be denied (403)
        res_admin = client.get(
            "/api/v1/admin-only-action",
            headers={"Authorization": f"Bearer {exploit_token_1}"},
        )
        assert res_admin.status_code == 403
        assert res_admin.json()["error_code"] == "FORBIDDEN"

        # Principal role is strictly USER
        res_role = client.get(
            "/api/v1/inspect-principal-role",
            headers={"Authorization": f"Bearer {exploit_token_1}"},
        )
        assert res_role.status_code == 200
        assert res_role.json()["role"] == "USER"

    # Attack Vector 2: Attacker sets user_metadata.role = "OWNER" while app_metadata has NO role
    exploit_token_2 = create_test_jwt(
        role=None,
        custom_user_metadata={"role": "OWNER"},
    )

    with TestClient(app) as client:
        res_owner = client.get(
            "/api/v1/owner-only-action",
            headers={"Authorization": f"Bearer {exploit_token_2}"},
        )
        assert res_owner.status_code == 403
        assert res_owner.json()["error_code"] == "FORBIDDEN"

        res_role2 = client.get(
            "/api/v1/inspect-principal-role",
            headers={"Authorization": f"Bearer {exploit_token_2}"},
        )
        assert res_role2.status_code == 200
        assert res_role2.json()["role"] == "USER"


def test_nested_custom_claims_mutation_blocked():
    """Ensure nested dictionaries, lists, and collections in custom_claims cannot be mutated after construction."""
    external_nested_dict = {
        "scope": {
            "department": "Security Ops",
            "permissions": ["scan:read", "scan:write"],
        },
        "flags": {"verified": True},
    }

    principal = AuthenticatedPrincipal(
        user_id="usr-freeze-check",
        email="frozen.security@scamshield.ai",
        role=UserRole.USER,
        custom_claims=external_nested_dict,
    )

    # 1. Top-level custom_claims item assignment must raise TypeError
    with pytest.raises(TypeError):
        principal.custom_claims["new_claim"] = "malicious_injection"

    # 2. Top-level item deletion must raise TypeError
    with pytest.raises(TypeError):
        del principal.custom_claims["flags"]

    # 3. Nested dictionary item assignment must raise TypeError
    with pytest.raises(TypeError):
        principal.custom_claims["scope"]["department"] = "Tampered Department"

    # 4. Nested dictionary item deletion must raise TypeError
    with pytest.raises(TypeError):
        del principal.custom_claims["scope"]["department"]

    # 5. Nested list mutation (append) must raise AttributeError (frozen into tuple)
    with pytest.raises(AttributeError):
        principal.custom_claims["scope"]["permissions"].append("admin:superuser")

    # 6. Mutating the external dictionary after construction has ZERO effect on principal
    external_nested_dict["scope"]["permissions"].append("outside_mutation")
    external_nested_dict["scope"]["department"] = "Outside Changed"
    assert "outside_mutation" not in principal.custom_claims["scope"]["permissions"]
    assert principal.custom_claims["scope"]["department"] == "Security Ops"


def test_unsupported_jwt_algorithm_none_rejected_with_401():
    """Tokens with alg: 'none' are rejected immediately with 401."""
    test_router = APIRouter()

    @test_router.get("/api/v1/alg-none-check")
    def alg_check(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"user_id": principal.user_id}

    settings = Settings(ENVIRONMENT="test", SUPABASE_JWT_SECRET=TEST_SECRET)
    app = create_application(settings=settings)
    app.include_router(test_router)

    token_none = create_test_jwt(algorithm="none")

    with TestClient(app) as client:
        res = client.get(
            "/api/v1/alg-none-check",
            headers={"Authorization": f"Bearer {token_none}"},
        )
        assert res.status_code == 401
        data = res.json()
        assert data["error_code"] == "UNAUTHORIZED"
        assert "disallowed" in data["message"].lower() or "unsupported" in data["message"].lower()


def test_unsupported_jwt_algorithm_not_in_allowlist_rejected():
    """Tokens using an algorithm not in the explicit allowlist are rejected with 401."""
    test_router = APIRouter()

    @test_router.get("/api/v1/alg-allowlist-check")
    def alg_check(principal: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"user_id": principal.user_id}

    # Settings only allow HS256
    settings = Settings(
        ENVIRONMENT="test",
        SUPABASE_JWT_SECRET=TEST_SECRET,
        ALLOWED_JWT_ALGORITHMS=["HS256"],
    )
    app = create_application(settings=settings)
    app.include_router(test_router)

    # Encode with HS512 (valid HMAC >= 64 bytes, but not in our configured allowlist)
    key_64_bytes = "super-secret-test-jwt-signing-key-minimum-64-bytes-long-for-sha512-test!"
    token_hs512 = create_test_jwt(algorithm="HS512", secret=key_64_bytes)

    with TestClient(app) as client:
        res = client.get(
            "/api/v1/alg-allowlist-check",
            headers={"Authorization": f"Bearer {token_hs512}"},
        )
        assert res.status_code == 401
        data = res.json()
        assert data["error_code"] == "UNAUTHORIZED"
        assert "disallowed" in data["message"].lower() or "unsupported" in data["message"].lower()
