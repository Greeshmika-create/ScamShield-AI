"""Tests for Phase 3.4 Role-Based Authorization, Admin Invitations, and Audit Events."""

from datetime import datetime, timezone
import pytest
from fastapi import APIRouter, Depends
from fastapi.testclient import TestClient

from app.core.audit import emit_audit_event, record_security_audit
from app.core.dependencies import (
    require_admin,
    require_authenticated_user,
    require_owner,
    require_permission,
)
from app.core.errors import ForbiddenException, InvalidInputException
from app.core.permissions import (
    can_modify_role,
    has_permission,
    validate_role_assignment,
)
from app.main import create_application
from app.schemas.audit import AuditEvent
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import AccountStatus, AuditEventType, Permission, UserRole
from app.schemas.invitation import AdminInvitationCreate, AdminInvitationResponse
from app.services.invitation_service import AdminInvitationService


# Fixtures for standardized test principals
@pytest.fixture
def user_principal() -> AuthenticatedPrincipal:
    return AuthenticatedPrincipal(
        user_id="user-001",
        email="normal.user@example.com",
        role=UserRole.USER,
        account_status=AccountStatus.ACTIVE,
    )


@pytest.fixture
def admin_principal() -> AuthenticatedPrincipal:
    return AuthenticatedPrincipal(
        user_id="admin-001",
        email="operations.admin@scamshield.ai",
        role=UserRole.ADMIN,
        account_status=AccountStatus.ACTIVE,
    )


@pytest.fixture
def owner_principal() -> AuthenticatedPrincipal:
    return AuthenticatedPrincipal(
        user_id="owner-001",
        email="system.owner@scamshield.ai",
        role=UserRole.OWNER,
        account_status=AccountStatus.ACTIVE,
    )


# ==============================================================================
# 1. Role-Based Access Control Endpoint Dependencies Tests
# ==============================================================================

def test_user_can_access_user_endpoints_but_denied_admin_and_owner(user_principal: AuthenticatedPrincipal):
    """A USER can access general protected endpoints, but is rejected with 403 from admin and owner routes."""
    test_router = APIRouter()

    @test_router.get("/api/v1/user-area")
    def user_area(p: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"access": "granted", "role": p.role.value}

    @test_router.get("/api/v1/admin-area")
    def admin_area(p: AuthenticatedPrincipal = Depends(require_admin)):
        return {"access": "granted", "role": p.role.value}

    @test_router.get("/api/v1/owner-area")
    def owner_area(p: AuthenticatedPrincipal = Depends(require_owner)):
        return {"access": "granted", "role": p.role.value}

    app = create_application()
    app.include_router(test_router)
    # Inject authenticated user principal
    app.dependency_overrides[require_authenticated_user] = lambda: user_principal

    with TestClient(app) as client:
        # 1. User area: 200 OK
        res_user = client.get("/api/v1/user-area")
        assert res_user.status_code == 200
        assert res_user.json()["role"] == "USER"

        # 2. Admin area: 403 Forbidden (NOT 401)
        res_admin = client.get("/api/v1/admin-area")
        assert res_admin.status_code == 403
        data_admin = res_admin.json()
        assert data_admin["error_code"] == "FORBIDDEN"
        assert "Administrator privileges required" in data_admin["message"]

        # 3. Owner area: 403 Forbidden
        res_owner = client.get("/api/v1/owner-area")
        assert res_owner.status_code == 403
        data_owner = res_owner.json()
        assert data_owner["error_code"] == "FORBIDDEN"
        assert "OWNER privileges required" in data_owner["message"]


def test_admin_can_access_admin_endpoints_but_denied_owner_endpoints(admin_principal: AuthenticatedPrincipal):
    """An ADMIN can access admin operations, but is strictly denied OWNER operations with 403."""
    test_router = APIRouter()

    @test_router.get("/api/v1/admin-dashboard")
    def admin_route(p: AuthenticatedPrincipal = Depends(require_admin)):
        return {"dashboard": "admin", "role": p.role.value}

    @test_router.get("/api/v1/owner-root")
    def owner_route(p: AuthenticatedPrincipal = Depends(require_owner)):
        return {"root": "owner", "role": p.role.value}

    app = create_application()
    app.include_router(test_router)
    app.dependency_overrides[require_authenticated_user] = lambda: admin_principal

    with TestClient(app) as client:
        # Admin route succeeds
        res_admin = client.get("/api/v1/admin-dashboard")
        assert res_admin.status_code == 200
        assert res_admin.json()["role"] == "ADMIN"

        # Owner route is rejected with 403
        res_owner = client.get("/api/v1/owner-root")
        assert res_owner.status_code == 403
        assert res_owner.json()["error_code"] == "FORBIDDEN"
        assert "OWNER privileges required" in res_owner.json()["message"]


def test_owner_can_access_all_tiers(owner_principal: AuthenticatedPrincipal):
    """An OWNER holds root authority and can access USER, ADMIN, and OWNER routes."""
    test_router = APIRouter()

    @test_router.get("/api/v1/user-op")
    def user_op(p: AuthenticatedPrincipal = Depends(require_authenticated_user)):
        return {"ok": True}

    @test_router.get("/api/v1/admin-op")
    def admin_op(p: AuthenticatedPrincipal = Depends(require_admin)):
        return {"ok": True}

    @test_router.get("/api/v1/owner-op")
    def owner_op(p: AuthenticatedPrincipal = Depends(require_owner)):
        return {"ok": True}

    app = create_application()
    app.include_router(test_router)
    app.dependency_overrides[require_authenticated_user] = lambda: owner_principal

    with TestClient(app) as client:
        assert client.get("/api/v1/user-op").status_code == 200
        assert client.get("/api/v1/admin-op").status_code == 200
        assert client.get("/api/v1/owner-op").status_code == 200


def test_granular_permission_dependency(user_principal: AuthenticatedPrincipal, admin_principal: AuthenticatedPrincipal):
    """Granular require_permission dependency accurately enforces specific matrix entries."""
    test_router = APIRouter()

    @test_router.get("/api/v1/scan-action")
    def scan_action(p: AuthenticatedPrincipal = Depends(require_permission(Permission.SCAN_EXECUTE))):
        return {"scan": True}

    @test_router.get("/api/v1/admin-view")
    def admin_view(p: AuthenticatedPrincipal = Depends(require_permission(Permission.ADMIN_READ))):
        return {"admin_read": True}

    app = create_application()
    app.include_router(test_router)

    # 1. Test as USER
    app.dependency_overrides[require_authenticated_user] = lambda: user_principal
    with TestClient(app) as client:
        # User has Permission.SCAN_EXECUTE
        assert client.get("/api/v1/scan-action").status_code == 200
        # User lacks Permission.ADMIN_READ
        res_denied = client.get("/api/v1/admin-view")
        assert res_denied.status_code == 403
        assert res_denied.json()["error_code"] == "FORBIDDEN"

    # 2. Test as ADMIN
    app.dependency_overrides[require_authenticated_user] = lambda: admin_principal
    with TestClient(app) as client:
        # Admin has both
        assert client.get("/api/v1/scan-action").status_code == 200
        assert client.get("/api/v1/admin-view").status_code == 200


# ==============================================================================
# 2. Privilege Escalation & Policy Rules
# ==============================================================================

def test_role_escalation_rules(
    user_principal: AuthenticatedPrincipal,
    admin_principal: AuthenticatedPrincipal,
    owner_principal: AuthenticatedPrincipal,
):
    """Verify role escalation boundaries."""
    # 1. User cannot modify any role
    assert can_modify_role(user_principal, UserRole.USER, UserRole.ADMIN) is False
    assert can_modify_role(user_principal, UserRole.USER, UserRole.OWNER) is False

    # 2. Admin cannot modify any role or become OWNER
    assert can_modify_role(admin_principal, UserRole.USER, UserRole.ADMIN) is False
    assert can_modify_role(admin_principal, UserRole.ADMIN, UserRole.OWNER) is False

    # 3. Owner can promote USER to ADMIN
    assert can_modify_role(owner_principal, UserRole.USER, UserRole.ADMIN) is True

    # 4. Owner cannot elevate anyone to OWNER through routine assignment
    assert can_modify_role(owner_principal, UserRole.ADMIN, UserRole.OWNER) is False


def test_validate_role_assignment_enforces_owner_only(
    user_principal: AuthenticatedPrincipal,
    admin_principal: AuthenticatedPrincipal,
    owner_principal: AuthenticatedPrincipal,
):
    """validate_role_assignment raises ForbiddenException for non-owners and rejects OWNER targets."""
    # User attempt -> 403
    with pytest.raises(ForbiddenException) as exc1:
        validate_role_assignment(actor=user_principal, target_new_role=UserRole.ADMIN)
    assert "Only the system OWNER" in exc1.value.message

    # Admin attempt -> 403
    with pytest.raises(ForbiddenException) as exc2:
        validate_role_assignment(actor=admin_principal, target_new_role=UserRole.ADMIN)
    assert "Only the system OWNER" in exc2.value.message

    # Owner promoting to ADMIN -> passes cleanly
    validate_role_assignment(actor=owner_principal, target_new_role=UserRole.ADMIN)

    # Owner promoting to OWNER -> rejected with 403
    with pytest.raises(ForbiddenException) as exc3:
        validate_role_assignment(actor=owner_principal, target_new_role=UserRole.OWNER)
    assert "OWNER role cannot be assigned" in exc3.value.message


# ==============================================================================
# 3. Admin Invitation Service Foundations
# ==============================================================================

def test_admin_invitation_created_by_owner(owner_principal: AuthenticatedPrincipal, caplog: pytest.LogCaptureFixture):
    """Owner successfully creates admin invitation contract and audit event is recorded."""
    service = AdminInvitationService()
    invitation_payload = AdminInvitationCreate(
        invitee_email="new.ops@scamshield.ai",
        role=UserRole.ADMIN,
    )

    with caplog.at_level("INFO", logger="scamshield.audit"):
        response = service.create_invitation(actor=owner_principal, invitation_data=invitation_payload)

    assert isinstance(response, AdminInvitationResponse)
    assert response.invitee_email == "new.ops@scamshield.ai"
    assert response.role == UserRole.ADMIN
    assert response.status.value == "PENDING"
    assert response.inviter_user_id == owner_principal.user_id
    assert response.expires_at > response.created_at

    # Audit log entry created
    assert "ADMIN_INVITED" in caplog.text
    assert "new.ops@scamshield.ai" in caplog.text


def test_admin_invitation_rejected_for_non_owner(admin_principal: AuthenticatedPrincipal):
    """An ADMIN attempting to create an administrator invitation is denied with 403."""
    service = AdminInvitationService()
    invitation_payload = AdminInvitationCreate(
        invitee_email="another.admin@scamshield.ai",
        role=UserRole.ADMIN,
    )

    with pytest.raises(ForbiddenException) as exc:
        service.create_invitation(actor=admin_principal, invitation_data=invitation_payload)
    assert exc.value.status_code == 403
    assert "Only the system OWNER" in exc.value.message


def test_admin_invitation_cannot_invite_owner_role():
    """AdminInvitationCreate schema rejects OWNER as an assignable invitation role."""
    with pytest.raises(ValueError) as exc:
        AdminInvitationCreate(
            invitee_email="fake.owner@scamshield.ai",
            role=UserRole.OWNER,  # type: ignore[arg-type]
        )
    assert "Only the 'ADMIN' role can be assigned" in str(exc.value)


def test_admin_invitation_self_invite_rejected(owner_principal: AuthenticatedPrincipal):
    """Owner attempting to invite their own email address is rejected with 422."""
    service = AdminInvitationService()
    self_invitation = AdminInvitationCreate(
        invitee_email=owner_principal.email,
        role=UserRole.ADMIN,
    )

    with pytest.raises(InvalidInputException) as exc:
        service.create_invitation(actor=owner_principal, invitation_data=self_invitation)
    assert "Cannot issue an administrator invitation to oneself" in exc.value.message


# ==============================================================================
# 4. Audit Event Sanitization Tests
# ==============================================================================

def test_audit_event_sanitizes_credentials_and_tokens():
    """AuditEvent automatically scrubs passwords, tokens, OTPs, and sensitive message data."""
    event = record_security_audit(
        event_type=AuditEventType.ROLE_ASSIGNED,
        action="test_assign",
        actor_user_id="owner-001",
        actor_role=UserRole.OWNER,
        target_user_id="target-002",
        details={
            "assigned_role": "ADMIN",
            "password": "UltraSecretPasswordToRedact!",
            "token": "secret_jwt_bearer_token",
            "otp": "991823",
            "raw_message": "Confidential scam text",
            "safe_metadata": "audit_ok",
        },
    )

    details = event.details
    # Sensitive keys must be redacted
    assert details["password"] == "[REDACTED_SECURITY_DATA]"
    assert details["token"] == "[REDACTED_SECURITY_DATA]"
    assert details["otp"] == "[REDACTED_SECURITY_DATA]"
    assert details["raw_message"] == "[REDACTED_SECURITY_DATA]"
    # Non-sensitive keys remain intact
    assert details["safe_metadata"] == "audit_ok"
    assert details["assigned_role"] == "ADMIN"


def test_permission_denied_emits_audit_event(
    user_principal: AuthenticatedPrincipal,
    caplog: pytest.LogCaptureFixture,
):
    """When an unauthorized request is denied, a PERMISSION_DENIED audit event is logged."""
    test_router = APIRouter()

    @test_router.get("/api/v1/restricted-admin")
    def restricted(p: AuthenticatedPrincipal = Depends(require_admin)):
        return {"ok": True}

    app = create_application()
    app.include_router(test_router)
    app.dependency_overrides[require_authenticated_user] = lambda: user_principal

    with caplog.at_level("INFO", logger="scamshield.audit"):
        with TestClient(app) as client:
            res = client.get("/api/v1/restricted-admin")
            assert res.status_code == 403

    assert "AUDIT_EVENT [PERMISSION_DENIED]" in caplog.text
    assert user_principal.user_id in caplog.text
    assert "/api/v1/restricted-admin" in caplog.text

