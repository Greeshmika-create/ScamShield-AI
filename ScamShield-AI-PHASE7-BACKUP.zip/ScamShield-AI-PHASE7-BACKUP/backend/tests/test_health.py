"""Tests for genuine health evaluation and dependency reporting."""

from fastapi.testclient import TestClient
from app.core.config import Settings
from app.main import create_application


def test_health_endpoint_returns_200_and_schema(client: TestClient):
    """GET /api/v1/health must return 200 OK and conform to specification."""
    response = client.get("/api/v1/health")
    assert response.status_code == 200

    data = response.json()
    assert data["status"] == "OPERATIONAL"
    assert data["version"] == "1.0.0"
    assert data["environment"] == "test"
    assert "timestamp" in data
    assert "components" in data
    assert "providers" in data


def test_health_reports_genuine_component_status_without_assumptions(client: TestClient):
    """Components must report genuine state: database NOT_CONFIGURED, ML false."""
    response = client.get("/api/v1/health")
    data = response.json()
    components = data["components"]

    # Gateway is active
    assert components["api_gateway"] == "HEALTHY"

    # Database is NOT claimed as connected when unconfigured or not initialized
    assert components["supabase_connection"] in ["NOT_CONFIGURED", "NOT_CONNECTED"]
    assert components["supabase_connection"] != "CONNECTED"

    # ML artifact is verified and loaded by the shared classifier
    assert components["ml_models_loaded"] is True


def test_health_reports_genuine_provider_status_without_assumptions(client: TestClient):
    """Providers must report UNCONFIGURED when keys are absent, never claim HEALTHY falsely."""
    response = client.get("/api/v1/health")
    data = response.json()
    providers = data["providers"]

    assert providers["google_safe_browsing"] == "UNCONFIGURED"
    assert providers["urlhaus"] == "UNCONFIGURED"
    assert providers["phishtank"] == "UNCONFIGURED"


def test_health_with_configured_keys_reports_not_initialized():
    """When API keys are supplied in settings, providers report NOT_INITIALIZED, not false HEALTHY."""
    settings = Settings(
        ENVIRONMENT="test",
        GOOGLE_SAFE_BROWSING_API_KEY="AIzaSyDummyKeyForTesting",
        URLHAUS_API_KEY="dummy_urlhaus_key",
        PHISHTANK_API_KEY="dummy_phishtank_key",
        SUPABASE_URL="https://testproject.supabase.co",
        SUPABASE_SERVICE_ROLE_KEY="eyDummyServiceRoleKeyForTesting",
    )
    app = create_application(settings=settings)
    with TestClient(app) as test_client:
        response = test_client.get("/api/v1/health")
        assert response.status_code == 200
        data = response.json()

        # Database credentials exist but connection is not initialized in Phase 3.1
        assert data["components"]["supabase_connection"] == "NOT_CONNECTED"

        # Credentials exist, but provider availability has not been live-verified
        assert data["providers"]["google_safe_browsing"] == "CONFIGURED_NOT_VERIFIED"
        assert data["providers"]["urlhaus"] == "CONFIGURED_NOT_VERIFIED"
        assert data["providers"]["phishtank"] == "CONFIGURED_NOT_VERIFIED"

