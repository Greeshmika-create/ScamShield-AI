"""Tests for CORS policy enforcement and origin validation."""

from fastapi.testclient import TestClient
from app.core.config import Settings
from app.main import create_application


def test_cors_allowed_origin_preflight():
    """OPTIONS preflight from configured origin is granted CORS headers."""
    settings = Settings(
        ENVIRONMENT="test",
        CORS_ORIGINS=["http://localhost:5173", "http://127.0.0.1:5173"],
    )
    app = create_application(settings=settings)

    with TestClient(app) as client:
        response = client.options(
            "/api/v1/health",
            headers={
                "Origin": "http://localhost:5173",
                "Access-Control-Request-Method": "GET",
                "Access-Control-Request-Headers": "Content-Type",
            },
        )
        assert response.status_code == 200
        assert response.headers.get("access-control-allow-origin") == "http://localhost:5173"


def test_cors_disallowed_origin_rejected():
    """OPTIONS preflight from untrusted origin does NOT receive allow-origin header."""
    settings = Settings(
        ENVIRONMENT="test",
        CORS_ORIGINS=["http://localhost:5173"],
    )
    app = create_application(settings=settings)

    with TestClient(app) as client:
        response = client.options(
            "/api/v1/health",
            headers={
                "Origin": "http://malicious-site.com",
                "Access-Control-Request-Method": "GET",
            },
        )
        # Untrusted origin must not be granted access
        assert response.headers.get("access-control-allow-origin") != "http://malicious-site.com"


def test_cors_allowed_origin_get_request():
    """GET request from allowed origin receives appropriate access-control-allow-origin header."""
    settings = Settings(
        ENVIRONMENT="test",
        CORS_ORIGINS=["http://localhost:5173"],
    )
    app = create_application(settings=settings)

    with TestClient(app) as client:
        response = client.get(
            "/api/v1/health",
            headers={"Origin": "http://localhost:5173"},
        )
        assert response.status_code == 200
        assert response.headers.get("access-control-allow-origin") == "http://localhost:5173"

