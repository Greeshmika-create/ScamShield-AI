"""Local Phase 10 database lifecycle, persistence, ownership, and telemetry tests."""

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.core.config import Settings
from app.core.dependencies import require_authenticated_user
from app.db.connection import DatabaseManager
from app.db.repository import ScanRepository
from app.main import create_application
from app.schemas.auth import AuthenticatedPrincipal


class FakeConnection:
    async def fetchval(self, query):
        return 1


class FakeAcquire:
    def __init__(self, connection):
        self.connection = connection

    async def __aenter__(self):
        return self.connection

    async def __aexit__(self, exc_type, exc, tb):
        return False


class FakePool:
    def __init__(self):
        self.connection = FakeConnection()
        self.closed = False

    def acquire(self):
        return FakeAcquire(self.connection)

    async def close(self):
        self.closed = True


@pytest.mark.asyncio
async def test_database_unconfigured_is_safe():
    manager = DatabaseManager(Settings(ENVIRONMENT="test"))
    await manager.start()
    assert manager.status == "UNCONFIGURED"
    assert await manager.check_connection() == "UNCONFIGURED"
    await manager.stop()


@pytest.mark.asyncio
async def test_database_startup_shutdown_and_health_mock(monkeypatch):
    pool = FakePool()

    async def fake_create_pool(**kwargs):
        assert kwargs["min_size"] >= 0
        assert kwargs["max_size"] >= 1
        assert kwargs["timeout"] > 0
        return pool

    monkeypatch.setattr("app.db.connection.asyncpg.create_pool", fake_create_pool)
    settings = Settings(
        ENVIRONMENT="test",
        SUPABASE_DB_URL="postgresql://test:test@localhost/test",
    )
    manager = DatabaseManager(settings)

    await manager.start()
    assert manager.status == "CONNECTED"
    assert await manager.check_connection() == "CONNECTED"
    await manager.stop()
    assert pool.closed is True
    assert manager.status == "DISCONNECTED"


@pytest.mark.asyncio
async def test_database_connection_error_is_nonfatal(monkeypatch):
    async def broken_create_pool(**kwargs):
        raise RuntimeError("credentials are sensitive")

    monkeypatch.setattr("app.db.connection.asyncpg.create_pool", broken_create_pool)
    manager = DatabaseManager(Settings(
        ENVIRONMENT="test",
        SUPABASE_DB_URL="postgresql://test:test@localhost/test",
    ))
    await manager.start()
    assert manager.status == "DISCONNECTED"


def test_migration_contains_core_tables_rls_and_indexes():
    migration = (
        Path(__file__).resolve().parents[1] / "migrations" / "001_phase10_supabase.sql"
    ).read_text(encoding="utf-8")
    for table in (
        "user_profiles", "scans", "url_analysis_records", "message_analysis_records",
        "threat_findings", "risk_assessments", "provider_reports", "audit_events",
    ):
        assert f"CREATE TABLE IF NOT EXISTS public.{table}" in migration
    assert "ENABLE ROW LEVEL SECURITY" in migration
    assert "owner_user_id = auth.uid()::text" in migration
    assert "CREATE INDEX" in migration


def test_history_requires_permission_and_returns_empty_without_database():
    app = create_application(Settings(ENVIRONMENT="test"))
    app.dependency_overrides[require_authenticated_user] = lambda: AuthenticatedPrincipal(
        user_id="owner-1"
    )
    with TestClient(app) as client:
        response = client.get("/api/v1/history?limit=20&offset=0")
    assert response.status_code == 200
    assert response.json()["total_count"] == 0
    assert response.json()["items"] == []


def test_history_detail_rejects_another_users_record(monkeypatch):
    app = create_application(Settings(ENVIRONMENT="test"))
    app.dependency_overrides[require_authenticated_user] = lambda: AuthenticatedPrincipal(
        user_id="owner-1"
    )

    class EmptyRepository:
        def __init__(self, database):
            pass

        async def get_scan_detail(self, owner_user_id, scan_id):
            assert owner_user_id == "owner-1"
            return None

    monkeypatch.setattr("app.api.v1.endpoints.history.ScanRepository", EmptyRepository)
    app.state.database = object()

    with TestClient(app) as client:
        response = client.get("/api/v1/history/00000000-0000-0000-0000-000000000001")
    assert response.status_code == 404


def test_analytics_requires_permission_and_returns_zero_empty_stats():
    app = create_application(Settings(ENVIRONMENT="test"))
    app.dependency_overrides[require_authenticated_user] = lambda: AuthenticatedPrincipal(
        user_id="owner-1"
    )
    with TestClient(app) as client:
        response = client.get("/api/v1/analytics/overview")
    assert response.status_code == 200
    body = response.json()
    assert body["total_scans"] == 0
    assert body["average_scan_latency_ms"] == 0
    assert body["top_threat_categories"] == []


def test_health_database_status_is_not_claimed_connected_when_unconfigured():
    app = create_application(Settings(ENVIRONMENT="test"))
    with TestClient(app) as client:
        response = client.get("/api/v1/health")
    assert response.status_code == 200
    status = response.json()["components"]["supabase_connection"]
    assert status in {"UNCONFIGURED", "NOT_CONFIGURED", "NOT_CONNECTED", "DISCONNECTED"}
    assert status != "CONNECTED"


def test_health_uses_real_database_manager_status(monkeypatch):
    pool = FakePool()

    async def fake_create_pool(**kwargs):
        return pool

    monkeypatch.setattr("app.db.connection.asyncpg.create_pool", fake_create_pool)
    app = create_application(Settings(ENVIRONMENT="test", SUPABASE_DB_URL="postgresql://test:test@localhost/test"))
    with TestClient(app) as client:
        response = client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json()["components"]["supabase_connection"] == "CONNECTED"


def test_repository_history_empty_without_pool():
    class EmptyManager:
        pool = None

    repository = ScanRepository(EmptyManager())
    import asyncio
    response = asyncio.run(repository.list_history("owner-1", __import__("app.schemas.history", fromlist=["HistoryQueryParams"]).HistoryQueryParams()))
    assert response.total_count == 0
    assert response.items == []


def test_scan_url_persistence_is_best_effort_and_does_not_echo_raw_secret(monkeypatch):
    app = create_application(Settings(ENVIRONMENT="test"))
    app.dependency_overrides[require_authenticated_user] = lambda: AuthenticatedPrincipal(
        user_id="owner-1"
    )

    async def fake_save(self, **kwargs):
        assert kwargs["owner_user_id"] == "owner-1"
        assert kwargs["target_preview"].startswith("https://example.com")
        assert "password" not in kwargs["target_preview"]
        return "00000000-0000-0000-0000-000000000001"

    monkeypatch.setattr("app.db.repository.ScanRepository.save_completed_scan", fake_save)
    app.state.database = object()

    from app.api.v1.endpoints import scan_url as scan_url_module

    class StubClassifier:
        def predict_from_features(self, features):
            from app.schemas.ml_analysis import URLMLAnalysis
            return URLMLAnalysis(prediction="BENIGN", threat_probability=0.1,
                                  evaluation_metadata={"status": "INFERRED"})

    class StubIntel:
        async def inspect_url(self, target):
            from app.schemas.threat_intelligence import ProviderReport
            from app.schemas.enums import ProviderStatus
            return [ProviderReport(provider_name="Mock", status=ProviderStatus.AVAILABLE_CLEAN)]

    monkeypatch.setattr(scan_url_module, "InspectionOrchestrator", lambda: __import__(
        "app.services.inspection_orchestrator", fromlist=["InspectionOrchestrator"]
    ).InspectionOrchestrator(classifier=StubClassifier(), threat_intel=StubIntel()))

    with TestClient(app) as client:
        response = client.post(
            "/api/v1/scan/url",
            json={"url": "https://user:password@example.com/login?api_key=secret"},
        )

    assert response.status_code == 200
    assert "password" not in response.text
    assert "secret" not in response.text
