"""Tests for MessageScanRequest static validation, multilingual support, and MessageScanResponse."""

import pytest
from pydantic import ValidationError
from app.schemas.common import UserGuidance
from app.schemas.enums import ConfidenceLevel, DetectedLanguage, EvidenceCategory, FindingSeverity, Verdict
from app.schemas.evidence import ThreatFinding
from app.schemas.message_scan import MessageScanRequest, MessageScanResponse
from app.schemas.ml_analysis import MessageMLAnalysis


def test_valid_english_message():
    """Standard English scam alert message passes validation and is trimmed."""
    raw = "  Your bank account has been suspended due to incomplete KYC. Verify immediately: https://fake-kyc.in  "
    req = MessageScanRequest(message_text=raw)
    assert req.message_text == raw.strip()
    assert req.sender_identifier is None


def test_valid_telugu_unicode_message():
    """Native Telugu Unicode text is accepted without distortion or truncation."""
    telugu_text = "మీ బ్యాంక్ ఖాతా తాత్కాలికంగా నిలిపివేయబడింది. దయచేసి వెంటనే కేవైసీ వివరాలు నమోదు చేయండి: https://secure-bank.co.in"
    req = MessageScanRequest(
        message_text=telugu_text,
        sender_identifier="AX-SBIINB",
    )
    assert req.message_text == telugu_text
    assert req.sender_identifier == "AX-SBIINB"
    # Ensure Telugu unicode code points are preserved
    assert "\u0C2E" in req.message_text  # Telugu letter Ma


def test_valid_telugish_message():
    """Transliterated Telugish text is accepted."""
    telugish_text = "Mee SBI YONO account block aindi. Ventane update cheyandi lekapothe balance freeze avthundi."
    req = MessageScanRequest(message_text=telugish_text)
    assert req.message_text == telugish_text


def test_valid_unicode_emojis_message():
    """Messages containing Unicode emojis and symbols are properly supported."""
    emoji_text = "⚠️ 🚨 💰 💳 Urgent warning! Your electricity bill is pending. Pay now: http://bill-pay.click"
    req = MessageScanRequest(message_text=emoji_text)
    assert "🚨" in req.message_text
    assert req.message_text == emoji_text


def test_empty_and_whitespace_message_rejected():
    """Empty and whitespace-only message bodies are rejected."""
    for empty_val in ["", "   ", "\t", "\n", "\r\n"]:
        with pytest.raises(ValidationError) as exc_info:
            MessageScanRequest(message_text=empty_val)
        assert "cannot be empty" in str(exc_info.value).lower()


def test_minimum_length_rejected():
    """Messages with fewer than 5 characters are rejected."""
    for short_text in ["a", "ab", "abc", "abcd", "  ok "]:
        with pytest.raises(ValidationError) as exc_info:
            MessageScanRequest(message_text=short_text)
        assert "at least 5 characters" in str(exc_info.value).lower()


def test_maximum_length_boundary():
    """Message of exactly 5000 Unicode characters succeeds; 5001 fails."""
    # 5000 characters exact
    exact_msg = "A" * 5000
    req = MessageScanRequest(message_text=exact_msg)
    assert len(req.message_text) == 5000

    # 5001 characters fails
    overlength_msg = "A" * 5001
    with pytest.raises(ValidationError) as exc_info:
        MessageScanRequest(message_text=overlength_msg)
    assert "exceeds maximum permitted length of 5000" in str(exc_info.value)


def test_unicode_codepoint_vs_utf16_consistency():
    """
    Verify that exactly 5000 Unicode code points (even when containing surrogate-pair emojis)
    succeed, and 5001 code points fail.
    """
    # 2500 astral-plane emojis (each is 1 code point, 2 UTF-16 code units) + 2500 Telugu chars
    emoji_part = "🚨" * 2500
    telugu_part = "అ" * 2500
    msg_5000 = emoji_part + telugu_part
    assert len(msg_5000) == 5000

    req = MessageScanRequest(message_text=msg_5000)
    assert len(req.message_text) == 5000

    # 5001 code points fails validation
    msg_5001 = msg_5000 + "A"
    assert len(msg_5001) == 5001
    with pytest.raises(ValidationError) as exc:
        MessageScanRequest(message_text=msg_5001)
    assert "5000" in str(exc.value)


def test_sender_identifier_handling():
    """Sender identifier is trimmed, optional, and clamped to 64 chars."""
    # Valid alphanumeric
    req = MessageScanRequest(
        message_text="Urgent KYC verification required.",
        sender_identifier="  VK-HDFCBK  ",
    )
    assert req.sender_identifier == "VK-HDFCBK"

    # Whitespace-only sender normalizes to None
    req_ws = MessageScanRequest(
        message_text="Urgent KYC verification required.",
        sender_identifier="    ",
    )
    assert req_ws.sender_identifier is None

    # Over 64 chars is rejected
    with pytest.raises(ValidationError) as exc_info:
        MessageScanRequest(
            message_text="Urgent KYC verification required.",
            sender_identifier="A" * 65,
        )
    assert "64 characters" in str(exc_info.value)


def test_repr_masks_sensitive_pii():
    """Debug representation masks OTPs, phone numbers, and bank account numbers."""
    sensitive_msg = "Your OTP is 482910 for transaction. Contact manager at 9876543210 or card 4111 2222 3333 4444."
    req = MessageScanRequest(
        message_text=sensitive_msg,
        sender_identifier="+919876543210",
    )
    rep = repr(req)
    str_rep = str(req)

    # Raw PII must NOT appear in representation
    assert "482910" not in rep
    assert "4111" not in rep

    # Redaction placeholders must appear
    assert "[OTP-REDACTED]" in rep or "REDACTED" in rep
    assert str_rep == rep


def test_message_scan_response_serialization():
    """MessageScanResponse validates and serializes complete multilingual forensic report."""
    resp = MessageScanResponse(
        scan_id="7f139d4e-128a-4bc3-a801-98782a129d91",
        scanned_at="2026-11-05T11:36:00.540Z",
        message_preview="మీ ఖాతా తాత్కాలికంగా బ్లాక్ చేయబడింది...",
        detected_language=DetectedLanguage.TELUGU_SCRIPT.value,
        extracted_urls=["https://phish-sbi.click/update"],
        verdict=Verdict.MALICIOUS,
        risk_score=94,
        confidence_level=ConfidenceLevel.HIGH,
        findings=[
            ThreatFinding(
                category=EvidenceCategory.LINGUISTIC,
                rule_name="TELUGU_COERCION_URGENCY",
                severity=FindingSeverity.HIGH,
                title="ఖాతా నిలిపివేత బెదిరింపు (Account Suspension Threat)",
                description="Message induces artificial panic demanding immediate action.",
            )
        ],
        ml_analysis=MessageMLAnalysis(
            threat_probability=0.965,
            primary_intent="CREDENTIAL_HARVESTING",
            significant_ngrams=["బ్లాక్ చేయబడింది", "ventane"],
        ),
        user_guidance=UserGuidance(
            english="Do not open any link. Banks never notify account suspensions via unverified SMS.",
            telugu="ఈ లింక్‌ను ఓపెన్ చేయవద్దు. మీ బ్యాంక్ ఎప్పుడూ ఇలాంటి సందేశాల ద్వారా సమాచారం కోరదు.",
        ),
        execution_time_ms=45,
    )
    assert resp.verdict == Verdict.MALICIOUS
    assert resp.risk_score == 94
    assert resp.detected_language == "TELUGU_SCRIPT"
    assert len(resp.findings) == 1
    assert resp.ml_analysis.threat_probability == 0.965
    assert "బ్యాంక్" in resp.user_guidance.telugu

    # Verify JSON serialization handles unicode cleanly
    dumped_json = resp.model_dump_json()
    assert "7f139d4e-128a-4bc3-a801-98782a129d91" in dumped_json
    assert "MALICIOUS" in dumped_json
