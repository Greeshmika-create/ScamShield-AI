"""Tests for URLScanRequest static validation, safe normalization, and URLScanResponse."""

import pytest
from pydantic import ValidationError
from app.schemas.enums import ConfidenceLevel, ProviderStatus, Verdict
from app.schemas.evidence import ThreatFinding
from app.schemas.threat_intelligence import ProviderReport
from app.schemas.url_scan import URLScanRequest, URLScanResponse


def test_valid_http_url():
    """Valid HTTP URLs are accepted and canonicalized."""
    req = URLScanRequest(url="http://example.com/path?query=val")
    assert req.url == "http://example.com/path?query=val"

    req_ip = URLScanRequest(url="http://192.168.1.10/verify-bank-account")
    assert req_ip.url == "http://192.168.1.10/verify-bank-account"


def test_valid_https_url():
    """Valid HTTPS URLs are accepted and canonicalized."""
    req = URLScanRequest(url="https://secure.bank.co.in/netbanking")
    assert req.url == "https://secure.bank.co.in/netbanking"


def test_url_safe_normalization():
    """URL normalization trims whitespace and lowercases scheme and host."""
    req = URLScanRequest(url="  HTTPS://SECURE-PAYMENT.COM/Checkout?Token=ABC123XYZ  ")
    assert req.url == "https://secure-payment.com/Checkout?Token=ABC123XYZ"


def test_missing_scheme_rejected():
    """URLs lacking http:// or https:// scheme must be rejected."""
    for raw in ["example.com", "www.google.com/search", "//example.com"]:
        with pytest.raises(ValidationError) as exc_info:
            URLScanRequest(url=raw)
        assert "scheme" in str(exc_info.value).lower()


def test_unsupported_schemes_rejected():
    """Non-HTTP(S) schemes such as file, ftp, and javascript must be rejected."""
    unsupported = [
        "file:///etc/passwd",
        "ftp://ftp.example.com/file.zip",
        "javascript:alert(1)",
        "data:text/html,<h1>hack</h1>",
        "blob:https://example.com/uuid",
        "ssh://git@github.com",
    ]
    for raw in unsupported:
        with pytest.raises(ValidationError) as exc_info:
            URLScanRequest(url=raw)
        assert "unsupported scheme" in str(exc_info.value).lower()


def test_malformed_hostname_rejected():
    """URLs with invalid domain syntax, spaces, or empty labels must be rejected."""
    malformed = [
        "http://-invalid.com",
        "http://invalid-.com",
        "http://..com",
        "http://example..com",
        "http://inv alid.com",
        "http://",
        "https://",
    ]
    for raw in malformed:
        with pytest.raises(ValidationError):
            URLScanRequest(url=raw)


def test_empty_and_whitespace_url_rejected():
    """Empty strings and whitespace-only URLs must fail validation."""
    for raw in ["", "   ", "\t", "\n"]:
        with pytest.raises(ValidationError):
            URLScanRequest(url=raw)


def test_url_maximum_length_boundary():
    """URL of exactly 2048 characters succeeds; 2049 characters fails."""
    base = "https://example.com/path?"
    padding_len = 2048 - len(base)
    exact_url = base + ("a" * padding_len)
    assert len(exact_url) == 2048

    req = URLScanRequest(url=exact_url)
    assert len(req.url) == 2048

    overlength_url = exact_url + "b"
    assert len(overlength_url) == 2049
    with pytest.raises(ValidationError) as exc_info:
        URLScanRequest(url=overlength_url)
    assert "2048" in str(exc_info.value)


def test_url_scan_response_serialization():
    """URLScanResponse correctly validates and serializes full forensic report."""
    resp = URLScanResponse(
        scan_id="c8b417e2-4521-4fa2-9eb2-f38b25a3d750",
        scanned_at="2026-11-05T11:35:10.120Z",
        target_url="http://192.168.1.10/verify-bank-account",
        canonical_url="http://192.168.1.10/verify-bank-account",
        target_domain="192.168.1.10",
        verdict=Verdict.MALICIOUS,
        risk_score=96,
        confidence_level=ConfidenceLevel.HIGH,
        threat_intelligence=[
            ProviderReport(
                provider_name="URLhaus",
                status=ProviderStatus.AVAILABLE_FLAGGED,
                response_time_ms=289,
                threat_details="Known active malware distribution endpoint",
            )
        ],
        findings=[
            ThreatFinding(
                category="INTEL",  # type: ignore[arg-type]
                rule_name="URLHAUS_HIT",
                severity="CRITICAL",  # type: ignore[arg-type]
                title="Blacklisted on URLhaus",
                description="This exact endpoint is indexed as an active cyber threat.",
            )
        ],
        execution_time_ms=412,
    )
    assert resp.verdict == Verdict.MALICIOUS
    assert resp.risk_score == 96
    assert resp.confidence_level == ConfidenceLevel.HIGH
    assert len(resp.threat_intelligence) == 1
    assert resp.threat_intelligence[0].status == ProviderStatus.AVAILABLE_FLAGGED

