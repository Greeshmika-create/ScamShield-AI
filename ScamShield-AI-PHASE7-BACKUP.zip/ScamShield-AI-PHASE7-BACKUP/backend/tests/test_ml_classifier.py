"""Unit and integration tests for Phase 6 ML Model Artifact Management, Dataset Validation, and Inference Service."""

import json
from pathlib import Path
import tempfile
import pytest

from app.schemas.ml_analysis import MLFeatureImpact, URLMLAnalysis
from app.services.ml.artifact_manager import ArtifactLoadResult, MLArtifactLoader
from app.services.ml_classifier import URLClassifierService, get_url_classifier, clear_url_classifier_cache
from app.services.scanners.url_extractor import URL_FEATURE_NAMES, URLFeatureExtractor
from ml.src.dataset_validator import (
    DatasetValidationResult,
    DatasetValidator,
    map_binary_to_label,
    map_label_to_binary,
)


# ==============================================================================
# 1. Dataset Validator & Label Mapping Tests
# ==============================================================================

class TestDatasetValidator:
    """Verifies dataset schema enforcement, label consistency, and leakage checks."""

    def test_label_mapping_consistency(self):
        # BENIGN maps to 0
        assert map_label_to_binary("BENIGN") == 0
        assert map_label_to_binary("0") == 0

        # PHISHING and MALICIOUS map to positive threat class (1)
        assert map_label_to_binary("PHISHING") == 1
        assert map_label_to_binary("MALICIOUS") == 1
        assert map_label_to_binary("SUSPICIOUS") == 1
        assert map_label_to_binary("1") == 1

        # Unknown label raises ValueError
        with pytest.raises(ValueError):
            map_label_to_binary("UNKNOWN_LABEL")

        # Binary to label mapping
        assert map_binary_to_label(0) == "BENIGN"
        assert map_binary_to_label(1) == "PHISHING"
        assert map_binary_to_label(1, is_malicious=True) == "MALICIOUS"

    def test_validate_records_valid(self):
        # Build valid mock record containing all 32 features
        record = {feat: 1.0 for feat in URL_FEATURE_NAMES}
        record["label"] = "PHISHING"

        result = DatasetValidator.validate_records([record])
        assert result.is_valid is True
        assert result.total_records == 1
        assert result.feature_count == 32
        assert result.label_distribution == {"PHISHING": 1}
        assert len(result.errors) == 0

    def test_validate_records_missing_feature(self):
        record = {feat: 1.0 for feat in URL_FEATURE_NAMES}
        del record["has_ip_address"]  # Remove 1 feature
        record["label"] = "BENIGN"

        result = DatasetValidator.validate_records([record])
        assert result.is_valid is False
        assert any("Missing feature 'has_ip_address'" in err for err in result.errors)

    def test_validate_records_invalid_label(self):
        record = {feat: 1.0 for feat in URL_FEATURE_NAMES}
        record["label"] = "FAKE_UNVERIFIED_LABEL"

        result = DatasetValidator.validate_records([record])
        assert result.is_valid is False
        assert any("Invalid label" in err for err in result.errors)

    def test_validate_records_non_numeric(self):
        record = {feat: 1.0 for feat in URL_FEATURE_NAMES}
        record["count_dot"] = "not_a_number"
        record["label"] = "BENIGN"

        result = DatasetValidator.validate_records([record])
        assert result.is_valid is False
        assert any("Non-numeric value" in err for err in result.errors)


# ==============================================================================
# 2. Model Artifact Loader & Integrity Tests
# ==============================================================================

class TestMLArtifactLoader:
    """Verifies safe artifact loading, SHA-256 verification, and error boundaries."""

    def test_load_default_application_artifact(self):
        result = MLArtifactLoader.load_artifact()
        assert result.is_loaded is True
        assert result.status == "LOADED"
        assert result.model_id == "url_lexical_heuristic_reference_v1.0"
        assert result.model_type == "HEURISTIC_BASELINE"
        assert result.model_data is not None
        assert len(result.model_data["features"]) == 32
        assert len(result.model_data["weights"]) == 32
        assert result.error_message is None

    def test_missing_artifact_handling(self):
        with tempfile.TemporaryDirectory() as empty_dir:
            result = MLArtifactLoader.load_artifact(artifacts_dir=empty_dir)
            assert result.is_loaded is False
            assert result.status == "MODEL_NOT_FOUND"
            assert "manifest not found" in result.error_message

    def test_checksum_mismatch_detection(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            artifact_file = temp_path / "model.json"
            artifact_file.write_text(json.dumps({"features": list(URL_FEATURE_NAMES), "weights": {}}))

            metadata_file = temp_path / "metadata.json"
            metadata_file.write_text(
                json.dumps(
                    {
                        "artifact_filename": "model.json",
                        "sha256_checksum": "0000000000000000000000000000000000000000000000000000000000000000",
                        "model_id": "tampered_model",
                    }
                )
            )

            result = MLArtifactLoader.load_artifact(artifacts_dir=temp_dir)
            assert result.is_loaded is False
            assert result.status == "CHECKSUM_MISMATCH"
            assert "checksum mismatch" in result.error_message.lower()

    def test_schema_mismatch_detection(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            # Only 2 features instead of 32
            artifact_content = json.dumps({"features": ["url_length", "count_dot"], "weights": {"url_length": 1.0}})
            import hashlib
            checksum = hashlib.sha256(artifact_content.encode("utf-8")).hexdigest()

            artifact_file = temp_path / "model.json"
            artifact_file.write_text(artifact_content)

            metadata_file = temp_path / "metadata.json"
            metadata_file.write_text(
                json.dumps(
                    {
                        "artifact_filename": "model.json",
                        "sha256_checksum": checksum,
                        "model_id": "incomplete_model",
                    }
                )
            )

            result = MLArtifactLoader.load_artifact(artifacts_dir=temp_dir)
            assert result.is_loaded is False
            assert result.status == "SCHEMA_MISMATCH"
            assert "feature count mismatch" in result.error_message.lower()


# ==============================================================================
# 3. ML Inference Service Tests
# ==============================================================================

class TestURLClassifierService:
    def test_classifier_instance_is_reused(self):
        clear_url_classifier_cache()
        first = get_url_classifier()
        second = get_url_classifier()
        assert first is second

    """Verifies deterministic in-memory inference, probability calibration, and fallbacks."""

    def test_benign_url_inference(self):
        service = URLClassifierService()
        assert service.is_available is True

        analysis = service.predict_target("https://example.com/about")
        assert isinstance(analysis, URLMLAnalysis)
        assert analysis.prediction == "BENIGN"
        assert analysis.threat_probability is not None
        assert 0.0 <= analysis.threat_probability < 0.45
        assert analysis.evaluation_metadata["status"] == "INFERRED"
        assert analysis.evaluation_metadata["provenance"] == "HEURISTIC_BASELINE"

    def test_phishing_url_inference(self):
        service = URLClassifierService()
        phishing_url = "https://sbi-banking-alert.xyz/verify-kyc?account=update&upi=refund"
        analysis = service.predict_target(phishing_url)

        assert isinstance(analysis, URLMLAnalysis)
        assert analysis.prediction in {"PHISHING", "MALICIOUS"}
        assert analysis.threat_probability is not None
        assert analysis.threat_probability >= 0.85
        assert len(analysis.top_contributing_features) > 0

        # Verify positive risk feature impact
        feature_names = [f.feature for f in analysis.top_contributing_features]
        assert any("keyword" in name or "token" in name for name in feature_names)

    def test_malicious_ip_url_inference(self):
        service = URLClassifierService()
        analysis = service.predict_target("http://192.168.1.1:8080/admin/login")

        assert isinstance(analysis, URLMLAnalysis)
        assert analysis.prediction == "MALICIOUS"
        assert analysis.threat_probability is not None
        assert analysis.threat_probability >= 0.85

    def test_unavailable_model_safe_fallback(self):
        # Inject un-loaded artifact result (simulating missing or corrupt model)
        unavailable_result = ArtifactLoadResult(
            is_loaded=False,
            status="MODEL_NOT_FOUND",
            error_message="Model artifact missing from disk.",
        )
        service = URLClassifierService(artifact_loader_result=unavailable_result)
        assert service.is_available is False

        analysis = service.predict_target("https://example.com/test")
        assert isinstance(analysis, URLMLAnalysis)
        # Invariant: Threat probability MUST be strictly None when model is unavailable
        assert analysis.threat_probability is None
        assert analysis.prediction is None
        assert analysis.top_contributing_features is None
        assert analysis.evaluation_metadata["status"] == "UNAVAILABLE"
        # Invariant: Never claim a URL is BENIGN when model is offline
        assert analysis.prediction != "BENIGN"

    def test_deterministic_predictions(self):
        service = URLClassifierService()
        url = "https://portal.bank-verification.com/login"

        run1 = service.predict_target(url)
        run2 = service.predict_target(url)

        assert run1.threat_probability == run2.threat_probability
        assert run1.prediction == run2.prediction

    def test_inference_from_extracted_features(self):
        service = URLClassifierService()
        features = URLFeatureExtractor.extract("https://example.com/")

        analysis = service.predict_from_features(features)
        assert isinstance(analysis, URLMLAnalysis)
        assert analysis.prediction == "BENIGN"
        assert analysis.threat_probability is not None

