"""Tests for verdicts, threat intelligence reports, ML analysis, history, and analytics schemas."""

import pytest
from pydantic import ValidationError
from app.schemas.analytics import AnalyticsOverviewResponse, ThreatCategoryCount, VerdictDistribution
from app.schemas.enums import (
    ConfidenceLevel,
    ErrorCode,
    EvidenceCategory,
    FindingSeverity,
    ProviderStatus,
    SortOrder,
    TargetType,
    Verdict,
)
from app.schemas.error import StandardErrorResponse
from app.schemas.evidence import ThreatFinding
from app.schemas.history import HistoryItem, HistoryQueryParams, HistoryResponse
from app.schemas.ml_analysis import MessageMLAnalysis, MLFeatureImpact, URLMLAnalysis
from app.schemas.risk import RiskScoreDetails
from app.schemas.threat_intelligence import ProviderReport


def test_verdict_enum_values_and_rejection():
    """Only the 4 approved verdicts are valid; others are strictly rejected."""
    # All 4 valid verdicts
    for v in [Verdict.MALICIOUS, Verdict.SUSPICIOUS, Verdict.NO_KNOWN_THREAT, Verdict.UNVERIFIED]:
        item = HistoryItem(
            scan_id="123e4567-e89b-12d3-a456-426614174000",
            scanned_at="2026-11-05T12:00:00Z",
            target_type=TargetType.URL,
            target_preview="https://example.com",
            verdict=v,
            execution_time_ms=100,
        )
        assert item.verdict == v

    # Prohibited/invalid verdicts
    invalid_verdicts = ["SAFE", "CLEAN", "BENIGN", "DANGEROUS", "UNKNOWN", "VERIFIED"]
    for inv in invalid_verdicts:
        with pytest.raises(ValidationError):
            HistoryItem(
                scan_id="123e4567-e89b-12d3-a456-426614174000",
                scanned_at="2026-11-05T12:00:00Z",
                target_type=TargetType.URL,
                target_preview="https://example.com",
                verdict=inv,  # type: ignore[arg-type]
                execution_time_ms=100,
            )


def test_provider_status_enum_values_and_rejection():
    """Provider reports must adhere strictly to the 5 ProviderStatus states."""
    for st in [
        ProviderStatus.AVAILABLE_CLEAN,
        ProviderStatus.AVAILABLE_FLAGGED,
        ProviderStatus.TIMEOUT,
        ProviderStatus.ERROR,
        ProviderStatus.UNCONFIGURED,
    ]:
        rep = ProviderReport(provider_name="TestProvider", status=st)
        assert rep.status == st

    # Invalid status strings fail validation
    with pytest.raises(ValidationError):
        ProviderReport(provider_name="TestProvider", status="OFFLINE")  # type: ignore[arg-type]


def test_ml_threat_probability_handling():
    """Missing ML threat probability remains None and is never coerced to 0.0."""
    url_ml = URLMLAnalysis()
    assert url_ml.threat_probability is None

    msg_ml = MessageMLAnalysis()
    assert msg_ml.threat_probability is None

    # Valid boundaries
    url_ml_zero = URLMLAnalysis(threat_probability=0.0)
    assert url_ml_zero.threat_probability == 0.0

    url_ml_one = URLMLAnalysis(threat_probability=1.0)
    assert url_ml_one.threat_probability == 1.0

    url_ml_mid = URLMLAnalysis(threat_probability=0.884)
    assert url_ml_mid.threat_probability == 0.884

    # Out of boundary checks
    with pytest.raises(ValidationError):
        URLMLAnalysis(threat_probability=-0.01)

    with pytest.raises(ValidationError):
        URLMLAnalysis(threat_probability=1.05)


def test_ml_feature_impact_schema():
    """ML feature impacts support positive and negative risk directional weights."""
    feat = MLFeatureImpact(
        feature="has_ip_in_url",
        value=1.0,
        impact="POSITIVE_RISK",
    )
    assert feat.feature == "has_ip_in_url"
    assert feat.impact == "POSITIVE_RISK"


def test_risk_score_details_boundaries():
    """Risk scores are bounded strictly to 0..100, or None when unverified."""
    # Valid boundaries
    r0 = RiskScoreDetails(
        score=0,
        verdict=Verdict.NO_KNOWN_THREAT,
        confidence_level=ConfidenceLevel.HIGH,
    )
    assert r0.score == 0
    assert "never a guarantee" in r0.safety_disclaimer

    r100 = RiskScoreDetails(
        score=100,
        verdict=Verdict.MALICIOUS,
        confidence_level=ConfidenceLevel.HIGH,
    )
    assert r100.score == 100

    r_none = RiskScoreDetails(
        score=None,
        verdict=Verdict.UNVERIFIED,
        confidence_level=ConfidenceLevel.PROVISIONAL,
    )
    assert r_none.score is None

    # Invalid out-of-range scores
    with pytest.raises(ValidationError):
        RiskScoreDetails(
            score=-1,
            verdict=Verdict.NO_KNOWN_THREAT,
            confidence_level=ConfidenceLevel.HIGH,
        )

    with pytest.raises(ValidationError):
        RiskScoreDetails(
            score=101,
            verdict=Verdict.MALICIOUS,
            confidence_level=ConfidenceLevel.HIGH,
        )


def test_threat_finding_schema():
    """Threat findings validate category, rule, severity, and confirmation flag."""
    finding = ThreatFinding(
        category=EvidenceCategory.HEURISTIC,
        rule_name="RAW_IP_HOST",
        severity=FindingSeverity.HIGH,
        title="Direct IP Address Host",
        description="The URL uses a raw IP address instead of a recognized hostname.",
        is_confirmed=True,
        raw_evidence={"ip": "192.168.1.10"},
    )
    assert finding.category == EvidenceCategory.HEURISTIC
    assert finding.severity == FindingSeverity.HIGH
    assert finding.is_confirmed is True
    assert finding.raw_evidence == {"ip": "192.168.1.10"}

    # Invalid severity
    with pytest.raises(ValidationError):
        ThreatFinding(
            category=EvidenceCategory.HEURISTIC,
            rule_name="RAW_IP_HOST",
            severity="URGENT",  # type: ignore[arg-type]
            title="Invalid",
            description="Invalid severity value",
        )


def test_threat_finding_raw_evidence_pii_masking():
    """Ensure raw_evidence, description, and title automatically mask sensitive PII at the data model level."""
    finding = ThreatFinding(
        category=EvidenceCategory.LINGUISTIC,
        rule_name="OTP_CREDENTIAL_DEMAND",
        severity=FindingSeverity.CRITICAL,
        title="Immediate OTP Verification 482910 Required",
        description="Victim was instructed to share OTP 482910 and call 9876543210 or +919876543210.",
        raw_evidence={
            "matched_otp": "482910",
            "callback_phone": "+919876543210",
            "target_account": "1234 5678 9012 3456",
            "metadata": {
                "nested_phone": "9876543210",
                "safe_note": "suspicious SMS",
            },
        },
    )
    # The actual stored data must be masked, protecting logging and database persistence
    assert "482910" not in finding.title
    assert "[OTP-REDACTED]" in finding.title
    assert "482910" not in finding.description
    assert "[OTP-REDACTED]" in finding.description
    assert "9876543210" not in finding.description

    assert finding.raw_evidence["matched_otp"] == "[OTP-REDACTED]"
    assert finding.raw_evidence["callback_phone"] == "[PHONE-REDACTED]"
    assert finding.raw_evidence["target_account"] == "[ACCOUNT-REDACTED]"
    assert finding.raw_evidence["metadata"]["nested_phone"] == "[PHONE-REDACTED]"
    assert finding.raw_evidence["metadata"]["safe_note"] == "suspicious SMS"

    # Serialized representations must also be clean
    dumped = finding.model_dump()
    assert dumped["raw_evidence"]["matched_otp"] == "[OTP-REDACTED]"
    assert "482910" not in str(dumped)


def test_history_query_params():
    """HistoryQueryParams correctly defaults, filters, and clamps bounds."""
    # Default parameters
    defaults = HistoryQueryParams()
    assert defaults.limit == 20
    assert defaults.offset == 0
    assert defaults.sort_order == SortOrder.NEWEST
    assert defaults.target_type is None
    assert defaults.verdict is None

    # Clamping out-of-range numbers
    clamped_low = HistoryQueryParams(limit=0, offset=-10)
    assert clamped_low.limit == 1
    assert clamped_low.offset == 0

    clamped_high = HistoryQueryParams(limit=500)
    assert clamped_high.limit == 100

    # Custom filters
    filtered = HistoryQueryParams(
        limit=50,
        offset=10,
        target_type=TargetType.URL,
        verdict=Verdict.MALICIOUS,
        sort_order=SortOrder.OLDEST,
    )
    assert filtered.limit == 50
    assert filtered.offset == 10
    assert filtered.target_type == TargetType.URL
    assert filtered.verdict == Verdict.MALICIOUS
    assert filtered.sort_order == SortOrder.OLDEST


def test_history_response():
    """HistoryResponse correctly serializes paginated audit trail lists."""
    resp = HistoryResponse(
        items=[
            HistoryItem(
                scan_id="c8b417e2-4521-4fa2-9eb2-f38b25a3d750",
                scanned_at="2026-11-05T11:35:10.120Z",
                target_type=TargetType.URL,
                target_preview="https://malicious-test.in",
                verdict=Verdict.MALICIOUS,
                risk_score=95,
                execution_time_ms=310,
            )
        ],
        total_count=1,
        limit=20,
        offset=0,
    )
    assert len(resp.items) == 1
    assert resp.total_count == 1
    assert resp.limit == 20
    assert resp.offset == 0

    # Negative total_count fails
    with pytest.raises(ValidationError):
        HistoryResponse(
            items=[],
            total_count=-1,
            limit=20,
            offset=0,
        )


def test_analytics_overview_response():
    """AnalyticsOverviewResponse accurately represents telemetry statistics."""
    resp = AnalyticsOverviewResponse(
        total_scans=150,
        verdict_distribution=VerdictDistribution(
            MALICIOUS=30,
            SUSPICIOUS=25,
            NO_KNOWN_THREAT=90,
            UNVERIFIED=5,
        ),
        average_scan_latency_ms=280,
        detected_language_distribution={"ENGLISH": 90, "TELUGISH": 40, "TELUGU_SCRIPT": 20},
        top_threat_categories=[
            ThreatCategoryCount(category="Financial Fraud / KYC", count=45),
            ThreatCategoryCount(category="Malware Distribution", count=10),
        ],
    )
    assert resp.total_scans == 150
    assert resp.verdict_distribution.MALICIOUS == 30
    assert resp.average_scan_latency_ms == 280
    assert len(resp.top_threat_categories) == 2

    # Negative counts rejected
    with pytest.raises(ValidationError):
        ThreatCategoryCount(category="Test", count=-5)


def test_standard_error_response():
    """StandardErrorResponse generates valid error payload with UTC timestamp."""
    err = StandardErrorResponse(
        error_code=ErrorCode.INVALID_INPUT_FORMAT.value,
        message="The supplied target is malformed.",
        details={"field": "url", "reason": "Missing protocol scheme."},
    )
    assert err.error_code == "INVALID_INPUT_FORMAT"
    assert "malformed" in err.message
    assert err.details == {"field": "url", "reason": "Missing protocol scheme."}
    assert err.timestamp is not None
