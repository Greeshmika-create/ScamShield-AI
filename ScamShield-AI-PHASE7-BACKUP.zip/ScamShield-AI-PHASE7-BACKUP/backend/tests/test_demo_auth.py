"""Environment-gated local demo authentication tests."""

import asyncio

from fastapi.testclient import TestClient

from app.core.auth import get_token_verifier
from app.core.config import Settings
from app.core.dependencies import require_authenticated_user
from app.main import create_application


def test_demo_login_disabled_returns_forbidden():
    app = create_application(Settings(
        ENVIRONMENT="test",
        DEMO_AUTH_ENABLED=False,
        DEMO_AUTH_SECRET="local-demo-signing-secret-long-enough",
    ))
    with TestClient(app) as client:
        response = client.post("/api/v1/auth/demo-login")
    assert response.status_code == 403


def test_demo_login_blocked_in_production():
    app = create_application(Settings(
        ENVIRONMENT="production",
        DEMO_AUTH_ENABLED=True,
        DEMO_AUTH_SECRET="local-demo-signing-secret-long-enough",
    ))
    with TestClient(app) as client:
        response = client.post("/api/v1/auth/demo-login")
    assert response.status_code == 403


def test_demo_login_token_accesses_protected_routes():
    settings = Settings(
        ENVIRONMENT="test",
        DEMO_AUTH_ENABLED=True,
        DEMO_AUTH_SECRET="local-demo-signing-secret-long-enough",
        DEMO_ACCESS_TOKEN_TTL_SECONDS=900,
        SUPABASE_URL=None,
        SUPABASE_JWT_ISSUER=None,
    )
    app = create_application(settings=settings)

    with TestClient(app) as client:
        unauthenticated = client.post(
            "/api/v1/scan/url",
            json={"url": "https://example.com/login"},
        )
        assert unauthenticated.status_code == 401

        login = client.post("/api/v1/auth/demo-login")
        assert login.status_code == 200
        body = login.json()
        assert body["token_type"] == "bearer"
        assert body["expires_in"] == 900

        protected = client.post(
            "/api/v1/scan/url",
            json={"url": "https://example.com/login"},
            headers={"Authorization": f"Bearer {body['access_token']}"},
        )

        health = client.get("/api/v1/health")

    assert protected.status_code == 200
    assert health.status_code == 200


def test_demo_verifier_returns_user_principal():
    settings = Settings(
        ENVIRONMENT="test",
        DEMO_AUTH_ENABLED=True,
        DEMO_AUTH_SECRET="local-demo-signing-secret-long-enough",
    )
    verifier = get_token_verifier(settings)

    app = create_application(settings=settings)
    with TestClient(app) as client:
        login = client.post("/api/v1/auth/demo-login")
        token = login.json()["access_token"]

    principal = asyncio.run(verifier.verify_token(token))
    assert principal.user_id == "demo-hackathon-user"
    assert principal.role.value == "USER"
    assert principal.is_active is True
