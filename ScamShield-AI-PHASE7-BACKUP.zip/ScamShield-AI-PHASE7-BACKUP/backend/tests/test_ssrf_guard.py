"""Tests for Phase 4.2 Static SSRF Guard and Target Validator."""

import pytest
from app.core.errors import SSRFRejectedException
from app.services.scanners.ssrf_guard import SSRFCheckResult, SSRFGuard
from app.services.url_normalizer import normalize_url


class TestSSRFGuardLoopback:
    """Tests for loopback IPv4, IPv6, and localhost hostname detection."""

    @pytest.mark.parametrize(
        "target",
        [
            "http://127.0.0.1",
            "http://127.0.0.1:8080/admin",
            "http://127.0.0.2",
            "https://127.255.255.254",
            "http://localhost",
            "http://localhost:3000",
            "http://localhost.localdomain",
            "http://ip6-localhost",
            "http://ip6-loopback",
            "http://app.localhost",
            "http://[::1]",
            "http://[::1]:8000/metrics",
            "http://[0:0:0:0:0:0:0:1]",
            "http://2130706433",  # Decimal representation of 127.0.0.1
            "http://0x7f000001",  # Hex representation of 127.0.0.1
        ],
    )
    def test_loopback_rejected(self, target: str):
        result = SSRFGuard.check_target(target)
        assert result.is_safe is False
        assert result.matched_rule in {
            "LOOPBACK_IPV4",
            "LOOPBACK_IPV6",
            "LOOPBACK_HOSTNAME",
            "INTERNAL_DOMAIN_SUFFIX",
        }

        with pytest.raises(SSRFRejectedException) as exc_info:
            SSRFGuard.validate_target(target, raise_on_error=True)
        assert exc_info.value.status_code == 400


class TestSSRFGuardPrivateIPv4:
    """Tests for RFC 1918 Private IPv4 address spaces."""

    @pytest.mark.parametrize(
        "target,expected_rule",
        [
            ("http://10.0.0.1", "PRIVATE_RFC1918_10"),
            ("http://10.254.1.1/login", "PRIVATE_RFC1918_10"),
            ("https://10.255.255.254:443", "PRIVATE_RFC1918_10"),
            ("http://172.16.0.1", "PRIVATE_RFC1918_172"),
            ("http://172.24.10.20", "PRIVATE_RFC1918_172"),
            ("http://172.31.255.254", "PRIVATE_RFC1918_172"),
            ("http://192.168.0.1", "PRIVATE_RFC1918_192"),
            ("http://192.168.1.1/status", "PRIVATE_RFC1918_192"),
            ("https://192.168.254.254:8443", "PRIVATE_RFC1918_192"),
        ],
    )
    def test_rfc1918_rejected(self, target: str, expected_rule: str):
        result = SSRFGuard.check_target(target)
        assert result.is_safe is False
        assert result.matched_rule == expected_rule

        with pytest.raises(SSRFRejectedException) as exc_info:
            SSRFGuard.validate_target(target, raise_on_error=True)
        assert exc_info.value.status_code == 400


class TestSSRFGuardCloudMetadataAndLinkLocal:
    """Tests for cloud metadata (169.254.169.254) and link-local ranges."""

    @pytest.mark.parametrize(
        "target",
        [
            "http://169.254.169.254/latest/meta-data/",
            "http://169.254.169.254:80",
            "http://169.254.1.1",
            "http://169.254.255.254",
            "http://[fe80::1]",
            "http://[fe80::a00:27ff:fe8e:ba81]",
        ],
    )
    def test_link_local_and_metadata_rejected(self, target: str):
        result = SSRFGuard.check_target(target)
        assert result.is_safe is False
        assert result.matched_rule in {"LINK_LOCAL_METADATA", "LINK_LOCAL_IPV6"}

        with pytest.raises(SSRFRejectedException):
            SSRFGuard.validate_target(target, raise_on_error=True)


class TestSSRFGuardSpecialNetworks:
    """Tests for CGNAT, Broadcast, Multicast, and Unspecified network boundaries."""

    @pytest.mark.parametrize(
        "target,expected_rule",
        [
            ("http://100.64.0.1", "CARRIER_GRADE_NAT"),
            ("http://100.127.255.254", "CARRIER_GRADE_NAT"),
            ("http://0.0.0.0", "THIS_HOST_NETWORK"),
            ("http://0.0.0.1", "THIS_HOST_NETWORK"),
            ("http://255.255.255.255", "BROADCAST_IPV4"),
            ("http://224.0.0.1", "MULTICAST_IPV4"),
            ("http://239.255.255.250", "MULTICAST_IPV4"),
            ("http://[::]", "UNSPECIFIED_IPV6"),
            ("http://[ff02::1]", "MULTICAST_IPV6"),
            ("http://[fc00::1]", "UNIQUE_LOCAL_IPV6"),
            ("http://[fd12:3456:789a::1]", "UNIQUE_LOCAL_IPV6"),
        ],
    )
    def test_special_networks_rejected(self, target: str, expected_rule: str):
        result = SSRFGuard.check_target(target)
        assert result.is_safe is False
        assert result.matched_rule == expected_rule

        with pytest.raises(SSRFRejectedException):
            SSRFGuard.validate_target(target)


class TestSSRFGuardIPv4MappedIPv6:
    """Tests for IPv4-mapped IPv6 addresses (::ffff:x.x.x.x)."""

    @pytest.mark.parametrize(
        "target",
        [
            "http://[::ffff:127.0.0.1]",
            "http://[::ffff:10.0.0.1]",
            "http://[::ffff:192.168.1.1]",
            "http://[::ffff:169.254.169.254]",
        ],
    )
    def test_ipv4_mapped_prohibited(self, target: str):
        result = SSRFGuard.check_target(target)
        assert result.is_safe is False
        assert result.matched_rule is not None
        assert result.matched_rule.startswith("IPV4_MAPPED_")

        with pytest.raises(SSRFRejectedException):
            SSRFGuard.validate_target(target)


class TestSSRFGuardInternalHostnames:
    """Tests for non-routable / internal hostname suffixes."""

    @pytest.mark.parametrize(
        "target",
        [
            "http://router.local",
            "http://printer.lan",
            "http://k8s-service.internal",
            "http://nas.home",
            "http://auth.corp",
            "http://api.test",
        ],
    )
    def test_internal_suffixes_rejected(self, target: str):
        result = SSRFGuard.check_target(target)
        assert result.is_safe is False
        assert result.matched_rule == "INTERNAL_DOMAIN_SUFFIX"

        with pytest.raises(SSRFRejectedException):
            SSRFGuard.validate_target(target)


class TestSSRFGuardProhibitedSchemes:
    """Tests for non-HTTP/HTTPS schemes."""

    @pytest.mark.parametrize(
        "target",
        [
            "ftp://example.com/file",
            "file:///etc/passwd",
            "gopher://example.com",
            "dict://example.com",
            "ldap://127.0.0.1",
        ],
    )
    def test_non_http_schemes_rejected(self, target: str):
        result = SSRFGuard.check_target(target)
        assert result.is_safe is False
        assert result.matched_rule == "PROHIBITED_SCHEME"


class TestSSRFGuardPublicSafeTargets:
    """Tests that legitimate public domains and public routable IPs are permitted."""

    @pytest.mark.parametrize(
        "target,is_ip",
        [
            ("https://google.com", False),
            ("https://api.github.com/users", False),
            ("http://example.org/path?q=1", False),
            ("https://sbi.co.in", False),
            ("http://8.8.8.8", True),
            ("http://1.1.1.1/dns-query", True),
            ("https://93.184.216.34", True),
            ("https://[2606:4700:4700::1111]", True),
        ],
    )
    def test_public_targets_accepted(self, target: str, is_ip: bool):
        result = SSRFGuard.check_target(target)
        assert result.is_safe is True
        assert result.is_ip == is_ip
        assert result.blocked_reason is None

        # validate_target should return the result cleanly without raising
        validated = SSRFGuard.validate_target(target, raise_on_error=True)
        assert validated.is_safe is True
        assert isinstance(validated, SSRFCheckResult)


class TestSSRFGuardIntegrationWithNormalizer:
    """Tests seamless interoperability with Phase 4.1 URLNormalizer."""

    def test_normalized_components_ssrf_integration(self):
        # 1. Private target through normalizer
        norm_result = normalize_url("http://192.168.1.1:8080/dashboard")
        assert norm_result.is_valid is True
        assert norm_result.components is not None

        result = SSRFGuard.check_target(norm_result.components)
        assert result.is_safe is False
        assert result.matched_rule == "PRIVATE_RFC1918_192"

        with pytest.raises(SSRFRejectedException):
            SSRFGuard.validate_target(norm_result)

        # 2. Public target through normalizer
        norm_public = normalize_url("https://subdomain.example.com/login?token=abc")
        assert norm_public.is_valid is True
        assert norm_public.components is not None

        result_public = SSRFGuard.check_target(norm_public.components)
        assert result_public.is_safe is True
        assert result_public.host == "subdomain.example.com"

        validated = SSRFGuard.validate_target(norm_public)
        assert validated.is_safe is True

