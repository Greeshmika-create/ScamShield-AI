"""Tests for standardized exception handling and security sanitization."""

from fastapi import APIRouter
from fastapi.testclient import TestClient
from pydantic import BaseModel, Field

from app.core.config import Settings
from app.core.errors import (
    InternalInspectionException,
    RateLimitExceededException,
    SSRFRejectedException,
    ScanTimeoutException,
)
from app.main import create_application


def test_404_returns_standardized_error_format(client: TestClient):
    """404 Not Found returns unified error envelope conforming to API specification."""
    response = client.get("/api/v1/non_existent_endpoint")
    assert response.status_code == 404
    data = response.json()
    assert data["error_code"] == "NOT_FOUND"
    assert "message" in data
    assert "timestamp" in data


def test_405_returns_standardized_error_format(client: TestClient):
    """405 Method Not Allowed returns unified error envelope."""
    response = client.post("/api/v1/health")
    assert response.status_code == 405
    data = response.json()
    assert data["error_code"] == "INVALID_INPUT_FORMAT"
    assert "timestamp" in data


def test_custom_ssrf_exception_handler():
    """SSRFRejectedException maps to 400 Bad Request with INVALID_INPUT_FORMAT."""
    test_router = APIRouter()

    @test_router.get("/trigger-ssrf")
    def trigger():
        raise SSRFRejectedException(
            message="Target address is private or non-routable.",
            details={"target": "127.0.0.1"},
        )

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as test_client:
        response = test_client.get("/trigger-ssrf")
        assert response.status_code == 400
        data = response.json()
        assert data["error_code"] == "INVALID_INPUT_FORMAT"
        assert "private or non-routable" in data["message"]
        assert data["details"]["target"] == "127.0.0.1"


def test_custom_rate_limit_and_timeout_exceptions():
    """Domain exceptions map to their standardized status codes and error codes."""
    test_router = APIRouter()

    @test_router.get("/trigger-rate-limit")
    def trigger_rate():
        raise RateLimitExceededException()

    @test_router.get("/trigger-timeout")
    def trigger_timeout():
        raise ScanTimeoutException()

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as test_client:
        # Rate limit
        resp_rate = test_client.get("/trigger-rate-limit")
        assert resp_rate.status_code == 429
        assert resp_rate.json()["error_code"] == "RATE_LIMITED"

        # Timeout
        resp_timeout = test_client.get("/trigger-timeout")
        assert resp_timeout.status_code == 504
        assert resp_timeout.json()["error_code"] == "REQUEST_TIMEOUT"


def test_request_validation_returns_standardized_format():
    """Request validation failure (422) returns standardized error payload."""
    test_router = APIRouter()

    class StrictModel(BaseModel):
        url: str = Field(..., min_length=4)

    @test_router.post("/test-validation")
    def validate_endpoint(payload: StrictModel):
        return {"ok": True}

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as test_client:
        response = test_client.post("/test-validation", json={"url": "a"})  # Too short
        assert response.status_code == 422
        data = response.json()
        assert data["error_code"] == "INVALID_INPUT_FORMAT"
        assert "validation_errors" in data["details"]


def test_unhandled_exception_does_not_leak_traceback_or_secrets():
    """Unhandled server errors return safe sanitized response without leaking internal traceback."""
    test_router = APIRouter()

    @test_router.get("/trigger-crash")
    def trigger_crash():
        # Simulate unexpected crash with secret in local variable
        secret_token = "SUPER_SECRET_INTERNAL_DB_PASSWORD"
        raise RuntimeError(f"Database crash with secret {secret_token}")

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app, raise_server_exceptions=False) as test_client:
        response = test_client.get("/trigger-crash")
        assert response.status_code == 500
        data = response.json()
        assert data["error_code"] == "INTERNAL_ERROR"
        # Verify NO secret or traceback is leaked in the response
        assert "SUPER_SECRET_INTERNAL_DB_PASSWORD" not in str(data)
        assert "RuntimeError" not in str(data)
        assert "Traceback" not in str(data)

