"""Endpoint integration tests for passive URL and multilingual message scans."""

import socket

import pytest
from fastapi.testclient import TestClient

from app.core.config import Settings
from app.core.dependencies import require_authenticated_user
from app.core.scan_rate_limit import scan_rate_limiter
from app.main import create_application
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import ProviderStatus
from app.schemas.ml_analysis import URLMLAnalysis
from app.schemas.threat_intelligence import ProviderReport
from app.services import inspection_orchestrator as inspection_module


class StubClassifier:
    def __init__(self, analysis=None):
        self.analysis = analysis or URLMLAnalysis(
            prediction="BENIGN",
            threat_probability=0.1,
            evaluation_metadata={"status": "INFERRED"},
        )
        self.features = []

    def predict_from_features(self, features):
        self.features.append(features)
        return self.analysis


class StubThreatIntel:
    def __init__(self, reports=None, error=None):
        self.reports = reports if reports is not None else [ProviderReport(
            provider_name="MockIntel",
            status=ProviderStatus.AVAILABLE_CLEAN,
        )]
        self.error = error
        self.targets = []

    async def inspect_url(self, target):
        self.targets.append(target)
        if self.error:
            raise self.error
        return self.reports


@pytest.fixture(autouse=True)
def reset_scan_rate_limiter():
    scan_rate_limiter.reset()
    yield
    scan_rate_limiter.reset()


@pytest.fixture
def app():
    application = create_application(Settings(ENVIRONMENT="test", RATE_LIMIT_PER_MINUTE=100))
    application.dependency_overrides[require_authenticated_user] = lambda: AuthenticatedPrincipal(
        user_id="scan-test-user"
    )
    return application


@pytest.fixture
def client(app):
    with TestClient(app) as test_client:
        yield test_client


def install_url_stubs(monkeypatch, classifier=None, intel=None):
    classifier = classifier or StubClassifier()
    intel = intel or StubThreatIntel()
    monkeypatch.setattr(inspection_module, "get_url_classifier", lambda: classifier)
    monkeypatch.setattr(inspection_module, "ThreatIntelAggregator", lambda settings=None: intel)
    return classifier, intel


def test_url_scan_returns_established_contract_and_extracts_features(client, monkeypatch):
    classifier, intel = install_url_stubs(monkeypatch)

    response = client.post("/api/v1/scan/url", json={"url": "https://example.com/login"})

    assert response.status_code == 200
    body = response.json()
    assert body["scan_id"]
    assert body["target_domain"] == "example.com"
    assert body["canonical_url"] == "https://example.com/login"
    assert body["ml_analysis"]["evaluation_metadata"]["status"] == "INFERRED"
    assert body["threat_intelligence"][0]["status"] == "AVAILABLE_CLEAN"
    assert classifier.features and len(classifier.features[0].to_dict()) == 32
    assert intel.targets == ["https://example.com/login"]


def test_url_credentials_and_query_secrets_are_redacted_before_provider_and_response(client, monkeypatch):
    _, intel = install_url_stubs(monkeypatch)

    response = client.post(
        "/api/v1/scan/url",
        json={"url": "https://user:password@example.com/login?api_key=secret&ref=ok#access_token"},
    )

    assert response.status_code == 200
    body = response.json()
    assert intel.targets == ["https://example.com/login?api_key=%5BREDACTED%5D&ref=ok"]
    serialized = response.text
    for secret in ("user", "password", "secret", "access_token"):
        assert secret not in serialized


def test_invalid_url_is_rejected(client):
    response = client.post("/api/v1/scan/url", json={"url": "ftp://example.com/file"})
    assert response.status_code == 422
    assert response.json()["error_code"] == "INVALID_INPUT_FORMAT"


def test_private_target_is_rejected_before_intelligence_lookup(client, monkeypatch):
    _, intel = install_url_stubs(monkeypatch)

    response = client.post("/api/v1/scan/url", json={"url": "http://127.0.0.1/admin"})

    assert response.status_code == 400
    assert response.json()["error_code"] == "INVALID_INPUT_FORMAT"
    assert intel.targets == []


def test_unavailable_model_and_provider_results_remain_unverified(client, monkeypatch):
    unavailable = URLMLAnalysis(evaluation_metadata={"status": "UNAVAILABLE"})
    reports = [ProviderReport(provider_name="MockIntel", status=ProviderStatus.UNCONFIGURED)]
    install_url_stubs(monkeypatch, StubClassifier(unavailable), StubThreatIntel(reports))

    response = client.post("/api/v1/scan/url", json={"url": "https://example.com/"})

    assert response.status_code == 200
    body = response.json()
    assert body["verdict"] == "UNVERIFIED"
    assert body["risk_score"] is None
    assert body["ml_analysis"]["evaluation_metadata"]["status"] == "UNAVAILABLE"
    assert body["threat_intelligence"][0]["status"] == "UNCONFIGURED"


def test_provider_timeout_is_preserved_in_response(client, monkeypatch):
    install_url_stubs(monkeypatch, intel=StubThreatIntel(error=TimeoutError()))

    response = client.post("/api/v1/scan/url", json={"url": "https://example.com/"})

    assert response.status_code == 200
    body = response.json()
    assert body["verdict"] == "UNVERIFIED"
    assert body["threat_intelligence"][0]["status"] == "TIMEOUT"


def test_mixed_provider_results_are_returned_without_collapsing_statuses(client, monkeypatch):
    reports = [
        ProviderReport(provider_name="Flagged", status=ProviderStatus.AVAILABLE_FLAGGED),
        ProviderReport(provider_name="Timed out", status=ProviderStatus.TIMEOUT),
    ]
    install_url_stubs(monkeypatch, intel=StubThreatIntel(reports))

    response = client.post("/api/v1/scan/url", json={"url": "https://example.com/"})

    assert response.status_code == 200
    body = response.json()
    assert [item["status"] for item in body["threat_intelligence"]] == [
        "AVAILABLE_FLAGGED", "TIMEOUT"
    ]
    assert body["verdict"] == "MALICIOUS"


def test_scan_endpoints_require_authentication(monkeypatch):
    install_url_stubs(monkeypatch)
    application = create_application(Settings(ENVIRONMENT="test"))
    with TestClient(application) as unauthenticated:
        url_response = unauthenticated.post("/api/v1/scan/url", json={"url": "https://example.com"})
        message_response = unauthenticated.post(
            "/api/v1/scan/message", json={"message_text": "Please verify this account"}
        )
    assert url_response.status_code == 401
    assert message_response.status_code == 401


def test_unexpected_url_failure_returns_sanitized_error(client, monkeypatch):
    async def fail(self, request):
        raise RuntimeError("credential=private-value")

    monkeypatch.setattr(inspection_module.InspectionOrchestrator, "scan_url", fail)

    response = client.post("/api/v1/scan/url", json={"url": "https://example.com/"})

    assert response.status_code == 500
    assert "private-value" not in response.text
    assert "credential=" not in response.text


@pytest.mark.parametrize(
    "message,expected_language",
    [
        ("Your account is ready for review today.", "ENGLISH"),
        ("మీ ఖాతా బ్లాక్ చేయబడింది వెంటనే సంప్రదించండి", "TELUGU_SCRIPT"),
        ("Mee account block aindi ventane update cheyandi", "TELUGISH"),
        ("Dear Customer account update వెంటనే", "MIXED"),
    ],
)
def test_message_scan_detects_supported_language(client, message, expected_language):
    response = client.post("/api/v1/scan/message", json={"message_text": message})
    assert response.status_code == 200
    assert response.json()["detected_language"] == expected_language


@pytest.mark.parametrize("message", ["", "   ", "tiny", "x" * 5001])
def test_message_scan_rejects_empty_or_out_of_range_input(client, message):
    response = client.post("/api/v1/scan/message", json={"message_text": message})
    assert response.status_code == 422


def test_message_preview_masks_otp_phone_and_upi(client, caplog):
    message = "Your OTP is 482910. Call 9876543210 or send payment to scammer@oksbi."

    with caplog.at_level("INFO"):
        response = client.post("/api/v1/scan/message", json={"message_text": message})

    assert response.status_code == 200
    body = response.json()
    preview = body["message_preview"]
    assert "482910" not in preview and "[OTP REDACTED]" in preview
    assert "9876543210" not in preview and "[PHONE REDACTED]" in preview
    assert "scammer@oksbi" not in preview and "[UPI REDACTED]" in preview
    assert "482910" not in response.text and "9876543210" not in response.text
    assert "scammer@oksbi" not in response.text
    assert "482910" not in caplog.text and "9876543210" not in caplog.text
    assert "scammer@oksbi" not in caplog.text
    assert body["ml_analysis"]["evaluation_metadata"]["status"] == "NOT_CONFIGURED"


def test_message_internal_error_does_not_echo_content(client, monkeypatch):
    async def fail(self, request):
        raise RuntimeError("raw message must not leak")

    monkeypatch.setattr(inspection_module.InspectionOrchestrator, "scan_message", fail)

    response = client.post(
        "/api/v1/scan/message",
        json={"message_text": "This private text should never appear in errors."},
    )

    assert response.status_code == 500
    assert "raw message" not in response.text
    assert "private text" not in response.text


def test_url_analysis_does_not_resolve_or_connect_to_target(client, monkeypatch):
    _, intel = install_url_stubs(monkeypatch)

    def network_access_forbidden(*args, **kwargs):
        raise AssertionError("URL inspection attempted target network access")

    monkeypatch.setattr(socket, "getaddrinfo", network_access_forbidden)
    monkeypatch.setattr(socket, "create_connection", network_access_forbidden)
    response = client.post("/api/v1/scan/url", json={"url": "https://example.com/login"})

    assert response.status_code == 200
    assert intel.targets == ["https://example.com/login"]


def test_scan_rate_limit_uses_existing_setting():
    scan_rate_limiter.reset()
    application = create_application(Settings(ENVIRONMENT="test", RATE_LIMIT_PER_MINUTE=1))
    application.dependency_overrides[require_authenticated_user] = lambda: AuthenticatedPrincipal(
        user_id="rate-test-user"
    )
    with TestClient(application) as limited_client:
        first = limited_client.post(
            "/api/v1/scan/message", json={"message_text": "A normal short message."}
        )
        second = limited_client.post(
            "/api/v1/scan/message", json={"message_text": "Another normal message."}
        )
    assert first.status_code == 200
    assert second.status_code == 429
    assert second.json()["error_code"] == "RATE_LIMITED"