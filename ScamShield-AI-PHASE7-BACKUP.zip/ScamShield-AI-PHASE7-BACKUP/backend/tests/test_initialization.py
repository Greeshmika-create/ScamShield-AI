"""Tests for application factory and route initialization."""

from fastapi.testclient import TestClient
from app.core.config import Settings
from app.main import create_application


def test_application_initialization_defaults():
    """Verify application creates cleanly with default settings."""
    app = create_application()
    assert app.title == "ScamShield AI"
    assert app.version == "1.0.0"

    # Check routes
    routes = [route.path for route in app.routes if hasattr(route, "path")]
    assert "/" in routes

    with TestClient(app) as test_client:
        resp = test_client.get("/api/v1/health")
        assert resp.status_code == 200


def test_root_endpoint_metadata(client: TestClient):
    """GET / must return high-level application metadata."""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "ScamShield AI Test"
    assert data["status"] == "OPERATIONAL"
    assert "/health" in data["health"]


def test_production_environment_disables_docs():
    """Production mode must disable OpenAPI documentation endpoints."""
    prod_settings = Settings(
        ENVIRONMENT="production",
        PROJECT_NAME="ScamShield AI Prod",
    )
    prod_app = create_application(settings=prod_settings)
    assert prod_app.docs_url is None
    assert prod_app.redoc_url is None
    assert prod_app.openapi_url is None
