"""Unit and integration tests for Phase 5 Threat Intelligence Aggregator and Providers.

All tests use exclusively mocked HTTP responses to guarantee zero API quota consumption.
"""

import asyncio
from datetime import datetime, timedelta, timezone
import pytest
import httpx

from app.core.config import Settings
from app.schemas.enums import ProviderStatus
from app.schemas.threat_intelligence import ProviderReport
from app.services.threat_intel.aggregator import ThreatIntelAggregator
from app.services.threat_intel.base import BaseThreatIntelProvider
from app.services.threat_intel.cache import ThreatIntelCache
from app.services.threat_intel.gsb import GoogleSafeBrowsingClient
from app.services.threat_intel.phishtank import PhishTankClient
from app.services.threat_intel.urlhaus import URLhausClient


# ==============================================================================
# 1. Threat Intelligence TTL Cache Tests
# ==============================================================================

class TestThreatIntelCache:
    """Verifies in-memory TTL caching, key derivation, and eviction mechanics."""

    def test_cache_key_generation(self):
        url = "https://example.com/login"
        provider = "Google Safe Browsing"
        key = ThreatIntelCache.generate_cache_key(url, provider)

        # Expected SHA-256 + provider slug
        assert "_" in key
        assert key.endswith("google_safe_browsing")
        assert len(key.split("_")[0]) == 64  # SHA-256 hex length

    def test_cache_set_and_get(self):
        cache = ThreatIntelCache(default_ttl_hours=2)
        url = "https://example.com/test"
        provider = "URLhaus"

        report = ProviderReport(
            provider_name=provider,
            status=ProviderStatus.AVAILABLE_CLEAN,
            response_time_ms=150,
            check_timestamp=datetime.now(timezone.utc).isoformat(),
        )

        # Before set -> None
        assert cache.get(url, provider) is None

        # After set -> report
        cache.set(url, provider, report)
        retrieved = cache.get(url, provider)
        assert retrieved is not None
        assert retrieved.status == ProviderStatus.AVAILABLE_CLEAN
        assert retrieved.provider_name == provider

    def test_transient_errors_not_cached(self):
        cache = ThreatIntelCache(default_ttl_hours=2)
        url = "https://example.com/timeout"
        provider = "PhishTank"

        timeout_report = ProviderReport(
            provider_name=provider,
            status=ProviderStatus.TIMEOUT,
            response_time_ms=2500,
        )
        cache.set(url, provider, timeout_report)
        assert cache.get(url, provider) is None  # Should not be cached

        error_report = ProviderReport(
            provider_name=provider,
            status=ProviderStatus.ERROR,
            response_time_ms=50,
        )
        cache.set(url, provider, error_report)
        assert cache.get(url, provider) is None  # Should not be cached

    def test_cache_expiration_and_cleanup(self):
        cache = ThreatIntelCache(default_ttl_hours=1)
        url = "https://example.com/expire-test"
        provider = "GSB"

        report = ProviderReport(
            provider_name=provider,
            status=ProviderStatus.AVAILABLE_FLAGGED,
            response_time_ms=100,
            threat_details="Malware",
        )

        # Set with 0 TTL seconds (immediately expired)
        cache.set(url, provider, report, ttl_seconds=-1)
        assert cache.get(url, provider) is None

        # Test cleanup_expired
        cache.set(url, provider, report, ttl_seconds=-5)
        assert cache.size() == 1
        evicted = cache.cleanup_expired()
        assert evicted == 1
        assert cache.size() == 0

    def test_provider_key_isolation(self):
        cache = ThreatIntelCache(default_ttl_hours=2)
        url = "https://shared-target.com"

        report_gsb = ProviderReport(
            provider_name="Google Safe Browsing",
            status=ProviderStatus.AVAILABLE_CLEAN,
        )
        report_urlhaus = ProviderReport(
            provider_name="URLhaus",
            status=ProviderStatus.AVAILABLE_FLAGGED,
            threat_details="Malware",
        )

        cache.set(url, "Google Safe Browsing", report_gsb)
        cache.set(url, "URLhaus", report_urlhaus)

        assert cache.get(url, "Google Safe Browsing").status == ProviderStatus.AVAILABLE_CLEAN
        assert cache.get(url, "URLhaus").status == ProviderStatus.AVAILABLE_FLAGGED


# ==============================================================================
# 2. Google Safe Browsing Adapter Tests (Mocked)
# ==============================================================================

class TestGoogleSafeBrowsingClient:
    """Verifies Google Safe Browsing client with mocked HTTP interactions."""

    @pytest.mark.asyncio
    async def test_unconfigured_credentials(self):
        client = GoogleSafeBrowsingClient(api_key=None)
        assert client.is_configured is False

        report = await client.check_url("https://example.com")
        assert report.status == ProviderStatus.UNCONFIGURED
        assert report.response_time_ms == 0
        assert report.threat_details is None

    @pytest.mark.asyncio
    async def test_flagged_threat_match(self):
        mock_response = httpx.Response(
            200,
            json={
                "matches": [
                    {
                        "threatType": "MALWARE",
                        "platformType": "ANY_PLATFORM",
                        "threatEntryType": "URL",
                        "threat": {"url": "https://malicious.example.com"},
                    },
                    {
                        "threatType": "SOCIAL_ENGINEERING",
                        "platformType": "ANY_PLATFORM",
                        "threatEntryType": "URL",
                        "threat": {"url": "https://malicious.example.com"},
                    },
                ]
            },
        )

        async def mock_handler(request: httpx.Request):
            return mock_response

        transport = httpx.MockTransport(mock_handler)
        client = GoogleSafeBrowsingClient(api_key="valid_operational_api_key_12345")

        async with httpx.AsyncClient(transport=transport) as mock_http_client:
            report = await client.check_url("https://malicious.example.com", client=mock_http_client)

        assert report.status == ProviderStatus.AVAILABLE_FLAGGED
        assert "MALWARE" in report.threat_details
        assert "SOCIAL_ENGINEERING" in report.threat_details
        assert report.raw_evidence["match_count"] == 2

    @pytest.mark.asyncio
    async def test_clean_response(self):
        mock_response = httpx.Response(200, json={})  # No matches

        async def mock_handler(request: httpx.Request):
            return mock_response

        transport = httpx.MockTransport(mock_handler)
        client = GoogleSafeBrowsingClient(api_key="valid_operational_api_key_12345")

        async with httpx.AsyncClient(transport=transport) as mock_http_client:
            report = await client.check_url("https://clean.example.com", client=mock_http_client)

        assert report.status == ProviderStatus.AVAILABLE_CLEAN
        assert report.threat_details is None

    @pytest.mark.asyncio
    async def test_upstream_error_handling(self):
        mock_response = httpx.Response(500, text="Internal Service Error")

        async def mock_handler(request: httpx.Request):
            return mock_response

        transport = httpx.MockTransport(mock_handler)
        client = GoogleSafeBrowsingClient(api_key="valid_operational_api_key_12345")

        async with httpx.AsyncClient(transport=transport) as mock_http_client:
            report = await client.check_url("https://error.example.com", client=mock_http_client)

        assert report.status == ProviderStatus.ERROR
        assert "UPSTREAM_HTTP_500" in report.error_category


# ==============================================================================
# 3. URLhaus Adapter Tests (Mocked)
# ==============================================================================

class TestURLhausClient:
    """Verifies abuse.ch URLhaus client with mocked HTTP responses."""

    @pytest.mark.asyncio
    async def test_unconfigured_client(self):
        client = URLhausClient(api_key="YOUR_URLHAUS_KEY")  # Placeholder
        assert client.is_configured is False
        report = await client.check_url("https://example.com")
        assert report.status == ProviderStatus.UNCONFIGURED

    @pytest.mark.asyncio
    async def test_flagged_malware_url(self):
        mock_response = httpx.Response(
            200,
            json={
                "query_status": "ok",
                "url_status": "online",
                "threat": "malware_download",
                "tags": ["Mozi", "botnet"],
                "urlhaus_reference": "https://urlhaus.abuse.ch/url/12345/",
            },
        )

        async def mock_handler(request: httpx.Request):
            return mock_response

        transport = httpx.MockTransport(mock_handler)
        client = URLhausClient(api_key="valid_urlhaus_key_9988")

        async with httpx.AsyncClient(transport=transport) as mock_http_client:
            report = await client.check_url("https://mozi-malware.xyz/payload.exe", client=mock_http_client)

        assert report.status == ProviderStatus.AVAILABLE_FLAGGED
        assert "malware_download" in report.threat_details
        assert "online" in report.threat_details
        assert report.raw_evidence["tags"] == ["Mozi", "botnet"]

    @pytest.mark.asyncio
    async def test_clean_no_results(self):
        mock_response = httpx.Response(200, json={"query_status": "no_results"})

        async def mock_handler(request: httpx.Request):
            return mock_response

        transport = httpx.MockTransport(mock_handler)
        client = URLhausClient(api_key="valid_urlhaus_key_9988")

        async with httpx.AsyncClient(transport=transport) as mock_http_client:
            report = await client.check_url("https://benign.com/app", client=mock_http_client)

        assert report.status == ProviderStatus.AVAILABLE_CLEAN


# ==============================================================================
# 4. PhishTank Adapter Tests (Mocked)
# ==============================================================================

class TestPhishTankClient:
    """Verifies PhishTank client with mocked HTTP interactions."""

    @pytest.mark.asyncio
    async def test_unconfigured_client(self):
        client = PhishTankClient(api_key=None)
        assert client.is_configured is False
        report = await client.check_url("https://example.com")
        assert report.status == ProviderStatus.UNCONFIGURED

    @pytest.mark.asyncio
    async def test_flagged_verified_phishing(self):
        mock_response = httpx.Response(
            200,
            json={
                "results": {
                    "in_database": True,
                    "phish_id": "7891234",
                    "valid": True,
                    "verified": "y",
                    "phish_detail_page": "http://www.phishtank.com/phish_detail.php?phish_id=7891234",
                }
            },
        )

        async def mock_handler(request: httpx.Request):
            return mock_response

        transport = httpx.MockTransport(mock_handler)
        client = PhishTankClient(api_key="valid_phishtank_key_555")

        async with httpx.AsyncClient(transport=transport) as mock_http_client:
            report = await client.check_url("http://sbi-fake-login.xyz", client=mock_http_client)

        assert report.status == ProviderStatus.AVAILABLE_FLAGGED
        assert "7891234" in report.threat_details
        assert report.raw_evidence["verified_phish"] is True

    @pytest.mark.asyncio
    async def test_clean_not_in_database(self):
        mock_response = httpx.Response(
            200, json={"results": {"in_database": False}}
        )

        async def mock_handler(request: httpx.Request):
            return mock_response

        transport = httpx.MockTransport(mock_handler)
        client = PhishTankClient(api_key="valid_phishtank_key_555")

        async with httpx.AsyncClient(transport=transport) as mock_http_client:
            report = await client.check_url("http://safe-bank.com", client=mock_http_client)

        assert report.status == ProviderStatus.AVAILABLE_CLEAN


# ==============================================================================
# 4.1 Invalid Provider Response Validation Tests
# ==============================================================================

class TestProviderResponseValidation:
    @pytest.mark.asyncio
    async def test_gsb_rejects_invalid_matches_type(self):
        async def mock_handler(request: httpx.Request):
            return httpx.Response(200, json={"matches": "invalid"})

        async with httpx.AsyncClient(transport=httpx.MockTransport(mock_handler)) as client:
            report = await GoogleSafeBrowsingClient(api_key="valid_gsb_key").check_url(
                "https://example.com", client=client
            )

        assert report.status == ProviderStatus.ERROR
        assert report.error_category == "INVALID_PROVIDER_MATCHES_TYPE"

    @pytest.mark.asyncio
    async def test_gsb_rejects_match_item_with_invalid_type(self):
        async def mock_handler(request: httpx.Request):
            return httpx.Response(200, json={"matches": ["invalid"]})

        async with httpx.AsyncClient(transport=httpx.MockTransport(mock_handler)) as client:
            report = await GoogleSafeBrowsingClient(api_key="valid_gsb_key").check_url(
                "https://example.com", client=client
            )

        assert report.status == ProviderStatus.ERROR
        assert report.error_category == "INVALID_PROVIDER_MATCH_ITEM"

    @pytest.mark.asyncio
    async def test_urlhaus_unknown_status_is_error_not_clean(self):
        async def mock_handler(request: httpx.Request):
            return httpx.Response(200, json={"query_status": "future_provider_status"})

        async with httpx.AsyncClient(transport=httpx.MockTransport(mock_handler)) as client:
            report = await URLhausClient(api_key="valid_urlhaus_key").check_url(
                "https://example.com", client=client
            )

        assert report.status == ProviderStatus.ERROR
        assert report.error_category == "UNKNOWN_QUERY_STATUS"

    @pytest.mark.asyncio
    async def test_urlhaus_rejects_invalid_tags_type(self):
        async def mock_handler(request: httpx.Request):
            return httpx.Response(200, json={
                "query_status": "ok",
                "url_status": "online",
                "threat": "malware_download",
                "tags": "not-a-list",
            })

        async with httpx.AsyncClient(transport=httpx.MockTransport(mock_handler)) as client:
            report = await URLhausClient(api_key="valid_urlhaus_key").check_url(
                "https://example.com", client=client
            )

        assert report.status == ProviderStatus.ERROR
        assert report.error_category == "INVALID_PROVIDER_TAGS"

    @pytest.mark.asyncio
    async def test_phishtank_missing_results_is_error(self):
        async def mock_handler(request: httpx.Request):
            return httpx.Response(200, json={"unexpected": True})

        async with httpx.AsyncClient(transport=httpx.MockTransport(mock_handler)) as client:
            report = await PhishTankClient(api_key="valid_phishtank_key").check_url(
                "https://example.com", client=client
            )

        assert report.status == ProviderStatus.ERROR
        assert report.error_category == "INVALID_PROVIDER_RESULTS"

    @pytest.mark.asyncio
    async def test_phishtank_rejects_string_boolean_fields(self):
        async def mock_handler(request: httpx.Request):
            return httpx.Response(200, json={
                "results": {"in_database": "true", "valid": True}
            })

        async with httpx.AsyncClient(transport=httpx.MockTransport(mock_handler)) as client:
            report = await PhishTankClient(api_key="valid_phishtank_key").check_url(
                "https://example.com", client=client
            )

        assert report.status == ProviderStatus.ERROR
        assert report.error_category == "INVALID_PROVIDER_BOOLEAN_FIELD"


# ==============================================================================
# 5. Threat Intelligence Aggregator Orchestrator Tests
# ==============================================================================

class TestThreatIntelAggregator:
    """Verifies concurrent multi-provider orchestration, fail-open resilience, and caching."""

    @pytest.mark.asyncio
    async def test_all_unconfigured_providers(self):
        # Settings with no API keys configured
        test_settings = Settings(
            GOOGLE_SAFE_BROWSING_API_KEY=None,
            URLHAUS_API_KEY=None,
            PHISHTANK_API_KEY=None,
        )
        aggregator = ThreatIntelAggregator(settings=test_settings)
        reports = await aggregator.inspect_url("https://example.com/check")

        assert len(reports) == 3
        assert all(r.status == ProviderStatus.UNCONFIGURED for r in reports)
        assert aggregator.is_flagged(reports) is False
        assert aggregator.get_flagged_providers(reports) == []

    @pytest.mark.asyncio
    async def test_mixed_provider_responses(self):
        async def mock_handler(request: httpx.Request):
            url_str = str(request.url)
            if "safebrowsing.googleapis.com" in url_str:
                # GSB: Clean
                return httpx.Response(200, json={})
            elif "urlhaus-api.abuse.ch" in url_str:
                # URLhaus: Flagged
                return httpx.Response(
                    200,
                    json={
                        "query_status": "ok",
                        "url_status": "online",
                        "threat": "malware_download",
                    },
                )
            elif "phishtank.com" in url_str:
                # PhishTank: 503 error
                return httpx.Response(503, text="Service Unavailable")
            return httpx.Response(404)

        transport = httpx.MockTransport(mock_handler)
        test_settings = Settings(
            GOOGLE_SAFE_BROWSING_API_KEY="gsb_key_test_123",
            URLHAUS_API_KEY="urlhaus_key_test_123",
            PHISHTANK_API_KEY="phishtank_key_test_123",
        )
        aggregator = ThreatIntelAggregator(settings=test_settings)

        async with httpx.AsyncClient(transport=transport) as mock_http_client:
            reports = await aggregator.inspect_url(
                "https://target.com/check", client=mock_http_client
            )

        assert len(reports) == 3
        status_map = {r.provider_name: r.status for r in reports}

        assert status_map["Google Safe Browsing"] == ProviderStatus.AVAILABLE_CLEAN
        assert status_map["URLhaus"] == ProviderStatus.AVAILABLE_FLAGGED
        assert status_map["PhishTank"] == ProviderStatus.ERROR

        assert aggregator.is_flagged(reports) is True
        assert aggregator.get_flagged_providers(reports) == ["URLhaus"]
        assert len(aggregator.get_threat_summaries(reports)) == 1

    @pytest.mark.asyncio
    async def test_cache_deduplication_repeat_query(self):
        call_counts = {"gsb": 0}

        async def mock_handler(request: httpx.Request):
            call_counts["gsb"] += 1
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(mock_handler)
        test_settings = Settings(
            GOOGLE_SAFE_BROWSING_API_KEY="gsb_key_test_123",
            URLHAUS_API_KEY=None,
            PHISHTANK_API_KEY=None,
        )
        cache = ThreatIntelCache(default_ttl_hours=1)
        aggregator = ThreatIntelAggregator(settings=test_settings, cache=cache)

        async with httpx.AsyncClient(transport=transport) as mock_http_client:
            # Query 1: Network call
            reports1 = await aggregator.inspect_url("https://cache-target.com", client=mock_http_client)
            # Query 2: Cache hit
            reports2 = await aggregator.inspect_url("https://cache-target.com", client=mock_http_client)

        assert call_counts["gsb"] == 1  # Only queried once!
        gsb_report1 = [r for r in reports1 if r.provider_name == "Google Safe Browsing"][0]
        gsb_report2 = [r for r in reports2 if r.provider_name == "Google Safe Browsing"][0]
        assert gsb_report1.status == ProviderStatus.AVAILABLE_CLEAN
        assert gsb_report2.status == ProviderStatus.AVAILABLE_CLEAN

    @pytest.mark.asyncio
    async def test_isolated_timeout_budget(self):
        async def mock_handler(request: httpx.Request):
            # Simulate upstream lagging beyond timeout budget
            await asyncio.sleep(0.5)
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(mock_handler)
        test_settings = Settings(
            GOOGLE_SAFE_BROWSING_API_KEY="gsb_key_test_123",
            URLHAUS_API_KEY=None,
            PHISHTANK_API_KEY=None,
            INTEL_TIMEOUT_SECONDS=0.1,  # Short timeout for test
        )
        aggregator = ThreatIntelAggregator(settings=test_settings)

        async with httpx.AsyncClient(transport=transport) as mock_http_client:
            reports = await aggregator.inspect_url("https://lagging-feed.com", client=mock_http_client)

        gsb_report = [r for r in reports if r.provider_name == "Google Safe Browsing"][0]
        assert gsb_report.status == ProviderStatus.TIMEOUT

