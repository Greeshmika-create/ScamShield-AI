"""Tests for Phase 7 Multilingual Message NLP & Scam Detection Engine."""

import pytest
from app.schemas.enums import DetectedLanguage, FindingSeverity
from app.schemas.message_analysis import MessageAnalysisResult
from app.services.message_nlp.analyzer import MessageAnalyzer
from app.services.message_nlp.feature_extractor import MessageFeatureExtractor
from app.services.message_nlp.indicator_engine import ScamIndicatorEngine
from app.services.message_nlp.language_detector import LanguageDetector
from app.services.message_nlp.normalizer import MessageNormalizer, NormalizationResult


# ============================================================================
# 1. Unicode & Text Normalizer Tests
# ============================================================================

class TestMessageNormalizer:
    """Verifies Unicode normalization, zero-width stripping, and PII masking."""

    def test_nfkc_normalization(self):
        """NFKC normalizes compatibility characters like ligatures and full-width letters."""
        raw = "ﬁle ＡＢＣ"
        result = MessageNormalizer.normalize(raw)
        assert "file" in result.normalized_text
        assert "ABC" in result.normalized_text

    def test_zero_width_space_stripping(self):
        """Invisible adversarial characters (\\u200B, \\u200C, \\u200D, \\uFEFF) are stripped and counted."""
        obfuscated = "y\u200Bo\u200Cn\u200Do\uFEFF kyc"
        result = MessageNormalizer.normalize(obfuscated)
        assert result.normalized_text == "yono kyc"
        assert result.zero_width_count == 4
        assert result.obfuscation_detected is True

    def test_bidi_override_stripping(self):
        """Directional formatting and overrides (\\u202E) are safely stripped."""
        text = "Hello\u202EWorld"
        result = MessageNormalizer.normalize(text)
        assert result.normalized_text == "HelloWorld"
        assert result.zero_width_count == 1
        assert result.obfuscation_detected is True

    def test_indian_script_integrity(self):
        """Indian script characters, vowel modifiers, and viramas are preserved."""
        telugu_text = "మీ ఖాతా బ్లాక్ చేయబడింది"
        result = MessageNormalizer.normalize(telugu_text)
        assert result.normalized_text == telugu_text
        assert result.zero_width_count == 0
        assert result.obfuscation_detected is False

    def test_whitespace_collapsing(self):
        """Excessive spaces and tabs are collapsed without losing linebreaks."""
        raw = "Hello   \t  World  \n\n  New   Line  "
        result = MessageNormalizer.normalize(raw)
        assert result.normalized_text == "Hello World\nNew Line"

    def test_pii_preview_masking_otp(self):
        """6-digit OTP codes are masked in previews."""
        text = "Your verification OTP is 482910 for payment."
        preview = MessageNormalizer.create_safe_preview(text)
        assert "482910" not in preview
        assert "[OTP REDACTED]" in preview

    def test_pii_preview_masking_phone(self):
        """Indian mobile phone numbers are masked in previews."""
        text = "Call officer on 9876543210 urgently."
        preview = MessageNormalizer.create_safe_preview(text)
        assert "9876543210" not in preview
        assert "[PHONE REDACTED]" in preview

    def test_pii_preview_masking_upi(self):
        """UPI VPA addresses are masked in previews."""
        text = "Send ₹500 to scammer@oksbi immediately."
        preview = MessageNormalizer.create_safe_preview(text)
        assert "scammer@oksbi" not in preview
        assert "[UPI REDACTED]" in preview

    def test_preview_length_cap(self):
        """Previews exceeding 120 chars are truncated with an ellipsis."""
        long_text = "A" * 200
        preview = MessageNormalizer.create_safe_preview(long_text, max_length=120)
        assert len(preview) == 120
        assert preview.endswith("...")


# ============================================================================
# 2. Language & Script Detection Tests
# ============================================================================

class TestLanguageDetector:
    """Verifies offline Unicode script identification and transliterated Telugish heuristics."""

    def test_detect_telugu_script(self):
        """Telugu Unicode script is identified accurately."""
        text = "మీ ఖాతా బ్లాక్ చేయబడింది వెంటనే సంప్రదించండి"
        assessment = LanguageDetector.assess_message(text)
        assert assessment.primary_script == "TELUGU"
        assert assessment.detected_language == DetectedLanguage.TELUGU_SCRIPT
        assert assessment.is_mixed_script is False
        assert assessment.confidence == "HIGH"
        assert "TELUGU" in assessment.script_distribution

    def test_detect_devanagari_script(self):
        """Devanagari Unicode script (Hindi/Marathi) is detected."""
        text = "आपका बैंक खाता ब्लॉक कर दिया गया है तुरंत केवाईसी अपडेट करें"
        assessment = LanguageDetector.assess_message(text)
        assert assessment.primary_script == "DEVANAGARI"
        assert assessment.confidence == "HIGH"
        assert assessment.limitations_notice is not None

    def test_detect_tamil_script(self):
        """Tamil Unicode script is identified."""
        text = "உங்கள் வங்கி கணக்கு முடக்கப்பட்டுள்ளது"
        assessment = LanguageDetector.assess_message(text)
        assert assessment.primary_script == "TAMIL"
        assert assessment.confidence == "HIGH"

    def test_detect_kannada_script(self):
        """Kannada Unicode script is identified."""
        text = "ನಿಮ್ಮ ಬ್ಯಾಂಕ್ ಖಾತೆ ಸ್ಥಗಿತಗೊಂಡಿದೆ"
        assessment = LanguageDetector.assess_message(text)
        assert assessment.primary_script == "KANNADA"
        assert assessment.confidence == "HIGH"

    def test_detect_malayalam_script(self):
        """Malayalam Unicode script is identified."""
        text = "നിങ്ങളുടെ അക്കൗണ്ട് താൽക്കാലികമായി നിർത്തിവച്ചു"
        assessment = LanguageDetector.assess_message(text)
        assert assessment.primary_script == "MALAYALAM"
        assert assessment.confidence == "HIGH"

    def test_detect_bengali_script(self):
        """Bengali Unicode script is identified."""
        text = "আপনার ব্যাঙ্ক অ্যাকাউন্ট ব্লক করা হয়েছে"
        assessment = LanguageDetector.assess_message(text)
        assert assessment.primary_script == "BENGALI"
        assert assessment.confidence == "HIGH"

    def test_detect_latin_english(self):
        """Standard Latin alphabet is classified as English."""
        text = "Your account has been suspended. Please contact customer support immediately."
        assessment = LanguageDetector.assess_message(text)
        assert assessment.primary_script == "LATIN"
        assert assessment.detected_language == DetectedLanguage.ENGLISH
        assert assessment.confidence == "HIGH"

    def test_detect_telugish_transliterated(self):
        """Latin-script transliterated Telugish with phonetic markers is classified as TELUGISH."""
        text = "Mee SBI account block aindi. Ventane kyc update cheyandi lekapothe close avtundi."
        assessment = LanguageDetector.assess_message(text)
        assert assessment.primary_script == "LATIN"
        assert assessment.detected_language == DetectedLanguage.TELUGISH
        assert assessment.confidence == "HIGH"

    def test_detect_mixed_script(self):
        """Messages with substantial mix of English and Telugu are flagged as MIXED."""
        text = "Dear Customer, mee SBI account block aindi. Contact us వెంటనే."
        assessment = LanguageDetector.assess_message(text)
        assert assessment.is_mixed_script is True
        assert assessment.detected_language == DetectedLanguage.MIXED

    def test_empty_or_symbolic_text(self):
        """Purely numeric or punctuation text handles gracefully as UNKNOWN."""
        text = "12345 !@#$% 789"
        assessment = LanguageDetector.assess_message(text)
        assert assessment.primary_script == "UNKNOWN"
        assert assessment.detected_language == DetectedLanguage.UNKNOWN
        assert assessment.confidence == "LOW"


# ============================================================================
# 3. Scam Indicator Engine Tests
# ============================================================================

class TestScamIndicatorEngine:
    """Verifies multilingual indicator rules and false-positive immunity."""

    def test_banking_kyc_suspension_english(self):
        """English banking KYC threat triggers BANKING_KYC_SUSPENSION."""
        text = "Dear SBI user, your YONO account blocked. Update your KYC immediately to avoid permanent deactivation."
        indicators = ScamIndicatorEngine.evaluate_message(text)
        assert any(ind.rule_name == "BANKING_KYC_SUSPENSION" for ind in indicators)
        assert any(ind.severity == FindingSeverity.CRITICAL for ind in indicators)

    def test_banking_kyc_suspension_telugu(self):
        """Telugu script account block triggers BANKING_KYC_SUSPENSION."""
        text = "మీ ఎకౌంట్ బ్లాక్ చేయబడింది. వెంటనే సంప్రదించండి."
        indicators = ScamIndicatorEngine.evaluate_message(text)
        assert any(ind.rule_name == "BANKING_KYC_SUSPENSION" for ind in indicators)

    def test_banking_kyc_suspension_telugish(self):
        """Transliterated Telugish account block triggers BANKING_KYC_SUSPENSION."""
        text = "Mee SBI account block aindi kyc update cheyandi lekapothe deactive avtundi."
        indicators = ScamIndicatorEngine.evaluate_message(text)
        assert any(ind.rule_name == "BANKING_KYC_SUSPENSION" for ind in indicators)

    def test_urgency_power_cut_english(self):
        """Electricity power cut threat triggers URGENCY_COERCION."""
        text = "Dear consumer, your electricity power disconnected tonight at 9 PM by electricity board. Call 9876543210 immediately."
        indicators = ScamIndicatorEngine.evaluate_message(text)
        assert any(ind.rule_name == "URGENCY_COERCION" for ind in indicators)

    def test_urgency_power_cut_telugish(self):
        """Telugish power cut threat triggers URGENCY_COERCION."""
        text = "Current bill avtundi 9 pm ki power cut avuthundi call 9876543210."
        indicators = ScamIndicatorEngine.evaluate_message(text)
        assert any(ind.rule_name == "URGENCY_COERCION" for ind in indicators)

    def test_credential_otp_theft(self):
        """Demanding user to share OTP triggers CREDENTIAL_OTP_THEFT."""
        text = "Share your OTP to prevent immediate account cancellation."
        indicators = ScamIndicatorEngine.evaluate_message(text)
        assert any(ind.rule_name == "CREDENTIAL_OTP_THEFT" for ind in indicators)

    def test_upi_pin_fraud(self):
        """Trick to enter UPI PIN to receive cashback triggers PAYMENT_UPI_FRAUD."""
        text = "Congratulations! You have received cashback of ₹2,500. Enter UPI PIN to accept payment in PhonePe."
        indicators = ScamIndicatorEngine.evaluate_message(text)
        assert any(ind.rule_name == "PAYMENT_UPI_FRAUD" for ind in indicators)

    def test_lottery_prize_scam(self):
        """Fake lottery or KBC award triggers LOTTERY_PRIZE_SCAM."""
        text = "Dear customer, you have won a lottery of Rs. 2500000 in KBC lucky draw. Contact manager immediately."
        indicators = ScamIndicatorEngine.evaluate_message(text)
        assert any(ind.rule_name == "LOTTERY_PRIZE_SCAM" for ind in indicators)

    def test_delivery_fee_scam(self):
        """Fake India Post parcel fee triggers DELIVERY_FEE_SCAM."""
        text = "India Post: Your package on hold due to incomplete address. Pay small fee of Rs 25 to update address."
        indicators = ScamIndicatorEngine.evaluate_message(text)
        assert any(ind.rule_name == "DELIVERY_FEE_SCAM" for ind in indicators)

    def test_suspicious_job_offer(self):
        """Unrealistic work-from-home earnings triggers SUSPICIOUS_JOB_OFFER."""
        text = "Part-time job: Work from home and earn Rs 5000 daily by liking YouTube videos. Contact HR on telegram @job_scam."
        indicators = ScamIndicatorEngine.evaluate_message(text)
        assert any(ind.rule_name == "SUSPICIOUS_JOB_OFFER" for ind in indicators)

    def test_malicious_apk_install(self):
        """Instructing APK or AnyDesk installation triggers SUSPICIOUS_APK_INSTALL."""
        text = "Download and install the app from http://fake-bank.site/support.apk to verify your account."
        indicators = ScamIndicatorEngine.evaluate_message(text)
        assert any(ind.rule_name == "SUSPICIOUS_APK_INSTALL" for ind in indicators)

    def test_false_positive_immunity_bank_advisory(self):
        """Legitimate bank alert with safety disclaimer ('Do not share OTP') does NOT trigger credential theft."""
        legitimate_sms = "Rs. 2,000 debited from SBI A/c XX4910. OTP is 392019 for transaction. Do not share OTP with anyone. Bank never asks for OTP."
        indicators = ScamIndicatorEngine.evaluate_message(legitimate_sms)
        rule_names = [ind.rule_name for ind in indicators]
        assert "CREDENTIAL_OTP_THEFT" not in rule_names

    def test_benign_message_no_false_positive(self):
        """Normal conversational message produces zero scam indicators."""
        text = "Hey, are we still meeting for lunch today? Let me know when you are free."
        indicators = ScamIndicatorEngine.evaluate_message(text)
        assert len(indicators) == 0


# ============================================================================
# 4. Message Feature Extractor Tests
# ============================================================================

class TestMessageFeatureExtractor:
    """Verifies passive URL extraction, phone parsing, and character n-grams."""

    def test_passive_url_extraction(self):
        """Candidate URLs are extracted passively without network requests."""
        text = "Visit http://sbi-secure.phish.com/login and https://payment.top/verify.apk now."
        urls = MessageFeatureExtractor.extract_urls(text)
        assert "http://sbi-secure.phish.com/login" in urls
        assert "https://payment.top/verify.apk" in urls
        assert len(urls) == 2

    def test_indian_phone_extraction(self):
        """10-digit Indian phone numbers with prefixes are extracted."""
        text = "Call +91 9876543210 or 8765432109 immediately."
        phones = MessageFeatureExtractor.extract_phone_numbers(text)
        assert "+919876543210" in phones or "9876543210" in phones
        assert len(phones) >= 1

    def test_subword_char_ngrams(self):
        """Sub-word n-grams generate boundary markers (<word>)."""
        text = "cheyandi"
        ngrams = MessageFeatureExtractor.generate_subword_char_ngrams(text, min_n=3, max_n=3)
        assert "<ch" in ngrams
        assert "che" in ngrams
        assert "di>" in ngrams

    def test_complete_feature_extraction(self):
        """Quantitative features correctly count metrics."""
        text = "Pay ₹500 immediately to avoid power cut. Visit http://pay.me or call 9876543210."
        features = MessageFeatureExtractor.extract_features(text, zero_width_count=2)
        assert features.url_count == 1
        assert features.phone_count == 1
        assert features.currency_count >= 1
        assert features.urgency_count >= 1
        assert features.zero_width_obfuscation_count == 2
        assert features.message_length == len(text)
        assert features.word_count > 0


# ============================================================================
# 5. Message Analyzer Coordinator Tests
# ============================================================================

class TestMessageAnalyzer:
    """Verifies end-to-end coordinator flow, threat scoring, and privacy hygiene."""

    def test_analyze_scam_message(self):
        """Threatening banking scam produces ANALYZED status, high score, and indicators."""
        scam_text = (
            "Dear SBI Customer, your YONO account blocked. Update your KYC immediately. "
            "Call 9876543210 or visit http://sbi-kyc-verify.top/now."
        )
        result: MessageAnalysisResult = MessageAnalyzer.analyze(scam_text)
        assert result.status == "ANALYZED"
        assert result.threat_score_estimate > 30
        assert len(result.indicators) >= 1
        assert result.features.url_count == 1
        assert result.features.phone_count == 1
        # PII should be masked in preview
        assert "9876543210" not in result.message_preview
        assert "[PHONE REDACTED]" in result.message_preview
        assert result.cautious_disclaimer is not None

    def test_analyze_clean_message(self):
        """Benign conversational text returns NO_KNOWN_INDICATORS and 0 threat score."""
        clean_text = "Good morning! Please send the presentation slides when ready."
        result = MessageAnalyzer.analyze(clean_text)
        assert result.status == "NO_KNOWN_INDICATORS"
        assert result.threat_score_estimate == 0
        assert len(result.indicators) == 0

    def test_analyze_empty_message(self):
        """Empty input safely returns NO_KNOWN_INDICATORS without crashing."""
        result = MessageAnalyzer.analyze("")
        assert result.status == "NO_KNOWN_INDICATORS"
        assert result.threat_score_estimate == 0
        assert result.features.message_length == 0

    def test_analyze_whitespace_only(self):
        """Whitespace-only input safely handled."""
        result = MessageAnalyzer.analyze("   \n\t   ")
        assert result.status == "NO_KNOWN_INDICATORS"
        assert result.threat_score_estimate == 0

    def test_analyze_telugish_power_cut(self):
        """Transliterated Telugish urgency coercion correctly assessed."""
        text = "Current bill avtundi 9 pm ki power cut avuthundi. Ventane 9876543210 ki call cheyandi."
        result = MessageAnalyzer.analyze(text)
        assert result.status == "ANALYZED"
        assert result.script_assessment.detected_language == DetectedLanguage.TELUGISH
        assert any(ind.rule_name == "URGENCY_COERCION" for ind in result.indicators)
        assert result.threat_score_estimate >= 25

    def test_error_resilience(self, monkeypatch):
        """If an unexpected exception occurs inside analyzer, it returns safe ERROR status."""
        def broken_normalize(*args, **kwargs):
            raise RuntimeError("Unexpected simulated failure")

        monkeypatch.setattr(MessageNormalizer, "normalize", broken_normalize)
        result = MessageAnalyzer.analyze("Some suspicious text")
        assert result.status == "ERROR"
        assert result.threat_score_estimate == 0
        assert "internal processing error" in result.summary.lower()

