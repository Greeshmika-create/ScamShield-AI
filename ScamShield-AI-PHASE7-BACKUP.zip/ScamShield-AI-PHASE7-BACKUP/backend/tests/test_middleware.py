"""Tests for Phase 3.3 middleware: Request ID tracing, process timing, security headers, and protection."""

import asyncio
import re
import pytest
from fastapi import APIRouter
from fastapi.testclient import TestClient
from pydantic import BaseModel, Field

from app.core.config import Settings
from app.core.logging import SensitiveDataFilter, get_request_id
from app.core.middleware import (
    MAX_REQUEST_BODY_SIZE,
    REQUEST_ID_REGEX,
    sanitize_url_path,
    validate_or_generate_request_id,
)
from app.main import create_application


@pytest.fixture
def app_client():
    app = create_application(settings=Settings(ENVIRONMENT="test"))
    with TestClient(app) as client:
        yield client


# ==============================================================================
# 1. Request ID Tracing Middleware Tests
# ==============================================================================

def test_request_id_generated_when_missing(app_client: TestClient):
    """When client provides no X-Request-ID, the server generates a valid UUIDv4."""
    response = app_client.get("/api/v1/health")
    assert response.status_code == 200
    req_id = response.headers.get("X-Request-ID")
    assert req_id is not None
    # Verify standard UUID format
    assert re.match(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", req_id)


def test_valid_request_id_propagated(app_client: TestClient):
    """Server generates authoritative UUIDv4 for X-Request-ID and isolates valid client correlation ID in X-Client-Correlation-ID."""
    valid_ids = [
        "c8b417e2-4521-4fa2-9eb2-f38b25a3d750",
        "client-req-trace-9912",
        "INVESTIGATION_SCAN_001",
    ]
    for cid in valid_ids:
        response = app_client.get("/api/v1/health", headers={"X-Request-ID": cid})
        assert response.status_code == 200
        # Authoritative server request ID is always a fresh UUIDv4
        server_id = response.headers.get("X-Request-ID")
        assert server_id is not None
        assert re.match(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", server_id)
        # Client correlation ID is validated and mirrored in dedicated header
        assert response.headers.get("X-Client-Correlation-ID") == cid


def test_invalid_request_id_replaced(app_client: TestClient):
    """Untrusted or malformed client request IDs are rejected from correlation and server always generates authoritative UUID."""
    invalid_ids = [
        "short",  # < 8 chars
        "A" * 65,  # > 64 chars
        "id with spaces inside",  # spaces
        "<script>alert(1)</script>",  # XSS probe
        "id\r\nX-Injected: header",  # CRLF injection probe
        "id; DROP TABLE scans;",  # SQL injection probe
    ]
    for bad_id in invalid_ids:
        response = app_client.get("/api/v1/health", headers={"X-Request-ID": bad_id})
        assert response.status_code == 200
        # Server request ID is always authoritative UUIDv4
        returned_id = response.headers.get("X-Request-ID")
        assert returned_id != bad_id
        assert re.match(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", returned_id)
        # Malformed client correlation ID is strictly ignored (never reflected)
        assert response.headers.get("X-Client-Correlation-ID") is None


def test_concurrent_requests_have_unique_request_ids():
    """Ensure concurrent requests on event loop execute with distinct, isolated request IDs."""
    test_router = APIRouter()

    @test_router.get("/concurrent-test")
    async def concurrent_endpoint():
        await asyncio.sleep(0.01)
        return {"active_request_id": get_request_id()}

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as client:
        # Sequential and fast interleaved checks
        request_ids = set()
        for _ in range(15):
            res = client.get("/concurrent-test")
            assert res.status_code == 200
            hdr_id = res.headers.get("X-Request-ID")
            body_id = res.json()["active_request_id"]
            assert hdr_id == body_id
            request_ids.add(hdr_id)

        # All 15 requests had unique IDs
        assert len(request_ids) == 15


# ==============================================================================
# 2. Request Processing Time Tests
# ==============================================================================

def test_process_time_header_present(app_client: TestClient):
    """Every response includes X-Process-Time measured with a monotonic clock."""
    response = app_client.get("/api/v1/health")
    assert response.status_code == 200
    pt = response.headers.get("X-Process-Time")
    assert pt is not None
    assert pt.endswith("s")
    # Verify it represents a non-negative float duration
    numeric_seconds = float(pt[:-1])
    assert numeric_seconds >= 0.0


def test_process_time_on_error_responses(app_client: TestClient):
    """Even error responses (404, 405, 500) include X-Process-Time and X-Request-ID."""
    # 404
    r404 = app_client.get("/api/v1/non_existent")
    assert r404.status_code == 404
    assert "X-Request-ID" in r404.headers
    assert "X-Process-Time" in r404.headers

    # 405
    r405 = app_client.post("/api/v1/health")
    assert r405.status_code == 405
    assert "X-Request-ID" in r405.headers
    assert "X-Process-Time" in r405.headers


# ==============================================================================
# 3. Security Response Headers Tests
# ==============================================================================

def test_security_headers_enforced_on_api_endpoints(app_client: TestClient):
    """Enterprise security headers are enforced across API responses."""
    response = app_client.get("/api/v1/health")
    assert response.status_code == 200
    headers = response.headers

    # MIME sniffing protection
    assert headers.get("X-Content-Type-Options") == "nosniff"
    # Clickjacking protection
    assert headers.get("X-Frame-Options") == "DENY"
    # Referrer privacy
    assert headers.get("Referrer-Policy") == "strict-origin-when-cross-origin"
    # Anti-caching for sensitive security endpoints
    assert "no-store" in headers.get("Cache-Control", "")
    assert "must-revalidate" in headers.get("Cache-Control", "")


def test_cors_headers_exposure(app_client: TestClient):
    """CORS response exposes custom correlation and timing headers."""
    response = app_client.get(
        "/api/v1/health",
        headers={"Origin": "http://localhost:5173"},
    )
    assert response.status_code == 200
    exposed = response.headers.get("access-control-expose-headers", "")
    assert "X-Request-ID" in exposed
    assert "X-Process-Time" in exposed


# ==============================================================================
# 4. Request Size and Content-Type Protection Tests
# ==============================================================================

def test_payload_exceeding_1mb_rejected_with_413():
    """Request bodies over 1MB are rejected with standardized HTTP 413 error."""
    test_router = APIRouter()

    @test_router.post("/api/v1/test-upload")
    def upload_endpoint(payload: dict):
        return {"received": True}

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as client:
        # Declare Content-Length exceeding 1MB limit
        response = client.post(
            "/api/v1/test-upload",
            headers={
                "Content-Length": str(MAX_REQUEST_BODY_SIZE + 100),
                "Content-Type": "application/json",
            },
        )
        assert response.status_code == 413
        data = response.json()
        assert data["error_code"] == "INVALID_INPUT_FORMAT"
        assert "exceeds maximum allowed size of 1MB" in data["message"]
        assert "X-Request-ID" in response.headers
        assert "X-Process-Time" in response.headers


def test_unsupported_content_type_rejected_with_415():
    """Non-JSON bodies submitted to /api/ endpoints are rejected with HTTP 415."""
    test_router = APIRouter()

    @test_router.post("/api/v1/test-json-only")
    def json_endpoint(payload: dict):
        return {"received": True}

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as client:
        # Text/plain
        r_text = client.post(
            "/api/v1/test-json-only",
            content="some raw plain text payload",
            headers={"Content-Type": "text/plain"},
        )
        assert r_text.status_code == 415
        assert r_text.json()["error_code"] == "INVALID_INPUT_FORMAT"
        assert "application/json" in r_text.json()["message"]
        assert "X-Request-ID" in r_text.headers

        # XML
        r_xml = client.post(
            "/api/v1/test-json-only",
            content="<xml>attack</xml>",
            headers={"Content-Type": "application/xml"},
        )
        assert r_xml.status_code == 415


def test_valid_json_content_types_accepted():
    """Standard application/json and parameterized json content types succeed."""
    test_router = APIRouter()

    @test_router.post("/api/v1/test-json-accept")
    def accept_endpoint(payload: dict):
        return {"received": payload}

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as client:
        # Standard
        res1 = client.post(
            "/api/v1/test-json-accept",
            json={"valid": True},
            headers={"Content-Type": "application/json"},
        )
        assert res1.status_code == 200

        # With charset
        res2 = client.post(
            "/api/v1/test-json-accept",
            content='{"valid": true}',
            headers={"Content-Type": "application/json; charset=utf-8"},
        )
        assert res2.status_code == 200


def test_streamed_chunked_payload_exceeding_1mb_rejected_with_413():
    """Chunked streaming requests exceeding 1MB without Content-Length are stopped and rejected with 413."""
    test_router = APIRouter()

    @test_router.post("/api/v1/test-stream-upload")
    def stream_endpoint(payload: dict):
        return {"received": True}

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as client:
        # Generator yielding chunks exceeding 1MB in total without declaring Content-Length
        def oversized_chunk_generator():
            yield b'{"content": "'
            # Emit multiple 256KB chunks exceeding 1MB limit
            for _ in range(5):
                yield b"A" * (256 * 1024)
            yield b'"}'

        response = client.post(
            "/api/v1/test-stream-upload",
            content=oversized_chunk_generator(),
            headers={"Content-Type": "application/json"},
        )
        assert response.status_code == 413
        data = response.json()
        assert data["error_code"] == "INVALID_INPUT_FORMAT"
        assert "exceeds maximum allowed size of 1MB" in data["message"]
        assert "X-Request-ID" in response.headers


def test_streamed_chunked_payload_under_1mb_accepted():
    """Chunked streaming requests under 1MB are cleanly accepted and parsed."""
    test_router = APIRouter()

    @test_router.post("/api/v1/test-stream-accept")
    def stream_endpoint(payload: dict):
        return {"received": payload}

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as client:
        def valid_chunk_generator():
            yield b'{"field_a": '
            yield b'"chunk_1_value", '
            yield b'"field_b": "chunk_2_value"}'

        response = client.post(
            "/api/v1/test-stream-accept",
            content=valid_chunk_generator(),
            headers={"Content-Type": "application/json"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["received"]["field_a"] == "chunk_1_value"
        assert data["received"]["field_b"] == "chunk_2_value"


# ==============================================================================
# 5. Safe Logging and Redaction Tests
# ==============================================================================

def test_sensitive_data_filter_redacts_credentials():
    """SensitiveDataFilter scrubs passwords, tokens, OTPs, and phone numbers."""
    filter_obj = SensitiveDataFilter()

    # Passwords and Tokens
    assert "[REDACTED]" in filter_obj._sanitize_string("user password=SuperSecretPassword123 login")
    assert "[REDACTED]" in filter_obj._sanitize_string("token: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9")
    assert "Bearer [REDACTED]" in filter_obj._sanitize_string("Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9")

    # OTPs
    assert "[OTP-REDACTED]" in filter_obj._sanitize_string("Your OTP is 482910 for authentication")

    # Indian phone numbers
    assert "[PHONE-REDACTED]" in filter_obj._sanitize_string("Call manager at +919876543210 or 9876543210")

    # Bank cards
    assert "[ACCOUNT-REDACTED]" in filter_obj._sanitize_string("Card number 4111 2222 3333 4444")


def test_sensitive_query_parameters_sanitized_in_paths():
    """Sanitize_url_path strips credentials from URL query strings."""
    url1 = "https://api.scamshield.ai/api/v1/scan/url?token=secret123&otp=482910&target=https://phish.in"
    sanitized = sanitize_url_path(url1)  # type: ignore[arg-type]
    # Sensitive tokens and OTPs must NOT be present
    assert "secret123" not in sanitized
    assert "482910" not in sanitized
    assert "token=%5BREDACTED%5D" in sanitized or "token=[REDACTED]" in sanitized
    # Non-sensitive target remains intact
    assert "phish.in" in sanitized


def test_error_response_correlates_request_id():
    """Standard error response includes authoritative request_id and preserves client correlation ID."""
    app = create_application(settings=Settings(ENVIRONMENT="test"))
    with TestClient(app) as client:
        custom_id = "test-correlation-err-9999"
        response = client.get("/api/v1/does-not-exist", headers={"X-Request-ID": custom_id})
        assert response.status_code == 404
        server_id = response.headers.get("X-Request-ID")
        assert server_id is not None
        assert re.match(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", server_id)
        assert response.headers.get("X-Client-Correlation-ID") == custom_id
        data = response.json()
        assert data["request_id"] == server_id
        assert data["error_code"] == "NOT_FOUND"


def test_wildcard_cors_rejected_in_config():
    """Attempting to configure wildcard '*' CORS origin with credentials raises validation error."""
    with pytest.raises(ValueError) as exc_info:
        Settings(CORS_ORIGINS=["*"])
    assert "Wildcard origin '*'" in str(exc_info.value)


# ==============================================================================
# 6. Advanced Exception & Logging Isolation Tests
# ==============================================================================

def test_sensitive_headers_and_body_never_logged(caplog: pytest.LogCaptureFixture):
    """Ensure Authorization headers, cookies, and bodies are never dumped into logs."""
    test_router = APIRouter()

    @test_router.post("/api/v1/test-auth-log")
    def auth_endpoint(payload: dict):
        return {"ok": True}

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with caplog.at_level("INFO", logger="scamshield.access"):
        with TestClient(app) as client:
            client.post(
                "/api/v1/test-auth-log",
                json={"password": "UltraSecretPassword99!", "otp": "482910"},
                headers={
                    "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.supersecret",
                    "Cookie": "session_id=confidential_session_token_xyz",
                    "X-Request-ID": "test-auth-log-id-1234",
                },
            )

    log_output = caplog.text
    # Sensitive credentials must NEVER leak to access logs
    assert "UltraSecretPassword99!" not in log_output
    assert "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.supersecret" not in log_output
    assert "confidential_session_token_xyz" not in log_output
    assert "482910" not in log_output


def test_unhandled_exception_logs_request_id_and_returns_clean_response(caplog: pytest.LogCaptureFixture):
    """Unhandled exceptions log traceback with authoritative request_id while client receives sanitized response."""
    test_router = APIRouter()

    @test_router.get("/api/v1/test-crash-trace")
    def crash_endpoint():
        raise ZeroDivisionError("division by zero in internal algorithm")

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with caplog.at_level("ERROR", logger="scamshield.errors"):
        with TestClient(app, raise_server_exceptions=False) as client:
            response = client.get(
                "/api/v1/test-crash-trace",
                headers={"X-Request-ID": "test-crash-corr-9988"},
            )

    assert response.status_code == 500
    data = response.json()
    assert data["error_code"] == "INTERNAL_ERROR"
    server_req_id = response.headers.get("X-Request-ID")
    assert server_req_id is not None
    assert data["request_id"] == server_req_id
    assert response.headers.get("X-Client-Correlation-ID") == "test-crash-corr-9988"
    assert "ZeroDivisionError" not in str(data)
    assert "Traceback" not in str(data)

    # Server logs contain authoritative request_id correlation
    assert server_req_id in caplog.text


def test_application_exception_mappings():
    """Verify Unauthorized, Forbidden, and ServiceUnavailable map to proper status codes."""
    from app.core.errors import (
        ForbiddenException,
        ServiceUnavailableException,
        UnauthorizedException,
    )

    test_router = APIRouter()

    @test_router.get("/test-401")
    def r401():
        raise UnauthorizedException("Auth required.")

    @test_router.get("/test-403")
    def r403():
        raise ForbiddenException("Access denied.")

    @test_router.get("/test-503")
    def r503():
        raise ServiceUnavailableException("Feed down.")

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as client:
        res401 = client.get("/test-401")
        assert res401.status_code == 401
        assert res401.json()["error_code"] == "UNAUTHORIZED"

        res403 = client.get("/test-403")
        assert res403.status_code == 403
        assert res403.json()["error_code"] == "FORBIDDEN"

        res503 = client.get("/test-503")
        assert res503.status_code == 503
        assert res503.json()["error_code"] == "BACKEND_UNAVAILABLE"


def test_client_correlation_id_via_different_headers():
    """Client correlation header accepts X-Client-Correlation-ID, X-Correlation-ID, or X-Request-ID."""
    app = create_application(settings=Settings(ENVIRONMENT="test"))
    with TestClient(app) as client:
        # X-Client-Correlation-ID
        res1 = client.get("/api/v1/health", headers={"X-Client-Correlation-ID": "corr-id-alpha-123"})
        assert res1.status_code == 200
        assert res1.headers.get("X-Client-Correlation-ID") == "corr-id-alpha-123"
        server_id1 = res1.headers.get("X-Request-ID")
        assert server_id1 != "corr-id-alpha-123"

        # X-Correlation-ID
        res2 = client.get("/api/v1/health", headers={"X-Correlation-ID": "corr-id-beta-456"})
        assert res2.status_code == 200
        assert res2.headers.get("X-Client-Correlation-ID") == "corr-id-beta-456"
        server_id2 = res2.headers.get("X-Request-ID")
        assert server_id2 != "corr-id-beta-456"


def test_chunked_non_json_rejected_with_415():
    """Chunked streaming with non-JSON Content-Type is rejected with 415."""
    test_router = APIRouter()

    @test_router.post("/api/v1/test-stream-type")
    def stream_type_endpoint(payload: dict):
        return {"ok": True}

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as client:
        def chunk_gen():
            yield b"plain text line 1\n"
            yield b"plain text line 2\n"

        res = client.post(
            "/api/v1/test-stream-type",
            content=chunk_gen(),
            headers={"Content-Type": "text/plain"},
        )
        assert res.status_code == 415
        assert res.json()["error_code"] == "INVALID_INPUT_FORMAT"


def test_request_state_isolates_authoritative_and_client_ids():
    """Verify endpoint receives authoritative server UUID and isolated client correlation ID in request.state."""
    from fastapi import Request

    test_router = APIRouter()

    @test_router.get("/api/v1/test-state-ids")
    def state_endpoint(request: Request):
        return {
            "server_id": getattr(request.state, "request_id", None),
            "client_corr_id": getattr(request.state, "client_correlation_id", None),
        }

    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.include_router(test_router)

    with TestClient(app) as client:
        res = client.get("/api/v1/test-state-ids", headers={"X-Request-ID": "client-supplied-id-777"})
        assert res.status_code == 200
        data = res.json()
        assert data["server_id"] == res.headers.get("X-Request-ID")
        assert data["client_corr_id"] == "client-supplied-id-777"
        assert res.headers.get("X-Client-Correlation-ID") == "client-supplied-id-777"
        # Server ID is authoritative UUIDv4, never the client ID
        assert data["server_id"] != "client-supplied-id-777"

