"""Pytest configuration and reusable test fixtures."""

import os
import pytest
from fastapi.testclient import TestClient
from app.core.config import Settings, get_settings
from app.main import create_application


@pytest.fixture(scope="session")
def test_settings() -> Settings:
    """Return test-specific settings configuration."""
    return Settings(
        ENVIRONMENT="test",
        PROJECT_NAME="ScamShield AI Test",
        VERSION="1.0.0",
        LOG_LEVEL="DEBUG",
        CORS_ORIGINS=["http://localhost:5173", "http://127.0.0.1:5173"],
        SUPABASE_URL=None,
        SUPABASE_SERVICE_ROLE_KEY=None,
        GOOGLE_SAFE_BROWSING_API_KEY=None,
        URLHAUS_API_KEY=None,
        PHISHTANK_API_KEY=None,
    )


@pytest.fixture
def client(test_settings: Settings) -> TestClient:
    """Provide a TestClient instance bound to the application configured for testing."""
    app = create_application(settings=test_settings)

    # Override dependency
    app.dependency_overrides[get_settings] = lambda: test_settings

    with TestClient(app, base_url="http://testserver") as test_client:
        yield test_client

