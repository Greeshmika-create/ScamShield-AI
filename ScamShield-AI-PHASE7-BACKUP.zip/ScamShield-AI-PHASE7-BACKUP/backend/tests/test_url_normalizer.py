"""Tests for Phase 4.1 URL Normalization and Canonicalization Engine.

Covers all required categories:
- A: Basic normalization
- B: URL component extraction
- C: Internationalized domain names (IDN/Punycode)
- D: Security-sensitive cases (credentials, traversal, reserved characters)
- E: Edge cases and malformed inputs
- F: Passive scanning guarantee (offline execution with no DNS or socket calls)
"""

import http.client
import socket
import urllib.request
import pytest

from app.services.url_normalizer import (
    URLNormalizationError,
    URLNormalizer,
    normalize_url,
)


# =============================================================================
# Category A: Basic Normalization
# =============================================================================

def test_basic_standard_http_url():
    """Standard HTTP URL is normalized with path preserved."""
    res = normalize_url("http://example.com/index.html")
    assert res.is_valid is True
    assert res.canonical_url == "http://example.com/index.html"
    assert res.components is not None
    assert res.components.scheme == "http"
    assert res.components.hostname == "example.com"
    assert res.components.path == "/index.html"
    assert res.components.port is None


def test_basic_standard_https_url():
    """Standard HTTPS URL is normalized with secure scheme."""
    res = normalize_url("https://secure.example.com/dashboard")
    assert res.is_valid is True
    assert res.canonical_url == "https://secure.example.com/dashboard"
    assert res.components.scheme == "https"
    assert res.components.hostname == "secure.example.com"


def test_basic_uppercase_scheme_normalized():
    """Uppercase and mixed-case schemes are lowercased."""
    for raw in ["HTTP://example.com/path", "HtTpS://example.com/path", "HTTPS://example.com/path"]:
        res = normalize_url(raw)
        assert res.is_valid is True
        assert res.components.scheme in {"http", "https"}
        assert res.canonical_url.startswith(("http://", "https://"))


def test_basic_uppercase_hostname_normalized():
    """Uppercase and mixed-case hostnames are lowercased."""
    res = normalize_url("https://BANK-OF-INDIA.COM/Login")
    assert res.is_valid is True
    assert res.components.hostname == "bank-of-india.com"
    assert res.components.ascii_hostname == "bank-of-india.com"
    assert res.canonical_url == "https://bank-of-india.com/Login"


def test_basic_default_http_port_omitted_in_canonical():
    """Explicit port 80 for HTTP is omitted in the canonical representation."""
    res = normalize_url("http://example.com:80/home")
    assert res.is_valid is True
    assert res.components.raw_port == 80
    assert res.components.port is None
    assert res.canonical_url == "http://example.com/home"


def test_basic_default_https_port_omitted_in_canonical():
    """Explicit port 443 for HTTPS is omitted in the canonical representation."""
    res = normalize_url("https://example.com:443/home")
    assert res.is_valid is True
    assert res.components.raw_port == 443
    assert res.components.port is None
    assert res.canonical_url == "https://example.com/home"


def test_basic_non_default_ports_preserved():
    """Non-default ports are strictly preserved in the canonical representation."""
    res_8080 = normalize_url("http://example.com:8080/api")
    assert res_8080.is_valid is True
    assert res_8080.components.port == 8080
    assert res_8080.components.raw_port == 8080
    assert res_8080.canonical_url == "http://example.com:8080/api"

    res_8443 = normalize_url("https://example.com:8443/api")
    assert res_8443.is_valid is True
    assert res_8443.components.port == 8443
    assert res_8443.canonical_url == "https://example.com:8443/api"

    # Non-standard cross-scheme ports (e.g. HTTP on 443, HTTPS on 80)
    res_http_443 = normalize_url("http://example.com:443/test")
    assert res_http_443.components.port == 443
    assert res_http_443.canonical_url == "http://example.com:443/test"

    res_https_80 = normalize_url("https://example.com:80/test")
    assert res_https_80.components.port == 80
    assert res_https_80.canonical_url == "https://example.com:80/test"


def test_basic_empty_path_normalized_to_slash():
    """Empty path for HTTP/HTTPS is normalized to '/' according to RFC 3986 / WHATWG."""
    res = normalize_url("https://example.com")
    assert res.is_valid is True
    assert res.components.path == "/"
    assert res.canonical_url == "https://example.com/"

    res_port = normalize_url("http://example.com:8080")
    assert res_port.is_valid is True
    assert res_port.components.path == "/"
    assert res_port.canonical_url == "http://example.com:8080/"


# =============================================================================
# Category B: URL Component Extraction
# =============================================================================

def test_components_query_parameters_preserved_in_order():
    """Query parameter ordering is preserved without sorting or alterations."""
    raw = "https://example.com/search?z=99&a=1&m=50&a=2"
    res = normalize_url(raw)
    assert res.is_valid is True
    assert res.components.query == "z=99&a=1&m=50&a=2"
    assert res.canonical_url == raw


def test_components_fragment_preserved():
    """Fragment identifiers are extracted and preserved."""
    raw = "https://example.com/docs#installation-instructions"
    res = normalize_url(raw)
    assert res.is_valid is True
    assert res.components.fragment == "installation-instructions"
    assert res.canonical_url == raw


def test_components_path_query_and_fragment():
    """URL with path, query parameters, and fragment are all extracted correctly."""
    raw = "https://bank.example.com:9000/auth/login?redirect=portal&lang=en#step2"
    res = normalize_url(raw)
    assert res.is_valid is True
    assert res.components.scheme == "https"
    assert res.components.hostname == "bank.example.com"
    assert res.components.port == 9000
    assert res.components.path == "/auth/login"
    assert res.components.query == "redirect=portal&lang=en"
    assert res.components.fragment == "step2"
    assert res.canonical_url == raw


def test_components_ipv4_literal():
    """IPv4 addresses are accurately detected as IP literals."""
    res = normalize_url("http://192.168.1.100:8080/setup")
    assert res.is_valid is True
    assert res.components.is_ip_literal is True
    assert res.components.ip_version == 4
    assert res.components.hostname == "192.168.1.100"
    assert res.components.ascii_hostname == "192.168.1.100"
    assert res.canonical_url == "http://192.168.1.100:8080/setup"


def test_components_ipv6_literal():
    """IPv6 addresses enclosed in brackets are detected and normalized."""
    res = normalize_url("http://[2001:db8::1]:8080/status")
    assert res.is_valid is True
    assert res.components.is_ip_literal is True
    assert res.components.ip_version == 6
    assert res.components.hostname == "2001:db8::1"
    assert res.components.ascii_hostname == "2001:db8::1"
    assert res.components.netloc == "[2001:db8::1]:8080"
    assert res.canonical_url == "http://[2001:db8::1]:8080/status"

    # Default port for IPv6
    res_default = normalize_url("https://[::1]:443/")
    assert res_default.is_valid is True
    assert res_default.components.port is None
    assert res_default.canonical_url == "https://[::1]/"


# =============================================================================
# Category C: Internationalized Domains (IDN & Punycode)
# =============================================================================

def test_idn_unicode_domain_converted_to_punycode():
    """Unicode IDN hostnames are normalized to Punycode ASCII."""
    # German umlaut domain
    res = normalize_url("https://münchen.de/kultur")
    assert res.is_valid is True
    assert res.components.hostname == "münchen.de"
    assert res.components.ascii_hostname == "xn--mnchen-3ya.de"
    assert res.canonical_url == "https://xn--mnchen-3ya.de/kultur"


def test_idn_punycode_domain_extracted():
    """Existing Punycode domains decode to Unicode while maintaining ASCII form."""
    res = normalize_url("https://xn--mnchen-3ya.de/service")
    assert res.is_valid is True
    assert res.components.hostname == "münchen.de"
    assert res.components.ascii_hostname == "xn--mnchen-3ya.de"
    assert res.canonical_url == "https://xn--mnchen-3ya.de/service"


def test_idn_mixed_case_internationalized_hostname():
    """Mixed-case internationalized domains are properly lowercased before encoding."""
    res = normalize_url("HTTPS://MüNchEn.DE/tourismus")
    assert res.is_valid is True
    assert res.components.hostname == "münchen.de"
    assert res.components.ascii_hostname == "xn--mnchen-3ya.de"
    assert res.canonical_url == "https://xn--mnchen-3ya.de/tourismus"


def test_idn_telugu_internationalized_domain():
    """Telugu Unicode domain is safely canonicalized via IDNA 2008."""
    # Telugu script domain (e.g. పరీక్ష.భారత్)
    res = normalize_url("http://పరీక్ష.భారత్/login")
    assert res.is_valid is True
    assert res.components.ascii_hostname.startswith("xn--")
    assert "భారత్" in res.components.hostname


# =============================================================================
# Category D: Security-Sensitive Cases
# =============================================================================

def test_security_embedded_credentials_detected_and_masked():
    """Userinfo/embedded credentials are flagged, stripped from canonical URL, and masked in serialization."""
    raw = "https://analyst:SuperSecretP@ssw0rd!@portal.example.com/auth"
    res = normalize_url(raw)
    assert res.is_valid is True
    assert res.components.has_credentials is True
    assert res.components.username == "analyst"
    # Canonical URL excludes sensitive credentials
    assert res.canonical_url == "https://portal.example.com/auth"
    assert res.components.netloc == "portal.example.com"

    # Verify password is NOT exposed in the object's repr or serialization
    repr_str = repr(res)
    assert "SuperSecretP@ssw0rd!" not in repr_str
    assert "SuperSecretP@ssw0rd!" not in res.safe_original_url
    assert "analyst:[MASKED]@" in res.safe_original_url


def test_security_encoded_reserved_characters_preserved():
    """Meaningful percent-encoded reserved characters (%2F, %3F, %23) are NOT decoded."""
    raw = "https://example.com/path%2Fto%2Fresource?q=hello%26world%3D1#tag%231"
    res = normalize_url(raw)
    assert res.is_valid is True
    # %2F in path must remain %2F so path segmentation is not altered
    assert "%2F" in res.canonical_url
    assert "%26" in res.canonical_url
    assert "%23" in res.canonical_url


def test_security_encoded_path_traversal_preserved():
    """Encoded and literal path traversal sequences are NOT collapsed or sanitized."""
    raw = "https://example.com/files/%2e%2e/%2e%2e/etc/passwd"
    res = normalize_url(raw)
    assert res.is_valid is True
    assert "%2e%2e" in res.components.path
    assert res.canonical_url == raw

    raw_literal = "https://example.com/a/b/../../secret"
    res_literal = normalize_url(raw_literal)
    assert res_literal.is_valid is True
    assert "../.." in res_literal.components.path


def test_security_suspicious_query_parameters_preserved():
    """Query parameters containing SQL injection or redirect indicators are retained intact."""
    raw = "https://example.com/redirect?url=http://malicious.top&cmd=UNION+SELECT+1,2,3"
    res = normalize_url(raw)
    assert res.is_valid is True
    assert res.components.query == "url=http://malicious.top&cmd=UNION+SELECT+1,2,3"


def test_security_control_characters_rejected():
    """Control characters (ASCII < 32 or 127) are rejected."""
    for char_code in [0, 7, 9, 10, 13, 27, 127]:
        bad_url = f"https://example.com/test{chr(char_code)}path"
        res = normalize_url(bad_url)
        assert res.is_valid is False
        assert res.error_code in {"CONTROL_CHARACTERS", "INTERNAL_WHITESPACE"}


def test_security_unsupported_protocols_rejected():
    """Non-HTTP(S) schemes are rejected with UNSUPPORTED_SCHEME."""
    bad_schemes = [
        "file:///etc/shadow",
        "ftp://mirror.example.com/file",
        "javascript:alert(document.cookie)",
        "data:text/html,<script>alert(1)</script>",
        "blob:https://example.com/123-456",
        "ws://echo.example.com/socket",
        "gopher://gopher.example.com/",
    ]
    for url in bad_schemes:
        res = normalize_url(url)
        assert res.is_valid is False
        assert res.error_code == "UNSUPPORTED_SCHEME"


# =============================================================================
# Category E: Edge Cases & Malformed Inputs
# =============================================================================

def test_edge_case_empty_and_whitespace():
    """Empty and whitespace-only strings fail gracefully."""
    for empty in ["", "   ", "\t", "\n", " \t \r\n "]:
        res = normalize_url(empty)
        assert res.is_valid is False
        assert res.error_code == "EMPTY_INPUT"


def test_edge_case_missing_scheme():
    """URLs missing schemes fail gracefully."""
    for no_scheme in ["example.com", "www.google.com/search", "//cdn.example.com/lib.js"]:
        res = normalize_url(no_scheme)
        assert res.is_valid is False
        assert res.error_code == "MISSING_SCHEME"


def test_edge_case_invalid_ports():
    """Ports outside 1-65535 or non-numeric ports fail validation."""
    invalid_ports = [
        "http://example.com:0/",
        "http://example.com:65536/",
        "http://example.com:999999/",
        "http://example.com:-1/",
        "http://example.com:abc/",
    ]
    for url in invalid_ports:
        res = normalize_url(url)
        assert res.is_valid is False
        assert res.error_code == "INVALID_PORT"


def test_edge_case_excessively_long_url():
    """URLs exceeding 2048 characters are rejected."""
    long_url = "https://example.com/" + ("a" * 2050)
    res = normalize_url(long_url)
    assert res.is_valid is False
    assert res.error_code == "EXCEEDS_MAX_LENGTH"

    # Exactly 2048 characters succeeds
    base = "https://example.com/path?"
    exact_url = base + ("b" * (2048 - len(base)))
    assert len(exact_url) == 2048
    res_exact = normalize_url(exact_url)
    assert res_exact.is_valid is True


def test_edge_case_malformed_ipv6():
    """Unbalanced brackets or invalid IPv6 payloads are rejected."""
    malformed_ipv6 = [
        "http://[::1/path",
        "http://::1]/path",
        "http://[not-an-ip]/",
        "http://[2001:db8:::1]/",
    ]
    for url in malformed_ipv6:
        res = normalize_url(url)
        assert res.is_valid is False
        assert res.error_code in {"MALFORMED_IPV6", "INVALID_HOSTNAME", "MALFORMED_URL_STRUCTURE"}


def test_edge_case_invalid_percent_encoding():
    """Incomplete escape sequences or non-hex characters after '%' are rejected."""
    bad_encoding = [
        "https://example.com/test%",
        "https://example.com/test%2",
        "https://example.com/test%zz",
        "https://example.com/test%G1",
        "https://example.com/query?k=val%Q",
    ]
    for url in bad_encoding:
        res = normalize_url(url)
        assert res.is_valid is False
        assert res.error_code == "INVALID_PERCENT_ENCODING"


def test_edge_case_invalid_domain_labels():
    """Domain labels violating DNS syntax (leading/trailing hyphens, empty labels) fail."""
    bad_domains = [
        "http://-invalid.com/",
        "http://invalid-.com/",
        "http://example..com/",
        "http://..com/",
        "http://" + ("a" * 64) + ".com/",
    ]
    for url in bad_domains:
        res = normalize_url(url)
        assert res.is_valid is False
        assert res.error_code in {"INVALID_HOSTNAME", "IDNA_ENCODING_ERROR"}


def test_edge_case_raise_on_error_mode():
    """When raise_on_error=True, URLNormalizationError is raised instead of returning result."""
    with pytest.raises(URLNormalizationError) as exc_info:
        normalize_url("ftp://unsupported.com", raise_on_error=True)
    assert exc_info.value.error_code == "UNSUPPORTED_SCHEME"


# =============================================================================
# Category F: Passive Scanning Guarantee (Zero Socket & DNS Network Activity)
# =============================================================================

def test_passive_scanning_guarantee_offline_enforcement(monkeypatch):
    """Verify that URL normalization executes strictly offline with zero socket or network calls.

    Monkeypatches all Python socket, HTTP client, and DNS resolution functions to raise
    a fatal error if invoked.
    """
    def forbidden_network_activity(*args, **kwargs):
        raise RuntimeError("CRITICAL DEFENSE BREACH: URL normalizer attempted network or DNS operation!")

    # Guard socket operations
    monkeypatch.setattr(socket, "gethostbyname", forbidden_network_activity)
    monkeypatch.setattr(socket, "gethostbyname_ex", forbidden_network_activity)
    monkeypatch.setattr(socket, "getaddrinfo", forbidden_network_activity)
    monkeypatch.setattr(socket, "getfqdn", forbidden_network_activity)
    monkeypatch.setattr(socket, "create_connection", forbidden_network_activity)
    monkeypatch.setattr(socket.socket, "connect", forbidden_network_activity)

    # Guard HTTP client operations
    monkeypatch.setattr(urllib.request, "urlopen", forbidden_network_activity)
    monkeypatch.setattr(http.client.HTTPConnection, "connect", forbidden_network_activity)
    monkeypatch.setattr(http.client.HTTPSConnection, "connect", forbidden_network_activity)

    # Run comprehensive suite of normalization calls under strict offline lockdown
    test_cases = [
        "http://example.com/test",
        "https://192.168.1.1:8080/api?query=val#ref",
        "https://[2001:db8::1]:9443/login",
        "https://münchen.de/kultur",
        "http://sbi-netbanking.top:80/verify",
        "https://user:pass@internal-gateway.org/",
    ]

    for target in test_cases:
        result = normalize_url(target)
        assert result.is_valid is True
        assert result.canonical_url is not None


# =============================================================================
# Category G: Security Review Verifications (Requirements 1 - 9)
# =============================================================================

def test_security_review_req1_credentials_only_in_intended_forensic_field():
    """Requirement 1: Original URLs containing credentials are preserved ONLY in original_url."""
    raw = "https://victim:SecretPassword123@secure-bank.example.com/login"
    res = normalize_url(raw)
    assert res.is_valid is True

    # Preserved in the intended forensic field
    assert res.original_url == raw

    # Absolutely excluded from canonical URL and all other components
    assert res.canonical_url == "https://secure-bank.example.com/login"
    assert "SecretPassword123" not in res.canonical_url
    assert "victim" not in res.canonical_url

    assert res.components.netloc == "secure-bank.example.com"
    assert "SecretPassword123" not in res.components.netloc

    assert res.components.username == "victim"
    assert res.components.has_credentials is True

    # Check with special percent-encoded password
    raw_encoded = "https://admin:p%40ssw0rd%21@example.com/api"
    res_enc = normalize_url(raw_encoded)
    assert res_enc.original_url == raw_encoded
    assert res_enc.canonical_url == "https://example.com/api"
    assert "p%40ssw0rd%21" not in res_enc.canonical_url


def test_security_review_req2_credentials_never_in_ordinary_application_logs():
    """Requirement 2: Raw URLs with credentials never appear in ordinary logs or string conversions."""
    raw = "https://admin:SuperSecret999@portal.com/auth"
    res = normalize_url(raw)

    repr_str = repr(res)
    assert "SuperSecret999" not in repr_str

    str_str = str(res)
    assert "SuperSecret999" not in str_str

    comp_repr = repr(res.components)
    assert "SuperSecret999" not in comp_repr

    comp_str = str(res.components)
    assert "SuperSecret999" not in comp_str

    # safe_original_url masks the password
    assert "SuperSecret999" not in res.safe_original_url
    assert "admin:[MASKED]@" in res.safe_original_url


def test_security_review_req3_exception_messages_never_expose_passwords():
    """Requirement 3: Exception messages never expose embedded passwords under any failure condition."""
    secret = "TopSecretP@ssword123!"

    # 1. Invalid port
    res_port = normalize_url(f"https://admin:{secret}@example.com:notaport/test")
    assert res_port.is_valid is False
    assert secret not in str(res_port.error_message)

    # 2. Malformed host / internal whitespace
    res_space = normalize_url(f"https://admin:{secret}@invalid host.com/path")
    assert res_space.is_valid is False
    assert secret not in str(res_space.error_message)

    # 3. Invalid percent encoding
    res_pct = normalize_url(f"https://admin:{secret}@example.com/%zz")
    assert res_pct.is_valid is False
    assert secret not in str(res_pct.error_message)

    # 4. Raising exception with raise_on_error=True
    with pytest.raises(URLNormalizationError) as exc_info:
        normalize_url(f"https://admin:{secret}@example.com:notaport/test", raise_on_error=True)
    assert secret not in str(exc_info.value)
    assert secret not in exc_info.value.message


def test_security_review_req4_pydantic_serialization_safe_by_default():
    """Requirement 4: Pydantic model_dump, model_dump_json, and repr mask credentials by default."""
    secret = "TopSecretP@ssword99!"
    raw = f"https://analyst:{secret}@portal.example.com/auth"
    res = normalize_url(raw)

    # Default model_dump() masks credentials in original_url
    dump = res.model_dump()
    assert secret not in str(dump)
    assert dump["original_url"] == "https://analyst:[MASKED]@portal.example.com/auth"
    assert dump["canonical_url"] == "https://portal.example.com/auth"
    assert dump["components"]["netloc"] == "portal.example.com"
    assert dump["components"]["username"] == "analyst"

    # Default model_dump_json() masks credentials
    dump_json = res.model_dump_json()
    assert secret not in dump_json
    assert "[MASKED]" in dump_json

    # Explicit context allows authorized forensic pipelines to access raw unmasked original_url
    forensic_dump = res.model_dump(context={"include_sensitive": True})
    assert forensic_dump["original_url"] == raw


def test_security_review_req5_api_facing_representation_excludes_or_masks_userinfo():
    """Requirement 5: API-facing representations exclude credentials or mask sensitive userinfo."""
    # User-only in authority
    res_user = normalize_url("https://deployer@cloud.example.com/hook")
    assert res_user.canonical_url == "https://cloud.example.com/hook"
    assert res_user.components.username == "deployer"
    assert res_user.components.has_credentials is True
    assert res_user.components.netloc == "cloud.example.com"

    # Password-only in authority
    res_pw = normalize_url("http://:onlypass@cloud.example.com/status")
    assert res_pw.canonical_url == "http://cloud.example.com/status"
    assert res_pw.components.username is None
    assert res_pw.components.has_credentials is True
    assert res_pw.model_dump()["original_url"] == "http://:[MASKED]@cloud.example.com/status"


def test_security_review_req6_unicode_and_ascii_hostname_separately_available():
    """Requirement 6: Original Unicode hostname and ASCII/Punycode hostname remain separately available."""
    # 1. Telugu internationalized domain
    telugu_raw = "http://పరీక్ష.భారత్/దారి?విభాగం=1"
    res_telugu = normalize_url(telugu_raw)
    assert res_telugu.is_valid is True
    assert res_telugu.components.unicode_hostname == "పరీక్ష.భారత్"
    assert res_telugu.components.hostname == "పరీక్ష.భారత్"
    assert res_telugu.components.ascii_hostname.startswith("xn--")
    assert "xn--fpcrj9c3d" in res_telugu.components.ascii_hostname
    assert res_telugu.components.is_idn is True

    # 2. German umlaut domain
    german_raw = "https://München.DE/rathaus"
    res_german = normalize_url(german_raw)
    assert res_german.is_valid is True
    assert res_german.components.unicode_hostname == "münchen.de"
    assert res_german.components.ascii_hostname == "xn--mnchen-3ya.de"
    assert res_german.components.is_idn is True

    # 3. Standard ASCII domain
    ascii_raw = "https://example.com/path"
    res_ascii = normalize_url(ascii_raw)
    assert res_ascii.is_valid is True
    assert res_ascii.components.unicode_hostname == "example.com"
    assert res_ascii.components.ascii_hostname == "example.com"
    assert res_ascii.components.is_idn is False


def test_security_review_req7_trailing_dot_evidence_recoverable():
    """Requirement 7: Original trailing-dot hostname evidence remains recoverable when removed."""
    # URL with trailing dot in hostname
    raw_dot = "https://EXAMPLE.COM./index.html"
    res = normalize_url(raw_dot)
    assert res.is_valid is True

    # Canonical URL has trailing dot stripped
    assert res.canonical_url == "https://example.com/index.html"
    assert res.components.hostname == "example.com"
    assert res.components.ascii_hostname == "example.com"

    # Evidence of original trailing dot is fully preserved
    assert res.components.has_trailing_dot is True
    assert res.components.raw_hostname == "EXAMPLE.COM."

    # URL without trailing dot
    raw_no_dot = "https://example.com/index.html"
    res_no_dot = normalize_url(raw_no_dot)
    assert res_no_dot.components.has_trailing_dot is False
    assert res_no_dot.components.raw_hostname == "example.com"


def test_security_review_req8_percent_encoding_and_path_traversal_preserved():
    """Requirement 8: Percent-encoded reserved chars and path traversal evidence remain unchanged."""
    # Preserves encoded delimiters without decoding
    raw_delims = "https://site.com/a%2Fb?q=1%262#frag%3F"
    res_delims = normalize_url(raw_delims)
    assert res_delims.is_valid is True
    assert "%2F" in res_delims.canonical_url
    assert "%26" in res_delims.canonical_url
    assert "%3F" in res_delims.canonical_url

    # Preserves both encoded traversal (%2e%2e) and literal traversal (..)
    raw_traversal = "https://site.com/dir/%2e%2e/../windows/system32"
    res_traversal = normalize_url(raw_traversal)
    assert res_traversal.is_valid is True
    assert "%2e%2e" in res_traversal.canonical_url
    assert "../" in res_traversal.canonical_url
    assert res_traversal.canonical_url == "https://site.com/dir/%2e%2e/../windows/system32"


def test_security_review_req9_strict_offline_passive_scanning_zero_network(monkeypatch):
    """Requirement 9: Verification that no network operations are introduced."""
    call_log = []

    def trap_network(*args, **kwargs):
        call_log.append(args)
        raise RuntimeError("NETWORK OPERATION DETECTED IN PASSIVE ENGINE")

    # Patch socket
    monkeypatch.setattr(socket, "gethostbyname", trap_network)
    monkeypatch.setattr(socket, "getaddrinfo", trap_network)
    monkeypatch.setattr(socket, "getfqdn", trap_network)
    monkeypatch.setattr(socket.socket, "connect", trap_network)

    # Patch urllib and http
    monkeypatch.setattr(urllib.request, "urlopen", trap_network)
    monkeypatch.setattr(http.client.HTTPConnection, "connect", trap_network)
    monkeypatch.setattr(http.client.HTTPSConnection, "connect", trap_network)

    # Comprehensive targets: credentials, IDN, Punycode, IPv4, IPv6, trailing dot, traversal
    test_urls = [
        "https://admin:pass123@example.com./path/%2e%2e/test?q=val#sec",
        "http://పరీక్ష.భారత్/దారి",
        "https://[2001:db8::1]:8080/status",
        "http://192.168.1.1:80/setup",
        "https://user:p%40ss@xn--mnchen-3ya.de:443/tourismus",
    ]

    for u in test_urls:
        result = normalize_url(u)
        assert result.is_valid is True

    # Assert 0 network calls were attempted
    assert len(call_log) == 0


