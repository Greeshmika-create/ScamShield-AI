"""Focused tests for the unified passive analysis pipeline."""

import asyncio

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from app.api.v1.endpoints import analyze as analyze_endpoint
from app.core.dependencies import require_authenticated_user
from app.core.config import Settings
from app.main import create_application
from app.schemas.analyze import AnalyzeRequest
from app.schemas.auth import AuthenticatedPrincipal
from app.schemas.enums import (
    ConfidenceLevel,
    FindingSeverity,
    ProviderStatus,
    TargetType,
    Verdict,
)
from app.schemas.evidence import ThreatFinding
from app.schemas.ml_analysis import URLMLAnalysis
from app.schemas.threat_intelligence import ProviderReport
from app.services.scanners.ssrf_guard import SSRFGuard
from app.services.scanners.url_extractor import URLFeatureExtractor
from app.services.threat_intel.aggregator import ThreatIntelAggregator
from app.services.unified_analysis.evidence_combiner import EvidenceBundle, EvidenceCombiner
from app.services.unified_analysis.orchestrator import UnifiedAnalysisOrchestrator
from app.services.unified_analysis.risk_engine import RiskEngine


class StubClassifier:
    def __init__(self, analysis=None):
        self.analysis = analysis or URLMLAnalysis(
            prediction="BENIGN",
            threat_probability=0.05,
            evaluation_metadata={"status": "INFERRED"},
        )
        self.calls = 0

    def predict_from_features(self, features):
        self.calls += 1
        return self.analysis


class StubThreatIntel:
    def __init__(self, reports=None, error=None):
        self.reports = reports or [ProviderReport(
            provider_name="MockIntel",
            status=ProviderStatus.AVAILABLE_CLEAN,
        )]
        self.error = error
        self.targets = []

    async def inspect_url(self, target):
        self.targets.append(target)
        if self.error:
            raise self.error
        return self.reports


def test_url_analysis_integrates_existing_components_without_fetching_target():
    classifier = StubClassifier()
    intel = StubThreatIntel()
    orchestrator = UnifiedAnalysisOrchestrator(classifier=classifier, threat_intel=intel)

    response = asyncio.run(orchestrator.analyze(AnalyzeRequest(
        url="https://analyst:secret@example.com/login"
    )))

    assert response.target_type == TargetType.URL
    assert response.evidence_status["url_features"] == "AVAILABLE"
    assert response.evidence_status["url_ml"] == "INFERRED"
    assert intel.targets == ["https://example.com/login"]
    assert "secret" not in response.model_dump_json()
    assert classifier.calls == 1


def test_message_analysis_uses_existing_multilingual_analyzer():
    response = asyncio.run(UnifiedAnalysisOrchestrator().analyze(AnalyzeRequest(
        message_text="Your account is blocked, send your OTP immediately to verify."
    )))

    assert response.target_type == TargetType.MESSAGE
    assert response.evidence_status["message_nlp"] in {"ANALYZED", "NO_KNOWN_INDICATORS"}
    assert response.verdict != Verdict.UNVERIFIED
    assert response.findings


def test_evidence_combiner_maps_static_and_provider_findings():
    features = URLFeatureExtractor.extract("https://192.168.1.2/login")
    reports = [ProviderReport(provider_name="MockIntel", status=ProviderStatus.AVAILABLE_FLAGGED)]

    bundle = EvidenceCombiner.combine(
        url_features=features,
        ssrf_result=SSRFGuard.check_target("https://192.168.1.2/login"),
        ml_analysis=URLMLAnalysis(prediction="PHISHING", threat_probability=0.9,
                                  evaluation_metadata={"status": "INFERRED"}),
        provider_reports=reports,
    )

    categories = {finding.category.value for finding in bundle.findings}
    assert {"HEURISTIC", "ML", "INTEL"}.issubset(categories)
    assert bundle.evidence_status["intel:MockIntel"] == "AVAILABLE_FLAGGED"
    assert bundle.ssrf_blocked is True


@pytest.mark.parametrize(
    "score,expected_band,expected_verdict",
    [
        (24, "LOW", Verdict.NO_KNOWN_THREAT),
        (25, "MODERATE", Verdict.SUSPICIOUS),
        (49, "MODERATE", Verdict.SUSPICIOUS),
        (50, "HIGH", Verdict.SUSPICIOUS),
        (74, "HIGH", Verdict.SUSPICIOUS),
        (75, "CRITICAL", Verdict.MALICIOUS),
        (100, "CRITICAL", Verdict.MALICIOUS),
    ],
)
def test_risk_score_threshold_boundaries(score, expected_band, expected_verdict):
    bundle = EvidenceBundle(
        message_score=score,
        has_complete_local_analysis=True,
        evidence_status={"message_nlp": "ANALYZED"},
    )

    response = RiskEngine.score(bundle, TargetType.MESSAGE)

    assert response.risk_score == score
    assert response.risk_band.value == expected_band
    assert response.verdict == expected_verdict


def test_unavailable_ml_and_intel_do_not_become_clean():
    features = URLFeatureExtractor.extract("https://example.com/")
    bundle = EvidenceCombiner.combine(
        url_features=features,
        ml_analysis=URLMLAnalysis(evaluation_metadata={"status": "UNAVAILABLE"}),
        provider_reports=[ProviderReport(provider_name="MockIntel", status=ProviderStatus.AVAILABLE_CLEAN)],
    )

    response = RiskEngine.score(bundle, TargetType.URL)

    assert response.risk_score is None
    assert response.verdict == Verdict.UNVERIFIED
    assert response.confidence_level == ConfidenceLevel.PROVISIONAL


def test_unavailable_threat_intelligence_does_not_become_clean():
    features = URLFeatureExtractor.extract("https://example.com/")
    bundle = EvidenceCombiner.combine(
        url_features=features,
        ml_analysis=URLMLAnalysis(evaluation_metadata={"status": "INFERRED"}),
        provider_reports=[ProviderReport(provider_name="MockIntel", status=ProviderStatus.UNCONFIGURED)],
    )

    response = RiskEngine.score(bundle, TargetType.URL)

    assert response.risk_score is None
    assert response.verdict == Verdict.UNVERIFIED


def test_weak_url_heuristics_with_missing_providers_do_not_become_low():
    features = URLFeatureExtractor.extract("https://example.com/login")
    bundle = EvidenceCombiner.combine(url_features=features)

    response = RiskEngine.score(bundle, TargetType.URL)

    assert response.risk_score is None
    assert response.risk_band is None
    assert response.verdict == Verdict.UNVERIFIED


def test_threat_intel_timeout_is_preserved_and_incomplete():
    classifier = StubClassifier()
    intel = StubThreatIntel(error=TimeoutError())
    response = asyncio.run(UnifiedAnalysisOrchestrator(
        classifier=classifier, threat_intel=intel
    ).analyze(AnalyzeRequest(url="https://example.com/")))

    assert response.verdict == Verdict.UNVERIFIED
    assert response.evidence_status["intel:Threat intelligence aggregation"] == "TIMEOUT"


def test_ssrf_rejection_skips_threat_intel_lookup():
    intel = StubThreatIntel()
    response = asyncio.run(UnifiedAnalysisOrchestrator(
        classifier=StubClassifier(), threat_intel=intel
    ).analyze(AnalyzeRequest(url="http://127.0.0.1/admin")))

    assert response.verdict == Verdict.MALICIOUS
    assert response.risk_score == 100
    assert response.evidence_status["threat_intel"] == "SKIPPED_SSRF_REJECTED"
    assert intel.targets == []


@pytest.mark.parametrize(
    "payload",
    [
        {},
        {"url": "https://example.com", "message_text": "both target values"},
        {"url": "ftp://example.com"},
        {"message_text": "tiny"},
        {"message_text": "x" * 5001},
        {"url": 42},
    ],
)
def test_malformed_request_input_is_rejected(payload):
    with pytest.raises(ValidationError):
        AnalyzeRequest.model_validate(payload)


def test_provider_sensitive_metadata_is_redacted():
    report = ProviderReport(
        provider_name="MockIntel",
        status=ProviderStatus.ERROR,
        raw_evidence={"api_key": "secret-key", "url": "https://user:password@example.com"},
    )
    response = EvidenceCombiner.combine(provider_reports=[report])
    scored = RiskEngine.score(response, TargetType.URL)

    serialized = scored.model_dump_json()
    assert "secret-key" not in serialized
    assert "password" not in serialized
    assert "[REDACTED]" in serialized


def test_analysis_endpoint_requires_authentication():
    app = create_application(settings=Settings(ENVIRONMENT="test"))
    with TestClient(app) as client:
        response = client.post("/api/v1/analyze", json={"message_text": "Check account now"})
    assert response.status_code == 401
    assert response.json()["error_code"] == "UNAUTHORIZED"


def test_endpoint_invokes_orchestrator_after_authentication(monkeypatch):
    class FakeOrchestrator:
        async def analyze(self, request):
            assert request.target_type == TargetType.MESSAGE
            return RiskEngine.score(EvidenceBundle(
                message_score=30,
                has_complete_local_analysis=True,
                evidence_status={"message_nlp": "ANALYZED"},
            ), TargetType.MESSAGE)

    monkeypatch.setattr(analyze_endpoint, "UnifiedAnalysisOrchestrator", FakeOrchestrator)
    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.dependency_overrides[require_authenticated_user] = lambda: AuthenticatedPrincipal(user_id="test-user")
    with TestClient(app) as client:
        response = client.post("/api/v1/analyze", json={"message_text": "Check account now"})

    assert response.status_code == 200
    assert response.json()["risk_band"] == "MODERATE"


def test_endpoint_error_response_does_not_echo_input(monkeypatch):
    class BrokenOrchestrator:
        async def analyze(self, request):
            raise RuntimeError("credential=value")

    monkeypatch.setattr(analyze_endpoint, "UnifiedAnalysisOrchestrator", BrokenOrchestrator)
    app = create_application(settings=Settings(ENVIRONMENT="test"))
    app.dependency_overrides[require_authenticated_user] = lambda: AuthenticatedPrincipal(user_id="test-user")
    with TestClient(app) as client:
        response = client.post(
            "/api/v1/analyze",
            json={"message_text": "Message with a private OTP 123456"},
        )

    assert response.status_code == 500
    assert "credential=value" not in response.text
    assert "123456" not in response.text