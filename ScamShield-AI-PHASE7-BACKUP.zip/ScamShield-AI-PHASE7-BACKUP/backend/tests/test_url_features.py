"""Tests for Phase 4.2 URL Lexical and Structural Feature Extractor."""

import pytest
from app.schemas.ml_analysis import MLFeatureImpact
from app.services.scanners.url_extractor import (
    URL_FEATURE_NAMES,
    URLFeatureExtractor,
    URLFeatures,
)
from app.services.url_normalizer import normalize_url


class TestURLFeatureExtractorContract:
    """Verifies strict adherence to the 32-feature architectural contract."""

    def test_feature_name_count_and_types(self):
        assert len(URL_FEATURE_NAMES) == 32
        # Ensure no duplicates
        assert len(set(URL_FEATURE_NAMES)) == 32

    def test_extracted_features_dictionary_and_vector(self):
        url = "https://subdomain.example.com/login/verify?account=123&token=xyz"
        features = URLFeatureExtractor.extract(url)

        assert isinstance(features, URLFeatures)
        feature_dict = features.to_dict()
        assert len(feature_dict) == 32

        # Check all expected keys are present
        for name in URL_FEATURE_NAMES:
            assert name in feature_dict

        # Check vector conversion
        vector = features.to_vector()
        assert len(vector) == 32
        assert all(isinstance(v, (int, float)) for v in vector)


class TestURLFeatureExtractorLengthsAndFrequencies:
    """Tests length measurements and character frequency counters."""

    def test_exact_character_counts(self):
        url = "https://a.b.c.com/p_1-2/q?x=1&y=2@%20"
        features = URLFeatureExtractor.extract(url)

        # Dot count: a.b.c.com -> 3
        assert features.count_dot == 3
        # Hyphen count: p_1-2 -> 1
        assert features.count_hyphen == 1
        # Underscore count: p_1-2 -> 1
        assert features.count_underscore == 1
        # Question count: ? -> 1
        assert features.count_question == 1
        # Equal count: x=1&y=2 -> 2
        assert features.count_equal == 2
        # Ampersand count: & -> 1
        assert features.count_ampersand == 1
        # At symbol: @ -> 1
        assert features.count_at == 1
        # Percent count: %20 -> 1
        assert features.count_percent == 1

    def test_lengths(self):
        url = "https://example.com/test?param=value"
        features = URLFeatureExtractor.extract(url)

        assert features.hostname_length == len("example.com")
        assert features.path_length == len("/test")
        assert features.query_length == len("param=value")
        assert features.url_length == len(url)


class TestURLFeatureExtractorDomainHierarchyAndEntropy:
    """Tests domain depth, subdomains, and Shannon entropy for DGA detection."""

    def test_standard_domain(self):
        url = "https://example.com/"
        features = URLFeatureExtractor.extract(url)
        assert features.domain_depth == 2
        assert features.subdomain_count == 0

    def test_subdomains(self):
        url = "https://portal.secure.banking.example.com/"
        features = URLFeatureExtractor.extract(url)
        # portal, secure, banking, example, com -> depth 5
        assert features.domain_depth == 5
        # Subdomains = 5 - 2 = 3
        assert features.subdomain_count == 3

    def test_ip_address_domain_hierarchy(self):
        url = "http://192.168.1.1/dashboard"
        features = URLFeatureExtractor.extract(url)
        assert features.has_ip_address == 1.0
        assert features.subdomain_count == 0
        assert features.domain_depth == 1

    def test_shannon_entropy_comparison(self):
        # Repetitive / low entropy string
        low_entropy = URLFeatureExtractor.calculate_shannon_entropy("aaaaaa")
        assert low_entropy == 0.0

        # Standard dictionary word
        std_entropy = URLFeatureExtractor.calculate_shannon_entropy("google.com")
        assert 1.5 <= std_entropy <= 3.2

        # High entropy random DGA string
        dga_entropy = URLFeatureExtractor.calculate_shannon_entropy("xq7z8kw92jlmvb10")
        assert dga_entropy > 3.5


class TestURLFeatureExtractorSuspiciousKeywords:
    """Tests detection of sensitive financial and phishing keywords."""

    @pytest.mark.parametrize(
        "url,expected_flag",
        [
            ("https://example.com/login", "has_login_keyword"),
            ("https://signin.example.com/", "has_login_keyword"),
            ("https://example.com/verify-identity", "has_verify_keyword"),
            ("https://example.com/account/settings", "has_account_keyword"),
            ("https://example.com/sbi-netbanking", "has_banking_keyword"),
            ("https://example.com/update-kyc", "has_kyc_keyword"),
            ("https://example.com/upi-payment-refund", "has_upi_keyword"),
            ("https://example.com/customer-care-support", "has_support_keyword"),
        ],
    )
    def test_keyword_flags(self, url: str, expected_flag: str):
        features = URLFeatureExtractor.extract(url)
        feature_dict = features.to_dict()
        assert feature_dict[expected_flag] == 1.0
        assert features.suspicious_token_count >= 1

    def test_multiple_keywords_in_phishing_url(self):
        url = "https://sbi-banking-alert.xyz/verify-kyc?account=update&upi=refund"
        features = URLFeatureExtractor.extract(url)

        assert features.has_banking_keyword == 1.0
        assert features.has_verify_keyword == 1.0
        assert features.has_kyc_keyword == 1.0
        assert features.has_account_keyword == 1.0
        assert features.has_upi_keyword == 1.0
        assert features.suspicious_token_count >= 5


class TestURLFeatureExtractorStructuralFlags:
    """Tests structural flags: IP host, IDN Punycode, non-standard port."""

    def test_ip_address_flag(self):
        features_ip = URLFeatureExtractor.extract("http://93.184.216.34/path")
        assert features_ip.has_ip_address == 1.0

        features_domain = URLFeatureExtractor.extract("https://example.com/path")
        assert features_domain.has_ip_address == 0.0

    def test_punycode_flag(self):
        # IDN domain that normalizes to punycode
        features_idn = URLFeatureExtractor.extract("http://xn--bcher-kva.example/")
        assert features_idn.is_punycode == 1.0

        features_ascii = URLFeatureExtractor.extract("http://example.com/")
        assert features_ascii.is_punycode == 0.0

    def test_non_standard_port_flag(self):
        features_port = URLFeatureExtractor.extract("http://example.com:8080/test")
        assert features_port.has_non_standard_port == 1.0

        features_std = URLFeatureExtractor.extract("http://example.com/test")
        assert features_std.has_non_standard_port == 0.0


class TestURLFeatureExtractorLexicalRatios:
    """Tests digit counts, ratios, path depth, and query parameter parsing."""

    def test_digit_metrics(self):
        url = "https://example.com/item/1234567890"
        features = URLFeatureExtractor.extract(url)

        assert features.digit_count == 10
        assert features.digit_ratio > 0.0
        assert features.letter_count > 0

    def test_path_depth(self):
        url_root = "https://example.com/"
        assert URLFeatureExtractor.extract(url_root).path_depth == 0

        url_deep = "https://example.com/api/v1/auth/tokens/refresh/"
        assert URLFeatureExtractor.extract(url_deep).path_depth == 5

    def test_query_param_count(self):
        url_no_q = "https://example.com/search"
        assert URLFeatureExtractor.extract(url_no_q).query_param_count == 0

        url_params = "https://example.com/search?q=test&lang=te&page=2&sort=asc"
        assert URLFeatureExtractor.extract(url_params).query_param_count == 4


class TestURLFeatureExtractorInputModalityAndIntegration:
    """Tests extraction from different input modalities and schema compatibility."""

    def test_extract_from_normalized_components(self):
        norm = normalize_url("https://sbi.co.in.fake-bank.xyz:8443/login?user=123")
        assert norm.is_valid is True
        assert norm.components is not None

        features = URLFeatureExtractor.extract(norm.components)
        assert features.has_login_keyword == 1.0
        assert features.has_non_standard_port == 1.0
        assert features.subdomain_count >= 2

    def test_extract_from_normalization_result(self):
        norm = normalize_url("https://example.com/test")
        features = URLFeatureExtractor.extract(norm)
        assert features.url_length == len("https://example.com/test")

    def test_invalid_input_rejection(self):
        with pytest.raises(ValueError):
            URLFeatureExtractor.extract("not_a_valid_url")

    def test_ml_feature_impacts_generation(self):
        url = "http://192.168.1.1:8080/sbi/verify-kyc?account=123"
        features = URLFeatureExtractor.extract(url)

        impacts = URLFeatureExtractor.to_ml_feature_impacts(features, top_n=5)
        assert len(impacts) <= 5
        assert all(isinstance(imp, MLFeatureImpact) for imp in impacts)

        feature_names = [imp.feature for imp in impacts]
        assert "has_ip_address" in feature_names
        assert "has_non_standard_port" in feature_names
        assert "suspicious_token_count" in feature_names

