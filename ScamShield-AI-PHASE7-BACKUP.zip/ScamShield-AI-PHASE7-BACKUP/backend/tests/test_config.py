"""Tests for Pydantic configuration validation and environment parsing."""

import pytest
from pydantic import ValidationError
from app.core.config import Settings


def test_default_config_values():
    """Verify default configuration values."""
    settings = Settings()
    assert settings.PROJECT_NAME == "ScamShield AI"
    assert settings.VERSION == "1.0.0"
    assert settings.API_V1_PREFIX == "/api/v1"
    assert settings.PORT == 8000
    assert settings.HOST == "0.0.0.0"
    assert "http://localhost:5173" in settings.CORS_ORIGINS
    assert settings.RATE_LIMIT_PER_MINUTE == 30
    assert settings.INTEL_TIMEOUT_SECONDS == 2.5
    assert settings.TOTAL_SCAN_TIMEOUT_SECONDS == 6.0


def test_valid_environment_values():
    """Valid environment strings are normalized and accepted."""
    for env in ["development", "staging", "production", "test", "DEVELOPMENT", " Production "]:
        s = Settings(ENVIRONMENT=env)
        assert s.ENVIRONMENT in {"development", "staging", "production", "test"}


def test_invalid_environment_raises_validation_error():
    """Invalid environment values must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        Settings(ENVIRONMENT="invalid_env_name")
    assert "ENVIRONMENT must be one of" in str(exc_info.value)


def test_valid_log_levels():
    """Valid log levels are accepted and capitalized."""
    for level in ["debug", "info", "warning", "error", "critical"]:
        s = Settings(LOG_LEVEL=level)
        assert s.LOG_LEVEL == level.upper()


def test_invalid_log_level_raises_validation_error():
    """Invalid log level must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        Settings(LOG_LEVEL="VERBOSE")
    assert "LOG_LEVEL must be one of" in str(exc_info.value)


def test_invalid_port_raises_validation_error():
    """Port below 1024 or above 65535 must fail validation."""
    with pytest.raises(ValidationError):
        Settings(PORT=80)  # Restricted port < 1024
    with pytest.raises(ValidationError):
        Settings(PORT=70000)  # Exceeds max port 65535


def test_cors_origins_parsing_from_json_string():
    """CORS origins passed as JSON string are parsed into list of strings."""
    settings = Settings(CORS_ORIGINS='["http://localhost:3000", "http://example.com"]')
    assert settings.CORS_ORIGINS == ["http://localhost:3000", "http://example.com"]


def test_cors_origins_parsing_from_comma_separated_string():
    """CORS origins passed as comma-separated string are parsed into list."""
    settings = Settings(CORS_ORIGINS="http://localhost:3000, http://example.com")
    assert settings.CORS_ORIGINS == ["http://localhost:3000", "http://example.com"]

