-- ScamShield AI Phase 10: scan persistence and ownership
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS public.user_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    auth_user_id TEXT NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now())
);

CREATE TABLE IF NOT EXISTS public.scans (
    id UUID PRIMARY KEY,
    owner_user_id TEXT NOT NULL,
    target_type TEXT NOT NULL CHECK (target_type IN ('URL', 'MESSAGE')),
    target_preview TEXT NOT NULL,
    canonical_target TEXT,
    verdict TEXT NOT NULL CHECK (verdict IN ('MALICIOUS', 'SUSPICIOUS', 'NO_KNOWN_THREAT', 'UNVERIFIED')),
    risk_score INTEGER CHECK (risk_score BETWEEN 0 AND 100),
    risk_band TEXT CHECK (risk_band IN ('LOW', 'MODERATE', 'HIGH', 'CRITICAL')),
    confidence_level TEXT NOT NULL CHECK (confidence_level IN ('HIGH', 'MEDIUM', 'PROVISIONAL')),
    detected_language TEXT,
    execution_time_ms INTEGER NOT NULL CHECK (execution_time_ms >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now())
);

CREATE TABLE IF NOT EXISTS public.url_analysis_records (
    scan_id UUID PRIMARY KEY REFERENCES public.scans(id) ON DELETE CASCADE,
    canonical_url TEXT,
    target_domain TEXT,
    ml_status TEXT,
    ml_prediction TEXT,
    ml_threat_probability DOUBLE PRECISION,
    feature_count INTEGER CHECK (feature_count BETWEEN 0 AND 32)
);

CREATE TABLE IF NOT EXISTS public.message_analysis_records (
    scan_id UUID PRIMARY KEY REFERENCES public.scans(id) ON DELETE CASCADE,
    detected_language TEXT,
    mixed_script BOOLEAN NOT NULL DEFAULT false,
    nl_status TEXT,
    nl_threat_score INTEGER CHECK (nl_threat_score BETWEEN 0 AND 100)
);

CREATE TABLE IF NOT EXISTS public.threat_findings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scan_id UUID NOT NULL REFERENCES public.scans(id) ON DELETE CASCADE,
    category TEXT NOT NULL,
    rule_name TEXT NOT NULL,
    severity TEXT NOT NULL CHECK (severity IN ('INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    source TEXT,
    is_confirmed BOOLEAN NOT NULL DEFAULT false,
    raw_evidence JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS public.risk_assessments (
    scan_id UUID PRIMARY KEY REFERENCES public.scans(id) ON DELETE CASCADE,
    risk_score INTEGER CHECK (risk_score BETWEEN 0 AND 100),
    risk_band TEXT CHECK (risk_band IN ('LOW', 'MODERATE', 'HIGH', 'CRITICAL')),
    verdict TEXT NOT NULL,
    confidence_level TEXT NOT NULL,
    reasoning_summary TEXT,
    safety_disclaimer TEXT,
    evidence_status JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS public.provider_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scan_id UUID NOT NULL REFERENCES public.scans(id) ON DELETE CASCADE,
    provider_name TEXT NOT NULL,
    status TEXT NOT NULL,
    response_time_ms INTEGER NOT NULL DEFAULT 0 CHECK (response_time_ms >= 0),
    threat_details TEXT,
    error_category TEXT,
    check_timestamp TIMESTAMPTZ,
    raw_evidence JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS public.audit_events (
    id UUID PRIMARY KEY,
    owner_user_id TEXT,
    event_type TEXT NOT NULL,
    action TEXT NOT NULL,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    ip_address TEXT,
    request_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now())
);

CREATE INDEX IF NOT EXISTS idx_scans_owner_created ON public.scans(owner_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_scans_owner_verdict ON public.scans(owner_user_id, verdict);
CREATE INDEX IF NOT EXISTS idx_scans_owner_type ON public.scans(owner_user_id, target_type);
CREATE INDEX IF NOT EXISTS idx_findings_scan ON public.threat_findings(scan_id);
CREATE INDEX IF NOT EXISTS idx_provider_scan ON public.provider_reports(scan_id);
CREATE INDEX IF NOT EXISTS idx_audit_owner_created ON public.audit_events(owner_user_id, created_at DESC);

ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.url_analysis_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_analysis_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.threat_findings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.risk_assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.provider_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;
GRANT SELECT, INSERT, UPDATE ON public.user_profiles TO authenticated;
GRANT SELECT ON public.scans TO authenticated;

DROP POLICY IF EXISTS profiles_own_rows ON public.user_profiles;
CREATE POLICY profiles_own_rows ON public.user_profiles
    FOR ALL TO authenticated
    USING (auth_user_id = auth.uid()::text)
    WITH CHECK (auth_user_id = auth.uid()::text);

DROP POLICY IF EXISTS scans_own_rows ON public.scans;
CREATE POLICY scans_own_rows ON public.scans
    FOR ALL TO authenticated
    USING (owner_user_id = auth.uid()::text)
    WITH CHECK (owner_user_id = auth.uid()::text);

DROP POLICY IF EXISTS url_analysis_own_rows ON public.url_analysis_records;
CREATE POLICY url_analysis_own_rows ON public.url_analysis_records
    FOR ALL TO authenticated
    USING (EXISTS (SELECT 1 FROM public.scans s WHERE s.id = scan_id AND s.owner_user_id = auth.uid()::text))
    WITH CHECK (EXISTS (SELECT 1 FROM public.scans s WHERE s.id = scan_id AND s.owner_user_id = auth.uid()::text));

DROP POLICY IF EXISTS message_analysis_own_rows ON public.message_analysis_records;
CREATE POLICY message_analysis_own_rows ON public.message_analysis_records
    FOR ALL TO authenticated
    USING (EXISTS (SELECT 1 FROM public.scans s WHERE s.id = scan_id AND s.owner_user_id = auth.uid()::text))
    WITH CHECK (EXISTS (SELECT 1 FROM public.scans s WHERE s.id = scan_id AND s.owner_user_id = auth.uid()::text));

DROP POLICY IF EXISTS findings_own_rows ON public.threat_findings;
CREATE POLICY findings_own_rows ON public.threat_findings
    FOR ALL TO authenticated
    USING (EXISTS (SELECT 1 FROM public.scans s WHERE s.id = scan_id AND s.owner_user_id = auth.uid()::text))
    WITH CHECK (EXISTS (SELECT 1 FROM public.scans s WHERE s.id = scan_id AND s.owner_user_id = auth.uid()::text));

DROP POLICY IF EXISTS risk_own_rows ON public.risk_assessments;
CREATE POLICY risk_own_rows ON public.risk_assessments
    FOR ALL TO authenticated
    USING (EXISTS (SELECT 1 FROM public.scans s WHERE s.id = scan_id AND s.owner_user_id = auth.uid()::text))
    WITH CHECK (EXISTS (SELECT 1 FROM public.scans s WHERE s.id = scan_id AND s.owner_user_id = auth.uid()::text));

DROP POLICY IF EXISTS provider_own_rows ON public.provider_reports;
CREATE POLICY provider_own_rows ON public.provider_reports
    FOR ALL TO authenticated
    USING (EXISTS (SELECT 1 FROM public.scans s WHERE s.id = scan_id AND s.owner_user_id = auth.uid()::text))
    WITH CHECK (EXISTS (SELECT 1 FROM public.scans s WHERE s.id = scan_id AND s.owner_user_id = auth.uid()::text));

DROP POLICY IF EXISTS audit_own_rows ON public.audit_events;
CREATE POLICY audit_own_rows ON public.audit_events
    FOR ALL TO authenticated
    USING (owner_user_id = auth.uid()::text)
    WITH CHECK (owner_user_id = auth.uid()::text);
