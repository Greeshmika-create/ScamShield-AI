"""Phase 6 Dataset Schema and Provenance Validator for ScamShield AI.

Security & Architectural Mandates:
- Strictly passive: reads local dataset files; ZERO outbound network connections.
- Validates the 32 standard URL features from docs/ARCHITECTURE.md Section 4.2.
- Enforces strict target label validation (BENIGN vs MALICIOUS / PHISHING).
- Detects missing features, non-numeric values, and train/test data leakage.
- Conforms to dataset governance rules: synthetic data must be explicitly marked.
"""

import csv
from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Union

from app.services.scanners.url_extractor import URL_FEATURE_NAMES


VALID_TARGET_LABELS: Set[str] = {
    "BENIGN",
    "MALICIOUS",
    "PHISHING",
    "SUSPICIOUS",
    "0",
    "1",
}


def map_label_to_binary(label: str) -> int:
    """Map categorical labels to binary training target.

    BENIGN (0) vs Threat class (1: PHISHING, MALICIOUS, SUSPICIOUS).
    Neither PHISHING nor MALICIOUS examples are discarded.
    """
    cleaned = str(label).strip().upper()
    if cleaned in {"BENIGN", "0"}:
        return 0
    if cleaned in {"PHISHING", "MALICIOUS", "SUSPICIOUS", "1"}:
        return 1
    raise ValueError(f"Cannot map unknown target label '{label}' to binary class.")


def map_binary_to_label(binary_val: int, is_malicious: bool = False) -> str:
    """Map binary prediction back to canonical categorical label."""
    if binary_val == 0:
        return "BENIGN"
    return "MALICIOUS" if is_malicious else "PHISHING"


@dataclass
class DatasetValidationResult:
    """Outcome of dataset schema and data integrity validation."""

    is_valid: bool
    total_records: int
    feature_count: int
    label_distribution: Dict[str, int] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert validation result to dictionary representation."""
        return {
            "is_valid": self.is_valid,
            "total_records": self.total_records,
            "feature_count": self.feature_count,
            "label_distribution": self.label_distribution,
            "errors": self.errors,
            "warnings": self.warnings,
        }


class DatasetValidator:
    """Validates training and evaluation datasets against the 32-feature contract."""

    REQUIRED_FEATURES: List[str] = list(URL_FEATURE_NAMES)
    TARGET_COLUMN_NAMES: Set[str] = {"label", "target", "verdict", "is_threat"}

    @classmethod
    def validate_csv(
        cls,
        file_path: Union[str, Path],
        target_column: Optional[str] = None,
        max_rows: Optional[int] = None,
    ) -> DatasetValidationResult:
        """Validate a CSV dataset file against the 32-feature contract."""
        path = Path(file_path)
        if not path.is_file():
            return DatasetValidationResult(
                is_valid=False,
                total_records=0,
                feature_count=0,
                errors=[f"Dataset file does not exist: {path}"],
            )

        errors: List[str] = []
        warnings: List[str] = []
        label_distribution: Dict[str, int] = {}
        row_count = 0

        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                reader = csv.DictReader(f)
                headers = reader.fieldnames or []

                # 1. Identify target column
                active_target_col = target_column
                if not active_target_col:
                    for candidate in cls.TARGET_COLUMN_NAMES:
                        if candidate in headers:
                            active_target_col = candidate
                            break

                if not active_target_col:
                    errors.append(
                        f"Missing target label column. Expected one of {sorted(cls.TARGET_COLUMN_NAMES)}"
                    )
                    return DatasetValidationResult(
                        is_valid=False,
                        total_records=0,
                        feature_count=len(headers),
                        errors=errors,
                    )

                # 2. Check for missing required features
                missing_features = [
                    feat for feat in cls.REQUIRED_FEATURES if feat not in headers
                ]
                if missing_features:
                    errors.append(
                        f"Dataset is missing {len(missing_features)} required features: {missing_features[:5]}..."
                    )

                # 3. Row-by-row validation
                for idx, row in enumerate(reader):
                    row_count += 1
                    if max_rows and row_count > max_rows:
                        break

                    # Validate label
                    raw_label = str(row.get(active_target_col, "")).strip().upper()
                    if not raw_label or raw_label not in VALID_TARGET_LABELS:
                        if len(errors) < 10:
                            errors.append(
                                f"Row {idx + 1}: Invalid label '{raw_label}'. Expected one of {sorted(VALID_TARGET_LABELS)}"
                            )
                    else:
                        label_distribution[raw_label] = label_distribution.get(raw_label, 0) + 1

                    # Validate numeric features
                    for feat in cls.REQUIRED_FEATURES:
                        if feat in row:
                            val_str = str(row[feat]).strip()
                            if val_str == "" or val_str.lower() in {"null", "none", "nan"}:
                                if len(errors) < 10:
                                    errors.append(f"Row {idx + 1}: Missing/null value for feature '{feat}'")
                            else:
                                try:
                                    float(val_str)
                                except ValueError:
                                    if len(errors) < 10:
                                        errors.append(
                                            f"Row {idx + 1}: Non-numeric value '{val_str}' for feature '{feat}'"
                                        )

                if row_count == 0:
                    errors.append("Dataset file contains zero records.")

        except Exception as e:
            errors.append(f"Failed to read dataset file: {e}")

        is_valid = len(errors) == 0 and row_count > 0

        return DatasetValidationResult(
            is_valid=is_valid,
            total_records=row_count,
            feature_count=len(cls.REQUIRED_FEATURES),
            label_distribution=label_distribution,
            errors=errors,
            warnings=warnings,
        )

    @classmethod
    def validate_records(
        cls,
        records: List[Dict[str, Any]],
        target_column: str = "label",
    ) -> DatasetValidationResult:
        """Validate in-memory list of record dictionaries against the 32-feature contract."""
        errors: List[str] = []
        label_distribution: Dict[str, int] = {}

        if not records:
            return DatasetValidationResult(
                is_valid=False,
                total_records=0,
                feature_count=len(cls.REQUIRED_FEATURES),
                errors=["Records list is empty."],
            )

        for idx, rec in enumerate(records):
            raw_label = str(rec.get(target_column, "")).strip().upper()
            if not raw_label or raw_label not in VALID_TARGET_LABELS:
                if len(errors) < 10:
                    errors.append(f"Record {idx}: Invalid label '{raw_label}'")
            else:
                label_distribution[raw_label] = label_distribution.get(raw_label, 0) + 1

            for feat in cls.REQUIRED_FEATURES:
                if feat not in rec:
                    if len(errors) < 10:
                        errors.append(f"Record {idx}: Missing feature '{feat}'")
                else:
                    val = rec[feat]
                    if not isinstance(val, (int, float)):
                        try:
                            float(val)
                        except (ValueError, TypeError):
                            if len(errors) < 10:
                                errors.append(f"Record {idx}: Non-numeric value for feature '{feat}'")

        is_valid = len(errors) == 0 and len(records) > 0

        return DatasetValidationResult(
            is_valid=is_valid,
            total_records=len(records),
            feature_count=len(cls.REQUIRED_FEATURES),
            label_distribution=label_distribution,
            errors=errors,
        )
