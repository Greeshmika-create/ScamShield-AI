import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  validateUrlInput,
  validateMessageInput,
  countCodePoints,
  MAX_MESSAGE_LENGTH,
  MIN_MESSAGE_LENGTH,
} from './validation.ts';

describe('Scanner Validation & Unicode Integrity', () => {
  it('rejects empty and whitespace-only URL inputs', () => {
    assert.match(validateUrlInput('') || '', /cannot be empty/i);
    assert.match(validateUrlInput('   ') || '', /cannot be empty/i);
  });

  it('rejects non-HTTP/HTTPS protocols like ftp, file, or gopher', () => {
    assert.match(
      validateUrlInput('ftp://suspicious-files.com/trojan.exe') || '',
      /Only HTTP and HTTPS/i,
    );
    assert.match(
      validateUrlInput('file:///etc/passwd') || '',
      /Only HTTP and HTTPS/i,
    );
  });

  it('rejects URLs lacking protocol scheme', () => {
    assert.match(
      validateUrlInput('suspicious-bank-login.com') || '',
      /must begin with http:\/\/ or https:\/\//i,
    );
  });

  it('accepts valid RFC-compliant HTTP/HTTPS URLs', () => {
    assert.equal(validateUrlInput('https://sbi-online.example.com/login'), null);
    assert.equal(validateUrlInput('http://test-warning.org/index.html'), null);
  });

  it('rejects empty message inputs', () => {
    assert.match(validateMessageInput('') || '', /cannot be empty/i);
    assert.match(validateMessageInput('   \n  ') || '', /cannot be empty/i);
  });

  it(`rejects messages shorter than ${MIN_MESSAGE_LENGTH} characters`, () => {
    assert.match(
      validateMessageInput('Hey') || '',
      /too short for threat evaluation/i,
    );
    assert.match(
      validateMessageInput('1234') || '',
      /too short for threat evaluation/i,
    );
  });

  it('accepts valid messages within length bounds', () => {
    assert.equal(
      validateMessageInput('Mee electricity bill update cheyandi లేదంటే power cut'),
      null,
    );
  });

  it('correctly counts Unicode code points identically to Python 3 len(str)', () => {
    // 🚨 is 1 code point, but in standard JS str.length it is 2 UTF-16 code units
    const emojiStr = '🚨 Urgent: 🚨';
    assert.equal(countCodePoints(emojiStr), 11);
    assert.equal(emojiStr.length, 13); // Confirms JS length discrepancy avoided

    // Telugu characters
    const teluguStr = 'విద్యుత్ బిల్లు';
    assert.equal(countCodePoints(teluguStr), Array.from(teluguStr).length);
  });

  it(`rejects messages exceeding ${MAX_MESSAGE_LENGTH} characters`, () => {
    const longMsg = 'A'.repeat(MAX_MESSAGE_LENGTH + 1);
    assert.match(validateMessageInput(longMsg) || '', /exceeds maximum allowed length/i);
  });
});
