export const validateUrlInput = (input: string): string | null => {
  const trimmed = input.trim();
  if (!trimmed) {
    return 'URL target cannot be empty. Please enter a web address to inspect.';
  }

  // Reject unsupported protocols
  if (/^[a-zA-Z0-9+.-]+:\/\//.test(trimmed) && !/^https?:\/\//i.test(trimmed)) {
    return 'Only HTTP and HTTPS protocols are supported for threat inspection.';
  }

  // Check for scheme presence
  if (!/^https?:\/\//i.test(trimmed)) {
    return 'URL must begin with http:// or https:// (e.g., https://secure-login.example.com)';
  }

  try {
    const parsed = new URL(trimmed);
    if (!parsed.hostname || parsed.hostname.length < 2) {
      return 'The target must include a valid hostname or domain name.';
    }
  } catch {
    return 'Malformed URL structure. Please enter a valid RFC-compliant URL.';
  }

  return null;
};

export const MAX_MESSAGE_LENGTH = 5000;
export const MIN_MESSAGE_LENGTH = 5;

/**
 * Counts Unicode code points (characters) identically to Python 3's `len(str)`.
 * Standard JavaScript `str.length` counts UTF-16 code units, which overcounts emojis
 * and astral-plane characters (e.g. 🚨 counts as 2 in UTF-16 vs 1 Unicode code point in Python).
 * Using `Array.from(str).length` iterates by Unicode code points.
 */
export const countCodePoints = (str: string): number => {
  return Array.from(str).length;
};

export const validateMessageInput = (text: string): string | null => {
  const trimmed = text.trim();
  if (!trimmed) {
    return 'Message content cannot be empty. Please paste a SMS, email, or chat message to analyze.';
  }

  const codePointCount = countCodePoints(trimmed);

  if (codePointCount < MIN_MESSAGE_LENGTH) {
    return `Message is too short for threat evaluation (minimum ${MIN_MESSAGE_LENGTH} characters required).`;
  }

  if (codePointCount > MAX_MESSAGE_LENGTH) {
    return `Message exceeds maximum allowed length of ${MAX_MESSAGE_LENGTH.toLocaleString()} characters (current: ${codePointCount.toLocaleString()}).`;
  }

  return null;
};

