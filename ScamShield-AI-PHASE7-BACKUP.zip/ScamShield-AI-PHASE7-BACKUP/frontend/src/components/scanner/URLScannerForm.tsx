import React, { useState } from 'react';
import { Globe, ArrowRight, ShieldCheck } from 'lucide-react';
import { Button, Input } from '../common';
import { validateUrlInput } from './validation';

export interface URLScannerFormProps {
  isLoading: boolean;
  onSubmit: (url: string) => void;
  onClear: () => void;
}

export const URLScannerForm: React.FC<URLScannerFormProps> = ({
  isLoading,
  onSubmit,
  onClear,
}) => {
  const [url, setUrl] = useState('');
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const error = validateUrlInput(url);
    if (error) {
      setValidationError(error);
      return;
    }

    setValidationError(null);
    onSubmit(url.trim());
  };

  const handleClear = () => {
    setUrl('');
    setValidationError(null);
    onClear();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4" noValidate>
      <div>
        <Input
          label="Destination Target URL"
          placeholder="https://example.com/login-verification"
          value={url}
          onChange={(e) => {
            setUrl(e.target.value);
            if (validationError) {
              setValidationError(null);
            }
          }}
          disabled={isLoading}
          leftIcon={<Globe className="w-4 h-4" />}
          error={validationError || undefined}
          helperText="Target is inspected passively via lexical indicators and external reputation feeds (GSB, URLhaus, PhishTank)."
        />
      </div>

      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
        <div className="flex items-center gap-2 text-xs text-content-muted">
          <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>Passive analysis only — target server is never contacted directly.</span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Button
            type="button"
            variant="outline"
            size="md"
            onClick={handleClear}
            disabled={isLoading || (!url && !validationError)}
          >
            Clear
          </Button>

          <Button
            type="submit"
            variant="primary"
            size="md"
            isLoading={isLoading}
            rightIcon={<ArrowRight className="w-4 h-4" />}
          >
            Scan URL
          </Button>
        </div>
      </div>
    </form>
  );
};
