import React, { useState, useMemo } from 'react';
import { MessageSquare, ArrowRight, UserCheck, Languages } from 'lucide-react';
import { Button, Input, Textarea, Badge } from '../common';
import { validateMessageInput, countCodePoints, MAX_MESSAGE_LENGTH } from './validation';

export interface MessageScannerFormProps {
  isLoading: boolean;
  onSubmit: (messageText: string, senderIdentifier?: string) => void;
  onClear: () => void;
}

export const MessageScannerForm: React.FC<MessageScannerFormProps> = ({
  isLoading,
  onSubmit,
  onClear,
}) => {
  const [messageText, setMessageText] = useState('');
  const [senderIdentifier, setSenderIdentifier] = useState('');
  const [validationError, setValidationError] = useState<string | null>(null);

  // Informative script helper: identifies whether Telugu characters are present in input
  const detectedScript = useMemo(() => {
    if (!messageText.trim()) return null;
    const hasTeluguScript = /[\u0C00-\u0C7F]/.test(messageText);
    const hasLatinScript = /[a-zA-Z]/.test(messageText);

    if (hasTeluguScript && hasLatinScript) {
      return 'Bilingual (Telugu + Latin / Telugish)';
    }
    if (hasTeluguScript) {
      return 'Telugu Script (తెలుగు)';
    }
    if (hasLatinScript) {
      return 'English / Transliterated Telugish';
    }
    return 'Text Detected';
  }, [messageText]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const error = validateMessageInput(messageText);
    if (error) {
      setValidationError(error);
      return;
    }

    setValidationError(null);
    onSubmit(
      messageText.trim(),
      senderIdentifier.trim() ? senderIdentifier.trim() : undefined,
    );
  };

  const handleClear = () => {
    setMessageText('');
    setSenderIdentifier('');
    setValidationError(null);
    onClear();
  };

  const charCount = countCodePoints(messageText);
  const isOverLimit = charCount > MAX_MESSAGE_LENGTH;

  return (
    <form onSubmit={handleSubmit} className="space-y-4" noValidate>
      {/* Optional Sender Header Input */}
      <div>
        <Input
          label="Sender Identifier (Optional)"
          placeholder="e.g., AD-SBIINB, +919876543210, Electricity Board"
          value={senderIdentifier}
          onChange={(e) => setSenderIdentifier(e.target.value)}
          disabled={isLoading}
          leftIcon={<UserCheck className="w-4 h-4" />}
          helperText="Alphanumeric SMS header, phone number, or sender email address."
        />
      </div>

      {/* Multiline Message Textarea */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <label
            htmlFor="scam-message-input"
            className="text-xs font-medium text-content-secondary flex items-center gap-1.5"
          >
            <MessageSquare className="w-3.5 h-3.5 text-content-muted" />
            <span>Raw Message Content</span>
          </label>

          {/* Live Character Counter */}
          <div className="flex items-center gap-2">
            {detectedScript && (
              <Badge variant="neutral" size="sm">
                <Languages className="w-3 h-3 mr-1 inline" />
                {detectedScript}
              </Badge>
            )}
            <span
              className={`text-xs font-mono ${
                isOverLimit
                  ? 'text-status-danger font-semibold'
                  : charCount > 4000
                  ? 'text-status-warning'
                  : 'text-content-muted'
              }`}
            >
              {charCount.toLocaleString()} / {MAX_MESSAGE_LENGTH.toLocaleString()}
            </span>
          </div>
        </div>

        <Textarea
          id="scam-message-input"
          placeholder="Paste SMS, WhatsApp message, or email body in English, Telugu (తెలుగు), or Telugish (e.g., 'Mee electricity bill update cheyandi...')"
          value={messageText}
          onChange={(e) => {
            setMessageText(e.target.value);
            if (validationError) {
              setValidationError(null);
            }
          }}
          disabled={isLoading}
          rows={5}
          error={validationError || (isOverLimit ? 'Character limit exceeded' : undefined)}
          helperText="Telugu script, English, and transliterated Telugish are supported without character restrictions."
        />
      </div>

      {/* Actions & Submit Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
        <div className="text-xs text-content-muted flex items-center gap-1.5">
          <span>PII (OTPs, phone numbers, VPAs) is automatically masked during analysis.</span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Button
            type="button"
            variant="outline"
            size="md"
            onClick={handleClear}
            disabled={isLoading || (!messageText && !senderIdentifier && !validationError)}
          >
            Clear
          </Button>

          <Button
            type="submit"
            variant="primary"
            size="md"
            isLoading={isLoading}
            disabled={isOverLimit}
            rightIcon={<ArrowRight className="w-4 h-4" />}
          >
            Scan Message
          </Button>
        </div>
      </div>
    </form>
  );
};
