import React, { useState } from 'react';
import {
  Globe,
  MessageSquare,
  AlertTriangle,
  ServerOff,
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Badge } from '../common';
import { URLScannerForm } from './URLScannerForm';
import { MessageScannerForm } from './MessageScannerForm';
import { ForensicReport } from '../report';
import { scanUrl, scanMessage, getApiBaseUrl } from '../../api/scanService';
import {
  URLScanResponse,
  MessageScanResponse,
  ScanServiceError,
} from '../../types/scan';

export type ScannerMode = 'url' | 'message';

export const ScannerWorkspace: React.FC = () => {
  const [mode, setMode] = useState<ScannerMode>('url');
  const [isLoading, setIsLoading] = useState(false);
  const [scanError, setScanError] = useState<ScanServiceError | null>(null);

  // Real scan response states (strictly populated by real API responses, NEVER fabricated)
  const [urlResult, setUrlResult] = useState<URLScanResponse | null>(null);
  const [messageResult, setMessageResult] = useState<MessageScanResponse | null>(null);

  const apiBaseUrl = getApiBaseUrl();

  const handleScanUrl = async (targetUrl: string) => {
    setIsLoading(true);
    setScanError(null);
    setUrlResult(null);

    try {
      const response = await scanUrl({ url: targetUrl });
      setUrlResult(response);
    } catch (err: unknown) {
      if (err instanceof ScanServiceError) {
        setScanError(err);
      } else {
        setScanError(
          new ScanServiceError(
            err instanceof Error ? err.message : 'An unexpected error occurred during URL inspection.',
            'UNKNOWN_ERROR',
          ),
        );
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleScanMessage = async (text: string, sender?: string) => {
    setIsLoading(true);
    setScanError(null);
    setMessageResult(null);

    try {
      const response = await scanMessage({
        message_text: text,
        sender_identifier: sender,
      });
      setMessageResult(response);
    } catch (err: unknown) {
      if (err instanceof ScanServiceError) {
        setScanError(err);
      } else {
        setScanError(
          new ScanServiceError(
            err instanceof Error ? err.message : 'An unexpected error occurred during message inspection.',
            'UNKNOWN_ERROR',
          ),
        );
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearResults = () => {
    setScanError(null);
    setUrlResult(null);
    setMessageResult(null);
  };

  return (
    <div className="space-y-6">
      {/* Mode Switcher Segmented Control */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 border-b border-border-subtle pb-4">
        <div>
          <h1 className="text-xl font-bold text-content-primary tracking-tight">
            Threat Scanner Workspace
          </h1>
          <p className="text-xs text-content-muted mt-1">
            Choose an inspection channel to evaluate suspicious digital targets.
          </p>
        </div>

        {/* Accessible Segmented Mode Tabs */}
        <div
          role="tablist"
          aria-label="Scanner Modes"
          className="inline-flex p-1 rounded-lg bg-surface-elevated border border-border-subtle self-start sm:self-auto"
        >
          <button
            type="button"
            role="tab"
            id="tab-url-mode"
            aria-selected={mode === 'url'}
            aria-controls="panel-url-mode"
            onClick={() => {
              setMode('url');
              handleClearResults();
            }}
            className={`
              flex items-center gap-2 px-3.5 py-1.5 rounded-md text-xs font-medium transition-all duration-150
              focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand
              ${
                mode === 'url'
                  ? 'bg-surface-card text-content-primary shadow-subtle border border-border-default'
                  : 'text-content-secondary hover:text-content-primary'
              }
            `}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>URL Inspection</span>
          </button>

          <button
            type="button"
            role="tab"
            id="tab-message-mode"
            aria-selected={mode === 'message'}
            aria-controls="panel-message-mode"
            onClick={() => {
              setMode('message');
              handleClearResults();
            }}
            className={`
              flex items-center gap-2 px-3.5 py-1.5 rounded-md text-xs font-medium transition-all duration-150
              focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand
              ${
                mode === 'message'
                  ? 'bg-surface-card text-content-primary shadow-subtle border border-border-default'
                  : 'text-content-secondary hover:text-content-primary'
              }
            `}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Message Inspection</span>
          </button>
        </div>
      </div>

      {/* Main Scanner Input Form Card */}
      <Card variant="default">
        <CardHeader
          action={
            <Badge variant="neutral" size="sm">
              API: {mode === 'url' ? 'POST /scan/url' : 'POST /scan/message'}
            </Badge>
          }
        >
          <CardTitle>
            {mode === 'url' ? 'Web Destination & URL Scanner' : 'Multilingual Scam Message Scanner'}
          </CardTitle>
          <CardDescription>
            {mode === 'url'
              ? 'Extracts 32 structural/lexical features and queries global threat feeds without contacting the target host.'
              : 'Analyzes digital messages for urgency coercion, payment deception, and phishing patterns in English and Telugu.'}
          </CardDescription>
        </CardHeader>

        <CardContent>
          <div
            role="tabpanel"
            id={mode === 'url' ? 'panel-url-mode' : 'panel-message-mode'}
            aria-labelledby={mode === 'url' ? 'tab-url-mode' : 'tab-message-mode'}
          >
            {mode === 'url' ? (
              <URLScannerForm
                isLoading={isLoading}
                onSubmit={handleScanUrl}
                onClear={handleClearResults}
              />
            ) : (
              <MessageScannerForm
                isLoading={isLoading}
                onSubmit={handleScanMessage}
                onClear={handleClearResults}
              />
            )}
          </div>
        </CardContent>
      </Card>

      {/* Honest Error & Backend-Unavailable State Handling */}
      {scanError && (
        <Card variant="default" className="border-status-danger-border bg-status-danger-bg/20">
          <CardContent className="p-5">
            <div className="flex items-start gap-3">
              {scanError.errorCode === 'BACKEND_UNAVAILABLE' ? (
                <ServerOff className="w-5 h-5 text-status-warning shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-status-danger shrink-0 mt-0.5" />
              )}
              <div className="space-y-1.5 flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-semibold text-content-primary">
                    {scanError.errorCode === 'BACKEND_UNAVAILABLE'
                      ? 'Backend Inspection Service Unavailable'
                      : `Inspection Failed: ${scanError.errorCode}`}
                  </h3>
                  <Badge variant="danger" size="sm">
                    {scanError.status ? `HTTP ${scanError.status}` : 'Offline'}
                  </Badge>
                </div>

                <p className="text-xs text-content-secondary leading-relaxed">
                  {scanError.message}
                </p>

                {scanError.errorCode === 'BACKEND_UNAVAILABLE' && (
                  <div className="mt-2 p-3 rounded-md bg-surface-card border border-border-subtle text-xs space-y-1">
                    <p className="font-mono text-content-primary">
                      Configured Target: <span className="text-brand">{apiBaseUrl}</span>
                    </p>
                    <p className="text-content-muted">
                      In accordance with our strict engineering policy, ScamShield AI does not generate fake scan scores or mock threat findings when backend services are offline. Start the backend service in Phase 3 to execute live threat intelligence.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Real Forensic Report (Rendered strictly when real API response is received) */}
      {(urlResult || messageResult) && (
        <div className="pt-2">
          <ForensicReport
            urlReport={urlResult}
            messageReport={messageResult}
            onClearReport={handleClearResults}
          />
        </div>
      )}
    </div>
  );
};
