import React from 'react';
import { Search, ArrowUpDown } from 'lucide-react';
import { Verdict } from '../../types/scan';
import { Input } from '../common';

export type TargetTypeFilter = 'ALL' | 'URL' | 'MESSAGE';
export type VerdictFilter = 'ALL' | Verdict;
export type SortOrder = 'NEWEST' | 'OLDEST';

export interface HistoryFiltersProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  targetType: TargetTypeFilter;
  onTargetTypeChange: (type: TargetTypeFilter) => void;
  verdict: VerdictFilter;
  onVerdictChange: (verdict: VerdictFilter) => void;
  sortOrder: SortOrder;
  onSortOrderChange: (order: SortOrder) => void;
  disabled?: boolean;
}

export const HistoryFilters: React.FC<HistoryFiltersProps> = ({
  searchQuery,
  onSearchChange,
  targetType,
  onTargetTypeChange,
  verdict,
  onVerdictChange,
  sortOrder,
  onSortOrderChange,
  disabled = false,
}) => {
  return (
    <div className="p-4 rounded-xl border border-border-subtle bg-surface-card space-y-3">
      {/* Top Search Input */}
      <div>
        <Input
          placeholder="Search investigation audit trails by URL, keywords, or preview text..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          leftIcon={<Search className="w-4 h-4" />}
          disabled={disabled}
        />
      </div>

      {/* Filter Selectors Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          {/* Target Type Filter */}
          <div className="flex items-center gap-1.5 bg-surface-elevated p-1 rounded-lg border border-border-subtle">
            <span className="text-[10px] font-mono text-content-muted px-2 uppercase">Type:</span>
            {(['ALL', 'URL', 'MESSAGE'] as TargetTypeFilter[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => onTargetTypeChange(t)}
                disabled={disabled}
                className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                  targetType === t
                    ? 'bg-surface-card text-content-primary shadow-subtle border border-border-default'
                    : 'text-content-secondary hover:text-content-primary'
                }`}
              >
                {t === 'ALL' ? 'All' : t === 'URL' ? 'URLs' : 'Messages'}
              </button>
            ))}
          </div>

          {/* Verdict Filter */}
          <div className="flex items-center gap-1.5 bg-surface-elevated p-1 rounded-lg border border-border-subtle">
            <span className="text-[10px] font-mono text-content-muted px-2 uppercase">Verdict:</span>
            <select
              value={verdict}
              onChange={(e) => onVerdictChange(e.target.value as VerdictFilter)}
              disabled={disabled}
              className="bg-surface-card text-content-primary text-xs rounded border border-border-default px-2 py-1 outline-none focus:ring-1 focus:ring-brand"
            >
              <option value="ALL">All Verdicts</option>
              <option value="MALICIOUS">Malicious</option>
              <option value="SUSPICIOUS">Suspicious</option>
              <option value="NO_KNOWN_THREAT">No Known Threat</option>
              <option value="UNVERIFIED">Unverified</option>
            </select>
          </div>
        </div>

        {/* Date Sort Toggle */}
        <button
          type="button"
          onClick={() => onSortOrderChange(sortOrder === 'NEWEST' ? 'OLDEST' : 'NEWEST')}
          disabled={disabled}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border-default bg-surface-elevated text-content-secondary hover:text-content-primary text-xs font-mono transition-colors"
        >
          <ArrowUpDown className="w-3.5 h-3.5" />
          <span>Sort: {sortOrder === 'NEWEST' ? 'Newest First' : 'Oldest First'}</span>
        </button>
      </div>
    </div>
  );
};
