import React from 'react';
import { Globe, MessageSquare, ChevronRight, Calendar } from 'lucide-react';
import { HistoryItem, Verdict } from '../../types/scan';
import { Badge } from '../common';

export interface HistoryTableProps {
  items: HistoryItem[];
  onSelectItem: (item: HistoryItem) => void;
}

const renderVerdictBadge = (verdict: Verdict) => {
  switch (verdict) {
    case 'MALICIOUS':
      return <Badge variant="danger" size="sm" dot>{verdict}</Badge>;
    case 'SUSPICIOUS':
      return <Badge variant="warning" size="sm" dot>{verdict}</Badge>;
    case 'NO_KNOWN_THREAT':
      return <Badge variant="success" size="sm" dot>{verdict}</Badge>;
    case 'UNVERIFIED':
    default:
      return <Badge variant="info" size="sm" dot>{verdict}</Badge>;
  }
};

export const HistoryTable: React.FC<HistoryTableProps> = ({ items, onSelectItem }) => {
  return (
    <div className="overflow-x-auto rounded-xl border border-border-subtle bg-surface-card shadow-card">
      <table className="w-full text-xs text-left" aria-label="Investigation scan history">
        <thead className="bg-surface-subtle text-content-muted font-mono uppercase text-[10px] border-b border-border-subtle">
          <tr>
            <th scope="col" className="px-5 py-3 font-medium">Type</th>
            <th scope="col" className="px-4 py-3 font-medium">Target Preview</th>
            <th scope="col" className="px-4 py-3 font-medium">Verdict</th>
            <th scope="col" className="px-4 py-3 font-medium">Risk Score</th>
            <th scope="col" className="px-4 py-3 font-medium">Timestamp</th>
            <th scope="col" className="px-4 py-3 font-medium text-right">Details</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border-subtle">
          {items.map((item) => {
            const formattedDate = new Date(item.scanned_at).toLocaleString(undefined, {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            });

            return (
              <tr
                key={item.scan_id}
                onClick={() => onSelectItem(item)}
                className="hover:bg-surface-subtle/60 cursor-pointer transition-colors group"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    onSelectItem(item);
                  }
                }}
                aria-label={`View investigation details for ${item.target_preview}`}
              >
                {/* Type Icon */}
                <td className="px-5 py-3.5 whitespace-nowrap">
                  <div className="flex items-center gap-1.5 font-medium text-content-primary">
                    {item.target_type === 'URL' ? (
                      <Globe className="w-4 h-4 text-brand shrink-0" />
                    ) : (
                      <MessageSquare className="w-4 h-4 text-purple-400 shrink-0" />
                    )}
                    <span className="font-mono text-[11px]">{item.target_type}</span>
                  </div>
                </td>

                {/* Target Preview */}
                <td className="px-4 py-3.5 max-w-xs md:max-w-md truncate text-content-primary">
                  <span
                    className={`${item.target_type === 'URL' ? 'font-mono text-[11px]' : 'font-sans'}`}
                    title={item.target_preview}
                  >
                    {item.target_preview}
                  </span>
                </td>

                {/* Verdict Badge */}
                <td className="px-4 py-3.5 whitespace-nowrap">
                  {renderVerdictBadge(item.verdict)}
                </td>

                {/* Risk Score */}
                <td className="px-4 py-3.5 whitespace-nowrap font-mono font-bold">
                  <span
                    className={
                      item.risk_score >= 70
                        ? 'text-status-danger'
                        : item.risk_score >= 25
                        ? 'text-status-warning'
                        : 'text-status-success'
                    }
                  >
                    {item.risk_score}
                  </span>
                  <span className="text-content-muted font-normal text-[10px]"> / 100</span>
                </td>

                {/* Timestamp */}
                <td className="px-4 py-3.5 whitespace-nowrap font-mono text-[11px] text-content-muted">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {formattedDate}
                  </span>
                </td>

                {/* Inspect Action */}
                <td className="px-4 py-3.5 whitespace-nowrap text-right">
                  <span className="inline-flex items-center gap-1 text-content-muted group-hover:text-brand font-medium text-[11px] transition-colors">
                    <span>Inspect</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
