import React, { useEffect } from 'react';
import { X, Globe, MessageSquare, Calendar, Clock, Copy, Check, Shield } from 'lucide-react';
import { HistoryItem, Verdict } from '../../types/scan';
import { Button, Badge } from '../common';

export interface HistoryDetailModalProps {
  item: HistoryItem | null;
  onClose: () => void;
}

const renderVerdictBadge = (verdict: Verdict) => {
  switch (verdict) {
    case 'MALICIOUS':
      return <Badge variant="danger" dot>{verdict}</Badge>;
    case 'SUSPICIOUS':
      return <Badge variant="warning" dot>{verdict}</Badge>;
    case 'NO_KNOWN_THREAT':
      return <Badge variant="success" dot>{verdict}</Badge>;
    case 'UNVERIFIED':
    default:
      return <Badge variant="info" dot>{verdict}</Badge>;
  }
};

export const HistoryDetailModal: React.FC<HistoryDetailModalProps> = ({ item, onClose }) => {
  const [copied, setCopied] = React.useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    if (item) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [item, onClose]);

  if (!item) return null;

  const handleCopyId = () => {
    navigator.clipboard.writeText(item.scan_id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formattedDate = new Date(item.scanned_at).toLocaleString(undefined, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZoneName: 'short',
  });

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
    >
      <div className="w-full max-w-lg rounded-xl border border-border-default bg-surface-card shadow-2xl p-6 space-y-5 animate-fadeIn">
        {/* Modal Header */}
        <div className="flex items-start justify-between gap-4 border-b border-border-subtle pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-surface-elevated border border-border-subtle text-brand">
              {item.target_type === 'URL' ? <Globe className="w-5 h-5" /> : <MessageSquare className="w-5 h-5" />}
            </div>
            <div>
              <h3 id="modal-title" className="text-sm font-semibold text-content-primary">
                Audit Record Details
              </h3>
              <p className="text-[11px] font-mono text-content-muted">
                {item.target_type} Target Investigation
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-1.5 rounded-lg text-content-muted hover:text-content-primary hover:bg-surface-elevated"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="space-y-4 text-xs">
          {/* Target Preview Box */}
          <div className="space-y-1">
            <span className="text-[11px] font-mono text-content-muted uppercase">Target Content Preview</span>
            <div className="p-3 rounded-lg bg-surface-subtle border border-border-subtle font-mono text-content-primary break-all">
              {item.target_preview}
            </div>
          </div>

          {/* Verdict & Score Bar */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-lg bg-surface-subtle border border-border-subtle space-y-1">
              <span className="text-[10px] font-mono text-content-muted uppercase block">Authoritative Verdict</span>
              {renderVerdictBadge(item.verdict)}
            </div>

            <div className="p-3 rounded-lg bg-surface-subtle border border-border-subtle space-y-1">
              <span className="text-[10px] font-mono text-content-muted uppercase block">Risk Score</span>
              <span
                className={`text-lg font-bold font-mono ${
                  item.risk_score >= 70
                    ? 'text-status-danger'
                    : item.risk_score >= 25
                    ? 'text-status-warning'
                    : 'text-status-success'
                }`}
              >
                {item.risk_score} / 100
              </span>
            </div>
          </div>

          {/* Telemetry Details */}
          <div className="space-y-2 p-3 rounded-lg bg-surface-subtle border border-border-subtle text-[11px] font-mono">
            <div className="flex items-center justify-between">
              <span className="text-content-muted flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" /> Timestamp:
              </span>
              <span className="text-content-primary">{formattedDate}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-content-muted flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> Pipeline Latency:
              </span>
              <span className="text-content-primary">
                {typeof item.execution_time_ms === 'number' && !Number.isNaN(item.execution_time_ms)
                  ? `${item.execution_time_ms} ms`
                  : 'N/A'}
              </span>
            </div>

            <div className="flex items-center justify-between pt-1 border-t border-border-subtle">
              <span className="text-content-muted">UUID:</span>
              <div className="flex items-center gap-1.5">
                <span className="text-content-primary truncate max-w-[200px]" title={item.scan_id}>
                  {item.scan_id}
                </span>
                <button
                  type="button"
                  onClick={handleCopyId}
                  aria-label="Copy UUID"
                  className="p-1 rounded text-content-muted hover:text-content-primary"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                </button>
              </div>
            </div>
          </div>

          {/* Privacy Notice */}
          <div className="flex items-center gap-2 text-[10px] text-content-muted">
            <Shield className="w-3.5 h-3.5 text-brand shrink-0" />
            <span>Full message payloads are discarded after ephemeral vectorization to preserve PII confidentiality.</span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex justify-end pt-3 border-t border-border-subtle">
          <Button variant="secondary" size="sm" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>
    </div>
  );
};

