import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '../common';

export interface HistoryPaginationProps {
  totalCount: number;
  limit: number;
  offset: number;
  onOffsetChange: (newOffset: number) => void;
  disabled?: boolean;
}

export const HistoryPagination: React.FC<HistoryPaginationProps> = ({
  totalCount,
  limit,
  offset,
  onOffsetChange,
  disabled = false,
}) => {
  if (totalCount <= 0) return null;

  const startRecord = Math.min(offset + 1, totalCount);
  const endRecord = Math.min(offset + limit, totalCount);

  const hasPrevious = offset > 0;
  const hasNext = offset + limit < totalCount;

  return (
    <div className="flex flex-col sm:flex-row items-center justify-between gap-3 px-2 py-3 text-xs text-content-muted">
      <div>
        <span>
          Showing <strong className="text-content-primary">{startRecord}</strong>–
          <strong className="text-content-primary">{endRecord}</strong> of{' '}
          <strong className="text-content-primary">{totalCount}</strong> audit records
        </span>
      </div>

      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          disabled={!hasPrevious || disabled}
          onClick={() => onOffsetChange(Math.max(0, offset - limit))}
          leftIcon={<ChevronLeft className="w-3.5 h-3.5" />}
        >
          Previous
        </Button>

        <Button
          variant="outline"
          size="sm"
          disabled={!hasNext || disabled}
          onClick={() => onOffsetChange(offset + limit)}
          rightIcon={<ChevronRight className="w-3.5 h-3.5" />}
        >
          Next Page
        </Button>
      </div>
    </div>
  );
};

