import React from 'react';
import { Database, SearchX, ShieldCheck } from 'lucide-react';
import { Card, CardContent } from '../common';

export interface HistoryEmptyStateProps {
  isFiltered?: boolean;
  onClearFilters?: () => void;
}

export const HistoryEmptyState: React.FC<HistoryEmptyStateProps> = ({
  isFiltered = false,
  onClearFilters,
}) => {
  return (
    <Card variant="subtle" className="border-dashed">
      <CardContent className="py-12 px-6 flex flex-col items-center justify-center text-center space-y-3 max-w-md mx-auto">
        <div className="p-3.5 rounded-full bg-surface-elevated border border-border-default text-content-muted">
          {isFiltered ? <SearchX className="w-6 h-6" /> : <Database className="w-6 h-6" />}
        </div>

        <div className="space-y-1">
          <h3 className="text-sm font-semibold text-content-primary">
            {isFiltered
              ? 'No Matching Audit Records Found'
              : 'No Scan Records In Database'}
          </h3>
          <p className="text-xs text-content-muted leading-relaxed">
            {isFiltered
              ? 'No past investigations matched the specified search term, target type, or verdict filter. Try refining or resetting your filter criteria.'
              : 'Zero investigations have been executed. To maintain complete data integrity, ScamShield AI does not display simulated or fabricated scan records. When an inspection is conducted, its audit record will catalog here.'}
          </p>
        </div>

        {isFiltered && onClearFilters && (
          <button
            type="button"
            onClick={onClearFilters}
            className="text-xs font-medium text-brand hover:underline pt-2"
          >
            Reset Search Filters
          </button>
        )}

        <div className="pt-2 flex items-center gap-1.5 text-[11px] font-mono text-content-muted">
          <ShieldCheck className="w-3.5 h-3.5 text-brand" />
          <span>Strict zero-mock policy active</span>
        </div>
      </CardContent>
    </Card>
  );
};

