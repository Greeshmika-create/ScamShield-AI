import React, { useState, useRef, useEffect } from 'react';
import { ShieldCheck, ArrowLeft, AlertCircle, Info } from 'lucide-react';
import { AuthScreen } from '../../types/auth';
import { Button, Card, CardContent } from '../common';

export interface OTPVerificationFormProps {
  email: string;
  onNavigate: (screen: AuthScreen) => void;
  onOtpVerified: () => void;
}

export const OTPVerificationForm: React.FC<OTPVerificationFormProps> = ({
  email,
  onNavigate,
  onOtpVerified,
}) => {
  const [digits, setDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [error, setError] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [cooldown, setCooldown] = useState(60); // 60s initial cooldown
  const [resendNotice, setResendNotice] = useState<string | null>(null);

  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Cooldown timer
  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => {
      setCooldown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  // Focus the first input on mount
  useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  const handleChange = (index: number, value: string) => {
    setError(null);

    // Only allow single numeric character
    const sanitized = value.replace(/\D/g, '');
    const char = sanitized.slice(-1);

    const newDigits = [...digits];
    newDigits[index] = char;
    setDigits(newDigits);

    // Auto-advance to next input
    if (char && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (!digits[index] && index > 0) {
        // Move to previous input on backspace if current is empty
        inputRefs.current[index - 1]?.focus();
      }
    } else if (e.key === 'ArrowLeft' && index > 0) {
      inputRefs.current[index - 1]?.focus();
    } else if (e.key === 'ArrowRight' && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pasteData = e.clipboardData.getData('text').replace(/\D/g, '');
    if (!pasteData) return;

    const newDigits = [...digits];
    for (let i = 0; i < 6; i++) {
      if (pasteData[i]) {
        newDigits[i] = pasteData[i]!;
      }
    }
    setDigits(newDigits);

    // Focus last filled index or the 6th
    const targetIndex = Math.min(pasteData.length, 5);
    inputRefs.current[targetIndex]?.focus();
  };

  const fullOtp = digits.join('');
  const isComplete = fullOtp.length === 6;

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (fullOtp.length !== 6) {
      setError('Please enter all 6 digits of the verification code.');
      return;
    }

    setIsVerifying(true);

    setTimeout(() => {
      setIsVerifying(false);
      // In Phase 2.7 client validation, allow proceeding to reset password
      onOtpVerified();
      onNavigate('reset-password');
    }, 600);
  };

  const handleResend = () => {
    if (cooldown > 0) return;
    setCooldown(60);
    setResendNotice('UI Preview: Resend action simulated. Live email delivery will be handled by Supabase in Phase 3.');
  };

  const handleSimulateInvalid = () => {
    setError('Invalid verification code. Please check your code or request a new one.');
  };

  return (
    <Card variant="default">
      <CardContent className="space-y-5">
        {/* UI Preview Notice */}
        <div className="p-3 rounded-lg bg-surface-subtle border border-border-default text-xs flex items-start gap-2.5 text-content-secondary">
          <Info className="w-4 h-4 text-brand shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <span className="font-medium text-content-primary">UI Preview Mode</span>
            <p className="text-[11px] text-content-muted leading-relaxed">
              This is an interactive UI preview. No live verification code was sent, and completing this form does not authenticate identity. Live OTP services connect via Supabase in Phase 3.
            </p>
          </div>
        </div>

        {/* Email Context */}
        <div className="text-center space-y-1">
          <p className="text-xs text-content-muted">
            Simulated Code Delivery Target (UI Preview):
          </p>
          <p className="text-xs font-mono font-medium text-content-primary px-2.5 py-1 rounded bg-surface-subtle inline-block border border-border-subtle">
            {email || 'analyst@scamshield.ai'}
          </p>
          <div>
            <button
              type="button"
              onClick={() => onNavigate('forgot-password')}
              className="text-[11px] text-brand hover:underline mt-0.5"
            >
              Change email address
            </button>
          </div>
        </div>

        {/* Status notice */}
        {resendNotice && (
          <div
            role="status"
            className="p-2.5 rounded-lg bg-surface-subtle border border-border-default text-xs flex items-center gap-2 text-content-secondary"
          >
            <Info className="w-3.5 h-3.5 text-brand shrink-0" />
            <span className="text-[11px] text-content-muted">{resendNotice}</span>
          </div>
        )}

        {/* Error display */}
        {error && (
          <div
            role="alert"
            className="p-3 rounded-lg bg-status-danger-bg border border-status-danger-border text-xs flex items-center gap-2 text-status-danger"
          >
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* 6-Digit OTP Form */}
        <form onSubmit={handleVerify} className="space-y-4">
          <div className="flex justify-between gap-2 max-w-xs mx-auto">
            {digits.map((digit, index) => (
              <input
                key={index}
                ref={(el) => {
                  inputRefs.current[index] = el;
                }}
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={1}
                value={digit}
                onChange={(e) => handleChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                onPaste={handlePaste}
                aria-label={`Digit ${index + 1} of 6`}
                className={`
                  w-11 h-13 text-center text-lg font-mono font-bold rounded-lg transition-colors
                  bg-surface-input text-content-primary border
                  focus:outline-none focus:ring-2 focus:ring-brand focus:border-brand
                  ${
                    error
                      ? 'border-status-danger focus:ring-status-danger'
                      : digit
                      ? 'border-brand/60 bg-surface-elevated'
                      : 'border-border-default'
                  }
                `}
              />
            ))}
          </div>

          <Button
            type="submit"
            variant="primary"
            size="md"
            className="w-full mt-2"
            isLoading={isVerifying}
            disabled={!isComplete}
            leftIcon={<ShieldCheck className="w-4 h-4" />}
          >
            Validate Code Format (UI Preview)
          </Button>
        </form>

        {/* Resend Action & Dev-Only Test Triggers */}
        <div className="space-y-2 pt-2 border-t border-border-subtle text-center">
          <div className="text-xs text-content-muted">
            <span>Didn&apos;t receive the code? </span>
            <button
              type="button"
              disabled={cooldown > 0}
              onClick={handleResend}
              className={`font-medium focus:outline-none ${
                cooldown > 0
                  ? 'text-content-muted cursor-not-allowed'
                  : 'text-brand hover:underline'
              }`}
            >
              {cooldown > 0 ? `Resend in ${cooldown}s` : 'Resend code'}
            </button>
          </div>

          {/* Development-only testing environment helper (hidden in production) */}
          {import.meta.env.DEV && (
            <div className="flex justify-center gap-3 pt-1 text-[11px] text-content-muted">
              <button
                type="button"
                onClick={handleSimulateInvalid}
                className="text-[10px] text-content-muted hover:text-status-danger transition-colors underline"
              >
                [Dev Only] Preview Error State
              </button>
            </div>
          )}
        </div>

        {/* Return to Sign In */}
        <div className="pt-2 text-center text-xs">
          <button
            type="button"
            onClick={() => onNavigate('login')}
            className="inline-flex items-center gap-1.5 font-medium text-content-secondary hover:text-content-primary focus:outline-none"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Sign In</span>
          </button>
        </div>
      </CardContent>
    </Card>
  );
};
