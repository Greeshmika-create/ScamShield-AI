import React, { useState, useMemo } from 'react';
import { Lock, Eye, EyeOff, Check, X, CheckCircle2, ArrowRight, Info } from 'lucide-react';
import { AuthScreen, ResetPasswordFormData } from '../../types/auth';
import { Button, Input, Card, CardContent } from '../common';
import { evaluatePasswordStrength } from './validation';

export interface ResetPasswordFormProps {
  onNavigate: (screen: AuthScreen) => void;
}

export const ResetPasswordForm: React.FC<ResetPasswordFormProps> = ({ onNavigate }) => {
  const [formData, setFormData] = useState<ResetPasswordFormData>({
    newPassword: '',
    confirmPassword: '',
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState<{ newPassword?: string; confirmPassword?: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const passwordStrength = useMemo(
    () => evaluatePasswordStrength(formData.newPassword),
    [formData.newPassword],
  );

  const passwordsMatch =
    formData.confirmPassword.length > 0 && formData.newPassword === formData.confirmPassword;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const newErrors: { newPassword?: string; confirmPassword?: string } = {};

    if (!formData.newPassword) {
      newErrors.newPassword = 'New password is required.';
    } else if (!passwordStrength.isValid) {
      newErrors.newPassword = 'Password does not meet the minimum security criteria.';
    }

    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Confirm your new password.';
    } else if (formData.newPassword !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match.';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 600);
  };

  const getStrengthBarColor = (index: number) => {
    if (passwordStrength.score < index + 1) return 'bg-surface-elevated';
    switch (passwordStrength.score) {
      case 1:
        return 'bg-status-danger';
      case 2:
        return 'bg-status-warning';
      case 3:
        return 'bg-brand';
      case 4:
        return 'bg-status-success';
      default:
        return 'bg-surface-elevated';
    }
  };

  if (isSuccess) {
    return (
      <Card variant="default">
        <CardContent className="space-y-5 text-center py-8">
          <div className="w-12 h-12 rounded-full bg-surface-elevated border border-border-default text-brand flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h2 className="text-base font-semibold text-content-primary">
              Password Reset Workflow (UI Preview)
            </h2>
            <p className="text-xs text-content-muted max-w-sm mx-auto leading-relaxed">
              Client-side password validation succeeded. This confirms the form interface and security rules. <strong>No live account password was changed.</strong> Production password management will be handled by Supabase in Phase 3.
            </p>
          </div>
          <Button
            type="button"
            variant="primary"
            size="md"
            className="w-full"
            rightIcon={<ArrowRight className="w-4 h-4" />}
            onClick={() => onNavigate('login')}
          >
            Return to Sign In
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card variant="default">
      <CardContent className="space-y-4">
        {/* UI Preview Notice */}
        <div className="p-3 rounded-lg bg-surface-subtle border border-border-default text-xs flex items-start gap-2.5 text-content-secondary">
          <Info className="w-4 h-4 text-brand shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <span className="font-medium text-content-primary">UI Preview Mode</span>
            <p className="text-[11px] text-content-muted leading-relaxed">
              This form previews password validation criteria. Submitting will not modify any live user credentials. Real updates connect with Supabase in Phase 3.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5" noValidate>
          {/* New Password */}
          <div>
            <Input
              label="New Password"
              type={showPassword ? 'text' : 'password'}
              placeholder="••••••••••••"
              value={formData.newPassword}
              onChange={(e) => {
                setFormData((prev) => ({ ...prev, newPassword: e.target.value }));
                if (errors.newPassword) setErrors((prev) => ({ ...prev, newPassword: undefined }));
              }}
              error={errors.newPassword}
              leftIcon={<Lock className="w-4 h-4" />}
              rightIcon={
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  className="p-1 text-content-muted hover:text-content-primary transition-colors focus:outline-none"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              }
              autoComplete="new-password"
              required
            />

            {/* Strength meter */}
            {formData.newPassword.length > 0 && (
              <div className="mt-2 space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-content-muted">Security Strength:</span>
                  <span className="font-medium text-content-primary">
                    {passwordStrength.feedback}
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-1.5 h-1.5">
                  <div className={`rounded-full transition-colors ${getStrengthBarColor(0)}`} />
                  <div className={`rounded-full transition-colors ${getStrengthBarColor(1)}`} />
                  <div className={`rounded-full transition-colors ${getStrengthBarColor(2)}`} />
                  <div className={`rounded-full transition-colors ${getStrengthBarColor(3)}`} />
                </div>

                <div className="grid grid-cols-2 gap-1.5 pt-1 text-[11px] text-content-muted">
                  <div className="flex items-center gap-1.5">
                    {passwordStrength.hasMinLength ? (
                      <Check className="w-3.5 h-3.5 text-status-success" />
                    ) : (
                      <X className="w-3.5 h-3.5 text-content-muted" />
                    )}
                    <span>8+ characters</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {passwordStrength.hasUpperCase && passwordStrength.hasLowerCase ? (
                      <Check className="w-3.5 h-3.5 text-status-success" />
                    ) : (
                      <X className="w-3.5 h-3.5 text-content-muted" />
                    )}
                    <span>Upper & lowercase</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {passwordStrength.hasNumber ? (
                      <Check className="w-3.5 h-3.5 text-status-success" />
                    ) : (
                      <X className="w-3.5 h-3.5 text-content-muted" />
                    )}
                    <span>At least 1 number</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {passwordStrength.hasSpecialChar ? (
                      <Check className="w-3.5 h-3.5 text-status-success" />
                    ) : (
                      <X className="w-3.5 h-3.5 text-content-muted" />
                    )}
                    <span>Special character</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Confirm New Password */}
          <div>
            <Input
              label="Confirm New Password"
              type={showConfirmPassword ? 'text' : 'password'}
              placeholder="••••••••••••"
              value={formData.confirmPassword}
              onChange={(e) => {
                setFormData((prev) => ({ ...prev, confirmPassword: e.target.value }));
                if (errors.confirmPassword) setErrors((prev) => ({ ...prev, confirmPassword: undefined }));
              }}
              error={errors.confirmPassword}
              leftIcon={<Lock className="w-4 h-4" />}
              rightIcon={
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword((prev) => !prev)}
                  className="p-1 text-content-muted hover:text-content-primary transition-colors focus:outline-none"
                  aria-label={showConfirmPassword ? 'Hide password' : 'Show password'}
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              }
              autoComplete="new-password"
              required
            />
            {formData.confirmPassword.length > 0 && (
              <p
                className={`text-[11px] mt-1 flex items-center gap-1 ${
                  passwordsMatch ? 'text-status-success' : 'text-status-danger'
                }`}
              >
                {passwordsMatch ? (
                  <>
                    <Check className="w-3.5 h-3.5" /> Passwords match
                  </>
                ) : (
                  <>
                    <X className="w-3.5 h-3.5" /> Passwords do not match
                  </>
                )}
              </p>
            )}
          </div>

          <Button
            type="submit"
            variant="primary"
            size="md"
            className="w-full mt-2"
            isLoading={isSubmitting}
          >
            Validate New Password (UI Preview)
          </Button>
        </form>

        <div className="pt-2 text-center text-xs text-content-muted border-t border-border-subtle">
          <button
            type="button"
            onClick={() => onNavigate('login')}
            className="font-medium text-content-secondary hover:text-content-primary focus:outline-none"
          >
            Cancel and Return to Sign In
          </button>
        </div>
      </CardContent>
    </Card>
  );
};

