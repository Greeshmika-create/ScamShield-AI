import React, { useState } from 'react';
import { Mail, Lock, Eye, EyeOff, Info } from 'lucide-react';
import { AuthScreen, LoginFormData } from '../../types/auth';
import { Button, Input, Card, CardContent, Divider } from '../common';
import { isValidEmail } from './validation';
import { demoLogin } from '../../api/authService';
import { setAccessToken } from '../../api/authSession.ts';

export interface LoginFormProps {
  onNavigate: (screen: AuthScreen) => void;
  onAuthenticated: () => void;
  onSuccessNotice?: (message: string) => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ onNavigate, onAuthenticated }) => {
  const [formData, setFormData] = useState<LoginFormData>({
    email: '',
    password: '',
    rememberMe: false,
  });

  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitNotice, setSubmitNotice] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitNotice(null);

    // Client-side validation
    const newErrors: { email?: string; password?: string } = {};

    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!isValidEmail(formData.email)) {
      newErrors.email = 'Please enter a valid email address format.';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required.';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setIsSubmitting(true);

    try {
      const session = await demoLogin();
      setAccessToken(session.access_token);
      setSubmitNotice('Local demo authentication succeeded. Opening the secured workspace.');
      onAuthenticated();
    } catch (error) {
      setSubmitNotice(error instanceof Error ? error.message : 'Demo authentication failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleSignIn = () => {
    setSubmitNotice(
      'UI Preview: Google OAuth SSO is not active. Real OAuth configuration will be established with Supabase in Phase 3.'
    );
  };

  return (
    <Card variant="default">
      <CardContent className="space-y-5">
        {/* Honest Backend Status Notice */}
        {submitNotice && (
          <div
            role="status"
            className="p-3 rounded-lg bg-surface-subtle border border-border-default text-xs flex items-start gap-2.5 text-content-secondary"
          >
            <Info className="w-4 h-4 text-brand shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <span className="font-medium text-content-primary">UI Preview — Authentication Notice</span>
              <p className="text-[11px] text-content-muted">{submitNotice}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          {/* Email Field */}
          <Input
            label="Analyst Email"
            type="email"
            placeholder="analyst@scamshield.ai"
            value={formData.email}
            onChange={(e) => {
              setFormData((prev) => ({ ...prev, email: e.target.value }));
              if (errors.email) setErrors((prev) => ({ ...prev, email: undefined }));
            }}
            error={errors.email}
            leftIcon={<Mail className="w-4 h-4" />}
            autoComplete="email"
            required
          />

          {/* Password Field */}
          <div>
            <Input
              label="Password"
              type={showPassword ? 'text' : 'password'}
              placeholder="••••••••••••"
              value={formData.password}
              onChange={(e) => {
                setFormData((prev) => ({ ...prev, password: e.target.value }));
                if (errors.password) setErrors((prev) => ({ ...prev, password: undefined }));
              }}
              error={errors.password}
              leftIcon={<Lock className="w-4 h-4" />}
              rightIcon={
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  className="p-1 text-content-muted hover:text-content-primary transition-colors focus:outline-none"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              }
              autoComplete="current-password"
              required
            />
            {/* Remember Me & Forgot Password Row */}
            <div className="flex items-center justify-between mt-2 pt-1">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={formData.rememberMe}
                  onChange={(e) => setFormData((prev) => ({ ...prev, rememberMe: e.target.checked }))}
                  className="rounded border-border-default text-brand focus:ring-brand focus:ring-offset-0 bg-surface-input"
                />
                <span className="text-xs text-content-muted hover:text-content-secondary">
                  Remember this device
                </span>
              </label>

              <button
                type="button"
                onClick={() => onNavigate('forgot-password')}
                className="text-xs font-medium text-brand hover:text-brand-hover focus:outline-none focus:underline"
              >
                Forgot password?
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            variant="primary"
            size="md"
            className="w-full mt-2"
            isLoading={isSubmitting}
          >
            Sign In to Platform
          </Button>
        </form>

        {/* Divider */}
        <Divider label="OR CONTINUE WITH" />

        {/* Google SSO Button */}
        <Button
          type="button"
          variant="secondary"
          size="md"
          className="w-full flex items-center justify-center gap-2 text-content-secondary hover:text-content-primary"
          onClick={handleGoogleSignIn}
        >
          {/* SVG Google Identity Icon */}
          <svg className="w-4 h-4" viewBox="0 0 24 24" aria-hidden="true">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span>Continue with Google</span>
        </Button>

        {/* Registration Navigation */}
        <div className="pt-2 text-center text-xs text-content-muted">
          <span>Don&apos;t have an analyst account? </span>
          <button
            type="button"
            onClick={() => onNavigate('register')}
            className="font-medium text-brand hover:text-brand-hover focus:outline-none focus:underline"
          >
            Create account
          </button>
        </div>
      </CardContent>
    </Card>
  );
};
