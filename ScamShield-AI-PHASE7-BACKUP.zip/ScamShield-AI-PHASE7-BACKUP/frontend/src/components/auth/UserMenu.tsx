import React, { useState, useEffect } from 'react';
import { User, LogIn, Shield, LogOut, X, Info, Crown, UserCheck } from 'lucide-react';
import { UserRole } from '../../types/auth';
import { Button, Badge } from '../common';

export interface UserMenuProps {
  onOpenAuth: () => void;
  onSignOut: () => void;
}

export const UserMenu: React.FC<UserMenuProps> = ({ onOpenAuth, onSignOut }) => {
  const [showRolePreview, setShowRolePreview] = useState(false);
  const [activePreviewRole, setActivePreviewRole] = useState<UserRole>('USER');

  // Keyboard accessibility: dismiss modal on Escape key press
  useEffect(() => {
    if (!showRolePreview) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowRolePreview(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showRolePreview]);

  const renderRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'OWNER':
        return (
          <Badge variant="danger" size="sm" dot>
            Owner
          </Badge>
        );
      case 'ADMIN':
        return (
          <Badge variant="warning" size="sm" dot>
            Admin
          </Badge>
        );
      case 'USER':
      default:
        return (
          <Badge variant="info" size="sm" dot>
            Analyst
          </Badge>
        );
    }
  };

  return (
    <>
      {/* Header Profile / Sign In Capsule */}
      <div className="flex items-center gap-2 pl-2 border-l border-border-subtle">
        {/* Task 7 Fix: Show guest session indicator only on large desktop screens (lg:) to avoid tablet header crowding */}
        <div className="hidden lg:flex flex-col text-right">
          <span className="text-xs font-medium text-content-primary leading-tight">
            Security Analyst
          </span>
          <span className="text-[10px] font-mono text-content-muted leading-tight">
            Guest Session
          </span>
        </div>

        {/* Sign In CTA Button */}
        <Button
          variant="primary"
          size="sm"
          onClick={onOpenAuth}
          leftIcon={<LogIn className="w-3.5 h-3.5" />}
          className="text-xs"
        >
          Sign In
        </Button>

        {/* Role & Profile Foundation Trigger */}
        <button
          type="button"
          onClick={() => setShowRolePreview(true)}
          title="Inspect Role & Profile Architecture Foundations"
          className="p-1.5 rounded-lg border border-border-default text-content-secondary hover:text-content-primary hover:bg-surface-elevated transition-colors"
          aria-label="View user profile architecture preview"
        >
          <User className="w-4 h-4" />
        </button>
      </div>

      {/* Task 3 Fix: Role Architecture Modal with strict viewport containment & scrolling */}
      {showRolePreview && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="profile-drawer-title"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowRolePreview(false);
          }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto"
        >
          <div className="bg-surface-card border border-border-default rounded-xl max-w-md w-full shadow-elevated p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150 my-auto max-h-[90vh] flex flex-col">
            {/* Header: Always visible and pinned at top */}
            <div className="flex items-start justify-between shrink-0 pb-1 border-b border-border-subtle">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-brand/10 border border-brand/20 text-brand">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h3 id="profile-drawer-title" className="text-sm font-semibold text-content-primary">
                    Profile & RBAC Architecture
                  </h3>
                  <p className="text-xs text-content-muted">
                    Phase 2.7 Foundation Preview
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowRolePreview(false)}
                className="p-1.5 rounded-lg text-content-muted hover:text-content-primary hover:bg-surface-elevated transition-colors"
                aria-label="Close dialog"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Body: Content scrolls smoothly if viewport height is constrained */}
            <div className="space-y-4 overflow-y-auto pr-1 min-h-0 flex-1">
              {/* Honest Notice */}
              <div className="p-3 rounded-lg bg-surface-subtle border border-border-subtle flex items-start gap-2.5 text-xs">
                <Info className="w-4 h-4 text-brand shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <span className="font-medium text-content-primary">Honest Session Telemetry</span>
                  <p className="text-[11px] text-content-muted leading-relaxed">
                    Real authentication, Supabase Row-Level Security (RLS), and JWT token handling are scheduled for Phase 3. Below is the verified presentation layout for authenticated security roles.
                  </p>
                </div>
              </div>

              {/* Role Switcher Preview */}
              <div className="space-y-2">
                <label className="text-xs font-mono font-medium text-content-muted uppercase tracking-wider">
                  Select Role to Preview UI:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['USER', 'ADMIN', 'OWNER'] as UserRole[]).map((role) => (
                    <button
                      key={role}
                      type="button"
                      onClick={() => setActivePreviewRole(role)}
                      className={`
                        px-3 py-2 rounded-lg text-xs font-medium border text-center transition-colors
                        ${
                          activePreviewRole === role
                            ? 'border-brand bg-brand/10 text-brand'
                            : 'border-border-default text-content-secondary hover:bg-surface-elevated'
                        }
                      `}
                    >
                      {role}
                    </button>
                  ))}
                </div>
              </div>

              {/* Simulated Profile Card Foundation */}
              <div className="p-4 rounded-lg bg-surface-elevated border border-border-default space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-brand/20 border border-brand/30 flex items-center justify-center text-brand font-bold text-sm">
                      {activePreviewRole === 'OWNER' ? 'OW' : activePreviewRole === 'ADMIN' ? 'AD' : 'AN'}
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-content-primary">
                        {activePreviewRole === 'OWNER'
                          ? 'System Owner'
                          : activePreviewRole === 'ADMIN'
                          ? 'Security Lead'
                          : 'Security Analyst'}
                      </h4>
                      <p className="text-xs text-content-muted font-mono">
                        {activePreviewRole.toLowerCase()}@scamshield.ai
                      </p>
                    </div>
                  </div>
                  {renderRoleBadge(activePreviewRole)}
                </div>

                {/* Role Permissions Description */}
                <div className="text-[11px] text-content-muted pt-2 border-t border-border-subtle flex items-center gap-1.5">
                  {activePreviewRole === 'OWNER' ? (
                    <>
                      <Crown className="w-3.5 h-3.5 text-status-danger" />
                      <span>Full tenant control, API billing, team orchestration</span>
                    </>
                  ) : activePreviewRole === 'ADMIN' ? (
                    <>
                      <UserCheck className="w-3.5 h-3.5 text-status-warning" />
                      <span>Manage scan retention, custom rules, analytics export</span>
                    </>
                  ) : (
                    <>
                      <Shield className="w-3.5 h-3.5 text-brand" />
                      <span>Execute investigations, view audit trails, copy forensic reports</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Footer: Pinned at bottom with clear dismiss / navigation actions */}
            <div className="pt-3 border-t border-border-subtle flex items-center justify-between shrink-0">
              <Button
                variant="outline"
                size="sm"
                leftIcon={<LogOut className="w-3.5 h-3.5" />}
                onClick={() => {
                  setShowRolePreview(false);
                  onSignOut();
                }}
              >
                Sign Out
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => {
                  setShowRolePreview(false);
                  onOpenAuth();
                }}
              >
                Open Sign In Page
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
