import React, { useState } from 'react';
import { ShieldCheck, ArrowRight } from 'lucide-react';
import { ThemeToggle } from '../common';

export interface AuthLayoutProps {
  children: React.ReactNode;
  title: string;
  subtitle: string;
  onContinueAsGuest?: () => void | Promise<void>;
}

export const AuthLayout: React.FC<AuthLayoutProps> = ({
  children,
  title,
  subtitle,
  onContinueAsGuest,
}) => {
  const [guestError, setGuestError] = useState<string | null>(null);
  const [isContinuingAsGuest, setIsContinuingAsGuest] = useState(false);

  const handleContinueAsGuest = async () => {
    if (!onContinueAsGuest) return;
    setGuestError(null);
    setIsContinuingAsGuest(true);
    try {
      await onContinueAsGuest();
    } catch (error) {
      setGuestError(error instanceof Error ? error.message : 'Guest access is unavailable.');
    } finally {
      setIsContinuingAsGuest(false);
    }
  };

  return (
    <div className="min-h-screen bg-surface-app text-content-primary flex flex-col justify-between transition-colors duration-150">
      {/* Top Bar: Brand & Quick Actions */}
      <header className="h-16 px-4 md:px-8 border-b border-border-subtle bg-surface-card/60 backdrop-blur sticky top-0 z-30 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-brand/10 border border-brand/20 text-brand">
            <ShieldCheck className="w-5 h-5" aria-hidden="true" />
          </div>
          <div>
            <span className="text-sm font-semibold tracking-tight text-content-primary">
              ScamShield AI
            </span>
            <span className="hidden sm:inline-block ml-2 px-1.5 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider bg-surface-elevated text-content-muted border border-border-subtle">
              v1.0 Cyber Defense
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {onContinueAsGuest && (
            <button
              type="button"
              onClick={handleContinueAsGuest}
              disabled={isContinuingAsGuest}
              className="text-xs font-medium text-content-secondary hover:text-brand flex items-center gap-1 px-3 py-1.5 rounded-md hover:bg-surface-elevated transition-colors"
            >
              <span>{isContinuingAsGuest ? 'Connecting…' : 'Explore as Guest'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
          <ThemeToggle size="sm" />
        </div>
      </header>

      {/* Main Content: Centered Auth Card with vertical scrolling when content expands */}
      <main className="flex-1 flex flex-col items-center justify-center p-4 py-6 md:py-10 overflow-y-auto">
        <div className="w-full max-w-md my-auto">
          {/* Header Typography */}
          <div className="text-center mb-6">
            <h1 className="text-xl md:text-2xl font-bold tracking-tight text-content-primary">
              {title}
            </h1>
            <p className="text-xs md:text-sm text-content-muted mt-1.5 max-w-sm mx-auto">
              {subtitle}
            </p>
          </div>

          {/* Form Container */}
          {guestError && (
            <p role="alert" className="mb-4 text-xs text-status-danger">
              {guestError}
            </p>
          )}
          {children}
        </div>
      </main>

      {/* Footer: Honest Compliance Notice */}
      <footer className="py-4 px-6 border-t border-border-subtle text-center text-xs text-content-muted bg-surface-card/30 shrink-0">
        <p className="font-mono text-[11px]">
          Phase 2.7 Authentication UI • Strict client-side validation • Supabase service integration scheduled for Phase 3
        </p>
      </footer>
    </div>
  );
};

