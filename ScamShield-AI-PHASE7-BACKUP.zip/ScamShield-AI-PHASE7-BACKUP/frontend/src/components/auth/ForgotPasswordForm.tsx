import React, { useState, useEffect } from 'react';
import { Mail, ArrowLeft, Info, Send, Clock } from 'lucide-react';
import { AuthScreen, ForgotPasswordFormData } from '../../types/auth';
import { Button, Input, Card, CardContent } from '../common';
import { isValidEmail } from './validation';

export interface ForgotPasswordFormProps {
  onNavigate: (screen: AuthScreen) => void;
  onEmailSubmitted: (email: string) => void;
  initialEmail?: string;
}

export const ForgotPasswordForm: React.FC<ForgotPasswordFormProps> = ({
  onNavigate,
  onEmailSubmitted,
  initialEmail = '',
}) => {
  const [formData, setFormData] = useState<ForgotPasswordFormData>({
    email: initialEmail,
  });

  const [error, setError] = useState<string | undefined>();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);

  // Handle countdown timer
  useEffect(() => {
    if (cooldown <= 0) return;
    const interval = setInterval(() => {
      setCooldown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [cooldown]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusNotice(null);

    if (!formData.email.trim()) {
      setError('Please provide your registered email address.');
      return;
    }

    if (!isValidEmail(formData.email)) {
      setError('Please enter a valid email address.');
      return;
    }

    setError(undefined);
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setCooldown(60); // 60-second cooldown
      setStatusNotice(
        'UI Preview: Email format verified. In production, an OTP will be dispatched via Supabase/SMTP. You may proceed to preview the OTP verification screen.'
      );
      onEmailSubmitted(formData.email.trim());
    }, 600);
  };

  return (
    <Card variant="default">
      <CardContent className="space-y-4">
        {statusNotice && (
          <div
            role="status"
            className="p-3 rounded-lg bg-surface-subtle border border-border-default text-xs flex items-start gap-2.5 text-content-secondary"
          >
            <Info className="w-4 h-4 text-brand shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-medium text-content-primary">UI Preview — Recovery Dispatch</span>
              <p className="text-[11px] text-content-muted leading-relaxed">{statusNotice}</p>
              <div className="pt-1">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => onNavigate('verify-otp')}
                >
                  Proceed to Preview OTP Screen
                </Button>
              </div>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          <p className="text-xs text-content-muted leading-relaxed">
            UI Preview: Enter an email address to test the recovery interface. Live code dispatch will be handled by Supabase in Phase 3.
          </p>

          <Input
            label="Registered Email Address"
            type="email"
            placeholder="analyst@scamshield.ai"
            value={formData.email}
            onChange={(e) => {
              setFormData({ email: e.target.value });
              if (error) setError(undefined);
            }}
            error={error}
            leftIcon={<Mail className="w-4 h-4" />}
            autoComplete="email"
            required
          />

          <Button
            type="submit"
            variant="primary"
            size="md"
            className="w-full"
            isLoading={isSubmitting}
            disabled={cooldown > 0}
            leftIcon={cooldown > 0 ? <Clock className="w-4 h-4" /> : <Send className="w-4 h-4" />}
          >
            {cooldown > 0 ? `Resend Code in ${cooldown}s` : 'Request Verification Code (UI Preview)'}
          </Button>
        </form>

        {/* Back to Login navigation */}
        <div className="pt-2 text-center text-xs text-content-muted border-t border-border-subtle">
          <button
            type="button"
            onClick={() => onNavigate('login')}
            className="inline-flex items-center gap-1.5 font-medium text-content-secondary hover:text-content-primary focus:outline-none"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Sign In</span>
          </button>
        </div>
      </CardContent>
    </Card>
  );
};

