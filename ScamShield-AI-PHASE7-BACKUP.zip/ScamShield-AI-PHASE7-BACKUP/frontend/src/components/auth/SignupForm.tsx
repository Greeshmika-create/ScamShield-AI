import React, { useState, useMemo } from 'react';
import { User, Mail, Lock, Eye, EyeOff, Check, X, Info } from 'lucide-react';
import { AuthScreen, SignupFormData } from '../../types/auth';
import { Button, Input, Card, CardContent } from '../common';
import { isValidEmail, evaluatePasswordStrength } from './validation';

export interface SignupFormProps {
  onNavigate: (screen: AuthScreen) => void;
}

export const SignupForm: React.FC<SignupFormProps> = ({ onNavigate }) => {
  const [formData, setFormData] = useState<SignupFormData>({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    agreedToTerms: false,
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitNotice, setSubmitNotice] = useState<string | null>(null);

  // Evaluate password strength live
  const passwordStrength = useMemo(
    () => evaluatePasswordStrength(formData.password),
    [formData.password],
  );

  const passwordsMatch =
    formData.confirmPassword.length > 0 && formData.password === formData.confirmPassword;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitNotice(null);

    const newErrors: Record<string, string> = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required.';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!isValidEmail(formData.email)) {
      newErrors.email = 'Please enter a valid email address format.';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required.';
    } else if (!passwordStrength.isValid) {
      newErrors.password = 'Password does not satisfy the security requirements below.';
    }

    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Confirm your password.';
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match.';
    }

    if (!formData.agreedToTerms) {
      newErrors.terms = 'You must accept the terms of service and privacy policy to continue.';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitNotice(
        'UI Preview: Form fields and password requirements validated. No account was created. Live user persistence will activate upon Supabase integration in Phase 3.'
      );
    }, 600);
  };

  const getStrengthBarColor = (index: number) => {
    if (passwordStrength.score < index + 1) {
      return 'bg-surface-elevated';
    }
    switch (passwordStrength.score) {
      case 1:
        return 'bg-status-danger';
      case 2:
        return 'bg-status-warning';
      case 3:
        return 'bg-brand';
      case 4:
        return 'bg-status-success';
      default:
        return 'bg-surface-elevated';
    }
  };

  return (
    <Card variant="default">
      <CardContent className="space-y-4">
        {submitNotice && (
          <div
            role="status"
            className="p-3 rounded-lg bg-surface-subtle border border-border-default text-xs flex items-start gap-2.5 text-content-secondary"
          >
            <Info className="w-4 h-4 text-brand shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <span className="font-medium text-content-primary">UI Preview — Registration Notice</span>
              <p className="text-[11px] text-content-muted">{submitNotice}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5" noValidate>
          {/* Full Name */}
          <Input
            label="Full Name"
            type="text"
            placeholder="Priya Sharma"
            value={formData.fullName}
            onChange={(e) => {
              setFormData((prev) => ({ ...prev, fullName: e.target.value }));
              if (errors.fullName) setErrors((prev) => ({ ...prev, fullName: '' }));
            }}
            error={errors.fullName}
            leftIcon={<User className="w-4 h-4" />}
            autoComplete="name"
            required
          />

          {/* Email Address */}
          <Input
            label="Work or Personal Email"
            type="email"
            placeholder="analyst@scamshield.ai"
            value={formData.email}
            onChange={(e) => {
              setFormData((prev) => ({ ...prev, email: e.target.value }));
              if (errors.email) setErrors((prev) => ({ ...prev, email: '' }));
            }}
            error={errors.email}
            leftIcon={<Mail className="w-4 h-4" />}
            autoComplete="email"
            required
          />

          {/* Password */}
          <div>
            <Input
              label="Password"
              type={showPassword ? 'text' : 'password'}
              placeholder="••••••••••••"
              value={formData.password}
              onChange={(e) => {
                setFormData((prev) => ({ ...prev, password: e.target.value }));
                if (errors.password) setErrors((prev) => ({ ...prev, password: '' }));
              }}
              error={errors.password}
              leftIcon={<Lock className="w-4 h-4" />}
              rightIcon={
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  className="p-1 text-content-muted hover:text-content-primary transition-colors focus:outline-none"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              }
              autoComplete="new-password"
              required
            />

            {/* Password Strength Visual Meter */}
            {formData.password.length > 0 && (
              <div className="mt-2 space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-content-muted">Security Strength:</span>
                  <span className="font-medium text-content-primary">
                    {passwordStrength.feedback}
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-1.5 h-1.5">
                  <div className={`rounded-full transition-colors ${getStrengthBarColor(0)}`} />
                  <div className={`rounded-full transition-colors ${getStrengthBarColor(1)}`} />
                  <div className={`rounded-full transition-colors ${getStrengthBarColor(2)}`} />
                  <div className={`rounded-full transition-colors ${getStrengthBarColor(3)}`} />
                </div>

                {/* Password Criteria Checklist */}
                <div className="grid grid-cols-2 gap-1.5 pt-1 text-[11px] text-content-muted">
                  <div className="flex items-center gap-1.5">
                    {passwordStrength.hasMinLength ? (
                      <Check className="w-3.5 h-3.5 text-status-success" />
                    ) : (
                      <X className="w-3.5 h-3.5 text-content-muted" />
                    )}
                    <span>8+ characters</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {passwordStrength.hasUpperCase && passwordStrength.hasLowerCase ? (
                      <Check className="w-3.5 h-3.5 text-status-success" />
                    ) : (
                      <X className="w-3.5 h-3.5 text-content-muted" />
                    )}
                    <span>Upper & lowercase</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {passwordStrength.hasNumber ? (
                      <Check className="w-3.5 h-3.5 text-status-success" />
                    ) : (
                      <X className="w-3.5 h-3.5 text-content-muted" />
                    )}
                    <span>At least 1 number</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {passwordStrength.hasSpecialChar ? (
                      <Check className="w-3.5 h-3.5 text-status-success" />
                    ) : (
                      <X className="w-3.5 h-3.5 text-content-muted" />
                    )}
                    <span>Special character</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Confirm Password */}
          <div>
            <Input
              label="Confirm Password"
              type={showConfirmPassword ? 'text' : 'password'}
              placeholder="••••••••••••"
              value={formData.confirmPassword}
              onChange={(e) => {
                setFormData((prev) => ({ ...prev, confirmPassword: e.target.value }));
                if (errors.confirmPassword) setErrors((prev) => ({ ...prev, confirmPassword: '' }));
              }}
              error={errors.confirmPassword}
              leftIcon={<Lock className="w-4 h-4" />}
              rightIcon={
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword((prev) => !prev)}
                  className="p-1 text-content-muted hover:text-content-primary transition-colors focus:outline-none"
                  aria-label={showConfirmPassword ? 'Hide password' : 'Show password'}
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              }
              autoComplete="new-password"
              required
            />
            {formData.confirmPassword.length > 0 && (
              <p
                className={`text-[11px] mt-1 flex items-center gap-1 ${
                  passwordsMatch ? 'text-status-success' : 'text-status-danger'
                }`}
              >
                {passwordsMatch ? (
                  <>
                    <Check className="w-3.5 h-3.5" /> Passwords match
                  </>
                ) : (
                  <>
                    <X className="w-3.5 h-3.5" /> Passwords do not match
                  </>
                )}
              </p>
            )}
          </div>

          {/* Terms Agreement Checkbox */}
          <div className="pt-1">
            <label className="flex items-start gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={formData.agreedToTerms}
                onChange={(e) => {
                  setFormData((prev) => ({ ...prev, agreedToTerms: e.target.checked }));
                  if (errors.terms) setErrors((prev) => ({ ...prev, terms: '' }));
                }}
                className="mt-0.5 rounded border-border-default text-brand focus:ring-brand bg-surface-input"
              />
              <span className="text-xs text-content-secondary leading-snug">
                I agree to the{' '}
                <span className="text-brand hover:underline">Cybersecurity Terms of Use</span> and{' '}
                <span className="text-brand hover:underline">Privacy Charter</span>.
              </span>
            </label>
            {errors.terms && (
              <p role="alert" className="text-xs text-status-danger mt-1">
                {errors.terms}
              </p>
            )}
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            variant="primary"
            size="md"
            className="w-full mt-2"
            isLoading={isSubmitting}
          >
            Create Analyst Account
          </Button>
        </form>

        {/* Login Navigation */}
        <div className="pt-2 text-center text-xs text-content-muted border-t border-border-subtle">
          <span>Already have an account? </span>
          <button
            type="button"
            onClick={() => onNavigate('login')}
            className="font-medium text-brand hover:text-brand-hover focus:outline-none focus:underline"
          >
            Sign In
          </button>
        </div>
      </CardContent>
    </Card>
  );
};

