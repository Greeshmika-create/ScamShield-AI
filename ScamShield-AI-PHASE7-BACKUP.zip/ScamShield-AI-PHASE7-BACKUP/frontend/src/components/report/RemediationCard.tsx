import React from 'react';
import { ShieldAlert, Languages, ExternalLink } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../common';

export interface RemediationCardProps {
  guidance?: {
    english: string;
    telugu: string;
  };
  verdict: 'MALICIOUS' | 'SUSPICIOUS' | 'NO_KNOWN_THREAT' | 'UNVERIFIED';
}

export const RemediationCard: React.FC<RemediationCardProps> = ({ guidance, verdict }) => {
  return (
    <Card variant="default">
      <CardHeader>
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-brand" />
          <CardTitle>Actionable Remediation & User Guidance</CardTitle>
        </div>
        <CardDescription>
          Contextual steps to safeguard digital credentials, payment accounts, and devices.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Multilingual Guidance Cards (Rendered when supplied by backend) */}
        {guidance ? (
          <div className="space-y-3">
            {/* English Section */}
            <div className="p-4 rounded-lg bg-surface-subtle border border-border-subtle space-y-1.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-content-primary">
                <Languages className="w-3.5 h-3.5 text-brand" />
                <span>English Remediation Advice</span>
              </div>
              <p className="text-xs text-content-secondary leading-relaxed">
                {guidance.english}
              </p>
            </div>

            {/* Telugu Section (in authentic Telugu script) */}
            <div className="p-4 rounded-lg bg-surface-subtle border border-border-subtle space-y-1.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-content-primary">
                <Languages className="w-3.5 h-3.5 text-brand" />
                <span>తెలుగు సూచనలు (Telugu Guidance)</span>
              </div>
              <p className="text-xs text-content-secondary leading-relaxed font-sans">
                {guidance.telugu}
              </p>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-lg bg-surface-subtle border border-border-subtle text-xs text-content-secondary space-y-2">
            <p className="font-medium text-content-primary">Standard Defense Protocol for {verdict} Targets:</p>
            <ul className="list-disc list-inside space-y-1 text-content-muted">
              <li>Do not click hyperlinks or download attachments from unfamiliar senders.</li>
              <li>Banks and government authorities never demand urgent UPI PIN entry or passwords via SMS.</li>
              <li>If you encounter fraudulent digital extortion, report it immediately to the National Cyber Crime Helpline (Dial 1930) or cybercrime.gov.in.</li>
            </ul>
          </div>
        )}

        {/* Official Indian Cyber Crime Reporting Reference Banner */}
        <div className="p-3.5 rounded-lg border border-border-subtle bg-surface-card flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div className="space-y-0.5">
            <span className="font-semibold text-content-primary">
              National Cyber Crime Reporting Portal (Govt. of India)
            </span>
            <p className="text-content-muted text-[11px]">
              Helpline: Dial 1930 &bull; Official Portal: cybercrime.gov.in
            </p>
          </div>
          <a
            href="https://cybercrime.gov.in"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 font-mono text-brand hover:underline shrink-0 text-xs"
          >
            <span>Visit Portal</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </CardContent>
    </Card>
  );
};

