import React from 'react';
import { Cpu, TrendingUp, Tag } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Badge } from '../common';

export interface MLAnalysisCardProps {
  threatProbability: number;
  topFeatures?: Array<{ feature: string; value: number; impact: string }>;
  topNgrams?: string[];
}

export const MLAnalysisCard: React.FC<MLAnalysisCardProps> = ({
  threatProbability,
  topFeatures,
  topNgrams,
}) => {
  const percentScore = Math.round(threatProbability * 100);

  return (
    <Card variant="default">
      <CardHeader
        action={
          <Badge
            variant={percentScore >= 70 ? 'danger' : percentScore >= 35 ? 'warning' : 'success'}
            size="sm"
          >
            P(Threat): {percentScore}%
          </Badge>
        }
      >
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-brand" />
          <CardTitle>Machine Learning Model Inference</CardTitle>
        </div>
        <CardDescription>
          Explainable model probability output and primary contributing classification signals.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Probability Metric Bar */}
        <div className="p-4 rounded-lg bg-surface-subtle border border-border-subtle flex items-center justify-between">
          <div className="space-y-0.5">
            <span className="text-xs font-medium text-content-primary">
              Calibrated Classifier Threat Probability
            </span>
            <p className="text-[11px] text-content-muted">
              Model score evaluating lexical feature vector or multilingual sub-word n-grams.
            </p>
          </div>
          <div className="text-right">
            <span className="text-2xl font-bold font-mono text-content-primary">
              {(threatProbability * 100).toFixed(1)}%
            </span>
          </div>
        </div>

        {/* URL Feature Weights (if present) */}
        {topFeatures && topFeatures.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-xs font-mono font-medium text-content-muted uppercase tracking-wider flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-brand" />
              <span>Key Extracted Features (Impact on Score)</span>
            </h4>
            <div className="space-y-1.5">
              {topFeatures.map((feat, idx) => (
                <div
                  key={idx}
                  className="px-3 py-2 rounded-md bg-surface-subtle border border-border-subtle flex items-center justify-between text-xs"
                >
                  <span className="font-mono text-content-primary">{feat.feature}</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-content-muted">val: {feat.value}</span>
                    <Badge
                      variant={feat.impact === 'POSITIVE_RISK' ? 'danger' : 'neutral'}
                      size="sm"
                    >
                      {feat.impact}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Message Sub-Word N-Grams (if present) */}
        {topNgrams && topNgrams.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-xs font-mono font-medium text-content-muted uppercase tracking-wider flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-brand" />
              <span>Salient Regional / Linguistic N-Gram Indicators</span>
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {topNgrams.map((ngram, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded bg-surface-subtle border border-border-default text-xs font-mono text-content-primary"
                >
                  &ldquo;{ngram}&rdquo;
                </span>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

