import React, { useState } from 'react';
import { FileCode, Clock, Calendar, Check, Copy, Globe, Lock } from 'lucide-react';
import { OptionalDomainIntel } from '../../types/scan';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Badge } from '../common';

export interface ScanMetadataCardProps {
  scanId: string;
  scannedAt: string;
  executionTimeMs: number;
  domainIntel?: OptionalDomainIntel | null;
  detectedLanguage?: string;
}

export const ScanMetadataCard: React.FC<ScanMetadataCardProps> = ({
  scanId,
  scannedAt,
  executionTimeMs,
  domainIntel,
  detectedLanguage,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopyScanId = () => {
    navigator.clipboard.writeText(scanId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formattedDate = new Date(scannedAt).toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZoneName: 'short',
  });

  return (
    <Card variant="subtle">
      <CardHeader>
        <div className="flex items-center gap-2">
          <FileCode className="w-4 h-4 text-content-muted" />
          <CardTitle>Investigation Metadata & Audit Record</CardTitle>
        </div>
        <CardDescription>
          Cryptographic identifier and telemetry recorded in the Supabase audit log.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Core Metadata Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          {/* Scan ID with Copy Action */}
          <div className="p-3 rounded-lg bg-surface-card border border-border-subtle flex flex-col justify-between gap-1">
            <span className="text-[11px] font-mono text-content-muted uppercase">Investigation UUID</span>
            <div className="flex items-center justify-between gap-2">
              <span className="font-mono text-content-primary truncate text-[11px]" title={scanId}>
                {scanId}
              </span>
              <button
                type="button"
                onClick={handleCopyScanId}
                aria-label="Copy Investigation UUID"
                className="p-1 rounded text-content-muted hover:text-content-primary hover:bg-surface-elevated transition-colors shrink-0"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Timestamp */}
          <div className="p-3 rounded-lg bg-surface-card border border-border-subtle flex flex-col justify-between gap-1">
            <span className="text-[11px] font-mono text-content-muted uppercase flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              <span>Timestamp</span>
            </span>
            <span className="font-mono text-content-primary text-[11px] truncate">
              {formattedDate}
            </span>
          </div>

          {/* Execution Latency */}
          <div className="p-3 rounded-lg bg-surface-card border border-border-subtle flex flex-col justify-between gap-1">
            <span className="text-[11px] font-mono text-content-muted uppercase flex items-center gap-1">
              <Clock className="w-3 h-3" />
              <span>Pipeline Duration</span>
            </span>
            <span className="font-mono text-content-primary text-[11px]">
              {executionTimeMs} ms
            </span>
          </div>
        </div>

        {/* Optional Domain Intelligence (Rendered when available, or clean fallback) */}
        {domainIntel != null && (
          <div className="p-3.5 rounded-lg bg-surface-card border border-border-subtle space-y-2 text-xs">
            <div className="flex items-center gap-1.5 font-medium text-content-primary">
              <Globe className="w-3.5 h-3.5 text-brand" />
              <span>Domain Intelligence (RDAP / WHOIS Telemetry)</span>
            </div>

            {domainIntel.domain_age_days !== null && domainIntel.domain_age_days !== undefined ? (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px] font-mono">
                <div>
                  <span className="text-content-muted block">Domain Age</span>
                  <span className="text-content-primary font-semibold">
                    {domainIntel.domain_age_days} days
                  </span>
                </div>
                <div>
                  <span className="text-content-muted block">Registrar</span>
                  <span className="text-content-primary truncate block">
                    {domainIntel.registrar || 'Unknown'}
                  </span>
                </div>
                <div>
                  <span className="text-content-muted block">SSL Issuer</span>
                  <span className="text-content-primary truncate block">
                    {domainIntel.ssl_issuer || 'None'}
                  </span>
                </div>
                <div>
                  <span className="text-content-muted block">SSL Valid</span>
                  <Badge variant={domainIntel.ssl_valid ? 'success' : 'danger'} size="sm">
                    {domainIntel.ssl_valid ? 'Valid SSL' : 'Invalid / None'}
                  </Badge>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-content-muted text-[11px]">
                <Lock className="w-3.5 h-3.5 shrink-0" />
                <span>
                  Domain age and SSL issuer telemetry not available. (Optional RDAP connector unconfigured or rate-limited).
                </span>
              </div>
            )}
          </div>
        )}

        {/* Detected Message Language (if present) */}
        {detectedLanguage && (
          <div className="flex items-center justify-between p-3 rounded-lg bg-surface-card border border-border-subtle text-xs">
            <span className="text-content-muted">Linguistic Classification:</span>
            <Badge variant="neutral" size="sm">
              {detectedLanguage}
            </Badge>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

