import React from 'react';
import {
  ListFilter,
  CheckCircle2,
  AlertOctagon,
  AlertTriangle,
  Info,
  Search,
} from 'lucide-react';
import { ThreatFinding, FindingSeverity } from '../../types/scan';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Badge } from '../common';

export interface EvidenceMatrixProps {
  findings: ThreatFinding[];
}

const severityBadgeMap: Record<FindingSeverity, 'danger' | 'warning' | 'info' | 'neutral'> = {
  CRITICAL: 'danger',
  HIGH: 'danger',
  MEDIUM: 'warning',
  LOW: 'neutral',
  INFO: 'info',
};

const categoryBadgeMap: Record<string, string> = {
  INTEL: 'bg-red-500/10 text-red-400 border-red-500/20',
  HEURISTIC: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  ML: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  LINGUISTIC: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
};

export const EvidenceMatrix: React.FC<EvidenceMatrixProps> = ({ findings }) => {
  if (!findings || findings.length === 0) {
    return (
      <Card variant="default">
        <CardHeader>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-status-success" />
            <CardTitle>Evidence Matrix & Forensic Indicators</CardTitle>
          </div>
          <CardDescription>
            Granular rule violations and corroborated indicators of compromise.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="py-8 text-center space-y-2">
            <div className="inline-flex p-3 rounded-full bg-status-success-bg border border-status-success-border text-status-success">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <p className="text-sm font-semibold text-content-primary">
              No Threat Indicators Flagged
            </p>
            <p className="text-xs text-content-muted max-w-md mx-auto">
              Lexical parsing, threat feeds, and structural heuristics did not identify explicit deception patterns or blacklisted IoCs for this target.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card variant="default">
      <CardHeader
        action={
          <Badge variant="danger" size="sm">
            {findings.length} Evidence Items
          </Badge>
        }
      >
        <div className="flex items-center gap-2">
          <ListFilter className="w-4 h-4 text-brand" />
          <CardTitle>Evidence Matrix & Forensic Indicators</CardTitle>
        </div>
        <CardDescription>
          Detailed forensic findings categorized by intelligence source, heuristic rules, and ML models.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-3">
        {findings.map((finding, idx) => {
          const isCritical = finding.severity === 'CRITICAL' || finding.severity === 'HIGH';
          const isMedium = finding.severity === 'MEDIUM';

          return (
            <div
              key={idx}
              className="p-4 rounded-lg bg-surface-subtle border border-border-subtle transition-colors space-y-2"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  {isCritical ? (
                    <AlertOctagon className="w-4 h-4 text-status-danger shrink-0" />
                  ) : isMedium ? (
                    <AlertTriangle className="w-4 h-4 text-status-warning shrink-0" />
                  ) : (
                    <Info className="w-4 h-4 text-content-muted shrink-0" />
                  )}

                  <h4 className="text-sm font-semibold text-content-primary">
                    {finding.title}
                  </h4>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {/* Category Pill */}
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase ${
                      categoryBadgeMap[finding.category] || 'bg-surface-elevated text-content-secondary'
                    }`}
                  >
                    {finding.category}
                  </span>

                  {/* Rule Name */}
                  <span className="text-[10px] font-mono text-content-muted px-2 py-0.5 rounded bg-surface-card border border-border-subtle">
                    {finding.rule_name}
                  </span>

                  {/* Severity Badge */}
                  <Badge
                    variant={severityBadgeMap[finding.severity] || 'neutral'}
                    size="sm"
                  >
                    {finding.severity}
                  </Badge>
                </div>
              </div>

              <p className="text-xs text-content-secondary leading-relaxed pl-6">
                {finding.description}
              </p>

              {/* Raw Evidence Detail (if provided by backend) */}
              {finding.raw_evidence && Object.keys(finding.raw_evidence).length > 0 && (
                <div className="ml-6 mt-2 p-2.5 rounded bg-surface-card border border-border-subtle text-[11px] font-mono text-content-muted overflow-x-auto">
                  <div className="flex items-center gap-1.5 mb-1 text-content-secondary font-medium">
                    <Search className="w-3 h-3 text-brand" />
                    <span>Raw Indicator Evidence:</span>
                  </div>
                  <pre className="text-[10px] text-content-primary">
                    {JSON.stringify(finding.raw_evidence, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};

