import React from 'react';
import { ShieldAlert, ShieldCheck, AlertTriangle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../common';

export interface RiskScoreGaugeProps {
  score: number;
  confidence: 'HIGH' | 'MEDIUM' | 'PROVISIONAL';
}

export const RiskScoreGauge: React.FC<RiskScoreGaugeProps> = ({ score, confidence }) => {
  const boundedScore = Math.min(100, Math.max(0, score));

  // Determine risk category
  let riskLabel = 'Minimal Threat';
  let colorClass = 'text-status-success';
  let barColor = 'bg-status-success';
  let Icon = ShieldCheck;

  if (boundedScore >= 70) {
    riskLabel = 'High Malicious Risk';
    colorClass = 'text-status-danger';
    barColor = 'bg-status-danger';
    Icon = ShieldAlert;
  } else if (boundedScore >= 25) {
    riskLabel = 'Elevated Suspicious Risk';
    colorClass = 'text-status-warning';
    barColor = 'bg-status-warning';
    Icon = AlertTriangle;
  }

  return (
    <Card variant="default">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Icon className={`w-4 h-4 ${colorClass}`} />
          <CardTitle>Evidence-Based Risk Score</CardTitle>
        </div>
        <CardDescription>
          Multi-engine risk index derived from threat intel feeds, heuristic indicators, and ML probability.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Main Score Display */}
        <div className="flex items-baseline justify-between">
          <div className="flex items-baseline gap-2">
            <span
              className={`text-4xl font-extrabold font-mono tracking-tight ${colorClass}`}
              aria-label={`Risk score: ${boundedScore} out of 100`}
            >
              {boundedScore}
            </span>
            <span className="text-sm font-mono text-content-muted">/ 100</span>
          </div>

          <div className="text-right">
            <span className={`text-xs font-semibold uppercase tracking-wider block ${colorClass}`}>
              {riskLabel}
            </span>
            <span className="text-[11px] font-mono text-content-muted">
              Confidence: {confidence}
            </span>
          </div>
        </div>

        {/* Progress Bar with accessible ARIA */}
        <div
          role="progressbar"
          aria-valuenow={boundedScore}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Risk score level"
          className="w-full h-2.5 rounded-full bg-surface-subtle border border-border-subtle overflow-hidden"
        >
          <div
            className={`h-full ${barColor} transition-all duration-500 ease-out`}
            style={{ width: `${boundedScore}%` }}
          />
        </div>

        {/* Range Reference Legend */}
        <div className="grid grid-cols-3 text-[10px] font-mono text-content-muted pt-1 border-t border-border-subtle">
          <div>
            <span className="inline-block w-2 h-2 rounded-full bg-status-success mr-1" />
            0–24 Clean
          </div>
          <div className="text-center">
            <span className="inline-block w-2 h-2 rounded-full bg-status-warning mr-1" />
            25–69 Suspicious
          </div>
          <div className="text-right">
            <span className="inline-block w-2 h-2 rounded-full bg-status-danger mr-1" />
            70–100 Malicious
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

