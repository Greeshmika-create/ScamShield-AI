import React from 'react';
import { ShieldCheck, Search } from 'lucide-react';
import { Card, CardContent } from '../common';

export const EmptyReportState: React.FC = () => {
  return (
    <Card variant="subtle" className="border-dashed">
      <CardContent className="py-12 px-6 flex flex-col items-center justify-center text-center space-y-3 max-w-md mx-auto">
        <div className="p-3.5 rounded-full bg-surface-elevated border border-border-default text-content-muted">
          <Search className="w-6 h-6" />
        </div>
        <div className="space-y-1">
          <h3 className="text-sm font-semibold text-content-primary">
            No Active Forensic Investigation
          </h3>
          <p className="text-xs text-content-muted leading-relaxed">
            Submit a URL or paste a digital scam message above to initiate passive multi-engine analysis. When the backend completes inspection, the verified verdict, evidence matrix, threat feeds, and remediation advice will generate here.
          </p>
        </div>
        <div className="pt-2 flex items-center gap-1.5 text-[11px] font-mono text-content-muted">
          <ShieldCheck className="w-3.5 h-3.5 text-brand" />
          <span>Strict zero-mock policy active</span>
        </div>
      </CardContent>
    </Card>
  );
};

