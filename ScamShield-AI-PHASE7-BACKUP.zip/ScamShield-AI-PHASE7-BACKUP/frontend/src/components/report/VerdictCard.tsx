import React from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  ShieldCheck,
  HelpCircle,
  Shield,
} from 'lucide-react';
import { Verdict } from '../../types/scan';
import { Badge } from '../common';

export interface VerdictCardProps {
  verdict: Verdict;
  confidence: 'HIGH' | 'MEDIUM' | 'PROVISIONAL';
  targetType: 'URL' | 'MESSAGE';
  className?: string;
}

interface VerdictConfig {
  label: string;
  badgeVariant: 'danger' | 'warning' | 'success' | 'info';
  icon: React.ComponentType<{ className?: string }>;
  headline: string;
  description: string;
  safetyDisclaimer?: string;
  bannerBorder: string;
  bannerBg: string;
  textColor: string;
}

const VERDICT_CONFIGS: Record<Verdict, VerdictConfig> = {
  MALICIOUS: {
    label: 'MALICIOUS',
    badgeVariant: 'danger',
    icon: ShieldAlert,
    headline: 'Confirmed Malicious Cyber Threat',
    description:
      'This target is identified as an active threat via authoritative threat intelligence feeds or high-confidence machine learning corroborated by severe heuristic deception markers.',
    bannerBorder: 'border-status-danger-border',
    bannerBg: 'bg-status-danger-bg/40',
    textColor: 'text-status-danger',
  },
  SUSPICIOUS: {
    label: 'SUSPICIOUS',
    badgeVariant: 'warning',
    icon: AlertTriangle,
    headline: 'Suspicious / Elevated Risk Indicators',
    description:
      'This target displays anomalous structural patterns, urgency coercion, or brand impersonation typical of active scam campaigns, but is not yet cataloged in global blocklists.',
    bannerBorder: 'border-status-warning-border',
    bannerBg: 'bg-status-warning-bg/40',
    textColor: 'text-status-warning',
  },
  NO_KNOWN_THREAT: {
    label: 'NO_KNOWN_THREAT',
    badgeVariant: 'success',
    icon: ShieldCheck,
    headline: 'No Known Threat Signatures Detected',
    description:
      'This target was analyzed across operational threat feeds and evaluated by the machine learning classifier without triggering active indicators of compromise.',
    safetyDisclaimer:
      'Notice: Absence of detection does not guarantee absolute safety. Newly registered or zero-day phishing targets may not yet be indexed in global reputation databases.',
    bannerBorder: 'border-status-success-border',
    bannerBg: 'bg-status-success-bg/40',
    textColor: 'text-status-success',
  },
  UNVERIFIED: {
    label: 'UNVERIFIED',
    badgeVariant: 'info',
    icon: HelpCircle,
    headline: 'Investigation Incomplete / Unverified',
    description:
      'One or more primary external threat intelligence feeds were unreachable or timed out during inspection. Conclusive safety verification could not be established.',
    safetyDisclaimer:
      'Caution: Upstream service degradation prevented complete threat validation. Treat this target with standard security precautions.',
    bannerBorder: 'border-status-info-border',
    bannerBg: 'bg-status-info-bg/40',
    textColor: 'text-status-info',
  },
};

export const VerdictCard: React.FC<VerdictCardProps> = ({
  verdict,
  confidence,
  targetType,
  className = '',
}) => {
  const config = VERDICT_CONFIGS[verdict] || VERDICT_CONFIGS.UNVERIFIED;
  const IconComponent = config.icon;

  return (
    <div
      className={`rounded-xl border p-5 md:p-6 transition-colors duration-150 ${config.bannerBorder} ${config.bannerBg} ${className}`}
    >
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className={`p-2.5 rounded-lg bg-surface-card border ${config.bannerBorder} ${config.textColor} shrink-0`}>
            <IconComponent className="w-6 h-6" />
          </div>

          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono font-medium text-content-muted uppercase tracking-wider">
                Authoritative Verdict:
              </span>
              <Badge variant={config.badgeVariant} dot>
                {config.label}
              </Badge>
              <Badge variant="neutral" size="sm">
                Confidence: {confidence}
              </Badge>
              <span className="text-xs font-mono text-content-muted">
                [{targetType} Target]
              </span>
            </div>

            <h3 className={`text-base font-bold tracking-tight ${config.textColor}`}>
              {config.headline}
            </h3>

            <p className="text-xs text-content-secondary leading-relaxed max-w-3xl">
              {config.description}
            </p>
          </div>
        </div>
      </div>

      {/* Safety Disclaimer (Mandatory for NO_KNOWN_THREAT and UNVERIFIED) */}
      {config.safetyDisclaimer && (
        <div className="mt-4 pt-3 border-t border-border-subtle flex items-start gap-2 text-[11px] text-content-muted">
          <Shield className="w-3.5 h-3.5 text-content-muted shrink-0 mt-0.5" />
          <span>{config.safetyDisclaimer}</span>
        </div>
      )}
    </div>
  );
};

