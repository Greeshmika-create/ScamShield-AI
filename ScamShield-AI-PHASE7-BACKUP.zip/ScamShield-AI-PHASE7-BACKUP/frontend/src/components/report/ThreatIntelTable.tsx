import React from 'react';
import { Network, CheckCircle2, AlertOctagon, Clock, AlertTriangle, ShieldOff } from 'lucide-react';
import { ProviderReport, ProviderStatus } from '../../types/scan';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Badge } from '../common';

export interface ThreatIntelTableProps {
  providers: ProviderReport[];
}

interface StatusRenderConfig {
  badgeVariant: 'success' | 'danger' | 'warning' | 'neutral';
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
}

const STATUS_CONFIGS: Record<ProviderStatus, StatusRenderConfig> = {
  AVAILABLE_CLEAN: {
    badgeVariant: 'success',
    label: 'Clean / Unlisted',
    icon: CheckCircle2,
    description: 'Target was queried successfully; not present in active blocklist.',
  },
  AVAILABLE_FLAGGED: {
    badgeVariant: 'danger',
    label: 'Flagged Malicious',
    icon: AlertOctagon,
    description: 'Target confirmed as an active indicator of compromise (IoC).',
  },
  TIMEOUT: {
    badgeVariant: 'warning',
    label: 'Request Timeout (2.5s)',
    icon: Clock,
    description: 'Provider failed to respond within the deadline. Cannot assume safe.',
  },
  ERROR: {
    badgeVariant: 'danger',
    label: 'Upstream Error',
    icon: AlertTriangle,
    description: 'Provider API returned non-200 or network error. Cannot assume safe.',
  },
  UNCONFIGURED: {
    badgeVariant: 'neutral',
    label: 'Unconfigured Feed',
    icon: ShieldOff,
    description: 'API key not configured in backend. Feed query bypassed.',
  },
};

export const ThreatIntelTable: React.FC<ThreatIntelTableProps> = ({ providers }) => {
  if (!providers || providers.length === 0) {
    return (
      <Card variant="default">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Network className="w-4 h-4 text-content-muted" />
            <CardTitle>Threat Intelligence Feeds</CardTitle>
          </div>
          <CardDescription>Multi-source reputation verification</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-content-muted py-4 text-center">
            No external threat intelligence telemetry reported for this target.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card variant="default">
      <CardHeader
        action={
          <Badge variant="neutral" size="sm">
            {providers.length} Sources Queried
          </Badge>
        }
      >
        <div className="flex items-center gap-2">
          <Network className="w-4 h-4 text-brand" />
          <CardTitle>Threat Intelligence Providers</CardTitle>
        </div>
        <CardDescription>
          Parallel queries against global threat databases with 2.5s timeout circuit breakers.
        </CardDescription>
      </CardHeader>

      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left" aria-label="Threat intelligence provider results">
            <thead className="bg-surface-subtle text-content-muted font-mono uppercase text-[10px] border-b border-border-subtle">
              <tr>
                <th scope="col" className="px-5 py-3 font-medium">Provider Name</th>
                <th scope="col" className="px-4 py-3 font-medium">Feed Status</th>
                <th scope="col" className="px-4 py-3 font-medium">Latency</th>
                <th scope="col" className="px-5 py-3 font-medium">Details & Findings</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border-subtle">
              {providers.map((p, idx) => {
                const config = STATUS_CONFIGS[p.status] || STATUS_CONFIGS.UNCONFIGURED;
                const IconComponent = config.icon;

                return (
                  <tr key={idx} className="hover:bg-surface-subtle/50 transition-colors">
                    <td className="px-5 py-3.5 font-medium text-content-primary">
                      {p.provider_name}
                    </td>

                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-1.5">
                        <IconComponent
                          className={`w-3.5 h-3.5 shrink-0 ${
                            config.badgeVariant === 'danger'
                              ? 'text-status-danger'
                              : config.badgeVariant === 'warning'
                              ? 'text-status-warning'
                              : config.badgeVariant === 'success'
                              ? 'text-status-success'
                              : 'text-content-muted'
                          }`}
                        />
                        <Badge variant={config.badgeVariant} size="sm">
                          {config.label}
                        </Badge>
                      </div>
                    </td>

                    <td className="px-4 py-3.5 font-mono text-content-muted">
                      {p.response_time_ms} ms
                    </td>

                    <td className="px-5 py-3.5 text-content-secondary max-w-xs truncate">
                      {p.threat_details ? (
                        <span className="font-mono text-status-danger font-medium">
                          {p.threat_details}
                        </span>
                      ) : (
                        <span className="text-content-muted">{config.description}</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
};

