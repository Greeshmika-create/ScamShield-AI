import React from 'react';
import { RefreshCw, Globe, MessageSquare } from 'lucide-react';
import { URLScanResponse, MessageScanResponse } from '../../types/scan';
import { Button } from '../common';
import { VerdictCard } from './VerdictCard';
import { RiskScoreGauge } from './RiskScoreGauge';
import { ThreatIntelTable } from './ThreatIntelTable';
import { EvidenceMatrix } from './EvidenceMatrix';
import { MLAnalysisCard } from './MLAnalysisCard';
import { RemediationCard } from './RemediationCard';
import { ScanMetadataCard } from './ScanMetadataCard';
import { EmptyReportState } from './EmptyReportState';

export interface ForensicReportProps {
  urlReport?: URLScanResponse | null;
  messageReport?: MessageScanResponse | null;
  onClearReport?: () => void;
}

export const ForensicReport: React.FC<ForensicReportProps> = ({
  urlReport,
  messageReport,
  onClearReport,
}) => {
  if (!urlReport && !messageReport) {
    return <EmptyReportState />;
  }

  // --- Render URL Report ---
  if (urlReport) {
    return (
      <div className="space-y-6 animate-fadeIn">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border-subtle pb-3">
          <div className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-brand" />
            <div>
              <h2 className="text-base font-bold text-content-primary tracking-tight">
                Forensic Investigation Findings
              </h2>
              <p className="text-xs text-content-muted font-mono truncate max-w-xl">
                Target: {urlReport.canonical_url}
              </p>
            </div>
          </div>

          {onClearReport && (
            <Button
              variant="outline"
              size="sm"
              leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
              onClick={onClearReport}
            >
              New Investigation
            </Button>
          )}
        </div>

        {/* 1. Authoritative Verdict Banner */}
        <VerdictCard
          verdict={urlReport.verdict}
          confidence={urlReport.confidence_level}
          targetType="URL"
        />

        {/* 2. Primary Metrics: Risk Score + ML Inference */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RiskScoreGauge
            score={urlReport.risk_score}
            confidence={urlReport.confidence_level}
          />

          <MLAnalysisCard
            threatProbability={urlReport.ml_analysis.threat_probability}
            topFeatures={urlReport.ml_analysis.top_contributing_features}
          />
        </div>

        {/* 3. External Threat Intelligence Feeds */}
        <ThreatIntelTable providers={urlReport.threat_intelligence} />

        {/* 4. Evidence Matrix (Granular Rule Violations) */}
        <EvidenceMatrix findings={urlReport.findings} />

        {/* 5. Recommended Actions / Remediation */}
        <RemediationCard verdict={urlReport.verdict} />

        {/* 6. Investigation Metadata & Audit Trail */}
        <ScanMetadataCard
          scanId={urlReport.scan_id}
          scannedAt={urlReport.scanned_at}
          executionTimeMs={urlReport.execution_time_ms}
          domainIntel={urlReport.domain_intelligence}
        />
      </div>
    );
  }

  // --- Render Message Report ---
  if (messageReport) {
    return (
      <div className="space-y-6 animate-fadeIn">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border-subtle pb-3">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-brand" />
            <div>
              <h2 className="text-base font-bold text-content-primary tracking-tight">
                Multilingual Scam Analysis Report
              </h2>
              <p className="text-xs text-content-muted truncate max-w-xl">
                Preview: &ldquo;{messageReport.message_preview}&rdquo;
              </p>
            </div>
          </div>

          {onClearReport && (
            <Button
              variant="outline"
              size="sm"
              leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
              onClick={onClearReport}
            >
              New Investigation
            </Button>
          )}
        </div>

        {/* 1. Authoritative Verdict Banner */}
        <VerdictCard
          verdict={messageReport.verdict}
          confidence={messageReport.confidence_level}
          targetType="MESSAGE"
        />

        {/* 2. Primary Metrics: Risk Score + ML Inference */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RiskScoreGauge
            score={messageReport.risk_score}
            confidence={messageReport.confidence_level}
          />

          <MLAnalysisCard
            threatProbability={messageReport.ml_analysis.threat_probability}
            topNgrams={messageReport.ml_analysis.top_contributing_ngrams}
          />
        </div>

        {/* 3. Evidence Matrix (Granular Linguistic / Coercion Markers) */}
        <EvidenceMatrix findings={messageReport.findings} />

        {/* 4. Contextual & Bilingual Remediation Guidance (English + Telugu) */}
        <RemediationCard
          guidance={messageReport.user_guidance}
          verdict={messageReport.verdict}
        />

        {/* 5. Investigation Metadata & Audit Trail */}
        <ScanMetadataCard
          scanId={messageReport.scan_id}
          scannedAt={messageReport.scanned_at}
          executionTimeMs={messageReport.execution_time_ms}
          detectedLanguage={messageReport.detected_language}
        />
      </div>
    );
  }

  return null;
};
