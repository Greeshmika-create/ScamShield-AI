import React from 'react';
import { LayoutDashboard, Radar, History, BarChart3 } from 'lucide-react';

export type NavSection = 'overview' | 'scanner' | 'history' | 'analytics';

export interface NavItemConfig {
  id: NavSection;
  label: string;
  shortLabel: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
}

export const NAVIGATION_ITEMS: NavItemConfig[] = [
  {
    id: 'overview',
    label: 'Overview',
    shortLabel: 'Overview',
    description: 'Threat posture & engine status',
    icon: LayoutDashboard,
  },
  {
    id: 'scanner',
    label: 'Threat Scanner',
    shortLabel: 'Scanner',
    description: 'Inspect URLs & scam text',
    icon: Radar,
  },
  {
    id: 'history',
    label: 'Scan History',
    shortLabel: 'History',
    description: 'Forensic audit trails',
    icon: History,
  },
  {
    id: 'analytics',
    label: 'Security Analytics',
    shortLabel: 'Analytics',
    description: 'Telemetry & threat metrics',
    icon: BarChart3,
  },
];
