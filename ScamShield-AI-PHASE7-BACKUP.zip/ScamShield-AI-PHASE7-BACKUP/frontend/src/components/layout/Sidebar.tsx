import React from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  X,
} from 'lucide-react';
import { NavSection, NAVIGATION_ITEMS } from './types';

export interface SidebarProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeSection,
  onSelectSection,
  isCollapsed,
  onToggleCollapse,
  isMobileOpen,
  onCloseMobile,
}) => {
  return (
    <>
      {/* Mobile Backdrop Overlay */}
      {isMobileOpen && (
        <div
          role="presentation"
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm md:hidden transition-opacity duration-200"
          aria-hidden="true"
        />
      )}

      {/* Sidebar Container */}
      <aside
        id="main-sidebar"
        aria-label="Main Navigation"
        className={`
          fixed md:sticky top-0 z-50 h-screen flex flex-col justify-between
          border-r border-border-subtle bg-surface-card transition-all duration-200 ease-in-out
          ${
            isMobileOpen
              ? 'translate-x-0 w-64'
              : '-translate-x-full md:translate-x-0'
          }
          ${isCollapsed ? 'md:w-18' : 'md:w-64'}
        `}
      >
        {/* Top: Branding & Mobile Close */}
        <div>
          <div className="h-16 px-4 flex items-center justify-between border-b border-border-subtle">
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="p-2 rounded-lg bg-brand/10 border border-brand/20 text-brand shrink-0">
                <ShieldCheck className="w-5 h-5" aria-hidden="true" />
              </div>
              {(!isCollapsed || isMobileOpen) && (
                <div className="flex flex-col min-w-0 transition-opacity duration-200">
                  <span className="text-sm font-semibold tracking-tight text-content-primary truncate">
                    ScamShield AI
                  </span>
                  <span className="text-[10px] font-mono text-content-muted uppercase tracking-wider">
                    Defensive Cyber v1.0
                  </span>
                </div>
              )}
            </div>

            {/* Mobile close button */}
            <button
              type="button"
              onClick={onCloseMobile}
              className="md:hidden p-1.5 rounded-lg text-content-muted hover:text-content-primary hover:bg-surface-elevated"
              aria-label="Close navigation sidebar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Section */}
          <nav className="p-3 space-y-1" aria-label="Primary sections">
            {(!isCollapsed || isMobileOpen) && (
              <p className="px-3 pt-3 pb-1.5 text-[10px] font-mono font-medium text-content-muted uppercase tracking-wider">
                Operational Modules
              </p>
            )}

            <ul className="space-y-1">
              {NAVIGATION_ITEMS.map((item) => {
                const IconComponent = item.icon;
                const isActive = activeSection === item.id;

                return (
                  <li key={item.id}>
                    <button
                      type="button"
                      onClick={() => {
                        onSelectSection(item.id);
                        onCloseMobile();
                      }}
                      title={isCollapsed && !isMobileOpen ? item.label : undefined}
                      aria-current={isActive ? 'page' : undefined}
                      className={`
                        w-full flex items-center gap-3 rounded-lg text-sm transition-colors duration-150
                        focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-1 focus-visible:ring-offset-surface-card
                        ${isCollapsed && !isMobileOpen ? 'justify-center px-2 py-2.5' : 'px-3 py-2.5 text-left'}
                        ${
                          isActive
                            ? 'bg-brand/10 text-brand border border-brand/20 font-medium'
                            : 'text-content-secondary hover:text-content-primary hover:bg-surface-elevated border border-transparent'
                        }
                      `}
                    >
                      <IconComponent
                        className={`w-4.5 h-4.5 shrink-0 ${
                          isActive ? 'text-brand' : 'text-content-muted'
                        }`}
                        aria-hidden="true"
                      />

                      {(!isCollapsed || isMobileOpen) && (
                        <div className="flex-1 min-w-0">
                          <p className="truncate leading-tight font-medium">
                            {item.label}
                          </p>
                          <p className="text-[11px] text-content-muted truncate leading-tight mt-0.5">
                            {item.description}
                          </p>
                        </div>
                      )}
                    </button>
                  </li>
                );
              })}
            </ul>
          </nav>
        </div>

        {/* Bottom: System Status & Collapse Toggle */}
        <div className="p-3 border-t border-border-subtle">
          {(!isCollapsed || isMobileOpen) ? (
            <div className="mb-2 px-3 py-2 rounded-lg bg-surface-subtle border border-border-subtle flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="font-mono text-[11px] text-content-secondary">
                  Gateway: Standby
                </span>
              </div>
              <span className="text-[10px] font-mono text-content-muted">v1.0</span>
            </div>
          ) : (
            <div className="flex justify-center mb-2" title="System Ready">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
            </div>
          )}

          {/* Desktop Collapse / Expand Button */}
          <button
            type="button"
            onClick={onToggleCollapse}
            aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="hidden md:flex w-full items-center justify-center p-2 rounded-lg text-content-muted hover:text-content-primary hover:bg-surface-elevated transition-colors"
          >
            {isCollapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <div className="flex items-center justify-between w-full px-2 text-xs text-content-muted">
                <span>Collapse Navigation</span>
                <ChevronLeft className="w-4 h-4" />
              </div>
            )}
          </button>
        </div>
      </aside>
    </>
  );
};
