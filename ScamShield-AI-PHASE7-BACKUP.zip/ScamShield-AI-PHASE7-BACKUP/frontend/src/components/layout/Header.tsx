import React from 'react';
import { Menu, Shield } from 'lucide-react';
import { ThemeToggle } from '../common';
import { UserMenu } from '../auth';
import { NavSection, NAVIGATION_ITEMS } from './types';

export interface HeaderProps {
  activeSection: NavSection;
  onOpenMobile: () => void;
  onOpenAuth?: () => void;
  onSignOut?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeSection,
  onOpenMobile,
  onOpenAuth,
  onSignOut,
}) => {
  const currentConfig =
    NAVIGATION_ITEMS.find((item) => item.id === activeSection) || NAVIGATION_ITEMS[0]!;

  return (
    <header className="h-16 px-4 md:px-8 border-b border-border-subtle bg-surface-card/80 backdrop-blur sticky top-0 z-30 flex items-center justify-between">
      {/* Left: Mobile Toggle & Page Title */}
      <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
        <button
          type="button"
          onClick={onOpenMobile}
          aria-label="Open navigation menu"
          className="md:hidden p-2 rounded-lg border border-border-default text-content-secondary hover:text-content-primary hover:bg-surface-elevated transition-colors shrink-0"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="min-w-0">
          {/* Task 9 Fix: Hide redundant breadcrumb on narrow mobile screens (<sm) while preserving page title */}
          <nav aria-label="Breadcrumb" className="hidden sm:flex items-center gap-1.5 text-xs text-content-muted">
            <span>ScamShield</span>
            <span>/</span>
            <span className="text-content-primary font-medium">{currentConfig.label}</span>
          </nav>
          <h2 className="text-sm font-semibold text-content-primary tracking-tight truncate">
            {currentConfig.label}
          </h2>
        </div>
      </div>

      {/* Right: Actions, Theme, & Honest Analyst Session */}
      <div className="flex items-center gap-3">
        {/* Environment Badge */}
        <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-surface-subtle border border-border-subtle text-[11px] font-mono text-content-secondary">
          <Shield className="w-3.5 h-3.5 text-brand" />
          <span>Local Engine</span>
        </div>

        {/* Theme Toggle */}
        <ThemeToggle size="sm" />

        {/* User Profile Capsule with Auth Trigger & RBAC Foundation */}
        <UserMenu
          onOpenAuth={onOpenAuth || (() => {})}
          onSignOut={onSignOut || (() => {})}
        />
      </div>
    </header>
  );
};
