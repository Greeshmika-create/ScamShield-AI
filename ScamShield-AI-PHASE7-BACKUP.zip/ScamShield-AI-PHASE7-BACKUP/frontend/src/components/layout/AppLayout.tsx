import React, { useState } from 'react';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { NavSection } from './types';

export interface AppLayoutProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  onOpenAuth?: () => void;
  onSignOut?: () => void;
  children: React.ReactNode;
}

export const AppLayout: React.FC<AppLayoutProps> = ({
  activeSection,
  onSelectSection,
  onOpenAuth,
  onSignOut,
  children,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-surface-app text-content-primary flex flex-col md:flex-row font-sans transition-colors duration-150">
      {/* Sidebar Navigation */}
      <Sidebar
        activeSection={activeSection}
        onSelectSection={onSelectSection}
        isCollapsed={isCollapsed}
        onToggleCollapse={() => setIsCollapsed(!isCollapsed)}
        isMobileOpen={isMobileOpen}
        onCloseMobile={() => setIsMobileOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        <Header
          activeSection={activeSection}
          onOpenMobile={() => setIsMobileOpen(true)}
          onOpenAuth={onOpenAuth}
          onSignOut={onSignOut}
        />

        <main id="main-content" className="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
};

