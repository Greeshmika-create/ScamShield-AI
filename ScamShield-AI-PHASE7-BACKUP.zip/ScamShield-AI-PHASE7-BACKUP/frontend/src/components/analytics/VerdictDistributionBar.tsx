import React from 'react';
import { ShieldCheck, PieChart } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../common';

export interface VerdictDistributionBarProps {
  distribution: {
    MALICIOUS: number;
    SUSPICIOUS: number;
    NO_KNOWN_THREAT: number;
    UNVERIFIED: number;
  };
  totalScans: number;
}

export const VerdictDistributionBar: React.FC<VerdictDistributionBarProps> = ({
  distribution,
  totalScans,
}) => {
  const safeTotal = totalScans > 0 ? totalScans : 1;

  const malPercent = ((distribution.MALICIOUS / safeTotal) * 100).toFixed(1);
  const suspPercent = ((distribution.SUSPICIOUS / safeTotal) * 100).toFixed(1);
  const cleanPercent = ((distribution.NO_KNOWN_THREAT / safeTotal) * 100).toFixed(1);
  const unverPercent = ((distribution.UNVERIFIED / safeTotal) * 100).toFixed(1);

  return (
    <Card variant="default">
      <CardHeader>
        <div className="flex items-center gap-2">
          <PieChart className="w-4 h-4 text-brand" />
          <CardTitle>Verdict Distribution</CardTitle>
        </div>
        <CardDescription>
          Proportional breakdown of authoritative threat verdicts across all investigations.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Proportional Segmented Bar */}
        <div
          role="img"
          aria-label={`Verdict Distribution: ${malPercent}% Malicious, ${suspPercent}% Suspicious, ${cleanPercent}% No Known Threat, ${unverPercent}% Unverified`}
          className="w-full h-3 rounded-full bg-surface-subtle overflow-hidden flex"
        >
          {distribution.MALICIOUS > 0 && (
            <div
              className="bg-status-danger h-full transition-all duration-500"
              style={{ width: `${malPercent}%` }}
              title={`Malicious: ${distribution.MALICIOUS} (${malPercent}%)`}
            />
          )}
          {distribution.SUSPICIOUS > 0 && (
            <div
              className="bg-status-warning h-full transition-all duration-500"
              style={{ width: `${suspPercent}%` }}
              title={`Suspicious: ${distribution.SUSPICIOUS} (${suspPercent}%)`}
            />
          )}
          {distribution.NO_KNOWN_THREAT > 0 && (
            <div
              className="bg-status-success h-full transition-all duration-500"
              style={{ width: `${cleanPercent}%` }}
              title={`No Known Threat: ${distribution.NO_KNOWN_THREAT} (${cleanPercent}%)`}
            />
          )}
          {distribution.UNVERIFIED > 0 && (
            <div
              className="bg-status-info h-full transition-all duration-500"
              style={{ width: `${unverPercent}%` }}
              title={`Unverified: ${distribution.UNVERIFIED} (${unverPercent}%)`}
            />
          )}
        </div>

        {/* Legend / Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs">
          <div className="p-3 rounded-lg bg-surface-subtle border border-border-subtle space-y-1">
            <div className="flex items-center gap-1.5 font-medium text-status-danger">
              <span className="w-2 h-2 rounded-full bg-status-danger" />
              <span>MALICIOUS</span>
            </div>
            <div className="flex items-baseline gap-1 font-mono">
              <span className="text-base font-bold text-content-primary">
                {distribution.MALICIOUS}
              </span>
              <span className="text-content-muted text-[11px]">({malPercent}%)</span>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-surface-subtle border border-border-subtle space-y-1">
            <div className="flex items-center gap-1.5 font-medium text-status-warning">
              <span className="w-2 h-2 rounded-full bg-status-warning" />
              <span>SUSPICIOUS</span>
            </div>
            <div className="flex items-baseline gap-1 font-mono">
              <span className="text-base font-bold text-content-primary">
                {distribution.SUSPICIOUS}
              </span>
              <span className="text-content-muted text-[11px]">({suspPercent}%)</span>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-surface-subtle border border-border-subtle space-y-1">
            <div className="flex items-center gap-1.5 font-medium text-status-success">
              <span className="w-2 h-2 rounded-full bg-status-success" />
              <span>NO_KNOWN_THREAT</span>
            </div>
            <div className="flex items-baseline gap-1 font-mono">
              <span className="text-base font-bold text-content-primary">
                {distribution.NO_KNOWN_THREAT}
              </span>
              <span className="text-content-muted text-[11px]">({cleanPercent}%)</span>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-surface-subtle border border-border-subtle space-y-1">
            <div className="flex items-center gap-1.5 font-medium text-status-info">
              <span className="w-2 h-2 rounded-full bg-status-info" />
              <span>UNVERIFIED</span>
            </div>
            <div className="flex items-baseline gap-1 font-mono">
              <span className="text-base font-bold text-content-primary">
                {distribution.UNVERIFIED}
              </span>
              <span className="text-content-muted text-[11px]">({unverPercent}%)</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-[11px] text-content-muted pt-1">
          <ShieldCheck className="w-3.5 h-3.5 text-brand" />
          <span>Real-time aggregate calculated directly from authentic database scan records.</span>
        </div>
      </CardContent>
    </Card>
  );
};

