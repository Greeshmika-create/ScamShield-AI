import React from 'react';
import { BarChart3, ServerOff, ShieldCheck, RefreshCw } from 'lucide-react';
import { Card, CardContent, Button } from '../common';

export interface AnalyticsEmptyStateProps {
  isOffline?: boolean;
  onRetry?: () => void;
}

export const AnalyticsEmptyState: React.FC<AnalyticsEmptyStateProps> = ({
  isOffline = false,
  onRetry,
}) => {
  return (
    <Card variant="subtle" className="border-dashed">
      <CardContent className="py-12 px-6 flex flex-col items-center justify-center text-center space-y-3 max-w-md mx-auto">
        <div className="p-3.5 rounded-full bg-surface-elevated border border-border-default text-content-muted">
          {isOffline ? <ServerOff className="w-6 h-6 text-status-warning" /> : <BarChart3 className="w-6 h-6" />}
        </div>

        <div className="space-y-1">
          <h3 className="text-sm font-semibold text-content-primary">
            {isOffline ? 'Analytics Telemetry Unavailable' : 'Awaiting Telemetry Data Points'}
          </h3>
          <p className="text-xs text-content-muted leading-relaxed">
            {isOffline
              ? 'Unable to connect to the backend analytics service. ScamShield AI does not display simulated charts or fabricated numbers when live services are offline.'
              : 'Zero scan records exist in the database. Charts and macro telemetry will automatically generate once URL and message investigations are conducted.'}
          </p>
        </div>

        {onRetry && (
          <div className="pt-2">
            <Button
              variant="outline"
              size="sm"
              leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
              onClick={onRetry}
            >
              Retry Connection
            </Button>
          </div>
        )}

        <div className="pt-2 flex items-center gap-1.5 text-[11px] font-mono text-content-muted">
          <ShieldCheck className="w-3.5 h-3.5 text-brand" />
          <span>Strict zero-mock policy active</span>
        </div>
      </CardContent>
    </Card>
  );
};

