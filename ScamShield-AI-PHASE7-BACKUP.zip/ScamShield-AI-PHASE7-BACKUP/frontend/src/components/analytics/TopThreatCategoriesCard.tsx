import React from 'react';
import { ShieldAlert } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../common';

export interface TopThreatCategoriesCardProps {
  categories: Array<{ category: string; count: number }>;
}

export const TopThreatCategoriesCard: React.FC<TopThreatCategoriesCardProps> = ({
  categories,
}) => {
  if (!categories || !Array.isArray(categories) || categories.length === 0) {
    return (
      <Card variant="default">
        <CardHeader>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-brand" />
            <CardTitle>Top Flagged Threat Motifs</CardTitle>
          </div>
          <CardDescription>Primary fraud and threat categories identified</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-content-muted py-6 text-center">
            No threat motifs classified yet.
          </p>
        </CardContent>
      </Card>
    );
  }

  const maxCount = Math.max(...categories.map((c) => c.count), 1);

  return (
    <Card variant="default">
      <CardHeader>
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-brand" />
          <CardTitle>Top Flagged Threat Motifs</CardTitle>
        </div>
        <CardDescription>
          Prevalent scam vectors detected across analyzed URLs and regional messages.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-3">
        {categories.map((item, idx) => {
          const barWidth = Math.round((item.count / maxCount) * 100);

          return (
            <div key={idx} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-content-primary truncate max-w-xs">
                  {item.category}
                </span>
                <span className="font-mono text-content-muted shrink-0">
                  <strong className="text-status-danger">{item.count}</strong> incidents
                </span>
              </div>

              <div className="w-full h-2 rounded-full bg-surface-subtle overflow-hidden">
                <div
                  className="bg-status-danger h-full rounded-full transition-all duration-500"
                  style={{ width: `${barWidth}%` }}
                />
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};

