import React from 'react';
import { Card, CardContent } from '../common';

export interface StatCardProps {
  title: string;
  value: string | number;
  subtext?: string;
  icon: React.ComponentType<{ className?: string }>;
  accentColor?: 'danger' | 'warning' | 'success' | 'brand' | 'neutral';
}

const colorMap = {
  danger: 'text-status-danger bg-status-danger-bg border-status-danger-border',
  warning: 'text-status-warning bg-status-warning-bg border-status-warning-border',
  success: 'text-status-success bg-status-success-bg border-status-success-border',
  brand: 'text-brand bg-brand/10 border-brand/20',
  neutral: 'text-content-muted bg-surface-elevated border-border-default',
};

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtext,
  icon: Icon,
  accentColor = 'brand',
}) => {
  return (
    <Card variant="default">
      <CardContent className="p-5 flex items-start justify-between gap-4">
        <div className="space-y-1">
          <span className="text-xs font-mono font-medium text-content-muted uppercase tracking-wider block">
            {title}
          </span>
          <span className="text-2xl font-bold font-mono tracking-tight text-content-primary block">
            {value}
          </span>
          {subtext && (
            <p className="text-[11px] text-content-muted mt-0.5">
              {subtext}
            </p>
          )}
        </div>

        <div className={`p-2.5 rounded-lg border shrink-0 ${colorMap[accentColor]}`}>
          <Icon className="w-5 h-5" />
        </div>
      </CardContent>
    </Card>
  );
};

