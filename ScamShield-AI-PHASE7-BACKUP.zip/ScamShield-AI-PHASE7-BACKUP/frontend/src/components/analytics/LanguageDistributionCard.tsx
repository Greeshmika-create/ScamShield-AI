import React from 'react';
import { Languages } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../common';

export interface LanguageDistributionCardProps {
  distribution: Record<string, number>;
}

export const LanguageDistributionCard: React.FC<LanguageDistributionCardProps> = ({
  distribution,
}) => {
  const entries = Object.entries(distribution || {});
  const totalMessages = entries.reduce((acc, [, count]) => acc + (typeof count === 'number' ? count : 0), 0);
  const safeTotal = totalMessages > 0 ? totalMessages : 1;

  if (entries.length === 0) {
    return (
      <Card variant="default">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Languages className="w-4 h-4 text-brand" />
            <CardTitle>Regional Language Telemetry</CardTitle>
          </div>
          <CardDescription>Linguistic distribution across message investigations</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-content-muted py-6 text-center">
            No message investigations recorded yet to populate linguistic telemetry.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card variant="default">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Languages className="w-4 h-4 text-brand" />
          <CardTitle>Regional Language Telemetry</CardTitle>
        </div>
        <CardDescription>
          Distribution across English, native Telugu script, and transliterated Telugish.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-3">
        {entries.map(([lang, count]) => {
          const percent = ((count / safeTotal) * 100).toFixed(1);

          return (
            <div key={lang} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-mono text-content-primary">
                  {lang === 'TELUGU_SCRIPT'
                    ? 'Telugu Script (తెలుగు)'
                    : lang === 'TELUGISH'
                    ? 'Transliterated Telugish'
                    : lang === 'ENGLISH'
                    ? 'English'
                    : lang}
                </span>
                <span className="font-mono text-content-muted">
                  <strong className="text-content-primary">{count}</strong> ({percent}%)
                </span>
              </div>

              <div className="w-full h-2 rounded-full bg-surface-subtle overflow-hidden">
                <div
                  className="bg-brand h-full rounded-full transition-all duration-500"
                  style={{ width: `${percent}%` }}
                />
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};

