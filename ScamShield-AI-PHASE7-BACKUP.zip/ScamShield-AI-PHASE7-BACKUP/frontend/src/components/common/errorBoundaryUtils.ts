/**
 * Sanitizes diagnostic log messages to prevent accidental exposure of tokens,
 * passwords, OTPs, API keys, or sensitive query parameters.
 */
export function sanitizeErrorMessage(message: string): string {
  if (!message || typeof message !== 'string') {
    return 'Unknown render interruption';
  }

  let sanitized = message;

  // 1. Mask JWT tokens (e.g. eyJhbGciOi...)
  sanitized = sanitized.replace(
    /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}(?:\.[A-Za-z0-9_-]*)?\b/g,
    '[TOKEN_MASKED]'
  );

  // 2. Mask Bearer authorization tokens
  sanitized = sanitized.replace(
    /\bBearer\s+[A-Za-z0-9._~+/-]+=*\b/gi,
    'Bearer [TOKEN_MASKED]'
  );

  // 3. Mask sensitive URL query parameters (?token=..., &apikey=..., &otp=..., &password=...)
  sanitized = sanitized.replace(
    /([?&](?:token|access_token|refresh_token|api_key|apikey|key|secret|password|passwd|otp|code|session)=)[^&\s#]+/gi,
    '$1[MASKED]'
  );

  // 4. Mask sensitive key-value pairs (password=secret, otp: 123456, etc.) that are not already masked
  sanitized = sanitized.replace(
    /\b(password|passwd|secret|otp|pin|auth_code)[\s:=]+(?!\[MASKED\])([^\s,;&]+)/gi,
    '$1: [MASKED]'
  );

  return sanitized;
}

/**
 * Sanitizes the component stack trace to avoid logging local paths or sensitive parameters.
 */
export function sanitizeComponentStack(stack: string | null | undefined): string {
  if (!stack || typeof stack !== 'string') return 'unavailable';

  return (
    stack
      .split('\n')
      .slice(0, 3)
      .map((s) => s.trim())
      .map((s) => s.replace(/\s*\(at\s+[^)]+\)/g, ''))
      .map((s) => s.replace(/(?:\([A-Za-z]:[^)]+\)|\([/][^)]+\))/g, ''))
      .filter(Boolean)
      .join(' > ') || 'unavailable'
  );
}
