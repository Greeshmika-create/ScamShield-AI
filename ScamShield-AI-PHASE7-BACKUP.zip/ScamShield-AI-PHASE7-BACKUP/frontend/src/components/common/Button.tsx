import React, { forwardRef } from 'react';
import { Loader2 } from 'lucide-react';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

const variantStyles: Record<ButtonVariant, string> = {
  primary:
    'bg-brand text-brand-text hover:bg-brand-hover active:bg-brand-active border border-transparent shadow-subtle',
  secondary:
    'bg-surface-elevated text-content-primary hover:bg-surface-subtle active:opacity-90 border border-border-default',
  outline:
    'bg-transparent text-content-primary hover:bg-surface-elevated border border-border-default hover:border-border-strong',
  ghost:
    'bg-transparent text-content-secondary hover:text-content-primary hover:bg-surface-elevated border border-transparent',
  danger:
    'bg-status-danger text-white hover:opacity-90 active:opacity-95 border border-transparent shadow-subtle',
};

const sizeStyles: Record<ButtonSize, string> = {
  sm: 'px-2.5 py-1.5 text-xs gap-1.5',
  md: 'px-3.5 py-2 text-sm gap-2',
  lg: 'px-4.5 py-2.5 text-base gap-2.5',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      children,
      variant = 'primary',
      size = 'md',
      isLoading = false,
      disabled = false,
      leftIcon,
      rightIcon,
      className = '',
      type = 'button',
      ...rest
    },
    ref,
  ) => {
    const isInteractionDisabled = disabled || isLoading;

    return (
      <button
        ref={ref}
        type={type}
        disabled={isInteractionDisabled}
        aria-busy={isLoading}
        className={`
          inline-flex items-center justify-center font-medium transition-colors duration-150 rounded-md
          focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:ring-offset-surface-app
          ${variantStyles[variant]}
          ${sizeStyles[size]}
          ${isInteractionDisabled ? 'opacity-50 cursor-not-allowed pointer-events-none' : ''}
          ${className}
        `}
        {...rest}
      >
        {isLoading ? (
          <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
        ) : (
          leftIcon && <span className="shrink-0 flex items-center">{leftIcon}</span>
        )}
        <span>{children}</span>
        {!isLoading && rightIcon && <span className="shrink-0 flex items-center">{rightIcon}</span>}
      </button>
    );
  },
);

Button.displayName = 'Button';

