import React from 'react';

export interface DividerProps extends React.HTMLAttributes<HTMLDivElement> {
  orientation?: 'horizontal' | 'vertical';
  label?: string;
}

export const Divider: React.FC<DividerProps> = ({
  orientation = 'horizontal',
  label,
  className = '',
  ...rest
}) => {
  if (orientation === 'vertical') {
    return (
      <div
        role="separator"
        aria-orientation="vertical"
        className={`w-px self-stretch bg-border-subtle ${className}`}
        {...rest}
      />
    );
  }

  if (label) {
    return (
      <div
        role="separator"
        aria-orientation="horizontal"
        className={`w-full flex items-center gap-3 my-4 ${className}`}
        {...rest}
      >
        <div className="flex-1 h-px bg-border-subtle" />
        <span className="text-xs font-mono font-medium text-content-muted uppercase tracking-wider">
          {label}
        </span>
        <div className="flex-1 h-px bg-border-subtle" />
      </div>
    );
  }

  return (
    <hr
      role="separator"
      aria-orientation="horizontal"
      className={`w-full my-4 border-0 border-t border-border-subtle ${className}`}
      {...rest}
    />
  );
};

