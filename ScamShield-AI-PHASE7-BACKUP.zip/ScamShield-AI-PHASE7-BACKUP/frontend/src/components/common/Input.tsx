import React, { forwardRef, useId } from 'react';
import { AlertCircle } from 'lucide-react';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  helperText?: string;
  error?: string | boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  (
    {
      label,
      helperText,
      error,
      leftIcon,
      rightIcon,
      id: customId,
      disabled,
      className = '',
      ...rest
    },
    ref,
  ) => {
    const generatedId = useId();
    const inputId = customId || generatedId;
    const errorId = `${inputId}-error`;
    const helperId = `${inputId}-helper`;

    const hasError = Boolean(error);
    const errorMessage = typeof error === 'string' ? error : undefined;

    return (
      <div className="w-full flex flex-col gap-1.5">
        {label && (
          <label
            htmlFor={inputId}
            className="text-xs font-medium text-content-secondary flex items-center justify-between"
          >
            <span>{label}</span>
          </label>
        )}

        <div className="relative flex items-center">
          {leftIcon && (
            <div className="absolute left-3 flex items-center pointer-events-none text-content-muted">
              {leftIcon}
            </div>
          )}

          <input
            ref={ref}
            id={inputId}
            disabled={disabled}
            aria-invalid={hasError}
            aria-describedby={
              hasError ? errorId : helperText ? helperId : undefined
            }
            className={`
              w-full rounded-md text-sm transition-colors duration-150
              bg-surface-input text-content-primary placeholder:text-content-muted
              border ${
                hasError
                  ? 'border-status-danger focus:border-status-danger focus:ring-1 focus:ring-status-danger'
                  : 'border-border-default focus:border-brand focus:ring-1 focus:ring-brand'
              }
              ${leftIcon ? 'pl-9' : 'pl-3.5'}
              ${rightIcon || hasError ? 'pr-9' : 'pr-3.5'}
              py-2 outline-none
              disabled:opacity-50 disabled:bg-surface-subtle disabled:cursor-not-allowed
              ${className}
            `}
            {...rest}
          />

          {hasError ? (
            <div className="absolute right-3 flex items-center pointer-events-none text-status-danger">
              <AlertCircle className="w-4 h-4" aria-hidden="true" />
            </div>
          ) : (
            rightIcon && (
              <div className="absolute right-3 flex items-center text-content-muted">
                {rightIcon}
              </div>
            )
          )}
        </div>

        {errorMessage && (
          <p id={errorId} role="alert" className="text-xs text-status-danger flex items-center gap-1 mt-0.5">
            {errorMessage}
          </p>
        )}

        {!hasError && helperText && (
          <p id={helperId} className="text-xs text-content-muted mt-0.5">
            {helperText}
          </p>
        )}
      </div>
    );
  },
);

Input.displayName = 'Input';

