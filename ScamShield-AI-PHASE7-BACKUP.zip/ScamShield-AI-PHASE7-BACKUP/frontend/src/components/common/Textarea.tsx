import React, { forwardRef, useId } from 'react';
import { AlertCircle } from 'lucide-react';

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  helperText?: string;
  error?: string | boolean;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  (
    {
      label,
      helperText,
      error,
      id: customId,
      disabled,
      rows = 4,
      className = '',
      ...rest
    },
    ref,
  ) => {
    const generatedId = useId();
    const textareaId = customId || generatedId;
    const errorId = `${textareaId}-error`;
    const helperId = `${textareaId}-helper`;

    const hasError = Boolean(error);
    const errorMessage = typeof error === 'string' ? error : undefined;

    return (
      <div className="w-full flex flex-col gap-1.5">
        {label && (
          <label
            htmlFor={textareaId}
            className="text-xs font-medium text-content-secondary flex items-center justify-between"
          >
            <span>{label}</span>
          </label>
        )}

        <div className="relative">
          <textarea
            ref={ref}
            id={textareaId}
            rows={rows}
            disabled={disabled}
            aria-invalid={hasError}
            aria-describedby={
              hasError ? errorId : helperText ? helperId : undefined
            }
            className={`
              w-full rounded-md text-sm transition-colors duration-150 resize-y
              bg-surface-input text-content-primary placeholder:text-content-muted
              border ${
                hasError
                  ? 'border-status-danger focus:border-status-danger focus:ring-1 focus:ring-status-danger'
                  : 'border-border-default focus:border-brand focus:ring-1 focus:ring-brand'
              }
              p-3 outline-none
              disabled:opacity-50 disabled:bg-surface-subtle disabled:cursor-not-allowed
              ${className}
            `}
            {...rest}
          />

          {hasError && (
            <div className="absolute top-3 right-3 pointer-events-none text-status-danger">
              <AlertCircle className="w-4 h-4" aria-hidden="true" />
            </div>
          )}
        </div>

        {errorMessage && (
          <p id={errorId} role="alert" className="text-xs text-status-danger flex items-center gap-1 mt-0.5">
            {errorMessage}
          </p>
        )}

        {!hasError && helperText && (
          <p id={helperId} className="text-xs text-content-muted mt-0.5">
            {helperText}
          </p>
        )}
      </div>
    );
  },
);

Textarea.displayName = 'Textarea';

