import React from 'react';

export type BadgeVariant = 'default' | 'neutral' | 'success' | 'warning' | 'danger' | 'info';
export type BadgeSize = 'sm' | 'md';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant;
  size?: BadgeSize;
  dot?: boolean;
  children: React.ReactNode;
}

const variantStyles: Record<BadgeVariant, { container: string; dot: string }> = {
  default: {
    container: 'bg-brand/10 text-brand border-brand/30',
    dot: 'bg-brand',
  },
  neutral: {
    container: 'bg-surface-elevated text-content-secondary border-border-default',
    dot: 'bg-content-muted',
  },
  success: {
    container: 'bg-status-success-bg text-status-success border-status-success-border',
    dot: 'bg-status-success',
  },
  warning: {
    container: 'bg-status-warning-bg text-status-warning border-status-warning-border',
    dot: 'bg-status-warning',
  },
  danger: {
    container: 'bg-status-danger-bg text-status-danger border-status-danger-border',
    dot: 'bg-status-danger',
  },
  info: {
    container: 'bg-status-info-bg text-status-info border-status-info-border',
    dot: 'bg-status-info',
  },
};

const sizeStyles: Record<BadgeSize, string> = {
  sm: 'px-2 py-0.5 text-xs',
  md: 'px-2.5 py-1 text-xs font-medium',
};

export const Badge: React.FC<BadgeProps> = ({
  variant = 'default',
  size = 'md',
  dot = false,
  children,
  className = '',
  ...rest
}) => {
  const currentVariant = variantStyles[variant];

  return (
    <span
      className={`
        inline-flex items-center gap-1.5 rounded-full border font-mono tracking-tight
        ${currentVariant.container}
        ${sizeStyles[size]}
        ${className}
      `}
      {...rest}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${currentVariant.dot}`} />}
      <span>{children}</span>
    </span>
  );
};

