import { Component, ErrorInfo, ReactNode } from 'react';
import { ShieldAlert, RefreshCw, Home } from 'lucide-react';
import { Card, CardContent } from './Card';
import { Button } from './Button';
import { sanitizeErrorMessage, sanitizeComponentStack } from './errorBoundaryUtils';

export interface ErrorBoundaryProps {
  children: ReactNode;
  fallback?: ReactNode | ((error: Error, reset: () => void) => ReactNode);
  onReset?: () => void;
  onNavigateHome?: () => void;
  componentName?: string;
}

export interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      error,
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    // Sanitize diagnostic logging: log only safe error name and message without exposing raw data or PII
    const sanitizedDiagnostics = {
      name: error.name || 'ComponentRenderError',
      message: sanitizeErrorMessage(error.message),
      component: this.props.componentName || 'ScopedComponent',
      componentStack: sanitizeComponentStack(errorInfo.componentStack),
    };

    console.error('[ScamShield UI Boundary]', sanitizedDiagnostics);
  }

  handleReset = (): void => {
    this.setState({ hasError: false, error: null });
    if (this.props.onReset) {
      this.props.onReset();
    }
  };

  handleNavigateHome = (): void => {
    this.setState({ hasError: false, error: null });
    if (this.props.onNavigateHome) {
      this.props.onNavigateHome();
    }
  };

  render(): ReactNode {
    if (this.state.hasError) {
      try {
        if (this.props.fallback) {
          if (typeof this.props.fallback === 'function') {
            return this.props.fallback(
              this.state.error || new Error('Unknown error'),
              this.handleReset,
            );
          }
          return this.props.fallback;
        }

        return (
          <div
            role="alert"
            aria-live="assertive"
            className="py-8 px-4 flex items-center justify-center min-h-[300px]"
          >
            <Card variant="default" className="border-status-danger-border bg-status-danger-bg/10 max-w-lg w-full">
              <CardContent className="p-6 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-lg bg-status-danger-bg border border-status-danger-border text-status-danger shrink-0 mt-0.5">
                    <ShieldAlert className="w-5 h-5" />
                  </div>

                  <div className="space-y-1.5 flex-1 min-w-0">
                    <h3 className="text-sm font-semibold text-content-primary">
                      Interface Module Interruption
                    </h3>
                    <p className="text-xs text-content-secondary leading-relaxed">
                      A runtime error occurred in {this.props.componentName || 'this module'}. The application has isolated the interruption to protect platform security and state integrity.
                    </p>
                    <p className="text-[11px] font-mono text-content-muted">
                      Defensive isolation active • Sensitive details masked
                    </p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-3 border-t border-border-subtle">
                  {this.props.onNavigateHome && (
                    <Button
                      variant="outline"
                      size="sm"
                      leftIcon={<Home className="w-3.5 h-3.5" />}
                      onClick={this.handleNavigateHome}
                    >
                      Return to Overview
                    </Button>
                  )}

                  <Button
                    variant="primary"
                    size="sm"
                    leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
                    onClick={this.handleReset}
                  >
                    Reload Module
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      } catch (fallbackError: unknown) {
        // Safe ultra-minimal fallback using native HTML elements with zero external dependencies
        console.error('[ScamShield UI Boundary] Fallback render failed', {
          fallbackFailure: fallbackError instanceof Error ? fallbackError.message : 'Unknown fallback failure',
        });

        return (
          <div
            role="alert"
            aria-live="assertive"
            style={{
              padding: '24px',
              margin: '16px auto',
              maxWidth: '480px',
              textAlign: 'center',
              backgroundColor: 'rgba(239, 68, 68, 0.1)',
              border: '1px solid rgba(239, 68, 68, 0.4)',
              borderRadius: '8px',
              color: '#ef4444',
              fontFamily: 'sans-serif',
            }}
          >
            <h3 style={{ fontSize: '14px', fontWeight: 600, margin: '0 0 8px 0' }}>
              Interface Module Interruption
            </h3>
            <p style={{ fontSize: '12px', color: '#9ca3af', margin: '0 0 16px 0', lineHeight: 1.5 }}>
              A critical interface fault occurred. You may return to the Overview view or reload the module.
            </p>
            <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
              {this.props.onNavigateHome && (
                <button
                  type="button"
                  onClick={this.handleNavigateHome}
                  style={{
                    padding: '6px 12px',
                    fontSize: '12px',
                    backgroundColor: 'transparent',
                    border: '1px solid #4b5563',
                    color: '#e5e7eb',
                    borderRadius: '6px',
                    cursor: 'pointer',
                  }}
                >
                  Return to Overview
                </button>
              )}
              <button
                type="button"
                onClick={this.handleReset}
                style={{
                  padding: '6px 12px',
                  fontSize: '12px',
                  backgroundColor: '#ef4444',
                  border: 'none',
                  color: '#ffffff',
                  borderRadius: '6px',
                  cursor: 'pointer',
                }}
              >
                Reload Module
              </button>
            </div>
          </div>
        );
      }
    }

    return this.props.children;
  }
}
