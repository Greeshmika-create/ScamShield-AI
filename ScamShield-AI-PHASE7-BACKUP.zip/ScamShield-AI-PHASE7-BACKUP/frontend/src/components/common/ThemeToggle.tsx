import React from 'react';
import { Sun, Moon } from 'lucide-react';
import { useTheme } from '../../hooks/useTheme';

export interface ThemeToggleProps {
  className?: string;
  size?: 'sm' | 'md';
}

export const ThemeToggle: React.FC<ThemeToggleProps> = ({
  className = '',
  size = 'md',
}) => {
  const { theme, toggleTheme, isDark } = useTheme();

  const isSmall = size === 'sm';
  const label = isDark ? 'Switch to light theme' : 'Switch to dark theme';

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={label}
      title={label}
      className={`
        relative inline-flex items-center justify-center rounded-lg border border-border-default
        bg-surface-elevated text-content-secondary hover:text-content-primary hover:border-border-strong
        transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:ring-offset-surface-app
        ${isSmall ? 'p-1.5' : 'p-2'}
        ${className}
      `}
    >
      <span className="sr-only">{label}</span>
      {isDark ? (
        <Sun className={`${isSmall ? 'w-4 h-4' : 'w-4.5 h-4.5'} text-amber-400 transition-transform duration-200 hover:rotate-45`} />
      ) : (
        <Moon className={`${isSmall ? 'w-4 h-4' : 'w-4.5 h-4.5'} text-slate-700 transition-transform duration-200 hover:-rotate-12`} />
      )}
      <span className="hidden md:inline-block ml-2 text-xs font-mono capitalize">
        {theme}
      </span>
    </button>
  );
};

