import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import {
  sanitizeErrorMessage,
  sanitizeComponentStack,
} from './errorBoundaryUtils.ts';

describe('ErrorBoundary Diagnostic Sanitization & PII Protection', () => {
  test('1. sanitizeErrorMessage masks JWT tokens', () => {
    const raw = 'Failed to load user session with token eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c in session storage';
    const sanitized = sanitizeErrorMessage(raw);
    assert.ok(!sanitized.includes('eyJhbGciOiJIUzI1NiIs'), 'JWT token header must be masked');
    assert.ok(!sanitized.includes('SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c'), 'JWT signature must be masked');
    assert.ok(sanitized.includes('[TOKEN_MASKED]'), 'Masking placeholder must be present');
  });

  test('2. sanitizeErrorMessage masks Bearer tokens', () => {
    const raw = 'Request header contains Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.xyz.abc';
    const sanitized = sanitizeErrorMessage(raw);
    assert.ok(!sanitized.includes('eyJhbGciOiJIUzI1NiIs'));
    assert.ok(sanitized.includes('Bearer [TOKEN_MASKED]'));
  });

  test('3. sanitizeErrorMessage masks sensitive query parameters in URLs', () => {
    const raw = 'Failed to fetch https://api.supabase.com/auth/v1/verify?apikey=anon-key-12345&otp=987654&token=sec_abc_789&user_id=123';
    const sanitized = sanitizeErrorMessage(raw);
    assert.ok(!sanitized.includes('anon-key-12345'), 'API key query param must be masked');
    assert.ok(!sanitized.includes('987654'), 'OTP query param must be masked');
    assert.ok(!sanitized.includes('sec_abc_789'), 'Token query param must be masked');
    assert.ok(sanitized.includes('apikey=[MASKED]'));
    assert.ok(sanitized.includes('otp=[MASKED]'));
    assert.ok(sanitized.includes('token=[MASKED]'));
    assert.ok(sanitized.includes('user_id=123'), 'Non-sensitive query params should be preserved');
  });

  test('4. sanitizeErrorMessage masks password and OTP key-values in strings', () => {
    const raw = 'AuthError: password: SuperSecretPassword123! failed verification with otp: 654321';
    const sanitized = sanitizeErrorMessage(raw);
    assert.ok(!sanitized.includes('SuperSecretPassword123!'), 'Password must be masked');
    assert.ok(!sanitized.includes('654321'), 'OTP must be masked');
    assert.ok(sanitized.includes('password: [MASKED]'));
    assert.ok(sanitized.includes('otp: [MASKED]'));
  });

  test('5. sanitizeComponentStack strips filesystem paths and cleans stack', () => {
    const rawStack = `
      in ScannerView (at C:\\Users\\SHYAM SIMHA\\Documents\\ScamShield-AI\\frontend\\src\\views\\ScannerView.tsx:42)
      in ErrorBoundary (at C:\\Users\\SHYAM SIMHA\\Documents\\ScamShield-AI\\frontend\\src\\App.tsx:60)
      in AppLayout (at C:\\Users\\SHYAM SIMHA\\Documents\\ScamShield-AI\\frontend\\src\\App.tsx:51)
    `;
    const sanitized = sanitizeComponentStack(rawStack);
    assert.ok(!sanitized.includes('C:\\Users'), 'Local absolute path must be stripped');
    assert.ok(!sanitized.includes('.tsx:42'), 'File line details must be stripped');
    assert.ok(sanitized.includes('in ScannerView'), 'Component hierarchy must be preserved');
    assert.ok(sanitized.includes('in ErrorBoundary'));
  });

  test('6. sanitizeErrorMessage handles empty or non-string inputs safely', () => {
    assert.equal(sanitizeErrorMessage(''), 'Unknown render interruption');
    // @ts-expect-error Testing runtime invalid input
    assert.equal(sanitizeErrorMessage(null), 'Unknown render interruption');
    // @ts-expect-error Testing runtime invalid input
    assert.equal(sanitizeErrorMessage(undefined), 'Unknown render interruption');
  });

  test('7. sanitizeComponentStack handles empty or invalid stack traces safely', () => {
    assert.equal(sanitizeComponentStack(null), 'unavailable');
    assert.equal(sanitizeComponentStack(undefined), 'unavailable');
    assert.equal(sanitizeComponentStack(''), 'unavailable');
  });
});
