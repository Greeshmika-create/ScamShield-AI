import React from 'react';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'elevated' | 'subtle';
}

const cardVariants = {
  default: 'bg-surface-card border-border-subtle shadow-card',
  elevated: 'bg-surface-elevated border-border-default shadow-elevated',
  subtle: 'bg-surface-subtle border-border-subtle',
};

export const Card: React.FC<CardProps> = ({
  variant = 'default',
  children,
  className = '',
  ...rest
}) => {
  return (
    <div
      className={`
        rounded-xl border transition-colors duration-150
        ${cardVariants[variant]}
        ${className}
      `}
      {...rest}
    >
      {children}
    </div>
  );
};

export interface CardHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  action?: React.ReactNode;
}

export const CardHeader: React.FC<CardHeaderProps> = ({
  action,
  children,
  className = '',
  ...rest
}) => {
  return (
    <div
      className={`p-5 md:p-6 pb-4 flex items-start justify-between gap-4 border-b border-border-subtle ${className}`}
      {...rest}
    >
      <div className="flex-1 min-w-0">{children}</div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
};

export const CardTitle: React.FC<React.HTMLAttributes<HTMLHeadingElement>> = ({
  children,
  className = '',
  ...rest
}) => {
  return (
    <h3
      className={`text-base font-semibold text-content-primary tracking-tight ${className}`}
      {...rest}
    >
      {children}
    </h3>
  );
};

export const CardDescription: React.FC<React.HTMLAttributes<HTMLParagraphElement>> = ({
  children,
  className = '',
  ...rest
}) => {
  return (
    <p className={`text-xs text-content-muted mt-1 ${className}`} {...rest}>
      {children}
    </p>
  );
};

export const CardContent: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({
  children,
  className = '',
  ...rest
}) => {
  return (
    <div className={`p-5 md:p-6 ${className}`} {...rest}>
      {children}
    </div>
  );
};

export const CardFooter: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({
  children,
  className = '',
  ...rest
}) => {
  return (
    <div
      className={`p-4 md:px-6 py-3 border-t border-border-subtle bg-surface-subtle/50 rounded-b-xl flex items-center justify-between text-xs text-content-muted ${className}`}
      {...rest}
    >
      {children}
    </div>
  );
};

