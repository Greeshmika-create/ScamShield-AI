// ==============================================================================
// ScamShield AI — Versioned API Contracts (v1.0)
// Matches docs/API_SPEC.md exactly
// ==============================================================================

export type Verdict = 'MALICIOUS' | 'SUSPICIOUS' | 'NO_KNOWN_THREAT' | 'UNVERIFIED';

export type ProviderStatus =
  | 'AVAILABLE_CLEAN'
  | 'AVAILABLE_FLAGGED'
  | 'TIMEOUT'
  | 'ERROR'
  | 'UNCONFIGURED';

export type FindingSeverity = 'INFO' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface ThreatFinding {
  category: 'INTEL' | 'HEURISTIC' | 'ML' | 'LINGUISTIC' | string;
  rule_name: string;
  severity: FindingSeverity;
  title: string;
  description: string;
  raw_evidence?: Record<string, unknown>;
}

export interface ProviderReport {
  provider_name: string;
  status: ProviderStatus;
  response_time_ms: number;
  threat_details?: string | null;
}

export interface OptionalDomainIntel {
  domain_age_days?: number | null;
  registrar?: string | null;
  ssl_issuer?: string | null;
  ssl_valid?: boolean | null;
}

export interface URLScanRequest {
  url: string;
}

export interface URLScanResponse {
  scan_id: string;
  scanned_at: string;
  target_url: string;
  canonical_url: string;
  target_domain: string;
  verdict: Verdict;
  risk_score: number;
  confidence_level: 'HIGH' | 'MEDIUM' | 'PROVISIONAL';
  threat_intelligence: ProviderReport[];
  findings: ThreatFinding[];
  domain_intelligence?: OptionalDomainIntel | null;
  ml_analysis: {
    threat_probability: number;
    top_contributing_features?: Array<{ feature: string; value: number; impact: string }>;
  };
  execution_time_ms: number;
}

export interface MessageScanRequest {
  message_text: string;
  sender_identifier?: string;
}

export interface MessageScanResponse {
  scan_id: string;
  scanned_at: string;
  message_preview: string;
  detected_language: 'ENGLISH' | 'TELUGU_SCRIPT' | 'TELUGISH' | 'MIXED' | string;
  extracted_urls: string[];
  verdict: Verdict;
  risk_score: number;
  confidence_level: 'HIGH' | 'MEDIUM' | 'PROVISIONAL';
  findings: ThreatFinding[];
  ml_analysis: {
    threat_probability: number;
    top_contributing_ngrams?: string[];
  };
  user_guidance: {
    english: string;
    telugu: string;
  };
  execution_time_ms: number;
}

export interface APIErrorResponse {
  error_code: string;
  message: string;
  details?: Record<string, unknown>;
  timestamp?: string;
}

// ==============================================================================
// History & Telemetry Contracts (docs/API_SPEC.md Sections 2.3 & 2.4)
// ==============================================================================

export interface HistoryItem {
  scan_id: string;
  scanned_at: string;
  target_type: 'URL' | 'MESSAGE';
  target_preview: string;
  verdict: Verdict;
  risk_score: number;
  execution_time_ms: number;
}

export interface HistoryQueryParams {
  limit?: number;
  offset?: number;
  target_type?: 'URL' | 'MESSAGE' | null;
  verdict?: Verdict | null;
}

export interface HistoryResponse {
  total_count: number;
  limit: number;
  offset: number;
  items: HistoryItem[];
}

export interface AnalyticsOverviewResponse {
  total_scans: number;
  verdict_distribution: {
    MALICIOUS: number;
    SUSPICIOUS: number;
    NO_KNOWN_THREAT: number;
    UNVERIFIED: number;
  };
  average_scan_latency_ms: number;
  detected_language_distribution: Record<string, number>;
  top_threat_categories: Array<{ category: string; count: number }>;
}

export class ScanServiceError extends Error {
  public readonly errorCode: string;
  public readonly status?: number;
  public readonly details?: Record<string, unknown>;

  constructor(message: string, errorCode = 'SCAN_ERROR', status?: number, details?: Record<string, unknown>) {
    super(message);
    this.name = 'ScanServiceError';
    this.errorCode = errorCode;
    this.status = status;
    this.details = details;
  }
}

