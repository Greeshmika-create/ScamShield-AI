// ==============================================================================
// ScamShield AI — Authentication Domain Types
// Strictly defines client-side contracts for Phase 2.7 Auth UI
// ==============================================================================

export type AuthScreen =
  | 'login'
  | 'register'
  | 'forgot-password'
  | 'verify-otp'
  | 'reset-password';

export type UserRole = 'USER' | 'ADMIN' | 'OWNER';

export interface AuthUser {
  id: string;
  email: string;
  fullName: string;
  role: UserRole;
  createdAt: string;
}

export interface PasswordValidation {
  hasMinLength: boolean;
  hasUpperCase: boolean;
  hasLowerCase: boolean;
  hasNumber: boolean;
  hasSpecialChar: boolean;
  isValid: boolean;
  score: number; // 0 to 4
  feedback: string;
}

export interface LoginFormData {
  email: string;
  password: string;
  rememberMe: boolean;
}

export interface SignupFormData {
  fullName: string;
  email: string;
  password: string;
  confirmPassword: string;
  agreedToTerms: boolean;
}

export interface ForgotPasswordFormData {
  email: string;
}

export interface OTPFormData {
  otp: string; // 6-digit string
}

export interface ResetPasswordFormData {
  newPassword: string;
  confirmPassword: string;
}

