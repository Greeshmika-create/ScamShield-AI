import React, { useState } from 'react';
import { ThemeProvider } from './context/ThemeProvider';
import { AppLayout } from './components/layout/AppLayout';
import { NavSection } from './components/layout/types';
import { clearAccessToken, setAccessToken } from './api/authSession.ts';
import { demoLogin } from './api/authService';
import { ErrorBoundary } from './components/common';
import {
  OverviewView,
  ScannerView,
  HistoryView,
  AnalyticsView,
  AuthView,
} from './views';

export const ScamShieldApp: React.FC = () => {
  // Start in authentication entry view as specified in Phase 2.7
  const [isAuthActive, setIsAuthActive] = useState<boolean>(true);
  const [activeSection, setActiveSection] = useState<NavSection>('overview');

  const renderActiveSection = () => {
    switch (activeSection) {
      case 'overview':
        return <OverviewView onNavigateToScanner={() => setActiveSection('scanner')} />;
      case 'scanner':
        return <ScannerView />;
      case 'history':
        return <HistoryView />;
      case 'analytics':
        return <AnalyticsView />;
      default:
        return <OverviewView onNavigateToScanner={() => setActiveSection('scanner')} />;
    }
  };

  // If Auth view is active, render the dedicated authentication module
  if (isAuthActive) {
    return (
      <ErrorBoundary
        componentName="Authentication Module"
        onNavigateHome={() => setIsAuthActive(false)}
      >
        <AuthView
          initialScreen="login"
          onContinueAsGuest={() => setIsAuthActive(false)}
          onGuestLogin={async () => {
            const session = await demoLogin();
            setAccessToken(session.access_token);
          }}
          onAuthenticated={() => setIsAuthActive(false)}
        />
      </ErrorBoundary>
    );
  }

  // Otherwise render the main application layout in guest/analyst mode
  return (
    <AppLayout
      activeSection={activeSection}
      onSelectSection={setActiveSection}
      onOpenAuth={() => setIsAuthActive(true)}
      onSignOut={() => {
        clearAccessToken();
        setIsAuthActive(true);
      }}
    >
      <ErrorBoundary
        key={activeSection}
        componentName={`${activeSection.charAt(0).toUpperCase() + activeSection.slice(1)} Module`}
        onNavigateHome={() => setActiveSection('overview')}
      >
        {renderActiveSection()}
      </ErrorBoundary>
    </AppLayout>
  );
};

export const App: React.FC = () => {
  return (
    <ThemeProvider defaultTheme="dark">
      <ScamShieldApp />
    </ThemeProvider>
  );
};

export default App;
