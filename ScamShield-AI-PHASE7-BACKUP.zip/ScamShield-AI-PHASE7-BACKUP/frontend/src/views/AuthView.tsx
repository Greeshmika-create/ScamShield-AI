import React, { useState } from 'react';
import { AuthScreen } from '../types/auth';
import {
  AuthLayout,
  LoginForm,
  SignupForm,
  ForgotPasswordForm,
  OTPVerificationForm,
  ResetPasswordForm,
} from '../components/auth';

export interface AuthViewProps {
  initialScreen?: AuthScreen;
  onContinueAsGuest: () => void;
  onGuestLogin: () => Promise<void>;
  onAuthenticated: () => void;
}

export const AuthView: React.FC<AuthViewProps> = ({
  initialScreen = 'login',
  onContinueAsGuest,
  onGuestLogin,
  onAuthenticated,
}) => {
  const [currentScreen, setCurrentScreen] = useState<AuthScreen>(initialScreen);
  const [transientEmail, setTransientEmail] = useState<string>('');

  const getScreenMetadata = (): { title: string; subtitle: string } => {
    switch (currentScreen) {
      case 'login':
        return {
          title: 'Analyst Sign In',
          subtitle: 'Authenticate to access persistent audit records and telemetry.',
        };
      case 'register':
        return {
          title: 'Create Analyst Account',
          subtitle: 'Register your security profile for authenticated forensic investigations.',
        };
      case 'forgot-password':
        return {
          title: 'Account Recovery (UI Preview)',
          subtitle: 'Preview the recovery email interface. Live code dispatch connects to Supabase in Phase 3.',
        };
      case 'verify-otp':
        return {
          title: 'OTP Verification (UI Preview)',
          subtitle: 'Preview the 6-digit code entry interface. Code delivery and verification are simulated.',
        };
      case 'reset-password':
        return {
          title: 'Reset Password (UI Preview)',
          subtitle: 'Preview password validation rules. No live user credentials will be altered.',
        };
      default:
        return {
          title: 'Authentication',
          subtitle: 'ScamShield AI Enterprise Threat Platform',
        };
    }
  };

  const { title, subtitle } = getScreenMetadata();

  const renderActiveScreen = () => {
    switch (currentScreen) {
      case 'login':
        return (
          <LoginForm
            onNavigate={setCurrentScreen}
            onAuthenticated={onAuthenticated}
          />
        );
      case 'register':
        return <SignupForm onNavigate={setCurrentScreen} />;
      case 'forgot-password':
        return (
          <ForgotPasswordForm
            initialEmail={transientEmail}
            onEmailSubmitted={(email) => {
              setTransientEmail(email);
            }}
            onNavigate={setCurrentScreen}
          />
        );
      case 'verify-otp':
        return (
          <OTPVerificationForm
            email={transientEmail}
            onNavigate={setCurrentScreen}
            onOtpVerified={() => {
              // Proceed to reset password
            }}
          />
        );
      case 'reset-password':
        return <ResetPasswordForm onNavigate={setCurrentScreen} />;
      default:
        return (
          <LoginForm
            onNavigate={setCurrentScreen}
            onAuthenticated={onAuthenticated}
          />
        );
    }
  };

  return (
    <AuthLayout
      title={title}
      subtitle={subtitle}
      onContinueAsGuest={async () => {
        await onGuestLogin();
        onContinueAsGuest();
      }}
    >
      {renderActiveScreen()}
    </AuthLayout>
  );
};

