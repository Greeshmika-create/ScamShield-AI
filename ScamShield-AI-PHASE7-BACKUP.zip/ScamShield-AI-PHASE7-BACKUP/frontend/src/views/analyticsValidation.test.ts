import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { validateAnalyticsPayload } from './analyticsValidation.ts';

describe('Analytics Payload Validation & Null-Safety', () => {
  // Scenario 1: Normal valid analytics response
  it('1. correctly parses and normalizes a normal valid analytics response', () => {
    const validPayload = {
      total_scans: 150,
      verdict_distribution: {
        MALICIOUS: 60,
        SUSPICIOUS: 40,
        NO_KNOWN_THREAT: 45,
        UNVERIFIED: 5,
      },
      average_scan_latency_ms: 320,
      detected_language_distribution: {
        English: 80,
        'Telugu Script': 45,
        Telugish: 25,
      },
      top_threat_categories: [
        { category: 'Phishing', count: 50 },
        { category: 'Electricity Fraud', count: 30 },
      ],
    };

    const result = validateAnalyticsPayload(validPayload);
    assert.equal(result.status, 'VALID');
    if (result.status === 'VALID') {
      assert.equal(result.data.totalScans, 150);
      assert.equal(result.data.hasValidVerdictDistribution, true);
      assert.deepEqual(result.data.verdictDistribution, {
        MALICIOUS: 60,
        SUSPICIOUS: 40,
        NO_KNOWN_THREAT: 45,
        UNVERIFIED: 5,
      });
      assert.equal(result.data.averageLatencyMs, 320);
      assert.equal(result.data.languageDistribution['English'], 80);
      assert.equal(result.data.topThreatCategories.length, 2);
    }
  });

  // Scenario 2: Missing verdict_distribution (undefined)
  it('2. handles missing (undefined) verdict_distribution without fabricating zeros', () => {
    const missingDistPayload = {
      total_scans: 85,
      average_scan_latency_ms: 250,
      detected_language_distribution: { English: 50 },
      top_threat_categories: [],
    };

    const result = validateAnalyticsPayload(missingDistPayload);
    assert.equal(result.status, 'VALID');
    if (result.status === 'VALID') {
      assert.equal(result.data.totalScans, 85);
      // Must distinguish unavailable from genuine zeros
      assert.equal(result.data.hasValidVerdictDistribution, false);
      assert.equal(result.data.verdictDistribution, null);
    }
  });

  // Scenario 3: Null verdict_distribution
  it('3. handles null verdict_distribution safely without fabricating fake metrics', () => {
    const nullDistPayload = {
      total_scans: 42,
      verdict_distribution: null,
      average_scan_latency_ms: 180,
      detected_language_distribution: {},
      top_threat_categories: [],
    };

    const result = validateAnalyticsPayload(nullDistPayload);
    assert.equal(result.status, 'VALID');
    if (result.status === 'VALID') {
      assert.equal(result.data.totalScans, 42);
      assert.equal(result.data.hasValidVerdictDistribution, false);
      assert.equal(result.data.verdictDistribution, null);
    }
  });

  // Scenario 4: Missing individual verdict category (e.g. UNVERIFIED omitted)
  it('4. handles missing individual category according to API contract when distribution exists', () => {
    const partialCategoryPayload = {
      total_scans: 100,
      verdict_distribution: {
        MALICIOUS: 50,
        SUSPICIOUS: 30,
        NO_KNOWN_THREAT: 20,
        // UNVERIFIED is omitted by backend
      },
    };

    const result = validateAnalyticsPayload(partialCategoryPayload);
    assert.equal(result.status, 'VALID');
    if (result.status === 'VALID') {
      assert.equal(result.data.totalScans, 100);
      assert.equal(result.data.hasValidVerdictDistribution, true);
      assert.deepEqual(result.data.verdictDistribution, {
        MALICIOUS: 50,
        SUSPICIOUS: 30,
        NO_KNOWN_THREAT: 20,
        UNVERIFIED: 0, // Safe contract default for omitted category
      });
    }
  });

  // Scenario 5: Empty valid distribution (total_scans: 0)
  it('5. returns EMPTY status for an authentic zero-count scan state', () => {
    const emptyPayload = {
      total_scans: 0,
      verdict_distribution: {
        MALICIOUS: 0,
        SUSPICIOUS: 0,
        NO_KNOWN_THREAT: 0,
        UNVERIFIED: 0,
      },
      average_scan_latency_ms: 0,
      detected_language_distribution: {},
      top_threat_categories: [],
    };

    const result = validateAnalyticsPayload(emptyPayload);
    assert.equal(result.status, 'EMPTY');
  });

  // Scenario 6: Completely malformed analytics payload
  it('6. returns MALFORMED status for non-object, missing total_scans, or corrupt payloads', () => {
    // Null input
    assert.equal(validateAnalyticsPayload(null).status, 'MALFORMED');

    // String input
    assert.equal(validateAnalyticsPayload('Internal Server Error').status, 'MALFORMED');

    // Array input
    assert.equal(validateAnalyticsPayload([1, 2, 3]).status, 'MALFORMED');

    // Empty object missing total_scans
    assert.equal(validateAnalyticsPayload({}).status, 'MALFORMED');

    // Negative total_scans
    assert.equal(validateAnalyticsPayload({ total_scans: -10 }).status, 'MALFORMED');

    // Non-numeric total_scans
    assert.equal(validateAnalyticsPayload({ total_scans: 'invalid' }).status, 'MALFORMED');
  });
});
