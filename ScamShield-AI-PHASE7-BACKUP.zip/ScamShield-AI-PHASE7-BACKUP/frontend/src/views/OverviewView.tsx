import React from 'react';
import { ArrowRight, Cpu, Database, Network } from 'lucide-react';
import { Button, Card, CardHeader, CardTitle, CardDescription, CardContent, Badge } from '../components/common';

export interface OverviewViewProps {
  onNavigateToScanner: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({ onNavigateToScanner }) => {
  return (
    <div className="space-y-6">
      {/* Top Section Header */}
      <div>
        <h1 className="text-xl font-bold text-content-primary tracking-tight">
          System Overview & Threat Posture
        </h1>
        <p className="text-xs text-content-muted mt-1">
          High-level operational status and core detection engine telemetry.
        </p>
      </div>

      {/* Honest Empty State / Getting Started Hero */}
      <Card variant="default">
        <CardHeader
          action={
            <Badge variant="neutral" size="sm">
              Architecture v1.0
            </Badge>
          }
        >
          <CardTitle>Inspection Pipeline Ready</CardTitle>
          <CardDescription>
            The ScamShield AI frontend shell is initialized. Real threat data will generate upon executing URL or message investigations.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-lg p-5 bg-surface-subtle border border-border-subtle flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <h2 className="text-sm font-semibold text-content-primary">
                Awaiting Initial Investigation
              </h2>
              <p className="text-xs text-content-muted max-w-xl">
                No active threats have been analyzed yet. Open the Threat Scanner to evaluate a suspicious website link, SMS alert, or WhatsApp message in English, Telugu script, or transliterated Telugish.
              </p>
            </div>
            <Button
              variant="primary"
              size="md"
              rightIcon={<ArrowRight className="w-4 h-4" />}
              onClick={onNavigateToScanner}
            >
              Open Threat Scanner
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Structural Engine Status Grid (Honest configuration status, no fake uptime numbers) */}
      <div>
        <h2 className="text-xs font-mono font-medium text-content-muted uppercase tracking-wider mb-3">
          Architecture Modules Configuration
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card variant="subtle">
            <CardContent className="p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-content-primary text-xs font-medium">
                  <Network className="w-4 h-4 text-brand" />
                  <span>Threat Intelligence</span>
                </div>
                <Badge variant="neutral" size="sm">
                  Phase 3.2
                </Badge>
              </div>
              <p className="text-xs text-content-muted">
                Google Safe Browsing, URLhaus, and PhishTank multi-source IoC verification.
              </p>
            </CardContent>
          </Card>

          <Card variant="subtle">
            <CardContent className="p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-content-primary text-xs font-medium">
                  <Cpu className="w-4 h-4 text-brand" />
                  <span>Machine Learning Engine</span>
                </div>
                <Badge variant="neutral" size="sm">
                  Phase 3.1
                </Badge>
              </div>
              <p className="text-xs text-content-muted">
                32 lexical URL features and multilingual char-ngram Telugu/English NLP model.
              </p>
            </CardContent>
          </Card>

          <Card variant="subtle">
            <CardContent className="p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-content-primary text-xs font-medium">
                  <Database className="w-4 h-4 text-brand" />
                  <span>Persistence & RLS</span>
                </div>
                <Badge variant="neutral" size="sm">
                  Phase 3.3
                </Badge>
              </div>
              <p className="text-xs text-content-muted">
                Supabase PostgreSQL audit tables, finding relations, and 2-hour TTL cache.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
