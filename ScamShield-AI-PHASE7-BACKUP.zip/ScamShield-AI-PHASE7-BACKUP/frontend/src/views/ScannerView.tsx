import React from 'react';
import { ScannerWorkspace } from '../components/scanner';

export const ScannerView: React.FC = () => {
  return <ScannerWorkspace />;
};
