/**
 * ScamShield AI — Analytics Payload Validation & Normalization
 * 
 * Provides strict validation and null-safety for analytics telemetry responses.
 * Distinguishes genuine zero counts from unavailable telemetry without fabricating fake metrics.
 */

export interface ValidatedVerdictDistribution {
  MALICIOUS: number;
  SUSPICIOUS: number;
  NO_KNOWN_THREAT: number;
  UNVERIFIED: number;
}

export interface ValidatedAnalytics {
  totalScans: number;
  hasValidVerdictDistribution: boolean;
  verdictDistribution: ValidatedVerdictDistribution | null;
  averageLatencyMs: number | null;
  languageDistribution: Record<string, number>;
  topThreatCategories: Array<{ category: string; count: number }>;
}

export type AnalyticsParseResult =
  | { status: 'VALID'; data: ValidatedAnalytics }
  | { status: 'EMPTY' }
  | { status: 'MALFORMED'; error: string };

/**
 * Validates a raw analytics response payload against the API contract.
 */
export function validateAnalyticsPayload(raw: unknown): AnalyticsParseResult {
  if (raw === null || typeof raw !== 'object' || Array.isArray(raw)) {
    return {
      status: 'MALFORMED',
      error: 'Analytics payload must be a non-null JSON object.',
    };
  }

  const record = raw as Record<string, unknown>;

  // Check total_scans (must be a non-negative finite number)
  if (
    typeof record.total_scans !== 'number' ||
    !Number.isFinite(record.total_scans) ||
    record.total_scans < 0
  ) {
    return {
      status: 'MALFORMED',
      error: 'Missing or invalid "total_scans" metric in analytics telemetry.',
    };
  }

  const totalScans = Math.floor(record.total_scans);

  // If total_scans is 0, this represents an authentic empty state (no investigations recorded yet)
  if (totalScans === 0) {
    return { status: 'EMPTY' };
  }

  // Evaluate verdict_distribution
  let hasValidVerdictDistribution = false;
  let verdictDistribution: ValidatedVerdictDistribution | null = null;

  const rawDist = record.verdict_distribution;
  if (rawDist !== undefined && rawDist !== null && typeof rawDist === 'object' && !Array.isArray(rawDist)) {
    hasValidVerdictDistribution = true;
    const distRecord = rawDist as Record<string, unknown>;

    // Missing individual categories default to 0 according to API contract if the distribution itself exists
    const toNonNegativeNum = (val: unknown): number => {
      if (typeof val === 'number' && Number.isFinite(val) && val >= 0) {
        return Math.floor(val);
      }
      return 0;
    };

    verdictDistribution = {
      MALICIOUS: toNonNegativeNum(distRecord.MALICIOUS),
      SUSPICIOUS: toNonNegativeNum(distRecord.SUSPICIOUS),
      NO_KNOWN_THREAT: toNonNegativeNum(distRecord.NO_KNOWN_THREAT),
      UNVERIFIED: toNonNegativeNum(distRecord.UNVERIFIED),
    };
  } else {
    // If verdict_distribution is missing, undefined, or null:
    // DO NOT fabricate zero values. Distinguish unavailable telemetry from genuine zeros.
    hasValidVerdictDistribution = false;
    verdictDistribution = null;
  }

  // Evaluate average_scan_latency_ms
  let averageLatencyMs: number | null = null;
  if (
    typeof record.average_scan_latency_ms === 'number' &&
    Number.isFinite(record.average_scan_latency_ms) &&
    record.average_scan_latency_ms >= 0
  ) {
    averageLatencyMs = Math.round(record.average_scan_latency_ms);
  }

  // Evaluate detected_language_distribution
  const languageDistribution: Record<string, number> = {};
  const rawLang = record.detected_language_distribution;
  if (rawLang !== null && typeof rawLang === 'object' && !Array.isArray(rawLang)) {
    for (const [key, val] of Object.entries(rawLang as Record<string, unknown>)) {
      if (typeof val === 'number' && Number.isFinite(val) && val >= 0) {
        languageDistribution[key] = Math.floor(val);
      }
    }
  }

  // Evaluate top_threat_categories
  const topThreatCategories: Array<{ category: string; count: number }> = [];
  const rawCats = record.top_threat_categories;
  if (Array.isArray(rawCats)) {
    for (const item of rawCats) {
      if (
        item !== null &&
        typeof item === 'object' &&
        typeof (item as Record<string, unknown>).category === 'string' &&
        typeof (item as Record<string, unknown>).count === 'number' &&
        Number.isFinite((item as Record<string, unknown>).count)
      ) {
        topThreatCategories.push({
          category: String((item as Record<string, unknown>).category),
          count: Math.floor((item as Record<string, unknown>).count as number),
        });
      }
    }
  }

  return {
    status: 'VALID',
    data: {
      totalScans,
      hasValidVerdictDistribution,
      verdictDistribution,
      averageLatencyMs,
      languageDistribution,
      topThreatCategories,
    },
  };
}

