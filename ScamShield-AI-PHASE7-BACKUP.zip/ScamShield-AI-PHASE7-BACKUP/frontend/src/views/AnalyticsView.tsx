import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  Clock,
  RefreshCw,
  ServerOff,
  Activity,
  PieChart,
} from 'lucide-react';
import { ScanServiceError } from '../types/scan';
import { fetchAnalyticsOverview, getApiBaseUrl } from '../api/scanService';
import {
  StatCard,
  VerdictDistributionBar,
  LanguageDistributionCard,
  TopThreatCategoriesCard,
  AnalyticsEmptyState,
} from '../components/analytics';
import { Button, Badge, Card, CardHeader, CardTitle, CardDescription, CardContent } from '../components/common';
import { validateAnalyticsPayload } from './analyticsValidation';

export const AnalyticsView: React.FC = () => {
  const [rawData, setRawData] = useState<unknown | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<ScanServiceError | null>(null);

  const apiBaseUrl = getApiBaseUrl();

  const loadAnalytics = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetchAnalyticsOverview();
      setRawData(response);
    } catch (err: unknown) {
      if (err instanceof ScanServiceError) {
        setError(err);
      } else {
        setError(
          new ScanServiceError(
            err instanceof Error ? err.message : 'Failed to retrieve analytics telemetry.',
            'UNKNOWN_ERROR',
          ),
        );
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAnalytics();
  }, [loadAnalytics]);

  // Strictly validate telemetry payload without assuming nested properties exist
  const parseResult = useMemo(() => {
    if (!rawData) return null;
    return validateAnalyticsPayload(rawData);
  }, [rawData]);

  return (
    <div className="space-y-6">
      {/* Page Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border-subtle pb-4">
        <div>
          <h1 className="text-xl font-bold text-content-primary tracking-tight">
            Security Analytics & Telemetry
          </h1>
          <p className="text-xs text-content-muted mt-1">
            Aggregated threat intelligence metrics, verdict distributions, and regional fraud indicators.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            isLoading={isLoading}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            onClick={() => loadAnalytics()}
          >
            Refresh Telemetry
          </Button>
        </div>
      </div>

      {/* Backend Offline Banner */}
      {error && (
        <Card variant="default" className="border-status-warning-border bg-status-warning-bg/20">
          <CardContent className="p-5 flex items-start gap-3">
            <ServerOff className="w-5 h-5 text-status-warning shrink-0 mt-0.5" />
            <div className="space-y-1.5 flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold text-content-primary">
                  {error.errorCode === 'BACKEND_UNAVAILABLE'
                    ? 'Backend Analytics Service Offline'
                    : `Analytics Service Failure [${error.errorCode}]`}
                </h3>
                <Badge variant="warning" size="sm">
                  {error.status ? `HTTP ${error.status}` : 'Offline'}
                </Badge>
              </div>

              <p className="text-xs text-content-secondary leading-relaxed">
                {error.message}
              </p>

              {/* Task 6 Fix: Added break-all to prevent horizontal mobile overflow */}
              <div className="mt-2 p-3 rounded-md bg-surface-card border border-border-subtle text-xs space-y-1">
                <p className="font-mono text-content-primary break-all">
                  Endpoint: <span className="text-brand">{apiBaseUrl}/analytics/overview</span>
                </p>
                <p className="text-content-muted">
                  ScamShield AI does not treat offline services as zero threat detections, nor does it display simulated or fabricated charts. Live telemetry will generate once the backend analytics worker is active in Phase 3.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Malformed Telemetry Notice (Task 1) */}
      {!isLoading && !error && parseResult?.status === 'MALFORMED' && (
        <Card variant="default" className="border-status-danger-border bg-status-danger-bg/20">
          <CardContent className="p-5 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-status-danger shrink-0 mt-0.5" />
            <div className="space-y-1.5 flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold text-content-primary">
                  Malformed Telemetry Payload
                </h3>
                <Badge variant="danger" size="sm">Schema Error</Badge>
              </div>
              <p className="text-xs text-content-secondary leading-relaxed">
                The analytics backend returned an unexpected response structure that violates API contracts. ScamShield AI enforces strict type safety and refuses to render corrupt data.
              </p>
              <p className="text-[11px] font-mono text-content-muted break-all">
                Details: {parseResult.error}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading Skeleton */}
      {isLoading && !rawData && (
        <div className="p-8 text-center text-xs text-content-muted rounded-xl border border-border-subtle bg-surface-card animate-pulse">
          <span>Aggregating threat metrics from Supabase database...</span>
        </div>
      )}

      {/* Offline State */}
      {!isLoading && error && (
        <AnalyticsEmptyState isOffline onRetry={() => loadAnalytics()} />
      )}

      {/* Empty State (Authentic zero records, or unparseable payload) */}
      {!isLoading && !error && (!parseResult || parseResult.status === 'EMPTY' || parseResult.status === 'MALFORMED') && (
        <AnalyticsEmptyState onRetry={() => loadAnalytics()} />
      )}

      {/* Real Analytics Presentation (Rendered strictly when real valid telemetry exists) */}
      {!isLoading && !error && parseResult?.status === 'VALID' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Top Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              title="Total Investigations"
              value={parseResult.data.totalScans.toLocaleString()}
              subtext="Accumulated scan volume"
              icon={Activity}
              accentColor="brand"
            />

            <StatCard
              title="Malicious Threats"
              value={
                parseResult.data.hasValidVerdictDistribution && parseResult.data.verdictDistribution
                  ? parseResult.data.verdictDistribution.MALICIOUS.toLocaleString()
                  : 'Unavailable'
              }
              subtext={
                parseResult.data.hasValidVerdictDistribution && parseResult.data.verdictDistribution
                  ? `${((parseResult.data.verdictDistribution.MALICIOUS / parseResult.data.totalScans) * 100).toFixed(1)}% threat rate`
                  : 'Verdict telemetry missing'
              }
              icon={ShieldAlert}
              accentColor="danger"
            />

            <StatCard
              title="Suspicious Targets"
              value={
                parseResult.data.hasValidVerdictDistribution && parseResult.data.verdictDistribution
                  ? parseResult.data.verdictDistribution.SUSPICIOUS.toLocaleString()
                  : 'Unavailable'
              }
              subtext={
                parseResult.data.hasValidVerdictDistribution && parseResult.data.verdictDistribution
                  ? 'Heuristic red flags identified'
                  : 'Verdict telemetry missing'
              }
              icon={AlertTriangle}
              accentColor="warning"
            />

            <StatCard
              title="Average Latency"
              value={
                parseResult.data.averageLatencyMs !== null
                  ? `${parseResult.data.averageLatencyMs} ms`
                  : 'N/A'
              }
              subtext={
                parseResult.data.averageLatencyMs !== null
                  ? 'End-to-end pipeline speed'
                  : 'Latency unrecorded'
              }
              icon={Clock}
              accentColor="neutral"
            />
          </div>

          {/* Verdict Distribution Section */}
          {parseResult.data.hasValidVerdictDistribution && parseResult.data.verdictDistribution ? (
            <VerdictDistributionBar
              distribution={parseResult.data.verdictDistribution}
              totalScans={parseResult.data.totalScans}
            />
          ) : (
            <Card variant="default">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <PieChart className="w-4 h-4 text-brand" />
                  <CardTitle>Verdict Distribution</CardTitle>
                </div>
                <CardDescription>
                  Proportional breakdown of authoritative threat verdicts across all investigations.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-6 text-center text-xs text-content-muted rounded-lg bg-surface-subtle border border-border-subtle">
                  <p className="font-semibold text-content-secondary">
                    Verdict Distribution Telemetry Unavailable
                  </p>
                  <p className="mt-1 max-w-md mx-auto text-[11px]">
                    The analytics backend did not provide verdict breakdown metrics for this period. ScamShield AI distinguishes unavailable telemetry from genuine zero counts and refuses to display fabricated distributions.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Dual Breakdown Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <LanguageDistributionCard
              distribution={parseResult.data.languageDistribution}
            />

            <TopThreatCategoriesCard
              categories={parseResult.data.topThreatCategories}
            />
          </div>
        </div>
      )}
    </div>
  );
};
