import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { RefreshCw, ServerOff, Shield } from 'lucide-react';
import {
  HistoryItem,
  HistoryResponse,
  ScanServiceError,
} from '../types/scan';
import { fetchHistory, getApiBaseUrl } from '../api/scanService';
import {
  HistoryFilters,
  HistoryTable,
  HistoryPagination,
  HistoryEmptyState,
  HistoryDetailModal,
  TargetTypeFilter,
  VerdictFilter,
  SortOrder,
} from '../components/history';
import { Button, Badge, Card, CardContent } from '../components/common';

const PAGE_SIZE = 20;

export const HistoryView: React.FC = () => {
  const [data, setData] = useState<HistoryResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<ScanServiceError | null>(null);

  // Filters & Pagination State
  const [searchQuery, setSearchQuery] = useState('');
  const [targetType, setTargetType] = useState<TargetTypeFilter>('ALL');
  const [verdict, setVerdict] = useState<VerdictFilter>('ALL');
  const [sortOrder, setSortOrder] = useState<SortOrder>('NEWEST');
  const [offset, setOffset] = useState<number>(0);

  // Selected Item for Detail Modal
  const [selectedItem, setSelectedItem] = useState<HistoryItem | null>(null);

  const apiBaseUrl = getApiBaseUrl();

  const loadHistory = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetchHistory({
        limit: PAGE_SIZE,
        offset,
        target_type: targetType === 'ALL' ? null : targetType,
        verdict: verdict === 'ALL' ? null : verdict,
      });
      setData(response);
    } catch (err: unknown) {
      if (err instanceof ScanServiceError) {
        setError(err);
      } else {
        setError(
          new ScanServiceError(
            err instanceof Error ? err.message : 'Failed to retrieve scan history.',
            'UNKNOWN_ERROR',
          ),
        );
      }
    } finally {
      setIsLoading(false);
    }
  }, [offset, targetType, verdict]);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  // Client-side search and sorting on fetched items
  const displayItems = useMemo(() => {
    if (!data?.items) return [];

    let filtered = [...data.items];

    // Search query filter (matches preview or scan ID)
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      filtered = filtered.filter(
        (item) =>
          item.target_preview.toLowerCase().includes(q) ||
          item.scan_id.toLowerCase().includes(q),
      );
    }

    // Sort Order
    filtered.sort((a, b) => {
      const timeA = new Date(a.scanned_at).getTime();
      const timeB = new Date(b.scanned_at).getTime();
      return sortOrder === 'NEWEST' ? timeB - timeA : timeA - timeB;
    });

    return filtered;
  }, [data?.items, searchQuery, sortOrder]);

  const handleClearFilters = () => {
    setSearchQuery('');
    setTargetType('ALL');
    setVerdict('ALL');
    setSortOrder('NEWEST');
    setOffset(0);
  };

  const isFiltered =
    searchQuery.trim().length > 0 || targetType !== 'ALL' || verdict !== 'ALL';

  return (
    <div className="space-y-6">
      {/* Page Title & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border-subtle pb-4">
        <div>
          <h1 className="text-xl font-bold text-content-primary tracking-tight">
            Investigation History & Audit Trail
          </h1>
          <p className="text-xs text-content-muted mt-1">
            Chronological audit log of all completed URL and message threat assessments.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            isLoading={isLoading}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            onClick={() => loadHistory()}
          >
            Refresh Logs
          </Button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <HistoryFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        targetType={targetType}
        onTargetTypeChange={(t) => {
          setTargetType(t);
          setOffset(0);
        }}
        verdict={verdict}
        onVerdictChange={(v) => {
          setVerdict(v);
          setOffset(0);
        }}
        sortOrder={sortOrder}
        onSortOrderChange={setSortOrder}
        disabled={isLoading && !data}
      />

      {/* Backend Offline Banner */}
      {error && (
        <Card variant="default" className="border-status-warning-border bg-status-warning-bg/20">
          <CardContent className="p-5 flex items-start gap-3">
            <ServerOff className="w-5 h-5 text-status-warning shrink-0 mt-0.5" />
            <div className="space-y-1.5 flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold text-content-primary">
                  {error.errorCode === 'BACKEND_UNAVAILABLE'
                    ? 'Backend History Service Offline'
                    : `Unable to Retrieve Audit Logs [${error.errorCode}]`}
                </h3>
                <Badge variant="warning" size="sm">
                  {error.status ? `HTTP ${error.status}` : 'Offline'}
                </Badge>
              </div>

              <p className="text-xs text-content-secondary leading-relaxed">
                {error.message}
              </p>

              <div className="mt-2 p-3 rounded-md bg-surface-card border border-border-subtle text-xs space-y-1">
                <p className="font-mono text-content-primary break-all">
                  Endpoint Target: <span className="text-brand">{apiBaseUrl}/history</span>
                </p>
                <p className="text-content-muted">
                  ScamShield AI strictly prohibits rendering fabricated or synthetic scan records. Historical records will automatically populate once the FastAPI backend and Supabase persistence layer are running in Phase 3.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading Skeleton */}
      {isLoading && !data && (
        <div className="p-8 text-center text-xs text-content-muted rounded-xl border border-border-subtle bg-surface-card animate-pulse">
          <span>Querying Supabase audit records via backend gateway...</span>
        </div>
      )}

      {/* Results Table or Empty State */}
      {!isLoading && !error && displayItems.length === 0 && (
        <HistoryEmptyState
          isFiltered={isFiltered}
          onClearFilters={handleClearFilters}
        />
      )}

      {displayItems.length > 0 && (
        <div className="space-y-3">
          <HistoryTable
            items={displayItems}
            onSelectItem={setSelectedItem}
          />

          <HistoryPagination
            totalCount={data?.total_count || displayItems.length}
            limit={PAGE_SIZE}
            offset={offset}
            onOffsetChange={setOffset}
            disabled={isLoading}
          />
        </div>
      )}

      {/* Security Privacy Notice */}
      <div className="p-3.5 rounded-lg border border-border-subtle bg-surface-subtle flex items-center gap-2 text-xs text-content-muted">
        <Shield className="w-4 h-4 text-brand shrink-0" />
        <span>
          <strong>Audit Confidentiality:</strong> Investigation previews are automatically stripped of sensitive PII (OTPs, personal account numbers, and VPAs) to safeguard user privacy.
        </span>
      </div>

      {/* Detail Slide-over Modal */}
      <HistoryDetailModal
        item={selectedItem}
        onClose={() => setSelectedItem(null)}
      />
    </div>
  );
};
