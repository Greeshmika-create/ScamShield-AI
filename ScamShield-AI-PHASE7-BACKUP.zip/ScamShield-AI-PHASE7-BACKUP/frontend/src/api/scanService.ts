import {
  URLScanRequest,
  URLScanResponse,
  MessageScanRequest,
  MessageScanResponse,
  HistoryQueryParams,
  HistoryResponse,
  AnalyticsOverviewResponse,
  APIErrorResponse,
  ScanServiceError,
} from '../types/scan';
import { clearAccessToken, getAccessToken } from './authSession.ts';

export { clearAccessToken, setAccessToken } from './authSession.ts';

const DEFAULT_BASE_URL = 'http://localhost:8000/api/v1';

export const getApiBaseUrl = (): string => {
  return import.meta.env.VITE_API_BASE_URL || DEFAULT_BASE_URL;
};

const REQUEST_TIMEOUT_MS = 10000; // 10s client timeout ceiling

const getAuthHeaders = (jsonBody: boolean): Record<string, string> => {
  const headers: Record<string, string> = { Accept: 'application/json' };
  if (jsonBody) headers['Content-Type'] = 'application/json';
  const accessToken = getAccessToken();
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  return headers;
};

async function executeScanRequest<T>(endpoint: string, payload: unknown): Promise<T> {
  const baseUrl = getApiBaseUrl().replace(/\/+$/, '');
  const targetUrl = `${baseUrl}${endpoint}`;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(targetUrl, {
      method: 'POST',
      headers: getAuthHeaders(true),
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (response.status === 401) {
      clearAccessToken();
    }

    if (!response.ok) {
      let errorData: APIErrorResponse | null = null;
      try {
        errorData = (await response.json()) as APIErrorResponse;
      } catch {
        // Response was not JSON
      }

      const errorCode = errorData?.error_code || `HTTP_${response.status}`;
      const message =
        errorData?.message ||
        `Backend server responded with error code ${response.status} (${response.statusText})`;

      throw new ScanServiceError(message, errorCode, response.status, errorData?.details);
    }

    const data = (await response.json()) as T;
    return data;
  } catch (error: unknown) {
    clearTimeout(timeoutId);

    if (error instanceof ScanServiceError) {
      throw error;
    }

    if (error instanceof DOMException && error.name === 'AbortError') {
      throw new ScanServiceError(
        'The investigation request timed out after 10 seconds. The backend or threat intelligence feeds exceeded their latency limit.',
        'REQUEST_TIMEOUT',
        504,
      );
    }

    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new ScanServiceError(
        `Unable to establish connection to ScamShield backend API at ${baseUrl}. Please verify the FastAPI service is running on the configured port.`,
        'BACKEND_UNAVAILABLE',
        503,
      );
    }

    const genericMsg = error instanceof Error ? error.message : 'Unknown communication error';
    throw new ScanServiceError(
      `Network communication failure: ${genericMsg}`,
      'NETWORK_FAILURE',
      0,
    );
  }
}

async function executeGetRequest<T>(endpoint: string): Promise<T> {
  const baseUrl = getApiBaseUrl().replace(/\/+$/, '');
  const targetUrl = `${baseUrl}${endpoint}`;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(targetUrl, {
      method: 'GET',
      headers: getAuthHeaders(false),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (response.status === 401) {
      clearAccessToken();
    }

    if (!response.ok) {
      let errorData: APIErrorResponse | null = null;
      try {
        errorData = (await response.json()) as APIErrorResponse;
      } catch {
        // Non-JSON response
      }

      const errorCode =
        response.status === 401
          ? 'UNAUTHORIZED'
          : response.status === 403
          ? 'FORBIDDEN'
          : errorData?.error_code || `HTTP_${response.status}`;

      const message =
        errorData?.message ||
        `Backend server responded with error code ${response.status} (${response.statusText})`;

      throw new ScanServiceError(message, errorCode, response.status, errorData?.details);
    }

    const data = (await response.json()) as T;
    return data;
  } catch (error: unknown) {
    clearTimeout(timeoutId);

    if (error instanceof ScanServiceError) {
      throw error;
    }

    if (error instanceof DOMException && error.name === 'AbortError') {
      throw new ScanServiceError(
        'The data request timed out after 10 seconds. The backend service exceeded its latency threshold.',
        'REQUEST_TIMEOUT',
        504,
      );
    }

    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new ScanServiceError(
        `Unable to establish connection to ScamShield backend API at ${baseUrl}. Please verify the FastAPI service is running on the configured port.`,
        'BACKEND_UNAVAILABLE',
        503,
      );
    }

    const genericMsg = error instanceof Error ? error.message : 'Unknown communication error';
    throw new ScanServiceError(
      `Network communication failure: ${genericMsg}`,
      'NETWORK_FAILURE',
      0,
    );
  }
}

export const scanUrl = async (request: URLScanRequest): Promise<URLScanResponse> => {
  return executeScanRequest<URLScanResponse>('/scan/url', request);
};

export const scanMessage = async (request: MessageScanRequest): Promise<MessageScanResponse> => {
  return executeScanRequest<MessageScanResponse>('/scan/message', request);
};

export const fetchHistory = async (params?: HistoryQueryParams): Promise<HistoryResponse> => {
  const query = new URLSearchParams();
  if (params?.limit !== undefined) query.set('limit', String(params.limit));
  if (params?.offset !== undefined) query.set('offset', String(params.offset));
  if (params?.target_type) query.set('target_type', params.target_type);
  if (params?.verdict) query.set('verdict', params.verdict);

  const queryString = query.toString();
  const endpoint = `/history${queryString ? `?${queryString}` : ''}`;
  return executeGetRequest<HistoryResponse>(endpoint);
};

export const fetchAnalyticsOverview = async (): Promise<AnalyticsOverviewResponse> => {
  return executeGetRequest<AnalyticsOverviewResponse>('/analytics/overview');
};
