import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { clearAccessToken, getAccessToken, setAccessToken } from './authSession.ts';

describe('Authenticated API session', () => {
  test('401-style logout clears the bearer token', () => {
    setAccessToken('expired-demo-token');
    assert.equal(getAccessToken(), 'expired-demo-token');

    clearAccessToken();

    assert.equal(getAccessToken(), null);
  });
});
