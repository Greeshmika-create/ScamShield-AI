export interface DemoLoginResponse {
  access_token: string;
  token_type: 'bearer' | string;
  expires_in: number;
}

const DEFAULT_BASE_URL = 'http://localhost:8000/api/v1';

export const getApiBaseUrl = (): string => {
  return import.meta.env.VITE_API_BASE_URL || DEFAULT_BASE_URL;
};

export async function demoLogin(): Promise<DemoLoginResponse> {
  const baseUrl = getApiBaseUrl().replace(/\/+$/, '');
  const response = await fetch(`${baseUrl}/auth/demo-login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });

  if (!response.ok) {
    let message = 'Local demo authentication is unavailable.';
    try {
      const payload = await response.json();
      if (typeof payload?.message === 'string') message = payload.message;
    } catch {
      // Preserve the generic message for non-JSON responses.
    }
    throw new Error(message);
  }

  return (await response.json()) as DemoLoginResponse;
}
