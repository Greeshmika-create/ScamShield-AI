# ScamShield AI

> **Enterprise-Grade Multilingual Phishing and Digital Scam Detection Platform**  
> *Developed for competitive cybersecurity hackathon evaluation.*

---

## 1. Project Overview

Digital scams, phishing attacks, and payment fraud targeting regional Indian internet users have increased drastically. Attackers exploit regional languages (specifically **Telugu script** and transliterated **"Telugish"**) and urgent social engineering tactics (e.g., electricity power cut threats, urgent KYC suspensions, counterfeit UPI payment requests) to bypass conventional English-centric security filters.

**ScamShield AI** is an enterprise-grade threat analysis platform designed to inspect suspicious URLs and digital messages. Built on a **Defense-in-Depth, Multi-Engine Pipeline**, the platform correlates external threat intelligence, structural feature extraction, and machine learning into an **Evidence-Based Risk Scoring Engine (ERSE)** that generates transparent, human-readable forensic reports.

### Key Capabilities
- **Dual-Mode Inspection:** Unified operational console for suspicious URLs and digital text messages (SMS, WhatsApp, email).
- **Multilingual NLP Engine:** Dedicated tokenization and classification pipelines for English, native Telugu script (`\u0C00`–`\u0C7F`), and transliterated Latin-script Telugu (Telugish).
- **Fault-Tolerant Threat Intelligence:** Resilient aggregation across Google Safe Browsing, URLhaus, and PhishTank with asynchronous circuit breakers and Supabase TTL caching.
- **Evidence-Based Forensics:** Replaces black-box scores with four standard cybersecurity verdicts (`MALICIOUS`, `SUSPICIOUS`, `NO_KNOWN_THREAT`, `UNVERIFIED`) and transparent, auditable indicators.
- **Defensive Engineering:** Strictly passive basic URL scanning (no target fetching, no DNS probing), static private-IP blocking, strict SSRF defenses for active operations, and rate limiting.
- **Zero-Mock Telemetry:** Strictly real operational history and aggregate metrics powered by Supabase PostgreSQL without simulated or synthetic placeholder data.

---

## 2. Technology Stack

| Layer | Technologies | Rationale |
| :--- | :--- | :--- |
| **Frontend** | React 18, TypeScript, Vite, Tailwind CSS, Chart.js | Type-safe, high-performance enterprise console with responsive layouts and real-time visualization. |
| **Backend** | Python 3.11+, FastAPI, Pydantic v2, Uvicorn | Asynchronous I/O for non-blocking parallel threat queries, strict schema validation, and automatic OpenAPI generation. |
| **Machine Learning** | Scikit-learn, Pandas, NumPy, Joblib | Fast, deterministic CPU-based inference (<20ms latency), high explainability (feature weights/n-grams), and low memory footprint. |
| **Persistence & Cache**| Supabase PostgreSQL | Managed relational storage for scan history, threat findings, analytics aggregations, and TTL-based threat intel cache. |
| **Threat Intelligence**| Google Safe Browsing v4, URLhaus (abuse.ch), PhishTank | Multi-source IoC validation with automatic fail-open circuit breakers. |

---

## 3. Architecture Overview

ScamShield AI is structured as a **Modular Monolith** to maximize development velocity while maintaining strict separation of concerns across service boundaries:

```
[ Frontend: React + TS + Tailwind ]
            |  (v1 REST API)
            v
[ Backend: FastAPI Gateway + SSRF Guard ]
            |
    ┌───────┴──────────────────────────────────┐
    v                                          v
[ Threat Intel Aggregator ]          [ ML & Feature Extraction ]
(GSB, URLhaus, PhishTank)           (URL Classifier + Telugu NLP)
    │                                          │
    └───────────────────┬──────────────────────┘
                        v
        [ Tiered Decision Engine (ERSE) ]
        Outputs: MALICIOUS | SUSPICIOUS |
                 NO_KNOWN_THREAT | UNVERIFIED
                        │
                        v
        [ Persistence: Supabase PostgreSQL ]
        (Audit History + Findings + Intel Cache)
```

For detailed architectural specifications, data flows, and design decisions, refer to [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

---

## 4. Repository Structure

```
ScamShield-AI/
├── backend/            # FastAPI backend application
│   ├── app/            # Application core, schemas, services, endpoints
│   └── tests/          # Backend unit and security test suites
├── frontend/           # React 18 + TypeScript single page application
│   ├── public/         # Static assets and icons
│   └── src/            # Components, API clients, hooks, styles, types
├── ml/                 # Machine learning research and pipelines
│   ├── datasets/       # Strictly segregated real vs. synthetic corpora
│   ├── models/         # Model artifacts and evaluation metadata
│   ├── notebooks/      # Exploratory data analysis and feature engineering
│   └── src/            # Reproducible training and feature extraction scripts
├── docs/               # Engineering specifications and security documentation
│   ├── ARCHITECTURE.md # Approved system architecture v1.0
│   ├── API_SPEC.md     # Versioned REST API contracts
│   └── THREAT_MODEL.md # Threat model, attack vectors, and mitigations
├── .gitignore          # Comprehensive secrets and artifact exclusion
└── README.md           # Master project documentation
```

---

## 5. Development Setup

> **Note:** Initial environment setup is currently in progress. Dependency installation and environment configurations will be performed in accordance with the phased development sequence.

### Prerequisites
- Python 3.11 or higher
- Node.js 18 LTS or higher
- Git
- Supabase account & project

### Configuration Files
- Backend configuration: Copy `backend/.env.example` to `backend/.env` and supply required API credentials.
- Frontend configuration: Copy `frontend/.env.example` to `frontend/.env`.

---

## 6. Security & Responsible Use Notice

ScamShield AI is built as a defensive cybersecurity tool designed to assist internet users, rural communities, and security analysts in detecting malicious communication. 
- **Strictly Passive Basic Scanning:** All default URL inspections are performed passively using lexical analysis, structural heuristics, and external threat intelligence APIs. The backend scanner does not fetch submitted URLs, load remote assets, or perform live DNS lookups against target nameservers in basic scan mode.
- **SSRF & Boundary Defenses:** Any future active network enrichment operations are strictly protected by pre-flight DNS inspection and private CIDR firewalls. Static input validation rejects internal IP targets (`127.0.0.1`, `10.0.0.0/8`, `192.168.0.0/16`, `169.254.169.254`).
- **Privacy & PII Protection:** Submitted messages undergo client-side and server-side PII masking (redaction of OTPs, phone numbers, and payment identifiers) before audit persistence.

