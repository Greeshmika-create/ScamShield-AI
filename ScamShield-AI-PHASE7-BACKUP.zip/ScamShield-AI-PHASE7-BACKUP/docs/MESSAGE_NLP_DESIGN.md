# ScamShield AI — Multilingual Message NLP & Scam Detection Architecture

> **Document Version:** 1.0.0  
> **Classification:** Engineering Specification  
> **Phase:** Phase 7 (Multilingual Message NLP & Scam Detection)  
> **Status:** Active Standard  

---

## 1. Executive Summary & Objective

Digital scams targeting Indian citizens overwhelmingly exploit regional languages and social engineering coercion. Fraudulent SMS messages, WhatsApp forwards, and phishing emails weaponize urgency (electricity power cut threats, YONO SBI KYC suspensions, counterfeit UPI payment requests) in native Indian scripts and Latin transliterations to bypass conventional English-centric security filters.

**Phase 7** introduces the **Multilingual Message NLP Engine** for ScamShield AI. The engine operates strictly offline in volatile memory (<50ms) to inspect user-submitted messages across eight prioritized languages:
- **English** (Latin)
- **Telugu** (Telugu script `\u0C00`–`\u0C7F` & transliterated Latin "Telugish")
- **Hindi** (Devanagari script `\u0900`–`\u097F`)
- **Tamil** (Tamil script `\u0B80`–`\u0BFF`)
- **Kannada** (Kannada script `\u0C80`–`\u0CFF`)
- **Malayalam** (Malayalam script `\u0D00`–`\u0D7F`)
- **Bengali** (Bengali script `\u0980`–`\u09FF`)
- **Marathi** (Devanagari script `\u0900`–`\u097F`)

---

## 2. Unicode Normalization & Obfuscation Defense

### 2.1 Unicode Normalization Form
All input messages undergo **NFKC (Compatibility Decomposition, followed by Canonical Composition)** normalization:
- Replaces compatibility characters with their canonical equivalents.
- Preserves distinct Indian script vowel signs (*matras*), virama (*halant*), and consonant conjuncts.
- Does **not** strip meaningful linguistic diacritics or convert non-English scripts to English.

### 2.2 Adversarial Obfuscation & Invisible Character Stripping
In conformance with [`docs/THREAT_MODEL.md`](file:///c:/Users/HP/Desktop/ScamShield-AI/docs/THREAT_MODEL.md) §3.3:
Attackers routinely insert invisible zero-width characters to fragment keyword patterns (e.g. `K\u200BY\u200BC` or `O\u200CT\u200DP`).
The engine identifies and strips:
- `\u200B` (Zero-Width Space)
- `\u200C` (Zero-Width Non-Joiner, where used deceitfully outside standard Indic ligatures)
- `\u200D` (Zero-Width Joiner, outside standard Indic ligatures)
- `\uFEFF` (Byte Order Mark / Zero-Width No-Break Space)
- `\u202A`–`\u202E` (Bidirectional override formatting codes)

The presence of intentional zero-width obfuscation is recorded as a dedicated forensic risk marker (`UNICODE_ZERO_WIDTH_OBFUSCATION`).

---

## 3. Script Detection vs. Language Identification Limitations

> [!WARNING]
> **Honest Identification Limitations:**
> - **Script detection is NOT language identification.** For example, the Devanagari script (`\u0900`–`\u097F`) is shared by Hindi, Marathi, Sanskrit, Nepali, and Konkani. Detecting Devanagari Unicode characters proves the script is Devanagari, but does not guarantee the language is Hindi vs. Marathi without secondary lexical grammar analysis.
> - **Transliterated "Telugish" & Romanized Indian Languages:** Users frequently type regional languages using the Latin English keyboard (e.g., *"Mee power cut avtundi"*). These messages use the Latin script (`\u0041`–`\u007A`), requiring lexical phonetic marker analysis rather than script inspection.
> - **Offline Constraint:** In accordance with the privacy policy, no submitted messages are sent to external cloud translation APIs (e.g. Google Cloud Translation, Microsoft Translator). Language assessment is performed strictly offline.

---

## 4. Multilingual Scam Indicator Hierarchy

Scam indicators are evaluated through structured, explainable, and testable rules across eight primary cyber attack categories:

| Category | Typical Coercion Motifs | Multilingual Examples |
| :--- | :--- | :--- |
| **`URGENCY_COERCION`** | Power cut threats, 24-hr deadlines, immediate suspension | *"9 PM ki power cut avtundi"*, *"बिजली कट जाएगी"*, *"மின்சாரம் துண்டிக்கப்படும்"* |
| **`BANKING_KYC_SUSPENSION`**| YONO SBI blocked, PAN card expired, KYC verification | *"YONO account block aindi"*, *"खाता ब्लॉक हो गया है"*, *"KYC update cheyandi"* |
| **`CREDENTIAL_OTP_THEFT`** | Requests to share OTP, PIN, password, or install remote access | *"Share OTP to cancel charge"*, *"ओटीपी बताएं"*, *"OTP cheppandi"* |
| **`PAYMENT_UPI_FRAUD`** | UPI collect requests, enter PIN to receive money, cashback claims | *"Enter PIN to receive ₹5000"*, *"पिन दर्ज करें और पैसे पाएं"* |
| **`LOTTERY_PRIZE_SCAM`** | Lucky draw, KBC 25 lakh lottery, PM Yojana loan approvals | *"25 Lakh lottery winner"*, *"PM Yojana loan approved"*, *"లక్కీ డ్రా విజేత"* |
| **`DELIVERY_FEE_SCAM`** | Incomplete address, unpaid custom fee, courier on hold | *"India Post: package on hold, pay ₹25 fee"* |
| **`SUSPICIOUS_JOB_OFFER`** | Work from home, earn ₹5000 daily, like YouTube videos | *"Earn ₹2000-5000 daily part time on Telegram"* |
| **`SUSPICIOUS_APK_INSTALL`** | Download APK from link, install AnyDesk / QuickSupport | *"Download support.apk to update banking"* |

---

## 5. False-Positive Mitigation & Legitimate Message Handling

> [!IMPORTANT]
> **Strict Anti-False-Positive Rules:**
> 1. **No Single-Word False Triggers:** An SMS containing the word "OTP" or "bank" is **never** classified as a scam on that basis alone. Legitimate transaction receipts routinely state:
>    *"Your OTP for purchase of Rs. 1500 at Merchant is 123456. ScamShield warns: Do NOT share this OTP with anyone."*
> 2. **Safety Disclaimer Immunity:** Messages that explicitly advise the recipient *not* to share credentials ("do not share", "never share", "bank never asks for OTP") trigger safety-context rules that suppress false positive OTP theft findings.
> 3. **Contextual Coercion Requirement:** Threat indicators require corroborating action verbs (e.g. "share OTP to prevent", "call immediately", "enter PIN to receive").

---

## 6. Privacy & Volatile Memory Invariant

In accordance with [`docs/ARCHITECTURE.md`](file:///c:/Users/HP/Desktop/ScamShield-AI/docs/ARCHITECTURE.md) §9:
- Raw message bodies are processed **strictly in volatile memory** during the request lifecycle (<50ms).
- Raw text is **never** written to database tables or application logs.
- Audit records and responses only contain a sanitized `message_preview` (capped at 120 chars) with:
  - 6-digit OTPs masked $\rightarrow$ `[REDACTED_OTP]`
  - 10-digit Indian phone numbers masked $\rightarrow$ `[REDACTED_PHONE]`
  - UPI / VPA identifiers masked $\rightarrow$ `[REDACTED_UPI]`

