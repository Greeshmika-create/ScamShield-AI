# Phase 9 Implementation Plan: Inspection Endpoint Orchestrator

## Existing Architecture

ScamShield AI is a FastAPI modular monolith mounted beneath `/api/v1`, with a React client calling the documented `/scan/url` and `/scan/message` paths. The current backend router exposes health and Phase 8's authenticated `/analyze` endpoint; the scan paths are not yet registered. The existing gateway validates JSON requests and caps request bodies at 1 MiB. Authentication is based on verified principals and role-derived permissions, and the Phase 8 test suite plus the full backend suite currently pass.

The passive-inspection invariant is explicit: submitted targets are never fetched, crawled, resolved through DNS, or executed. Threat-intelligence adapters may make provider requests using the canonical URL. A scan must report incomplete evidence honestly and must not interpret an unavailable model or provider as a clean assessment. Scores are heuristic indicators, not fraud probabilities.

## Existing Reusable Components

- `URLScanRequest` and `MessageScanRequest` validate input; `URLScanResponse` and `MessageScanResponse` define the established response contracts.
- `URLNormalizer` performs local parsing/canonicalization and strips userinfo from canonical URLs.
- `SSRFGuard.validate_target` performs static private/internal target checks without DNS resolution.
- `URLFeatureExtractor` produces the existing 32 lexical features; `URLClassifierService.predict_from_features` reports explicit model status and probability.
- `ThreatIntelAggregator.inspect_url` queries configured reputation providers asynchronously and preserves clean, flagged, timeout, error, and unconfigured statuses.
- `MessageAnalyzer.analyze` performs Phase 7 normalization, language/script assessment, feature extraction, indicator matching, and safe preview generation.
- Phase 8 `EvidenceCombiner` and `RiskEngine` provide shared findings and a provisional risk assessment.
- `require_permission(Permission.SCAN_EXECUTE)` enforces authenticated scan access. `RequestProtectionMiddleware` supplies the existing JSON and 1 MiB request-body checks.
- `Settings.RATE_LIMIT_PER_MINUTE` and `RateLimitExceededException` exist, but no limiter currently enforces that setting. `record_security_audit` and `AuditEvent` exist, but there is no scan-completed event type.

## Proposed Endpoint Structure

Add independent URL and message endpoint modules under `backend/app/api/v1/endpoints/`, each with its own POST route and shared `require_permission(Permission.SCAN_EXECUTE)` dependency. Register both routers in the existing v1 router without changing existing routes.

Add a small inspection orchestration service that composes existing Phase 4-8 components. URL flow: normalize, statically validate with the SSRF guard, extract features, run classifier and asynchronous intelligence aggregation, combine only observed evidence, then score through Phase 8. A rejected target returns the established standardized 400 error and triggers no provider lookup. Message flow: call the existing message analyzer once, pass its analysis to the Phase 8 combiner/scorer, and construct the established message response from the returned analysis.

Provider calls target only reputation-service APIs and receive a canonical URL. No scan code will issue requests, DNS lookups, or socket connections to a submitted target. External provider calls will be replaced with mocks in endpoint tests.

## Request and Response Contracts

- `POST /api/v1/scan/url`: accepts the existing `URLScanRequest` body (`{"url":"https://example.com/path"}`) and returns `URLScanResponse` with scan ID/time, sanitized URL representations, verdict/score/confidence, provider reports, findings, URL model result/status, and execution time.
- `POST /api/v1/scan/message`: accepts the existing `MessageScanRequest` body (`{"message_text":"..."}` with optional `sender_identifier`) and returns `MessageScanResponse` with a masked/truncated preview, detected language, extracted URLs, verdict/score/confidence, findings, explicit message-model status (unavailable unless an actual model exists), generic user guidance, and execution time.
- Existing Pydantic response fields remain in use. Nullable risk scores remain nullable for `UNVERIFIED`; model probabilities remain null when no model inference exists. URL userinfo and sensitive query values must not be echoed in responses.
- Validation uses the existing 422 error envelope; static SSRF rejection uses the existing 400 exception; the existing rate-limit error maps to 429. Unexpected failures use the established sanitized 500 error handler.

## Authentication and Audit

Both scan routes require an active authenticated principal with `SCAN_EXECUTE`; request-body identity or role values are never used. Add one scan-completed audit event classification and emit only scan ID, target type, verdict, and execution duration with actor/request metadata. Do not include raw URLs, query secrets, sender identifiers, or message bodies in audit details or ordinary logs.

Enforce `RATE_LIMIT_PER_MINUTE` through a minimal process-local sliding-window limiter keyed by the direct client address (do not trust caller-supplied forwarding headers). Reuse the existing setting and 429 exception. This is appropriate for the hackathon's single-process prototype but is not a distributed limiter and must be documented as such. The existing 1 MiB request-body middleware remains authoritative for payload size.

## Security Considerations

- Keep URL handling static through normalization, SSRF validation, and feature extraction. Never call DNS or network libraries with the submitted host and never follow redirects.
- Run threat-intel aggregation only after successful static SSRF validation; provider requests remain isolated from target access.
- Preserve provider and model failure states. Never synthesize clean reports, probabilities, or findings.
- Do not serialize URL userinfo or sensitive query values. Return only masked/truncated message previews and avoid raw message logging or persistence.
- Keep API keys and service credentials in backend settings only. Do not change frontend files or authentication implementation.
- Keep risk scores described as provisional heuristics, never percentages or calibrated fraud probabilities.

## Testing Strategy

Add endpoint-level tests using the existing FastAPI test application and dependency overrides. Cover valid and malformed URL/message requests; `SCAN_EXECUTE` authentication; private-target rejection before intelligence lookup; feature-extractor/classifier integration including unavailable model status; provider timeout and mixed results; English, Telugu, Telugish, and mixed-script messages; safe preview masking; stable response-schema serialization; sanitized internal errors; audit redaction; and rate-limit behavior.

Mock threat-intelligence providers/aggregator interactions. For passive-scan assertions, patch DNS/socket entry points to fail if invoked and assert only canonical targets are supplied to the mocked intelligence service. Run the focused new endpoint tests and the complete backend suite. Run the frontend type-check, lint, and build commands from `frontend/`; frontend source is not in scope for edits.

## Files Expected to Change

Create:

- `backend/app/api/v1/endpoints/scan_url.py`
- `backend/app/api/v1/endpoints/scan_message.py`
- `backend/app/services/inspection_orchestrator.py`
- `backend/app/core/scan_rate_limit.py`
- `backend/tests/test_scan_endpoints.py`

Modify minimally:

- `backend/app/api/v1/router.py` to register the two endpoint routers.
- `backend/app/schemas/enums.py` to add the scan-completed audit event type.

This plan is the only file created during the inspection/planning stage. No frontend files, model artifacts/checksums, database settings, existing Phase 1-8 implementations, or existing tests are intended to be changed or removed.