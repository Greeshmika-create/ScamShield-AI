# ScamShield AI — Versioned API Contract Specification (v1.0)

> **API Version:** v1.0.0  
> **Protocol:** HTTPS / REST  
> **Content-Type:** `application/json`  
> **Base Path:** `/api/v1`  

---

## 1. Global Conventions & Standard Types

### 1.1 Enumerations

#### Verdict
The final authoritative threat classification assigned by the Evidence-Based Risk Scoring Engine (ERSE):
- `MALICIOUS`: Verified active cyber threat or high-confidence ML classification corroborated by high-severity heuristic markers.
- `SUSPICIOUS`: Strong anomalous, deceptive, or coercive patterns detected; not yet indexed in global blocklists.
- `NO_KNOWN_THREAT`: All active reputation feeds and ML models evaluated clean. (Not a zero-day safety guarantee).
- `UNVERIFIED`: Key external threat intelligence feeds were unreachable, preventing complete validation.

#### ProviderStatus
Operational outcome of an external threat intelligence query:
- `AVAILABLE_CLEAN`: Upstream service responded; target is not listed in blocklist.
- `AVAILABLE_FLAGGED`: Upstream service responded; target confirmed as active threat.
- `TIMEOUT`: Provider failed to respond within the 2.5-second budget.
- `ERROR`: Provider returned a non-200 HTTP code or network error.
- `UNCONFIGURED`: API key was not supplied in backend configuration.

#### FindingSeverity
- `INFO`: Neutral contextual telemetry (e.g., detected language, standard TLD).
- `LOW`: Minor anomalies with limited threat significance.
- `MEDIUM`: Questionable patterns (e.g., multiple redirect hops, uncommon TLD).
- `HIGH`: Deceptive markers (e.g., urgency coercion, brand keywords in subdomains).
- `CRITICAL`: Direct indicators of attack (e.g., blacklisted IoC, IP hostname, fake banking gateway).

---

## 2. Endpoints

### 2.1 Inspect URL
`POST /api/v1/scan/url`

Performs an asynchronous multi-engine forensic investigation of a target URL.

> **Passive Inspection Invariant:** The default URL inspection is strictly passive. The backend does not initiate network connections to the target host, download remote web assets, execute JavaScript, or perform live DNS resolution against target nameservers. Analysis is restricted to static lexical feature extraction and external threat feed queries (passing the URL string or SHA-256 hash to GSB, URLhaus, and PhishTank).

#### Request Headers
| Header | Type | Required | Description |
| :--- | :--- | :--- | :--- |
| `Content-Type` | `string` | Yes | Must be `application/json` |

#### Request Body Schema
```json
{
  "type": "object",
  "required": ["url"],
  "properties": {
    "url": {
      "type": "string",
      "minLength": 4,
      "maxLength": 2048,
      "description": "The target URL to be inspected"
    }
  }
}
```

#### Request Example
```json
{
  "url": "http://192.168.1.10/verify-bank-account"
}
```

#### Successful Response (`200 OK`)
```json
{
  "scan_id": "c8b417e2-4521-4fa2-9eb2-f38b25a3d750",
  "scanned_at": "2026-11-05T11:35:10.120Z",
  "target_url": "http://192.168.1.10/verify-bank-account",
  "canonical_url": "http://192.168.1.10/verify-bank-account",
  "target_domain": "192.168.1.10",
  "verdict": "MALICIOUS",
  "risk_score": 96,
  "confidence_level": "HIGH",
  "threat_intelligence": [
    {
      "provider_name": "Google Safe Browsing",
      "status": "AVAILABLE_CLEAN",
      "response_time_ms": 142,
      "threat_details": null
    },
    {
      "provider_name": "URLhaus",
      "status": "AVAILABLE_FLAGGED",
      "response_time_ms": 289,
      "threat_details": "Known active malware distribution endpoint"
    },
    {
      "provider_name": "PhishTank",
      "status": "TIMEOUT",
      "response_time_ms": 2500,
      "threat_details": null
    }
  ],
  "findings": [
    {
      "category": "INTEL",
      "rule_name": "URLHAUS_HIT",
      "severity": "CRITICAL",
      "title": "Blacklisted on URLhaus",
      "description": "This exact endpoint is indexed as an active cyber threat by URLhaus intelligence feeds.",
      "raw_evidence": { "threat": "malware_download" }
    },
    {
      "category": "HEURISTIC",
      "rule_name": "RAW_IP_HOST",
      "severity": "HIGH",
      "title": "IP Address Used in Hostname",
      "description": "Legitimate organizations rarely use bare IP addresses instead of registered domain names.",
      "raw_evidence": { "host": "192.168.1.10" }
    }
  ],
  "domain_intelligence": {
    "domain_age_days": null,
    "registrar": null,
    "ssl_issuer": null,
    "ssl_valid": false
  },
  "ml_analysis": {
    "threat_probability": 0.982,
    "top_contributing_features": [
      { "feature": "has_ip_address", "value": 1.0, "impact": "POSITIVE_RISK" },
      { "feature": "suspicious_keyword_count", "value": 2.0, "impact": "POSITIVE_RISK" }
    ]
  },
  "execution_time_ms": 412
}
```

---

### 2.2 Inspect Message / Text
`POST /api/v1/scan/message`

Analyzes raw SMS, WhatsApp, or email text for phishing, financial fraud, and coercion in English, native Telugu script, or transliterated Telugish.

> **Privacy & PII Protection Invariant:** The backend processes raw message text ephemerally in volatile memory for feature extraction and ML inference only. The returned `message_preview` (and the audit record persisted to database) automatically masks sensitive personal data (6-digit OTPs, 10-digit phone numbers, and payment VPAs) and truncates preview strings to 120 characters. Full message bodies are never permanently retained.

#### Request Body Schema
```json
{
  "type": "object",
  "required": ["message_text"],
  "properties": {
    "message_text": {
      "type": "string",
      "minLength": 5,
      "maxLength": 5000,
      "description": "Raw message content"
    },
    "sender_identifier": {
      "type": "string",
      "nullable": true,
      "description": "Optional sender phone number or alphanumeric header (e.g., AD-SBIINB)"
    }
  }
}
```

#### Request Example
```json
{
  "message_text": "Mee SBI YONO account block aindi. Ventane update cheyandi lekapothe power cut avtundi: http://sbi-kyc-fix.xyz",
  "sender_identifier": "SBI-ALERT"
}
```

#### Successful Response (`200 OK`)
```json
{
  "scan_id": "7f139d4e-128a-4bc3-a801-98782a129d91",
  "scanned_at": "2026-11-05T11:36:00.540Z",
  "message_preview": "Mee SBI YONO account block aindi. Ventane update cheyandi...",
  "detected_language": "TELUGISH",
  "extracted_urls": ["http://sbi-kyc-fix.xyz"],
  "verdict": "SUSPICIOUS",
  "risk_score": 78,
  "confidence_level": "HIGH",
  "findings": [
    {
      "category": "LINGUISTIC",
      "rule_name": "URGENCY_FINANCIAL_COERCION",
      "severity": "HIGH",
      "title": "Urgency & Account Suspension Coercion",
      "description": "The message creates artificial panic by threatening account blocking or service termination.",
      "raw_evidence": { "matched_phrases": ["block aindi", "ventane update"] }
    },
    {
      "category": "ML",
      "rule_name": "SCAM_INTENT_CLASSIFIER",
      "severity": "HIGH",
      "title": "High Scam Intent Detected",
      "description": "Multilingual n-gram analysis identified patterns common to Indian financial phishing templates.",
      "raw_evidence": { "probability": 0.884 }
    }
  ],
  "ml_analysis": {
    "threat_probability": 0.884,
    "top_contributing_ngrams": ["block", "update che", "yono", "ventane"]
  },
  "user_guidance": {
    "english": "Do not reply or share personal credentials. Banks never send account block alerts demanding urgent updates via unofficial channels.",
    "telugu": "ఎలాంటి వివరాలు పంచుకోవద్దు. మీ బ్యాంక్ ఎప్పుడూ ఇలాంటి అనధికారిక సందేశాల ద్వారా అకౌంట్ బ్లాక్ చేయదు."
  },
  "execution_time_ms": 38
}
```

---

### 2.3 Retrieve Scan History
`GET /api/v1/history`

Retrieves a paginated list of authentic previous investigations.

#### Query Parameters
| Parameter | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `limit` | `integer` | `20` | Max records to retrieve (1–100) |
| `offset` | `integer` | `0` | Pagination offset |
| `target_type` | `string` | `null` | Filter by `URL` or `MESSAGE` |
| `verdict` | `string` | `null` | Filter by verdict |

#### Successful Response (`200 OK`)
```json
{
  "total_count": 42,
  "limit": 20,
  "offset": 0,
  "items": [
    {
      "scan_id": "c8b417e2-4521-4fa2-9eb2-f38b25a3d750",
      "scanned_at": "2026-11-05T11:35:10.120Z",
      "target_type": "URL",
      "target_preview": "http://192.168.1.10/verify-bank-account",
      "verdict": "MALICIOUS",
      "risk_score": 96,
      "execution_time_ms": 412
    }
  ]
}
```

---

### 2.4 Retrieve Security Analytics
`GET /api/v1/analytics/overview`

Computes live telemetry across all authentic scans.

#### Successful Response (`200 OK`)
```json
{
  "total_scans": 284,
  "verdict_distribution": {
    "MALICIOUS": 48,
    "SUSPICIOUS": 73,
    "NO_KNOWN_THREAT": 151,
    "UNVERIFIED": 12
  },
  "average_scan_latency_ms": 320,
  "detected_language_distribution": {
    "ENGLISH": 180,
    "TELUGISH": 64,
    "TELUGU_SCRIPT": 40
  },
  "top_threat_categories": [
    { "category": "Financial Fraud / KYC", "count": 62 },
    { "category": "Malware URL", "count": 31 },
    { "category": "Utility / Power Cut Coercion", "count": 28 }
  ]
}
```

---

### 2.5 Health & Upstream Telemetry
`GET /api/v1/health`

Exposes system readiness and status of threat intelligence providers.

#### Successful Response (`200 OK`)
```json
{
  "status": "OPERATIONAL",
  "version": "1.0.0",
  "components": {
    "api_gateway": "HEALTHY",
    "supabase_connection": "CONNECTED",
    "ml_models_loaded": true
  },
  "providers": {
    "google_safe_browsing": "HEALTHY",
    "urlhaus": "HEALTHY",
    "phishtank": "DEGRADED"
  }
}
```

---

## 3. Standardized Error Payloads

All error conditions return a unified JSON schema:

```json
{
  "error_code": "SSRF_ATTEMPT_REJECTED",
  "message": "The destination URL resolves to a private, loopback, or non-routable IP address.",
  "details": {
    "target_host": "127.0.0.1",
    "resolved_ip": "127.0.0.1"
  },
  "timestamp": "2026-11-05T11:40:00.000Z"
}
```

### Error Code Reference
| HTTP Status | Error Code | Description |
| :--- | :--- | :--- |
| `400 Bad Request` | `SSRF_ATTEMPT_REJECTED` | Input target is identified as a private, loopback, or cloud-metadata IP address (`127.0.0.1`, `10.0.0.0/8`, `192.168.0.0/16`, `169.254.169.254`, `localhost`). |
| `422 Unprocessable` | `INVALID_INPUT_FORMAT` | Schema validation failed (e.g., malformed URL scheme, empty message, unsupported protocol). |
| `429 Too Many Req` | `RATE_LIMIT_EXCEEDED` | Client surpassed rate limits (30 scans/min). |
| `504 Gateway Timeout` | `SCAN_TIMEOUT` | Internal or upstream processing exceeded the 6.0s deadline. |
| `500 Server Error` | `INTERNAL_INSPECTION_ERROR` | Unhandled backend exception. |

