# ScamShield AI — Machine Learning Model Design Specification

> **Document Version:** 1.0.1 (Corrected & Hardened)  
> **Classification:** Engineering Specification  
> **Phase:** Phase 6 (Machine Learning Model Architecture & Integration)  
> **Status:** Active Standard  

---

## 1. Executive Summary & Objective

ScamShield AI utilizes machine learning as a secondary evidence component of its **Defense-in-Depth, Multi-Engine Pipeline**. While external threat intelligence feeds (Google Safe Browsing, URLhaus, PhishTank) provide authoritative ground truth for *known* threats, novel phishing campaigns and localized cyber scams targeting Indian users are frequently activated hours before cataloging in global reputation databases.

The primary objective of the **URL Lexical Classifier** is to evaluate structural anomalies, lexical evasion tactics, and deceptive domain formations purely in-memory (<2ms) without initiating outbound network connections to target hosts.

---

## 2. Model Honesty & Provenance Disclosure

> [!IMPORTANT]
> **Model Provenance Notice:** In accordance with strict engineering standards:
> - The initial packaged model parameters (`url_classifier_v1.json`) represent a **HEURISTIC BASELINE / REFERENCE MODEL** derived from architectural feature weights.
> - **Empirical training is explicitly BLOCKED pending ingestion of verified real-world datasets** (e.g. ISCX-URL2016, PhishTank archives, Tranco whitelist).
> - We do **NOT** claim empirical accuracy, cross-validated calibration, or production ML readiness for this reference model.
> - No synthetic evaluation metrics or fabricated accuracy statistics are claimed.

---

## 3. Artifact Integrity & Threat Model Realities

> [!WARNING]
> **Integrity Scope & Limitation:**
> - SHA-256 checksum verification provides integrity checking **only against accidental file corruption or tampering when the expected checksum is securely controlled by application code**.
> - A cryptographic checksum **alone does not prevent malicious artifact replacement** if an attacker has write access to the host application directory (they could simply overwrite both the artifact and the expected checksum).
> - **Security Control:** Model artifacts and metadata are strictly application-controlled internal assets within `ml/models/artifacts/`. Under no circumstances are model files accepted from untrusted user uploads or external networks.

---

## 4. Classification Label Consistency & Binary Mapping

### 4.1 System-Wide Label Standards
The platform standardizes on three discrete threat classification outcomes across dataset validators, ML models, and downstream scoring engines:
1. **`BENIGN`**: Normal lexical distribution; no anomalous structural evasion markers.
2. **`PHISHING`**: Deceptive credential harvesting, brand impersonation, or fake authentication gateways.
3. **`MALICIOUS`**: Active exploit delivery, bare IP hostnames, or confirmed attack endpoints.

### 4.2 Binary Linear Mapping Documentation
The baseline linear projection evaluates a continuous threat score $P(\text{Threat}) \in [0.0, 1.0]$. In binary training datasets where ground-truth labels are binary:
- **Label 0 (Negative Class):** Maps exclusively to `BENIGN`.
- **Label 1 (Positive Class):** Combines both `PHISHING` and `MALICIOUS` into the positive threat class during binary optimization.
- **Granular Output Resolution:**
  - If $P(\text{Threat}) \ge 0.85$ and high-severity architectural flags exist (e.g. bare IP host or multiple sensitive brand tokens) $\rightarrow$ labeled **`MALICIOUS`**.
  - If $P(\text{Threat}) \ge 0.85$ with credential/banking tokens $\rightarrow$ labeled **`PHISHING`**.
  - If $0.45 \le P(\text{Threat}) < 0.85$ $\rightarrow$ labeled **`SUSPICIOUS`**.
  - If $P(\text{Threat}) < 0.45$ $\rightarrow$ labeled **`BENIGN`**.
- **Preservation Invariant:** Under no circumstances are `MALICIOUS` examples discarded or conflated with benign traffic.

---

## 5. Input Feature Specification (The 32 Features)

The classifier strictly consumes the 32 features extracted by [`URLFeatureExtractor`](file:///c:/Users/HP/Desktop/ScamShield-AI/backend/app/services/scanners/url_extractor.py) (Phase 4.2):

| # | Feature Identifier | Type | Range | Architectural Rationale |
| :---: | :--- | :---: | :---: | :--- |
| **1** | `url_length` | int | $[0, 2048]$ | Phishing URLs often use extended query strings or nested paths. |
| **2** | `hostname_length` | int | $[1, 253]$ | Brand impersonation subdomains inflate hostname length. |
| **3** | `path_length` | int | $[1, 2048]$ | Fake payment gateways often use deep nested paths. |
| **4** | `query_length` | int | $[0, 2048]$ | Token-stuffed URLs exhibit high parameter lengths. |
| **5** | `count_dot` | int | $[0, 50]$ | Excessive dots indicate subdomain chaining (`sbi.co.in.scam.xyz`). |
| **6** | `count_hyphen` | int | $[0, 50]$ | Deceptive hyphens in domains (`sbi-online-update`). |
| **7** | `count_underscore` | int | $[0, 50]$ | Query/path parameter obfuscation marker. |
| **8** | `count_slash` | int | $[0, 50]$ | Deep hierarchical structure indicator. |
| **9** | `count_question` | int | $[0, 10]$ | Query string initiator count. |
| **10** | `count_equal` | int | $[0, 50]$ | High key-value density marker. |
| **11** | `count_at` | int | $[0, 10]$ | Authentication credential spoofing delimiter (`user@host`). |
| **12** | `count_ampersand` | int | $[0, 50]$ | Multiple parameter chaining marker. |
| **13** | `count_percent` | int | $[0, 50]$ | Percent-encoding density indicator. |
| **14** | `subdomain_count` | int | $[0, 20]$ | Labels prior to registered domain. |
| **15** | `domain_depth` | int | $[1, 20]$ | Total label hierarchy depth. |
| **16** | `domain_entropy` | float | $[0.0, 5.0]$ | Shannon entropy $H(X)$ to detect algorithmically generated domains (DGA). |
| **17** | `has_login_keyword` | float | $\{0.0, 1.0\}$ | Presence of `login`, `signin`, `auth`. |
| **18** | `has_verify_keyword` | float | $\{0.0, 1.0\}$ | Presence of `verify`, `verification`, `confirm`. |
| **19** | `has_account_keyword` | float | $\{0.0, 1.0\}$ | Presence of `account`, `profile`, `wallet`. |
| **20** | `has_banking_keyword` | float | $\{0.0, 1.0\}$ | Regional banking targets: `sbi`, `hdfc`, `icici`, `netbanking`. |
| **21** | `has_kyc_keyword` | float | $\{0.0, 1.0\}$ | Regional KYC coercion motifs: `kyc`, `pan`, `aadhaar`. |
| **22** | `has_upi_keyword` | float | $\{0.0, 1.0\}$ | Payment fraud targets: `upi`, `vpa`, `paytm`, `phonepe`. |
| **23** | `has_support_keyword` | float | $\{0.0, 1.0\}$ | Impersonation motifs: `support`, `customer-care`. |
| **24** | `has_ip_address` | float | $\{0.0, 1.0\}$ | Bare IP address used in authority (`http://192.168.1.1`). |
| **25** | `is_punycode` | float | $\{0.0, 1.0\}$ | IDN homoglyph evasion marker (`xn--`). |
| **26** | `has_non_standard_port`| float | $\{0.0, 1.0\}$ | Explicit non-default port (`:8080`, `:8443`). |
| **27** | `digit_count` | int | $[0, 500]$ | Total numeric digits across URL. |
| **28** | `digit_ratio` | float | $[0.0, 1.0]$ | Ratio of digits to total length. |
| **29** | `letter_count` | int | $[0, 2048]$ | Total alphabetical characters. |
| **30** | `path_depth` | int | $[0, 50]$ | Number of directory segments. |
| **31** | `query_param_count` | int | $[0, 50]$ | Number of discrete query parameters. |
| **32** | `suspicious_token_count`| int | $[0, 50]$ | Cumulative count of security keywords detected. |

---

## 6. Non-Finality Invariant

A `BENIGN` prediction from the ML classifier does **never** constitute a final safety verdict. In ScamShield AI's Tiered Scoring architecture (Phase 8), ML inference is strictly an evidence source evaluated alongside external threat intelligence and heuristic rules.
