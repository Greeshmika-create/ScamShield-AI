# ScamShield AI — Threat Model & Security Architecture

> **Document Version:** 1.0.0  
> **Methodology:** STRIDE / Threat Modeling for Defensive Cyber Platforms  
> **Status:** Active Standard  

---

## 1. System Threat Context

As a cybersecurity platform analyzing malicious inputs (phishing URLs, scam texts, obfuscated scripts), ScamShield AI operates directly on untrusted, potentially hostile data. The platform must be defensively hardened against attackers attempting to exploit the analysis engine itself.

---

## 2. Threat Matrix & Defensive Mitigations

```
┌───────────────────────────────────────┬────────────────────────────────────────────────────────┐
│ Attack Vector                         │ Architectural Defense Mechanism                        │
├───────────────────────┬───────────────┴────────────────────────────────────────────────────────┤
│ 1. SSRF & Network     │ • Strictly passive basic scan: No fetching, no target DNS resolution.  │
│    Probing            │ • Static private IP and scheme filtering (http/https only).            │
│                       │ • Pre-flight DNS resolution & CIDR firewall for active operations only.│
├───────────────────────┼────────────────────────────────────────────────────────────────────────┤
│ 2. API Quota          │ • In-memory rate limiting (SlowAPI: 30 requests/min per IP).           │
│    Exhaustion & DoS   │ • 2-hour Supabase TTL cache on SHA-256 target hashes.                  │
│                       │ • 2.5-second timeout budgets per upstream threat feed.                 │
├───────────────────────┼────────────────────────────────────────────────────────────────────────┤
│ 3. Adversarial        │ • URL canonicalization and Punycode normalization.                     │
│    Evasion / Spoofing │ • Character-level n-gram analysis resilient to phonetic obfuscation.   │
│                       │ • Detection of zero-width and bidirectional Unicode control characters.│
├───────────────────────┼────────────────────────────────────────────────────────────────────────┤
│ 4. Stored XSS &       │ • Input sanitization on all raw strings.                               │
│    Payload Injection  │ • React parameterized DOM rendering (no dangerouslySetInnerHTML).      │
│                       │ • Structured JSON responses with sanitized preview strings.            │
├───────────────────────┼────────────────────────────────────────────────────────────────────────┤
│ 5. PII Leakage in     │ • Client and server-side masking of OTPs, phone numbers, and VPAs.     │
│    Scam Messages      │ • Ephemeral processing only; full message bodies never stored to disk. │
│                       │ • Preview truncation to 120 chars in audit records.                    │
├───────────────────────┼────────────────────────────────────────────────────────────────────────┤
│ 6. Insecure Model     │ • Model files strictly version-controlled; sha256 checksum validation. │
│    Deserialization    │ • Restricted file permissions on ml/models/artifacts.                  │
│                       │ • No untrusted runtime pickle loading.                                 │
├───────────────────────┼────────────────────────────────────────────────────────────────────────┤
│ 7. Credential Leakage │ • Environment variables managed strictly through Pydantic settings.    │
│    & Database Abuse   │ • Supabase Service Role Key restricted to backend runtime.             │
│                       │ • Supabase Row Level Security (RLS) enabled on all tables.             │
│                       │ • Comprehensive .gitignore excluding all secrets.                      │
└───────────────────────┴────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Detailed Attack Vectors & Defensive Specifications

### 3.1 Server-Side Request Forgery (SSRF) & Network Probing

#### The Threat
Attackers submit internal IP addresses, loopback addresses, or cloud metadata URLs (e.g., `http://169.254.169.254/latest/meta-data/` or `http://127.0.0.1:8000/admin`) to probe internal network topologies, cloud credentials, or local microservices.

#### Defensive Specification
ScamShield AI enforces a two-tier defense model:
1. **Passive Basic Scanning (Default & Mandatory):**
   - The basic URL scanner **never fetches the submitted URL** and **never connects to the target host**.
   - **No DNS Resolution in Basic Scan:** To eliminate information leakage to attacker-controlled authoritative nameservers, basic URL scanning does **not** resolve the target host via DNS.
   - **Static Target Validation:** The backend URL normalizer parses the host component statically using Python's `urllib.parse` and `ipaddress` module:
     - Scheme Allowlist: Only `http` and `https` schemes are accepted. Schemes like `file://`, `ftp://`, `gopher://`, `dict://` are rejected with HTTP 422.
     - Static Private IP Blocklist: If the parsed host is literally an IP literal or loopback hostname (`localhost`, `127.0.0.1`, `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`, `169.254.0.0/16`, `::1`), the scan is rejected with HTTP 400 (`SSRF_ATTEMPT_REJECTED`) without any network connection.
2. **Active Operations & Future Enrichment Pipeline:**
   - Any future active network operations (e.g., redirect crawling, HTTP header inspection) must pass through a strict active SSRF guard:
     - Pre-flight DNS resolution using `socket.getaddrinfo`.
     - Re-checking resolved IP addresses against all private and cloud metadata CIDR ranges before opening sockets.
     - Enforcing connection timeouts and disabling automatic redirects to prevent DNS rebinding.

---

### 3.2 Denial of Service (DoS) & Upstream API Exhaustion

#### The Threat
Malicious actors or bots flood the `/scan/url` endpoint with unique URLs, exhausting external API quotas (Google Safe Browsing, URLhaus) and incurring severe service degradation or financial costs.

#### Defensive Specification
1. **Tiered Rate Limiting:** Enforce a maximum of 30 scans per minute per client IP using `slowapi`.
2. **Deduplication & TTL Caching:** Before initiating outbound HTTP calls to Google Safe Browsing or URLhaus, calculate `SHA-256(canonical_url)`. Query the `threat_intel_cache` table. If a valid record exists ($<2$ hours old), return the cached assessment immediately.
3. **Hard Timeout Ceilings:** Upstream API calls are wrapped in `asyncio.wait_for(..., timeout=2.5)`. The total pipeline execution deadline is strictly capped at 6.0 seconds.

---

### 3.3 Adversarial Obfuscation & Homoglyph Attacks

#### The Threat
Attackers register homoglyph domains using Internationalized Domain Names (IDN) with Cyrillic or Greek characters (e.g., `google.com` vs `gооgle.com` where 'о' is Cyrillic `\u043E`), or insert zero-width spaces (`\u200B`) and invisible formatting characters into phishing SMS messages to bypass string matching.

#### Defensive Specification
1. **Punycode Normalization:** All URLs are converted to ASCII Punycode representation (`idna.encode`) before lexical analysis. Any domain containing mixed-script punycode (`xn--`) masquerading as a major brand triggers a high-severity heuristic flag.
2. **Zero-Width Stripping:** Input message text is stripped of invisible zero-width spaces (`\u200B`, `\u200C`, `\u200D`, `\uFEFF`) before tokenization.
3. **Sub-Word Character N-Grams:** Text classification utilizes character n-grams ($n=2$ to $5$) rather than plain word dictionaries. This ensures transliterated Telugish variations (e.g., `update cheyandi` vs `update cheyyandi`) are captured reliably.

---

### 3.4 Cross-Site Scripting (XSS) via Submitted Scam Text

#### The Threat
Attackers paste scam messages containing embedded JavaScript or HTML tags (`<script>document.cookie</script>`) hoping the web console executes the payload when viewing the scan history or evidence reports.

#### Defensive Specification
1. **Automatic Contextual Escaping:** React DOM renders all text nodes as text literals, completely preventing DOM injection.
2. **Explicit Prohibition:** The use of `dangerouslySetInnerHTML` is forbidden throughout the frontend codebase.
3. **Sanitized Previews:** The backend generates truncated, sanitized preview strings with angle brackets escaped prior to database persistence.

---

### 3.5 Insecure Deserialization of ML Model Artifacts

#### The Threat
Standard Python `pickle` deserialization can allow arbitrary code execution if an attacker replaces `.pkl` or `.joblib` files with a poisoned binary payload.

#### Defensive Specification
1. **Model Provenance:** All serialized models (`url_classifier.joblib`, `message_classifier.joblib`) are generated locally via reproducible training scripts (`ml/src/train_url.py`, `ml/src/train_message.py`).
2. **Integrity Hashes:** Model artifacts are accompanied by a versioned `metadata.json` containing SHA-256 checksums. The backend validates the checksum upon startup before loading artifacts into memory.
3. **Filesystem Isolation:** Model artifacts are stored in a dedicated read-only directory with access restricted to the backend runtime.

---

### 3.6 Secret Management & Database Row-Level Security

#### The Threat
Accidental leakage of the Supabase Service Role Key or threat intelligence API keys via client bundles, logs, or source code commits, or unauthorized manipulation of scan history tables.

#### Defensive Specification
1. **Strict Client Separation:** The frontend Vite application only receives `VITE_API_BASE_URL`. It possesses zero access to Supabase service keys or threat intel API keys.
2. **Backend Environment Isolation:** Secrets are injected strictly through environment variables validated at startup via Pydantic `BaseSettings`. Missing critical credentials raise fatal startup exceptions in production mode.
3. **Repository Defense:** The master `.gitignore` strictly blocks all variations of `.env`, certificates, and keys. `.env.example` templates remain strictly tracked with dummy placeholder values.
4. **Supabase Row-Level Security (RLS) Enforcement:**
   - RLS is enabled on all tables (`scans`, `scan_findings`, `threat_intel_cache`).
   - The backend connects using the `SUPABASE_SERVICE_ROLE_KEY` with full read/write privileges.
   - Public/anonymous roles are strictly limited to `SELECT` privileges on `scans` and `scan_findings`. Direct public `INSERT`, `UPDATE`, and `DELETE` operations are denied at the database engine level to prevent history tampering.
   - The `threat_intel_cache` table has zero public access policies, remaining an internal backend data store.

---

### 3.7 Sensitive Message Data Privacy & PII Retention

#### The Threat
Users submit raw phishing SMS or chat messages that contain sensitive Personally Identifiable Information (PII) such as bank account numbers, 6-digit one-time passwords (OTPs), personal telephone numbers, or UPI IDs. If stored in plain text, database leaks or public history endpoints could expose victim identities.

#### Defensive Specification
1. **Client & Server PII Redaction:**
   - Before persistence, the message undergoes redaction matching:
     - 6-digit OTPs / verification tokens (`\b\d{6}\b` $\rightarrow$ `[REDACTED_OTP]`)
     - 10-digit Indian phone numbers (`[6-9]\d{9}` $\rightarrow$ `[REDACTED_PHONE]`)
     - Payment VPAs / UPI addresses (`[\w\.\-_]+@[\w\.\-_]+` $\rightarrow$ `[REDACTED_UPI]`)
2. **Ephemeral Message Processing Invariant:**
   - The full, raw message body is held in memory only for feature extraction and ML inference ($<50\text{ms}$).
   - The database only retains the sanitized `target_preview` truncated to a maximum of 120 characters for audit logging. The raw message is never persisted.
3. **Retention & Purge Schedule:**
   - Audit logs older than 30 days are scheduled for automated preview clearing while preserving anonymized numerical metrics (risk score, verdict, execution time) for macro analytics.

