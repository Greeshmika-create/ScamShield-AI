# ScamShield AI Deployment Readiness

## Local Development

Backend:

```powershell
cd backend
python -m pip install -r requirements.txt
$env:DEMO_AUTH_ENABLED="true"
$env:DEMO_AUTH_SECRET="replace-with-a-long-random-local-secret"
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Frontend:

```powershell
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173` and use the login UI. The demo login endpoint issues a short-lived USER bearer token for local development only.

## Optional Supabase Persistence

Set `SUPABASE_DB_URL` to the backend-only Supabase PostgreSQL pooled connection string. Apply `backend/migrations/001_phase10_supabase.sql` before expecting history or analytics persistence.

Real Supabase Auth is optional for the local demo. To use it, configure:

- `SUPABASE_URL`
- `SUPABASE_JWT_SECRET`
- `SUPABASE_JWT_AUDIENCE`
- `SUPABASE_JWT_ISSUER` when required

Never place `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_DB_URL`, JWT signing secrets, or database passwords in `VITE_*` variables or frontend source.

## Production Controls

- Demo login is blocked outside `development` and `test` environments.
- The demo verifier is not selected when a valid Supabase JWT secret is configured.
- CORS must contain explicit trusted frontend origins.
- Keep service-role credentials backend-only.
- Apply RLS migrations before enabling database-backed history and analytics.
- Use HTTPS and a secret-management provider in production.

## Verification Commands

Backend:

```powershell
cd backend
python -m pytest tests -q
python -m compileall app tests
```

Frontend:

```powershell
cd frontend
npm run test
npm run type-check
npm run lint
npm run build
```

## External Verification Required

The project does not claim verified Supabase connectivity until a real database instance and credentials are configured and the migration, RLS, persistence, and health checks are tested against it. It also does not claim external threat-feed availability until provider credentials and live network calls are configured.
