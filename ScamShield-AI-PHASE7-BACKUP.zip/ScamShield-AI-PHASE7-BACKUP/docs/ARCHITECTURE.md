# ScamShield AI — System Architecture Specification (v1.0)

> **Document Version:** 1.0.0  
> **Classification:** Engineering Specification  
> **Status:** Approved Baseline  

---

## 1. System Vision & Core Principles

ScamShield AI is an enterprise-grade digital scam and phishing analysis platform designed specifically to combat multilingual cyber threats targeting Indian digital users. Attackers routinely weaponize urgency, fake authority, and regional languages (native **Telugu script** and Latin-script **"Telugish"**) to bypass conventional English-only security controls.

### Core Architectural Principles
1. **Defense-in-Depth:** Multiple complementary detection engines (Reputation Feeds, Heuristic Rules, Lexical Classifiers, and Multilingual NLP) must corroborate findings.
2. **Absence of Proof is Not Proof of Absence:** The fact that a URL or message is not present in existing threat intelligence feeds (Google Safe Browsing, URLhaus, PhishTank) does **never** imply it is safe. Fast-flux and zero-day scam endpoints are frequently active hours before ingestion into global blocklists.
3. **Evidence-Based, Testable Scoring:** Rather than arbitrary weighted averages, the platform uses a tiered deterministic and probabilistic decision matrix that outputs verifiable indicators of compromise.
4. **Resilience & Graceful Degradation:** External dependencies (threat feeds) will fail, timeout, or rate-limit. The platform must never crash or block the user when upstream APIs fail.
5. **No Synthetic Telemetry:** The platform displays strictly real audit logs and real telemetry. Empty states are rendered transparently without fabricated statistics.
6. **Strictly Passive Basic Scanning:** Basic URL scanning is completely passive. The backend never fetches submitted target URLs, executes remote code, or performs live DNS queries against target nameservers. Analysis is restricted to lexical/structural inspection and querying reputation feeds by target URL or hash. Any future active enrichment operations must enforce strict pre-flight SSRF protections.

---

## 2. High-Level Modular Monolith Architecture

ScamShield AI is engineered as a **Modular Monolith**: a unified codebase with distinct, decoupled service boundaries running within a single backend runtime, coupled to a type-safe single-page application and managed PostgreSQL persistence.

```mermaid
flowchart TD
    subgraph PresentationLayer ["1. Presentation Layer (React 18 + TS + Tailwind)"]
        Nav["Fixed 4-View Navigation\n[Overview | Scanner | Scan History | Analytics]"]
        Console["Threat Scanner Console (URL & Message)"]
        ForensicCard["Explainable Evidence Matrix"]
        TelemetryDash["Live Analytics (Chart.js)"]
    end

    subgraph GatewayLayer ["2. API Gateway & Defense Layer (FastAPI)"]
        Router["Versioned Router (/api/v1)"]
        SSRF["Target Validator & Static SSRF Guard\n(Scheme Filter + Private IP Detection)"]
        RateLimiter["Rate Limiter (SlowAPI)"]
        Validator["Pydantic v2 Request Normalizers"]
    end

    subgraph ServiceLayer ["3. Internal Service Modules"]
        Orchestrator["Inspection Pipeline Orchestrator"]
        
        subgraph IntelService ["Threat Intel Aggregator"]
            GSB["Google Safe Browsing Client"]
            URLhaus["URLhaus Client"]
            PhishTank["PhishTank Client"]
            CacheManager["TTL Cache Resolver (2 Hours)"]
        end

        subgraph MLService ["Machine Learning Engine"]
            URLExtractor["32-Feature Lexical & Structural Extractor"]
            URLModel["Random Forest / Gradient Boosting Classifier"]
            NLPTokenizer["Multilingual Char-NGram Tokenizer (Telugu/English)"]
            NLPModel["Calibrated LinearSVC / Logistic Classifier"]
        end

        subgraph DecisionService ["Decision & Explanation Engine"]
            TieredRules["Tiered Evidence Evaluation Matrix"]
            Verdicts["Standard Verdict Generator"]
            Explainer["Forensic Finding & Bilingual Guidance Formatter"]
        end
    end

    subgraph PersistenceLayer ["4. Persistence Layer (Supabase PostgreSQL)"]
        ScansTable[("public.scans (Master Audit Log)")]
        FindingsTable[("public.scan_findings (Normalized Evidence)")]
        CacheTable[("public.threat_intel_cache (TTL-Indexed)")]
    end

    Console --> Router
    TelemetryDash --> Router
    Router --> SSRF --> RateLimiter --> Validator --> Orchestrator
    
    Orchestrator --> IntelService
    Orchestrator --> MLService
    
    IntelService <--> CacheManager <--> CacheTable
    IntelService --> GSB & URLhaus & PhishTank
    
    IntelService --> DecisionService
    MLService --> DecisionService
    
    DecisionService --> ScansTable & FindingsTable
    DecisionService --> Router --> ForensicCard
```

---

## 3. Tiered Evidence-Based Scoring Strategy

### 3.1 Abandoning Fixed Linear Weighting
Traditional heuristics assign arbitrary percentages (e.g., $40\%$ Threat Intel + $35\%$ ML + $25\%$ Heuristics). This creates severe security flaws:
- A verified, active phishing URL identified by Google Safe Browsing could receive a diluted score of 50/100 if the ML model is uncertain.
- Conversely, complex legitimate banking links with many parameters could be falsely classified as malicious due to heuristic point accumulation.

### 3.2 The Tiered Decision Matrix
ScamShield AI employs a testable, rule-based hierarchy:

```
[Target: URL or Message]
        │
        ▼
[TIER 1: Deterministic Threat Feeds]
Is the target blacklisted by GSB, URLhaus, or PhishTank?
├── YES ──► VERDICT: MALICIOUS (Risk: 95-100)
│           Confidence: HIGH
│           Evidence: Direct Feed Match (IoC confirmed)
└── NO / TIMEOUT ──► Proceed to Tier 2
        │
        ▼
[TIER 2: High-Severity Architectural Heuristics]
Does the target exhibit direct evasion/coercion mechanisms?
(e.g., Raw IP hostname, Punycode homoglyph spoofing, Zero-width character obfuscation)
├── YES ──► VERDICT: SUSPICIOUS (Risk: 70-89)
│           Confidence: HIGH
│           Evidence: Explicit Evasion Mechanism Flagged
└── NO ──► Proceed to Tier 3
        │
        ▼
[TIER 3: Machine Learning & Corroborating Signals]
Evaluate Calibrated Probabilities P(Threat):
├── If P(Threat) >= 0.85 AND >= 1 Corroborating Flag:
│     └──► VERDICT: MALICIOUS (Risk: 85-94)
├── If 0.45 <= P(Threat) < 0.85 OR Heuristic Warnings Present:
│     └──► VERDICT: SUSPICIOUS (Risk: 40-69)
├── If P(Threat) < 0.45 AND Primary Feeds Responded:
│     └──► VERDICT: NO_KNOWN_THREAT (Risk: 0-24)
└── If All External Threat Feeds Timed Out / Failed:
      └──► VERDICT: UNVERIFIED (Risk: 30-50)
```

### 3.3 The Four Standard Cybersecurity Verdicts

| Verdict | Definition | Forensic Meaning | Actionable User Guidance |
| :--- | :--- | :--- | :--- |
| **`MALICIOUS`** | Confirmed threat detected via threat intelligence feed OR high-probability ML with corroborating malicious indicators. | Critical threat. High probability of credential harvesting, financial theft, or malware. | **CRITICAL WARNING:** Do not click, open, or interact with this sender. Under no circumstances provide credentials or payment PINs. |
| **`SUSPICIOUS`** | Target demonstrates deceptive structural patterns, urgency coercion, or abnormal lexical features, but lacks active global blocklist cataloging. | Potential zero-day campaign, brand-impersonation, or uncatalogued regional scam. | **CAUTION ADVISED:** This target exhibits deception patterns typical of active scams. Avoid entering private details. |
| **`NO_KNOWN_THREAT`** | Target was checked across operational threat feeds and evaluated by ML without triggering threat signatures. | No known signatures found. **Not a guarantee of zero-day safety.** | **NO KNOWN THREAT:** Target passed standard checks. Exercise routine vigilance when dealing with unfamiliar senders. |
| **`UNVERIFIED`** | Primary external intelligence feeds failed to respond (network timeout, upstream error), preventing conclusive assessment. | Incomplete inspection due to provider degradation. | **INCOMPLETE SCAN:** Upstream threat feeds could not be reached. Treat with standard security precautions. |

---

## 4. Machine Learning & Dataset Governance

### 4.1 Strict Segregation of Training Data
To maintain rigorous scientific standards, training and validation datasets are strictly segregated into **Real** and **Synthetic** partitions:

1. **Real Dataset Sources:**
   - **URLs:** ISCX-URL2016 dataset, validated PhishTank archive feeds, and the Tranco Top 10,000 whitelist for benign web hosts.
   - **Messages:** UCI Machine Learning SMS Spam Collection, combined with documented real-world Indian financial fraud reports (CERT-In advisories, public scam alerts).
2. **Synthetic Dataset Sources:**
   - **Telugu Script Scam Corpus:** Realistic templates mirroring Indian regional scam motifs (APEPDCL/TSSPDCL electricity power cut warnings, YONO SBI KYC suspensions, PM Yojana loan approvals) authored in native Telugu script (`\u0C00`–`\u0C7F`).
   - **Transliterated "Telugish" Corpus:** Latin-character representations of conversational Telugu phrases commonly used in fraudulent SMS/WhatsApp outreach (e.g., *"Mee electricity bill update cheyandi lekapothe 9 PM ki power cut avtundi"*).
   - **Benign Regional Corpus:** Common conversational Telugu and Telugish messages to ensure the model does not treat the Telugu language itself as a risk factor.

> **Dataset Governance Invariant:** Synthetic datasets are utilized strictly to address the acute real-world shortage of labeled Indian regional language scam telemetry. Under no circumstances may synthetic datasets be presented or claimed as empirical real-world validation data. Evaluation reporting in `ml/models/metadata.json` must evaluate and publish metrics for the real test set and the synthetic test set separately.

### 4.2 Feature Engineering Specifications
- **URL Feature Extractor (32 Features):**
  - Hostname length, path length, query string length, total URL length.
  - Character frequencies: counts of `.`, `-`, `_`, `/`, `?`, `=`, `@`, `&`, `%`.
  - Number of subdomains and depth of domain hierarchy.
  - Shannon entropy of domain string ($H(X) = -\sum P(x) \log_2 P(x)$) to detect algorithmically generated domains (DGA).
  - Suspicious token flags: presence of sensitive strings (`login`, `verify`, `account`, `banking`, `kyc`, `upi`, `support`).
  - Structural flags: raw IP address used as hostname, punycode prefix (`xn--`), non-standard port numbers.
- **Multilingual Message Tokenizer:**
  - Script identification via Unicode code-point inspection.
  - Sub-word character n-gram analysis (`analyzer='char_wb'`, `ngram_range=(2, 5)`) combined with word tokens (`ngram_range=(1, 2)`).
  - Character n-grams are critical for transliterated Telugish, as they remain resilient against phonetic spelling variations (e.g., `cheyandi` vs `cheyyandi`).

### 4.3 Measurable Evaluation Benchmark Criteria
Model training must generate a versioned `metadata.json` documenting performance on an 80/20 stratified split:
- **Precision:** Target $\ge 94\%$ on the threat class to eliminate false accusations against legitimate services.
- **Recall:** Target $\ge 88\%$ to ensure active threats are intercepted.
- **F1-Score:** Target $\ge 90\%$.
- **Confusion Matrix:** Full $2 \times 2$ matrix ($TP, FP, TN, FN$) recorded with exact sample counts.

---

## 5. Domain Intelligence Strategy: Explicitly Optional

Public WHOIS and RDAP services present strict rate limits, CAPTCHA gating, and significant latency.
- In v1.0, fields such as **Domain Age (days)**, **Registrar**, **SSL Issuer**, and **SSL Validity** are modeled as strictly optional (`Optional[T] = None`).
- If an RDAP provider is unconfigured or rate-limited, the inspection pipeline populates `null` values without failing the scan.
- The UI conditionally renders these indicators only when available and displays a clean *"Telemetry not available"* status otherwise.

---

## 6. Fault-Tolerant Threat Intelligence Integration

Every external provider (Google Safe Browsing, URLhaus, PhishTank) is executed asynchronously under an isolated circuit-breaker pattern:
- **Strict Timeout Budget:** Each provider is capped at **2.5 seconds** via `asyncio.wait_for`.
- **Non-Blocking Aggregation:** Providers run concurrently using `asyncio.gather(..., return_exceptions=True)`.
- **Status Reporting:** Every provider returns an explicit status enum (`AVAILABLE_CLEAN`, `AVAILABLE_FLAGGED`, `TIMEOUT`, `ERROR`, `UNCONFIGURED`).
- **TTL Caching:** Results are cached in Supabase for **2 hours** keyed by `SHA-256(canonical_target) + '_' + provider_name`. Repeat requests for viral scam URLs are served instantly from cache in <15ms.

---

## 7. Frontend User Experience & Navigation

The user interface adheres to an enterprise Security Operations Center (SOC) aesthetic:
- **Four-View Primary Navigation:**
  1. **Overview:** System threat posture, operational engine health, and quick stats.
  2. **Scanner:** Primary forensic workbench for URL and multilingual message submissions.
  3. **Scan History:** Filterable, paginated audit records directly loaded from Supabase.
  4. **Analytics:** Real-time visual metrics (Chart.js) computed dynamically from scan history.
- **Zero-Mock Policy:**
  - When the database has 0 scans, History and Analytics display professional empty states.
  - No synthetic charts, fake notification badges, or mock scan logs are permitted in the codebase.
- **Explicit States:** Loading skeletons with real-time multi-stage pipeline status, partial-data warnings (when feeds timeout), and security rejection banners (when SSRF attempts occur).

---

## 8. Database Architecture (Supabase PostgreSQL)

```sql
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Master Scans Audit Table
CREATE TABLE IF NOT EXISTS public.scans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    target_type VARCHAR(20) NOT NULL CHECK (target_type IN ('URL', 'MESSAGE')),
    target_hash CHAR(64) NOT NULL,
    target_preview TEXT NOT NULL,
    canonical_target TEXT,
    verdict VARCHAR(20) NOT NULL CHECK (verdict IN ('MALICIOUS', 'SUSPICIOUS', 'NO_KNOWN_THREAT', 'UNVERIFIED')),
    risk_score INT NOT NULL CHECK (risk_score BETWEEN 0 AND 100),
    confidence_level VARCHAR(20) NOT NULL CHECK (confidence_level IN ('HIGH', 'MEDIUM', 'PROVISIONAL')),
    detected_language VARCHAR(30) DEFAULT 'NOT_APPLICABLE',
    execution_time_ms INT NOT NULL,
    raw_metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_scans_created_at ON public.scans(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_scans_target_hash ON public.scans(target_hash);
CREATE INDEX IF NOT EXISTS idx_scans_verdict ON public.scans(verdict);

-- Granular Findings Table (One-to-Many)
CREATE TABLE IF NOT EXISTS public.scan_findings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scan_id UUID NOT NULL REFERENCES public.scans(id) ON DELETE CASCADE,
    category VARCHAR(30) NOT NULL,
    rule_name VARCHAR(100) NOT NULL,
    severity VARCHAR(20) NOT NULL CHECK (severity IN ('INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    raw_evidence JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_findings_scan_id ON public.scan_findings(scan_id);

-- Threat Intelligence TTL Cache Table
CREATE TABLE IF NOT EXISTS public.threat_intel_cache (
    cache_key VARCHAR(128) PRIMARY KEY,
    provider_name VARCHAR(50) NOT NULL,
    is_flagged BOOLEAN NOT NULL,
    threat_details TEXT,
    cached_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_cache_expires_at ON public.threat_intel_cache(expires_at);

-- ==============================================================================
-- Supabase Row Level Security (RLS) Policies
-- ==============================================================================

-- 1. Enable RLS on all tables
ALTER TABLE public.scans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scan_findings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.threat_intel_cache ENABLE ROW LEVEL SECURITY;

-- 2. Backend Service Role (authenticated via SUPABASE_SERVICE_ROLE_KEY) has full read/write access
CREATE POLICY service_role_all_scans ON public.scans
    FOR ALL TO service_role USING (true) WITH CHECK (true);

CREATE POLICY service_role_all_findings ON public.scan_findings
    FOR ALL TO service_role USING (true) WITH CHECK (true);

CREATE POLICY service_role_all_cache ON public.threat_intel_cache
    FOR ALL TO service_role USING (true) WITH CHECK (true);

-- 3. Anonymous / Public Users: Read-only access to scans and findings
-- (Direct client-side INSERT, UPDATE, DELETE are strictly blocked to protect audit integrity)
CREATE POLICY anon_read_scans ON public.scans
    FOR SELECT TO anon USING (true);

CREATE POLICY anon_read_findings ON public.scan_findings
    FOR SELECT TO anon USING (true);

-- (threat_intel_cache has no public policy, keeping cache strictly internal to the backend)
```

---

## 9. Sensitive Message Data Privacy & Retention Policy

When investigating suspected scam messages, users frequently submit content containing Personally Identifiable Information (PII) such as bank account numbers, 6-digit OTPs, personal phone numbers, or Virtual Payment Addresses (VPAs).

### 9.1 Ingestion Masking & Anonymization
- **Client & Server Sanitization:** Before persisting into `public.scans.target_preview`, raw message text is scrubbed using regex sanitization filters:
  - 6-digit verification codes/OTPs (`\b\d{6}\b` $\rightarrow$ `[REDACTED_OTP]`)
  - 10-digit Indian phone numbers (`[6-9]\d{9}` $\rightarrow$ `[REDACTED_PHONE]`)
  - UPI / VPA identifiers (`[\w\.\-_]+@[\w\.\-_]+` $\rightarrow$ `[REDACTED_UPI]`)
- **Payload Truncation:** `target_preview` is strictly capped at 120 characters to store only an audit trail summary rather than the full message payload.

### 9.2 Non-Retention Invariant
- Full, unredacted raw message text is held **only in volatile memory** during the lifetime of the scan request ($<50\text{ms}$) to perform feature extraction and ML inference.
- Raw message bodies are **never** persisted to disk or written into relational database columns.

### 9.3 Data Expiration Lifecycle
- Historical scan records older than 30 days are subject to an automated retention purge that clears preview strings while preserving aggregated, anonymous forensic telemetry (risk score, verdict, detected language, execution latency).


